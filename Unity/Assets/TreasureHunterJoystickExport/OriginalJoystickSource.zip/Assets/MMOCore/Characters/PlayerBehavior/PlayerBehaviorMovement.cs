using MCP.DataModel.Utils;
using MCP.DataModels.BaseModels;
using MCP.Unity;
using Mirror;
using System.Collections;
using UnityEngine;

public partial class PlayerBehavior
{
    private Coroutine teleportCoroutine;

#if ENABLE_SERVER
    // Hotfix for released clients whose initial map tile pool is not ready when the
    // first position RPC arrives. Replaying the normal-position RPC once makes the
    // existing client call ResetMap after its camera/map initialization has settled.
    private const float InitialMapRefreshDelay = 0.75f;
    private Coroutine initialMapRefreshCoroutine;
    private bool hasSentInitialMapRefresh;
#endif

    //============================= TELEPORT TO===================================
    [Server]
    public bool TeleportToLand(string landId, string areaId, Vector2 pos = default, bool useWorldCoords = false,
                               TeleportData.TeleportMode mode = TeleportData.TeleportMode.Normal, float lockTimeAfterTele = 0f, bool keepAutoMode = false)
    {
#if ENABLE_SERVER
        if (landId.IsNullOrEmpty()) return false;
        if (!WorldManager.Instance.TryGetLandData(landId, out var land)) return false;

        if (areaId.IsNonEmpty())
        {
            RuntimeAreaController area = land.GetAreaController(areaId);
            if (area == null) return false; //Return false here instead correcting areaId to "" (means teleport to land only)

            if (!useWorldCoords)
            {
                pos += area.Position;
            }
        }
        else
        {
            if (!useWorldCoords)
            {
                pos += land.LandCenter;
            }
        }

        this.landId = landId;
        this.lockAreaId = areaId;

        TeleportToPosition_Internal(landId, areaId, pos, mode, lockTimeAfterTele, keepAutoMode);
#endif
        return true;
    }

    [Server]
    public bool TeleportToLand(string landId, Vector2 pos = default, bool useWorldCoords = false,
                    TeleportData.TeleportMode mode = TeleportData.TeleportMode.Normal, float lockTimeAfterTele = 0f, bool keepAutoMode = false)

    {
        return TeleportToLand(landId, "", pos, useWorldCoords, mode, lockTimeAfterTele, keepAutoMode);
    }

    [Server]
    public bool TeleportToArea(string areaId, Vector2 pos = default, bool useWorldCoords = false,
                    TeleportData.TeleportMode mode = TeleportData.TeleportMode.Normal, float lockTimeAfterTele = 0f, bool keepAutoMode = false)
    {
#if ENABLE_SERVER
        if (areaId.IsNullOrEmpty()) return false;
        if (!WorldManager.Instance.TryGetLandData(this.landId, out var land)) return false;

        var area = land.GetAreaController(areaId);
        if (area == null) return false;

        if (!useWorldCoords)
        {
            pos += area.Position;
        }

        this.lockAreaId = areaId;
        TeleportToPosition_Internal(landId, areaId, pos, mode, lockTimeAfterTele, keepAutoMode);
#endif
        return true;
    }

    //========================== TELEPORT IN =================================
    [Server]
    public bool TeleportInCurrent(Vector2 pos = default, bool useWorldCoords = false,
                   TeleportData.TeleportMode mode = TeleportData.TeleportMode.Normal, float lockTimeAfterTele = 0f, bool keepAutoMode = false)
    {
#if ENABLE_SERVER
        if (!WorldManager.Instance.TryGetLandData(this.landId, out var land)) return false;

        if (!useWorldCoords)
        {
            if (!string.IsNullOrEmpty(this.lockAreaId))
            {
                var area = land.GetAreaController(this.lockAreaId);
                if (area == null) return false; //lockAreaId corrupted
                pos += area.Position;
            }
            else
            {
                pos += land.LandCenter;
            }
        }


        TeleportToPosition_Internal(null, null, pos, mode, lockTimeAfterTele, keepAutoMode);
#endif
        return true;
    }


    [Server]
    public bool TeleportExitCurrentArea(Vector2? pos = null, bool useWorldCoords = false,
                   TeleportData.TeleportMode mode = TeleportData.TeleportMode.Normal, float lockTimeAfterTele = 0f, bool keepAutoMode = false)
    {
#if ENABLE_SERVER
        if (!WorldManager.Instance.TryGetLandData(this.landId, out var land)) return false;

        this.lockAreaId = "";

        if (pos.HasValue)
        {
            pos = useWorldCoords ? pos : pos.Value + land.LandCenter;
        }
        else
        {
            pos = transform.position;
        }

        TeleportToPosition_Internal(landId, lockAreaId, pos.Value, mode, lockTimeAfterTele, keepAutoMode);
#endif
        return true;
    }
    //------- TELEPORT INTERNAL

    /// <summary>
    /// Teleports player to a specified position within a land or area, clamping the position to valid bounds.
    /// </summary>
    /// <remarks>
    /// This method is intended to be called on the server and will synchronize the player's position. 
    /// Note: this method does not modify the player's <see cref="CharacterBehavior.landId"/>,  <see cref="CharacterBehavior.lockAreaId"/>, 
    /// <b></b>They should be set before calling this method.
    /// </remarks>
    /// <param name="landId">
    /// The identifier of the land to teleport to. If <see langword="null"/>, the current land is used. 
    /// But if <see cref="string.Empty"/> is use, nothing will happen.
    /// </param>
    /// <param name="areaId">
    /// The identifier of the area within the land to teleport to. If <see langword="null"/>, the current area is used. 
    /// If <see cref="string.Empty"/> is use, clear the area.
    /// </param>
    /// <param name="worldPos">
    /// The target position in world coordinates. The position will be clamped to valid bounds within the specified land or area.
    /// </param>

    [Server]
    private void TeleportToPosition_Internal(string landId, string areaId, Vector2 worldPos,
                  TeleportData.TeleportMode mode = TeleportData.TeleportMode.Normal, float lockTimeAfterTele = 0f, bool keepAutoMode = false)
    {
#if ENABLE_SERVER
        if (teleportCoroutine != null)
        {
            StopCoroutine(teleportCoroutine);
            teleportCoroutine = null;
        }

        if (!WorldManager.Instance.TryGetLandData(landId == null ? this.landId : landId, out var land)) return;
        var area = areaId == null ? lockAreaId.IsNullOrEmpty() ? null : land.GetAreaController(this.lockAreaId) :
                                    areaId.IsNullOrEmpty() ? null : land.GetAreaController(areaId);

        worldPos = area != null ? area.ClampInside(worldPos) : land.ClampLandPosition(worldPos);
        var allowed = FinalWarManager.ResolveVillagePosition(FinalWarManager.GetProtectedVillage(this, landId: land.landName),
            land, transform.position, worldPos);
        if (!allowed.HasValue) return;
        if (allowed.Value != worldPos && connectionToClient != null)
            BattleManager.instance.SendServerNotificationToTarget(connectionToClient, int.MaxValue, NotifyType.MiddleNotify,
                FinalWarManager.VillageBlockedMessage);
        worldPos = allowed.Value;
        if (area != null && !area.IsInside(worldPos, area.ClampInsideOffset))
        {
            this.lockAreaId = "";
            area = null;
        }

        // ========== 🆕 LOGGING: Teleport ==========
        Vector2 fromPos = this.transform.position;
        string targetLandId = landId ?? this.landId;
        string targetAreaId = areaId ?? (area != null ? area.Id : "");
        string modeStr = mode == TeleportData.TeleportMode.Arena ? "Arena" : "Normal";

        BattleManager.Log(this, LogAction.Teleport,
            $"From:({fromPos.x:F1},{fromPos.y:F1})|To:({worldPos.x:F1},{worldPos.y:F1})|Land:{targetLandId}|Area:{targetAreaId}|Mode:{modeStr}",
            "LockTime:" + lockTimeAfterTele);
        // ========== END Teleport Logging ==========

        SetLandType(land.GetLandType()); //TODO-REFACTOR: LandType will be delete (old, obsolete)

        // Tắt automation trong TẤT CẢ các trường hợp teleport (kể cả cùng land), TRỪ teleport sau khi chết
        // keepAutoMode = true: giữ nguyên automation (dùng cho teleport sau khi chết)
        // keepAutoMode = false: disable automation (dùng cho tất cả các trường hợp khác)
        if (IsAutoMode() && !keepAutoMode)
        {
            ServerDisableAutomationAndSync("TeleportToLand:" + landId);
        }


        this.authorativePlayerMovement?.SetLockMovement(true);
        this.authorativePlayerMovement?.SetPosition(worldPos, 0);

#if ENABLE_SERVER_TEST
        if (isFinalWarTestBot)
        {
            this.lastPosition = transform.position;
            UpdateLandData();
            this.authorativePlayerMovement?.SetLockMovement(false);
            return; // No client exists to acknowledge a test bot's teleport.
        }
#endif

        if (this.playerAuto != null)
        {
            this.playerAuto.BeginTeleportGrace(lockTimeAfterTele, worldPos);
        }

        this.lastPosition = this.transform.position;

        var teleportData = new TeleportData()
        {
            teleportMode = mode,
            worldPos = worldPos,

            landId = this.landId,
            areaId = this.lockAreaId,

            lockTimeAfterTeleport = lockTimeAfterTele
        };


        UpdateLandData();
        TargetSetPosition_Internal(teleportData);

        ScheduleInitialMapRefresh(teleportData);
#endif
    }

#if ENABLE_SERVER
    [Server]
    private void ScheduleInitialMapRefresh(TeleportData teleportData)
    {
        if (hasSentInitialMapRefresh || teleportData.teleportMode != TeleportData.TeleportMode.Normal)
        {
            return;
        }

        // If another normal teleport happens while the initial refresh is pending,
        // refresh the latest position instead of replaying stale coordinates.
        if (initialMapRefreshCoroutine != null)
        {
            StopCoroutine(initialMapRefreshCoroutine);
        }

        initialMapRefreshCoroutine = StartCoroutine(InitialMapRefreshCoroutine());
    }

    [Server]
    private IEnumerator InitialMapRefreshCoroutine()
    {
        yield return new WaitForSecondsRealtime(InitialMapRefreshDelay);

        initialMapRefreshCoroutine = null;

        if (hasSentInitialMapRefresh || connectionToClient == null || !connectionToClient.isReady)
        {
            yield break;
        }

        hasSentInitialMapRefresh = true;

        // Use the authoritative position at send time. The player may already have
        // started moving, so replaying the original login position could snap them back.
        var refreshData = new TeleportData
        {
            teleportMode = TeleportData.TeleportMode.Normal,
            worldPos = transform.position,
            landId = landId,
            areaId = lockAreaId,
            lockTimeAfterTeleport = 0f
        };

        TargetSetPosition_Internal(refreshData);
    }
#endif

    [TargetRpc]
    private void TargetSetPosition_Internal(TeleportData teleportData)
    {
        this.authorativePlayerMovement?.SetLockMovement(true);
        this.authorativePlayerMovement?.SnapClientState(teleportData.worldPos);

        landId = teleportData.landId;
        lockAreaId = teleportData.areaId;


        var mode = teleportData.teleportMode;

        if (mode == TeleportData.TeleportMode.Normal)
        {
            MapManager.instance?.ResetMap();
        }

        if (characterBody != null)
        {
            if (characterBody is PlayerBody body && body.petBehavior != null)
            {
                body.petBehavior.SetPosition();
            }

        }

        // Cosmetic world state can be absent while a session is reloading.
        // Normal teleport acknowledgement must still reach the server.
        if (WorldManager.Instance != null) UpdateLandData();
        if (mode != TeleportData.TeleportMode.Normal && ClientManager.instance == null) return;

        CmdCompleteSetPosition_New(
            mode == TeleportData.TeleportMode.Normal ? 0 : ClientManager.instance.GetApiToken(),
            mode,
            teleportData.lockTimeAfterTeleport);
    }
    [Command]
    private void CmdCompleteSetPosition_New(int apiToken, TeleportData.TeleportMode mode, float lockTimeAfterTele)
    {
#if ENABLE_SERVER
        if (mode == TeleportData.TeleportMode.Normal)
        {
            //if (AccountInvalid(password)) return;

            //TODO-FIX: Currently we put regen HP here to fix a case that player can be killed after 
            //teleported. Idealy, we add teleporting state to player then the player can't be attacked when in that state
            if (revivedHP > 0 && GetHealth() <= 0)
            {
                RegenHP(revivedHP);
                revivedHP = 0;
            }


            if (lockTimeAfterTele <= 0)
            {
                CoroutineUtils.ForceRunWithoutYield(UnlockAfter(0));
            }
            else
            {
                teleportCoroutine = StartCoroutine(UnlockAfter(lockTimeAfterTele));
            }
        }
        else
        {
            if (!ServerValidateApiToken(apiToken, nameof(CmdCompleteSetPosition_New))) return;

            if (GetArenaId() != -1)
            {
                var arenaBehavior = EventManager.instance.GetArenaBehavior(GetArenaId());
                if (arenaBehavior != null)
                {
                    bool exitWatchMode = arenaBehavior.CompleteArenaTeleport(this);
                    TargetCompleteSetPosition_Internal(mode, exitWatchMode);
                }
            }
            else
            {
                TargetCompleteSetPosition_Internal(mode, false);
            }
        }

        IEnumerator UnlockAfter(float time)
        {
            yield return new WaitForSeconds(time);
            TargetCompleteSetPosition_Internal(mode, false);
            this.authorativePlayerMovement?.SetLockMovement(false);
        }
#endif
    }
    [TargetRpc]
    private void TargetCompleteSetPosition_Internal(TeleportData.TeleportMode mode, bool exitArenaWatchMode)
    {
        if (mode == TeleportData.TeleportMode.Normal)
        {
            this.authorativePlayerMovement?.SetLockMovement(false);
        }
        else
        {
            if (exitArenaWatchMode)
            {
                if (UIManager.instance == null)
                    return;

                UIManager.instance.FindView<HUDView>().IsInMatch = false;
                UIManager.instance.ExitWatchMode();
            }
        }
    }
    //======================= TELEPORT TO ARENA ==============================
    public void TeleToArena(Vector2 pos)
    {
#if ENABLE_SERVER
        BattleManager.instance.DismissSummonsForPlayer(this);
#endif

        var areaId = ArenaBehavior.FindAreaId(GetArenaId());

        // Arena teleport: disable automation (keepAutoMode = false, mặc định)
        TeleportToLand(WorldManager.CENTER_LAND_NAME, areaId, pos, useWorldCoords: true, mode: TeleportData.TeleportMode.Arena);
    }
}

public struct TeleportData
{
    public enum TeleportMode : byte { Normal, Arena } //We handle teleport in different way in client by using mode

    public TeleportMode teleportMode;

    public Vector2 worldPos;

    public string landId;
    public string areaId;
    public float lockTimeAfterTeleport;
}
