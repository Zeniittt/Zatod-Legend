using System.Collections.Generic;
using Mirror;
using UnityEngine;

public class AuthorativePlayerMovement : NetworkBehaviour
{
    [Header("Network Input")]
    [SerializeField, Range(10, 60)] private int clientInputSendRate = 30;

    [Header("Client Prediction Correction")]
    [SerializeField, Range(0.01f, 1f)] private float movingCorrectionMinAlpha = 0.08f;
    [SerializeField, Range(0.01f, 1f)] private float movingCorrectionMaxAlpha = 0.35f;
    [SerializeField, Range(0.1f, 1.5f)] private float movingCorrectionSoftDistance = 0.8f;
    [SerializeField] private float movingHardSnapDistance = 1.5f;
    [SerializeField] private float movingNoCorrectionDistance = 0.12f;
    [SerializeField] private float idleNoSnapDistance = 0.5f;
    [SerializeField] private float inputDeadzone = 0.0001f;
    [SerializeField] private float serverOwnerSnapshotRate = 20f;
    [SerializeField] private float stopGraceMinSeconds = 0.08f;
    [SerializeField] private float stopGraceMaxSeconds = 2f;
    [SerializeField] private float stopGraceResumeInputMagnitude = 0.1f;
    [SerializeField] private float autoMoveHandoffStopDistance = 0.01f;
    [SerializeField] private float autoMoveHandoffLerpMultiplier = 2f;
    [SerializeField] private bool lockMovement = false;

    private PlayerBehavior playerBehavior;

    private Vector2 latestServerInput = Vector2.zero;
    private int latestServerInputSequence = 0;
    private Vector2 latestServerPosition = Vector2.zero;
    private bool hasServerPosition = false;

    private Vector2 predictedRenderPosition = Vector2.zero;
    private bool hasRenderState = false;
    private readonly List<PredictedMoveFrame> predictedMoveFrames = new List<PredictedMoveFrame>(128);

    private bool wasMovingInputLastFrame = false;
    private bool manualAutoStopRequested = false;
    private bool manualAutoStopArmed = false;

    private float clientSendAccumulator = 0f;
    private float stopGraceRemaining = 0f;
    private Vector2 stopGraceHoldPosition = Vector2.zero;
    private bool hasStopGraceHoldPosition = false;
    private bool isStopGraceVisualCatchUp = false;
    private int clientInputSequence = 0;
    private int latestOwnerSnapshotSequence = 0;
    private int serverOwnerSnapshotSequence = 0;
    private float serverOwnerSnapshotAccumulator = 0f;
    private bool autoMoveHandoffActive = false;

    private const int MaxPredictedMoveFrames = 180;
    private const float ManualAutoStopInputDeadzoneSqr = 0.1f * 0.1f;

    private float ClientSendDelta => 1f / Mathf.Max(1, clientInputSendRate);

    private struct PredictedMoveFrame
    {
        public int InputSequence;
        public Vector2 Input;
        public float DeltaTime;

        public PredictedMoveFrame(int inputSequence, Vector2 input, float deltaTime)
        {
            InputSequence = inputSequence;
            Input = input;
            DeltaTime = deltaTime;
        }
    }

    [Server]
    public void SnapServerState(Vector2 position)
    {
        latestServerInput = Vector2.zero;
        latestServerInputSequence = 0;
        latestServerPosition = position;
        hasServerPosition = true;
        predictedRenderPosition = position;
        hasRenderState = true;
        wasMovingInputLastFrame = false;
        clientSendAccumulator = 0f;
        stopGraceRemaining = 0f;
        hasStopGraceHoldPosition = false;
        isStopGraceVisualCatchUp = false;
        autoMoveHandoffActive = false;
        serverOwnerSnapshotAccumulator = 0f;
        serverOwnerSnapshotSequence = 0;
        predictedMoveFrames.Clear();
    }

    [Client]
    public void SnapClientState(Vector2 position)
    {
        latestServerInput = Vector2.zero;
        latestServerInputSequence = 0;
        latestServerPosition = position;
        hasServerPosition = true;
        predictedRenderPosition = position;
        hasRenderState = true;
        wasMovingInputLastFrame = false;
        clientSendAccumulator = 0f;
        stopGraceRemaining = 0f;
        hasStopGraceHoldPosition = false;
        isStopGraceVisualCatchUp = false;
        autoMoveHandoffActive = false;
        latestOwnerSnapshotSequence = 0;
        predictedMoveFrames.Clear();
        SetRenderPosition(position);
    }

    [Server]
    public void PrepareServerAutoMoveHandoff(Vector2 position)
    {
        latestServerInput = Vector2.zero;
        latestServerPosition = position;
        hasServerPosition = true;
        serverOwnerSnapshotAccumulator = 0f;
    }

    [Client]
    public void PrepareClientAutoMoveHandoff(Vector2 serverPosition)
    {
        Vector2 visualPosition = playerBehavior != null && playerBehavior.characterBody != null
            ? (Vector2)playerBehavior.characterBody.transform.position
            : serverPosition;

        latestServerInput = Vector2.zero;
        latestServerPosition = serverPosition;
        hasServerPosition = true;
        predictedRenderPosition = visualPosition;
        hasRenderState = true;
        wasMovingInputLastFrame = false;
        clientSendAccumulator = 0f;
        stopGraceRemaining = 0f;
        hasStopGraceHoldPosition = false;
        isStopGraceVisualCatchUp = false;
        predictedMoveFrames.Clear();
        autoMoveHandoffActive = true;
    }

    private void Awake()
    {
        playerBehavior = GetComponent<PlayerBehavior>();
    }

#if ENABLE_CLIENT
    private void Update()
    {
#if !ENABLE_ADMIN
        if (!isClient || !isLocalPlayer)
            return;

        if (playerBehavior == null)
            return;

        if (playerBehavior.isWatchingAd)
            return;

        ClientOwnerUpdate(Time.deltaTime);

#endif
    }
#endif 

    public void ServerTick(float dt)
    {
#if !ENABLE_ADMIN && ENABLE_SERVER
        if (playerBehavior == null)
            return;

        ServerTickUpdate(dt);
#endif
    }

    private void ClientOwnerUpdate(float dt)
    {
        if (playerBehavior.IsAutoMode())
        {
            TryRequestManualAutoStop();
            StopClientInputIfNeeded();
            return;
        }

        manualAutoStopRequested = false;
        manualAutoStopArmed = false;

        if (!playerBehavior.isActive || playerBehavior.GetHealth() <= 0)
        {
            StopClientInputIfNeeded();
            return;
        }

        if (IsLock())
        {
            StopClientInputIfNeeded();
            return;
        }

        Vector2 rawInput = ReadJoystickInput();
        Vector2 normalizedInput = ClampInputMagnitude(rawInput);
        bool isMovingInput = normalizedInput.sqrMagnitude > inputDeadzone;
        if (isMovingInput)
        {
            autoMoveHandoffActive = false;
        }
        bool wasMovingInput = wasMovingInputLastFrame;
        TickStopGrace(dt);
        float stopGraceResumeInputSqr = stopGraceResumeInputMagnitude * stopGraceResumeInputMagnitude;
        if (IsInStopGrace() && normalizedInput.sqrMagnitude > stopGraceResumeInputSqr)
        {
            EndStopGrace(false);
        }
        else if (IsInStopGrace() && normalizedInput.sqrMagnitude <= stopGraceResumeInputSqr)
        {
            normalizedInput = Vector2.zero;
            isMovingInput = false;
        }

        if (!hasRenderState)
        {
            predictedRenderPosition = playerBehavior.transform.position;
            hasRenderState = true;
        }

        if (isMovingInput && !wasMovingInput)
        {
            SendMoveInput(normalizedInput, false);
            clientSendAccumulator = 0f;
        }
        else if (!isMovingInput && wasMovingInput)
        {
            // On input release, send zero immediately so server stops without waiting for next send tick.
            SendMoveInput(Vector2.zero, true);
            clientSendAccumulator = 0f;
            BeginStopGrace();
        }

        clientSendAccumulator += dt;
        while (clientSendAccumulator >= ClientSendDelta)
        {
            clientSendAccumulator -= ClientSendDelta;
            SendMoveInput(normalizedInput, false);
        }

        UpdatePredictedRender(normalizedInput, dt);
        wasMovingInputLastFrame = isMovingInput;
    }

    [Command(channel = Channels.Unreliable)]
    private void CmdSetMoveInput(Vector2 inputDirection, int inputSequence)
    {
#if ENABLE_SERVER
        if (playerBehavior == null)
            return;

        if (inputSequence < latestServerInputSequence)
            return;

        latestServerInput = ClampInputMagnitude(inputDirection);
        latestServerInputSequence = inputSequence;
#endif
    }

    [Command]
    private void CmdSetMoveInputReliable(Vector2 inputDirection, int inputSequence)
    {
#if ENABLE_SERVER
        if (playerBehavior == null)
            return;

        if (inputSequence < latestServerInputSequence)
            return;

        latestServerInput = ClampInputMagnitude(inputDirection);
        latestServerInputSequence = inputSequence;
#endif
    }

    private void ServerTickUpdate(float dt)
    {
#if ENABLE_SERVER
        if (!ShouldServerSimulate())
            return;

        Vector2 oldPos = playerBehavior.transform.position;
        bool isMoving = latestServerInput.sqrMagnitude > inputDeadzone * inputDeadzone;
        float speed = playerBehavior.ServerUpdateArenaEnergyAndGetSpeed(dt, isMoving);
        speed = Mathf.Max(0f, speed);
        Vector2 targetPos = oldPos + latestServerInput * speed * dt;
        targetPos = playerBehavior.ValidateMovement(oldPos, targetPos);

        playerBehavior.transform.position = targetPos;


        SendOwnerServerSnapshot(dt, false);
#endif
    }

    private void UpdatePredictedRender(Vector2 normalizedInput, float dt)
    {
        if (!hasRenderState)
            return;

        bool isMoving = normalizedInput.sqrMagnitude > inputDeadzone;

        if (autoMoveHandoffActive && hasServerPosition)
        {
            float lerpAlpha = Mathf.Clamp01(Mathf.Max(0f, playerBehavior.speed) * dt * autoMoveHandoffLerpMultiplier);
            predictedRenderPosition = Vector2.Lerp(predictedRenderPosition, latestServerPosition, lerpAlpha);

            float stopDistance = Mathf.Max(0.001f, autoMoveHandoffStopDistance);
            if (Vector2.SqrMagnitude(predictedRenderPosition - latestServerPosition) <= stopDistance * stopDistance)
            {
                predictedRenderPosition = latestServerPosition;
                autoMoveHandoffActive = false;
            }

            SetRenderPosition(predictedRenderPosition);
            return;
        }

        RecordPredictedMoveFrame(normalizedInput, dt);

        if (isMoving)
        {
            float speed = Mathf.Max(0f, playerBehavior.speed);
            Vector2 oldPos = predictedRenderPosition;
            Vector2 predictedPos = oldPos + normalizedInput * speed * dt;
            predictedPos = playerBehavior.ValidateMovement(oldPos, predictedPos);

            predictedRenderPosition = predictedPos;
            SetRenderPosition(predictedRenderPosition);
            return;
        }

        if (hasServerPosition)
        {
            float serverDelta = Vector2.Distance(predictedRenderPosition, latestServerPosition);
            if (IsInStopGrace())
            {
                SetRenderPosition(predictedRenderPosition);
                return;
            }

            if (ShouldUsePreciseStopCorrection())
            {
                predictedRenderPosition = latestServerPosition;
            }
            else if (serverDelta < idleNoSnapDistance)
            {
                SetRenderPosition(predictedRenderPosition);
                return;
            }
            else if (serverDelta >= movingHardSnapDistance)
            {
                predictedRenderPosition = latestServerPosition;
            }

            SetRenderPosition(predictedRenderPosition);
            return;
        }

        SetRenderPosition(predictedRenderPosition);
    }

    private void SendMoveInput(Vector2 inputDirection, bool alsoSendReliable)
    {
        clientInputSequence++;
        CmdSetMoveInput(inputDirection, clientInputSequence);

        if (alsoSendReliable)
        {
            CmdSetMoveInputReliable(inputDirection, clientInputSequence);
        }
    }

    private void StopClientInputIfNeeded()
    {
        if (!wasMovingInputLastFrame)
            return;

        SendMoveInput(Vector2.zero, true);
        wasMovingInputLastFrame = false;
        clientSendAccumulator = 0f;
        BeginStopGrace();
    }

    [TargetRpc(channel = Channels.Unreliable)]
    private void TargetReceiveOwnerServerSnapshot(NetworkConnectionToClient target, Vector2 position, Vector2 inputDirection, int snapshotSequence, int ackInputSequence)
    {
        if (!isLocalPlayer)
            return;

        if (snapshotSequence < latestOwnerSnapshotSequence)
            return;

        latestOwnerSnapshotSequence = snapshotSequence;
        latestServerPosition = position;
        latestServerInput = inputDirection;
        hasServerPosition = true;
        ReconcileWithServerSnapshot(position, ackInputSequence);
    }

#if ENABLE_SERVER
    private void SendOwnerServerSnapshot(float dt, bool force)
    {
        if (connectionToClient == null)
            return;

        float interval = 1f / Mathf.Max(1f, serverOwnerSnapshotRate);
        serverOwnerSnapshotAccumulator += dt;
        if (!force && serverOwnerSnapshotAccumulator < interval)
            return;

        serverOwnerSnapshotAccumulator = 0f;
        serverOwnerSnapshotSequence++;
        TargetReceiveOwnerServerSnapshot(connectionToClient, playerBehavior.transform.position, latestServerInput, serverOwnerSnapshotSequence, latestServerInputSequence);
    }
#endif

    private void SetRenderPosition(Vector2 position)
    {
        if (IsInStopGrace() && hasStopGraceHoldPosition)
        {
            position = stopGraceHoldPosition;
        }

        if (playerBehavior.characterBody != null)
        {
            if (isStopGraceVisualCatchUp)
            {
                Vector2 bodyPosition = playerBehavior.characterBody.transform.position;
                Vector2 targetPosition = position;
                float visualDelta = Vector2.Distance(bodyPosition, position);
                bool shouldSnapVisual = ShouldSnapStopGraceVisual(bodyPosition);

                if (!shouldSnapVisual && visualDelta > 0.001f)
                {
                    position = Vector2.Lerp(bodyPosition, position, movingCorrectionMaxAlpha);
                    if (Vector2.Distance(position, targetPosition) <= 0.001f)
                    {
                        position = targetPosition;
                        isStopGraceVisualCatchUp = false;
                    }
                }
                else
                {
                    isStopGraceVisualCatchUp = false;
                }
            }

            playerBehavior.characterBody.transform.position = position;
        }
    }

    private bool ShouldSnapStopGraceVisual(Vector2 bodyPosition)
    {
        if (ShouldUsePreciseStopCorrection())
            return true;

        if (!hasServerPosition)
            return false;

        return Vector2.Distance(bodyPosition, latestServerPosition) > idleNoSnapDistance;
    }

    private float CalculateAdaptiveMovingAlpha(float errorDistance)
    {
        float normalizedError = Mathf.Clamp01(errorDistance / Mathf.Max(0.001f, movingCorrectionSoftDistance));
        float minAlpha = Mathf.Min(movingCorrectionMinAlpha, movingCorrectionMaxAlpha);
        float maxAlpha = Mathf.Max(movingCorrectionMinAlpha, movingCorrectionMaxAlpha);
        return Mathf.Lerp(minAlpha, maxAlpha, normalizedError);
    }

    private void RecordPredictedMoveFrame(Vector2 inputDirection, float dt)
    {
        if (clientInputSequence <= 0)
            return;

        predictedMoveFrames.Add(new PredictedMoveFrame(clientInputSequence, inputDirection, dt));
        if (predictedMoveFrames.Count > MaxPredictedMoveFrames)
        {
            predictedMoveFrames.RemoveAt(0);
        }
    }

    private void ReconcileWithServerSnapshot(Vector2 serverPosition, int ackInputSequence)
    {
        if (!hasRenderState)
            return;

        RemoveAckedPredictionFrames(ackInputSequence);

        if (autoMoveHandoffActive)
        {
            return;
        }

        Vector2 replayedPosition = ReplayUnackedPredictionFrames(serverPosition);
        float errorDistance = Vector2.Distance(predictedRenderPosition, replayedPosition);
        if (IsInStopGrace())
        {
            predictedRenderPosition = replayedPosition;
            return;
        }

        bool hasMovingReplay = wasMovingInputLastFrame && predictedMoveFrames.Count > 0;

        if (hasMovingReplay)
        {
            if (errorDistance >= movingHardSnapDistance)
            {
                predictedRenderPosition = replayedPosition;
            }
            else if (errorDistance >= movingNoCorrectionDistance)
            {
                float adaptiveAlpha = CalculateAdaptiveMovingAlpha(errorDistance);
                predictedRenderPosition = Vector2.Lerp(predictedRenderPosition, replayedPosition, adaptiveAlpha);
            }

            SetRenderPosition(predictedRenderPosition);
            return;
        }

        if (ShouldUsePreciseStopCorrection() || errorDistance >= movingHardSnapDistance)
        {
            predictedRenderPosition = replayedPosition;
            SetRenderPosition(predictedRenderPosition);
        }
    }

    private void RemoveAckedPredictionFrames(int ackInputSequence)
    {
        for (int i = predictedMoveFrames.Count - 1; i >= 0; i--)
        {
            if (predictedMoveFrames[i].InputSequence <= ackInputSequence)
            {
                predictedMoveFrames.RemoveAt(i);
            }
        }
    }

    private Vector2 ReplayUnackedPredictionFrames(Vector2 serverPosition)
    {
        Vector2 replayedPosition = serverPosition;
        float speed = Mathf.Max(0f, playerBehavior.speed);

        for (int i = 0; i < predictedMoveFrames.Count; i++)
        {
            PredictedMoveFrame frame = predictedMoveFrames[i];
            Vector2 nextPosition = replayedPosition + frame.Input * speed * frame.DeltaTime;
            replayedPosition = playerBehavior.ValidateMovement(replayedPosition, nextPosition);
        }

        return replayedPosition;
    }

    private bool ShouldUsePreciseStopCorrection()
    {
        if (playerBehavior == null)
            return false;

        if (playerBehavior.GetCharacterState() == CharacterState.OpenChest)
            return true;

        if (IsSameBreakableBlockInteraction(latestServerPosition, predictedRenderPosition))
            return false;

        if (HasInteractionAtPosition(latestServerPosition))
            return true;

        return !IsInStopGrace() && HasInteractionAtPosition(predictedRenderPosition);
    }

    private bool IsSameBreakableBlockInteraction(Vector2 serverPosition, Vector2 renderPosition)
    {
        if (!hasServerPosition || MapManager.instance == null)
            return false;

        int serverX = Mathf.RoundToInt(serverPosition.x);
        int serverY = Mathf.RoundToInt(serverPosition.y);
        int renderX = Mathf.RoundToInt(renderPosition.x);
        int renderY = Mathf.RoundToInt(renderPosition.y);

        return serverX == renderX
            && serverY == renderY
            && MapManager.instance.HaveMap(serverX, serverY);
    }

    private void BeginStopGrace()
    {
        stopGraceRemaining = CalculateStopGraceSeconds();
        stopGraceHoldPosition = predictedRenderPosition;
        hasStopGraceHoldPosition = true;
    }

    private void EndStopGrace(bool preserveVisualIfSoft)
    {
        bool hadVisualHold = hasStopGraceHoldPosition;
        Vector2 visualPosition = GetCurrentVisualPosition();
        stopGraceRemaining = 0f;
        hasStopGraceHoldPosition = false;

        if (hadVisualHold && preserveVisualIfSoft && !ShouldSnapStopGraceVisual(visualPosition))
        {
            predictedRenderPosition = visualPosition;
            isStopGraceVisualCatchUp = false;
            return;
        }

        isStopGraceVisualCatchUp = hadVisualHold;
    }

    private Vector2 GetCurrentVisualPosition()
    {
        if (playerBehavior != null && playerBehavior.characterBody != null)
            return playerBehavior.characterBody.transform.position;

        return stopGraceHoldPosition;
    }

    private void TickStopGrace(float dt)
    {
        if (stopGraceRemaining <= 0f)
            return;

        stopGraceRemaining = Mathf.Max(0f, stopGraceRemaining - dt);
        if (stopGraceRemaining <= 0f)
        {
            EndStopGrace(true);
        }
    }

    private bool IsInStopGrace()
    {
        return stopGraceRemaining > 0f;
    }

    private float CalculateStopGraceSeconds()
    {
        float oneWayLatency = (float)NetworkTime.rtt + 0.1f;
        if (oneWayLatency <= 0f)
            oneWayLatency = stopGraceMinSeconds;

        return Mathf.Clamp(oneWayLatency, stopGraceMinSeconds, stopGraceMaxSeconds);
    }

    private bool HasInteractionAtPosition(Vector2 position)
    {
        if (!hasServerPosition)
            return false;

        return IsPositionOnBreakableBlock(position) || HasAttackTargetAtPosition(position);
    }

    private bool IsPositionOnBreakableBlock(Vector2 position)
    {
        if (MapManager.instance == null)
            return false;

        int x = Mathf.RoundToInt(position.x);
        int y = Mathf.RoundToInt(position.y);
        return MapManager.instance.HaveMap(x, y);
    }

    private bool HasAttackTargetAtPosition(Vector2 position)
    {
        if (IsAttackableTargetInRange(playerBehavior.enermy, position))
            return true;

        for (int i = 0; i < playerBehavior.enermies.Count; i++)
        {
            if (IsAttackableTargetInRange(playerBehavior.enermies[i], position))
                return true;
        }

        return false;
    }

    private bool IsAttackableTargetInRange(CharacterBehavior target, Vector2 serverPosition)
    {
        if (target == null || target.characterBody == null)
            return false;

        if (!playerBehavior.CanAttack(target))
            return false;

        return Vector2.Distance(serverPosition, target.characterBody.transform.position) < 1.5f;
    }

    private bool ShouldServerSimulate()
    {
        if (playerBehavior == null)
            return false;

        if (playerBehavior.IsAutoMode())
            return false;

        if (!playerBehavior.isActive)
            return false;

        if (playerBehavior.isWatchingAd)
            return false;

        if (playerBehavior.GetHealth() <= 0)
            return false;

        if (IsLock())
            return false;

        return true;
    }

    private Vector2 ReadJoystickInput()
    {
        if (UIManager.instance == null)
            return Vector2.zero;

        return new Vector2(
            UIManager.instance.GetJoysticHorizontal(),
            UIManager.instance.GetJoysticVertical());
    }

    private void TryRequestManualAutoStop()
    {
        if (ClientManager.instance == null)
            return;

        Vector2 joystickInput = ReadJoystickInput();
        if (joystickInput.sqrMagnitude <= ManualAutoStopInputDeadzoneSqr)
        {
            // Require a fresh joystick movement for every auto session/stop request.
            manualAutoStopArmed = true;
            manualAutoStopRequested = false;
            return;
        }

        if (!manualAutoStopArmed || manualAutoStopRequested)
            return;

        manualAutoStopRequested = true;
        ClientManager.instance.StopGoTo(ClientManager.instance.GetClientToken());
    }

    public void OnAutoModeSessionStarted()
    {
        manualAutoStopRequested = false;
        manualAutoStopArmed = false;
    }

    public void OnAutoModeSessionStopped()
    {
        manualAutoStopRequested = false;
        manualAutoStopArmed = false;
    }

    private static Vector2 ClampInputMagnitude(Vector2 input)
    {
        if (input.sqrMagnitude > 1f)
            input.Normalize();
        return input;
    }

    public bool IsLock()
    {
        return lockMovement;
    }

    public void SetLockMovement(bool isLock)
    {
        lockMovement = isLock;
    }

    public bool IsMoving()
    {
        return wasMovingInputLastFrame || latestServerInput.sqrMagnitude > inputDeadzone;
    }

    public void StopDirection(string clientToken)
    {
        if (ClientManager.instance == null || !ClientManager.instance.IsCorrectClientToken(clientToken))
            return;

        StopInput();
    }

    public void SetExternalInput(Vector2 input)
    {
        if (IsLock())
            return;

        SendMoveInput(ClampInputMagnitude(input), false);
    }

    public void StopInput()
    {
        if (isClient && isLocalPlayer)
        {
            SendMoveInput(Vector2.zero, true);
            wasMovingInputLastFrame = false;
            clientSendAccumulator = 0f;
            BeginStopGrace();
        }

#if ENABLE_SERVER
        if (isServer)
            latestServerInput = Vector2.zero;
#endif
    }

    [Server]
    public void SetPosition(Vector3 position, int seedNumber)
    {
        if (playerBehavior == null)
            return;

        playerBehavior.transform.position = position;
        SnapServerState(position);
    }

    public void ResetCheck()
    {
        latestServerPosition = playerBehavior != null ? (Vector2)playerBehavior.transform.position : Vector2.zero;
        hasServerPosition = true;
        predictedRenderPosition = latestServerPosition;
        hasRenderState = true;
    }
}
