using UnityEngine;

/// <summary>
/// Combines the view's requested interaction with session readiness without changing visibility.
/// Raycasts recheck the player at event time; the group also blocks Selectable submit/navigation.
/// </summary>
[DisallowMultipleComponent]
public sealed class ViewSessionInputGate : MonoBehaviour, ICanvasRaycastFilter
{
    [SerializeField, HideInInspector] private BaseView owner;
    [SerializeField, HideInInspector] private CanvasGroup sessionGroup;
    [SerializeField, HideInInspector] private bool requestedInteractable;
    [SerializeField, HideInInspector] private bool blocked;

    public static void Install(BaseView view)
    {
        Attach(view.gameObject, view);
        // These boundaries can bypass a parent filter/group in Unity UI.
        foreach (var canvas in view.GetComponentsInChildren<Canvas>(true))
            if (canvas.GetComponentInParent<BaseView>(true) == view)
                Attach(canvas.gameObject, view);
        foreach (var group in view.GetComponentsInChildren<CanvasGroup>(true))
            if (group.ignoreParentGroups && group.GetComponentInParent<BaseView>(true) == view)
                Attach(group.gameObject, view);
    }

    private static void Attach(GameObject target, BaseView view)
    {
        var gate = target.GetComponent<ViewSessionInputGate>();
        if (gate == null)
            gate = target.AddComponent<ViewSessionInputGate>();
        gate.owner = view;
        if (gate.sessionGroup == null)
        {
            gate.sessionGroup = target.GetComponent<CanvasGroup>();
            if (gate.sessionGroup == null)
                gate.sessionGroup = target.AddComponent<CanvasGroup>();
            gate.requestedInteractable = gate.sessionGroup.interactable;
        }
        gate.Refresh();
    }

    private void OnEnable()
    {
        // Runtime UI clones retain the requested state, while Unity remaps the
        // owner/group references when cloning a whole view.
        if (owner == null)
            owner = GetComponentInParent<BaseView>(true);
        Refresh();
    }
    private void Update() => Refresh();

    private void Refresh()
    {
        if (sessionGroup == null)
            return;
        if (!blocked)
            requestedInteractable = sessionGroup.interactable;
        blocked = owner == null || !owner.CanReceiveSessionInput;
        bool interactable = requestedInteractable && !blocked;
        if (sessionGroup.interactable != interactable)
            sessionGroup.interactable = interactable;
    }

    // EnableCanvas/DisableCanvas and control renderers use this so a presentation
    // change while logged out is retained without temporarily unlocking input.
    public void SetRequestedInteractable(bool value)
    {
        requestedInteractable = value;
        blocked = owner == null || !owner.CanReceiveSessionInput;
        sessionGroup.interactable = value && !blocked;
    }

    public bool IsRaycastLocationValid(Vector2 screenPoint, Camera eventCamera)
        => owner != null && owner.CanReceiveSessionInput;
}
