﻿#if ENABLE_CLIENT
using MCP.DataModels.BaseModels;
using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using static MCP.Unity.UnityUtils;
using static UIManager;
#if ENABLE_GDPR
using UCM;
#endif

public class SettingView : BaseView
{
    [Header("SettingView")]
    //TODO: UImono
    public Toggle musicButton;
    public Toggle soundButton;
    public Slider musicSlider;
    public Slider soundSlider;
    public Dropdown joystickDropDown;
    public Text joystickText;
    public Dropdown fpsDropdown;
    [SerializeField] TabsUI tabSettings;
    private Button consentSettingsButton;
    private Button privacyPolicyButton;


    [Header("Language")]
    public Dropdown languageDropdown;
    private int[] languageIds;

    [Header("GamePlayPanel")]
    public Setting_GamePlayPanel gamePlayPanel;

    [Header("ProfilePanel")]
    public Setting_ProfilePanel profilePanel;

    [Header("HUD Layout Panel")]
    public Setting_HudLayoutPanel hudLayoutPanel;

    public const int TAB_DEVICE = 0;
    public const int TAB_GAMEPLAY = 1;
    public const int TAB_PROFILE = 2;
    public const int TAB_HUD_LAYOUT = 3;

    protected override void CachingUIElementType()
    {
        profilePanel.CachingUIElementType();
    }

    protected override IEnumerator OnInitialize()
    {
        BindConsentSettings();
        tabSettings.OnTabChange.AddListener(OnTabChange);

        musicSlider.onValueChanged.AddListener(OnMusicValueChange);
        soundSlider.onValueChanged.AddListener(OnSoundValueChange);

        gamePlayPanel.Initialize(uiManager);

        languageIds = DataHolder.Instance().languageIDs;
        languageDropdown.options.Clear();

        for (int i = 0, length = languageIds.Length; i < length; i++)
        {
            var name = DataHolder.Instance().GetLanguageName(i);
            var countryName = DataHolder.CountryName[languageIds[i]];
            Sprite flag = null;

            AssetManager.instance.LoadSprite(countryName, ressult => flag = ressult);
            languageDropdown.options.Add(new Dropdown.OptionData(name, flag));
        }

        yield return MCPCoroutines.WaitFor(0.1f);

        languageDropdown.value = uiManager.GetLanguageID();

        yield return DisableComponent();

        tabSettings.Initialize();
        yield return profilePanel.Initialize(uiManager);

        hudLayoutPanel.Init(ExecuteClose);
        tabSettings.UpdateTweenObject();
    }

    protected override void OnEnable()
    {
        base.OnEnable();
        RefreshConsentSettings();
    }

    private void BindConsentSettings()
    {
        // Existing prefab controls have null persistent targets. Bind once without asset migration.
        var buttons = transform.Find("Panel/TabUI/Tab Content/Device Tab/BottomButtons");
        if (buttons == null) return;
        consentSettingsButton = buttons.Find("ConsentSetting")?.GetComponent<Button>();
        privacyPolicyButton = buttons.Find("Privacy")?.GetComponent<Button>();
        if (consentSettingsButton != null)
            consentSettingsButton.onClick.AddListener(OnConsentSetting);
        if (privacyPolicyButton != null)
            privacyPolicyButton.onClick.AddListener(OnPrivacySetting);
        RefreshConsentSettings();
    }

    protected override void OnUpdate()
    {
        base.OnUpdate();
        RefreshConsentSettings();
    }

    private void RefreshConsentSettings()
    {
        if (consentSettingsButton == null) return;
        var ads = AdManager.instance;
        bool required = ads != null && ads.IsPrivacyOptionsRequired;
        var group = consentSettingsButton.transform.parent.gameObject;
        if (group.activeSelf != required) group.SetActive(required);
        consentSettingsButton.interactable = required && ads.CanShowPrivacyOptions;
    }

    public void OnConsentSetting()
    {
        if (AdManager.instance != null) AdManager.instance.ShowPrivacyOptions();
        RefreshConsentSettings();
    }

    public void OnPrivacySetting()
    {
        if (ClientManager.instance != null) ClientManager.instance.OnPrivacy();
    }

    private void OnDestroy()
    {
        if (consentSettingsButton != null)
            consentSettingsButton.onClick.RemoveListener(OnConsentSetting);
        if (privacyPolicyButton != null)
            privacyPolicyButton.onClick.RemoveListener(OnPrivacySetting);
    }

    public override void OnManagerReload()
    {
        profilePanel.OnManagerReload();
        tabSettings.SetTab(0);
        base.OnManagerReload();
    }

    protected override void OnLoadDataUI(BaseViewParam param)
    {
        gamePlayPanel.OnLoadDataUI();

        OnSetLanguageDataToJoystick();
        joystickDropDown.value = (int)uiManager.joystickType;
        OnLoadJoystickText();
        fpsDropdown.value = (int)uiManager.deviceLocalSetting.FpsSetting;

        musicSlider.value = SoundManager.instance.GetMusicValue();
        musicButton.isOn = musicSlider.value > 0;
        soundSlider.value = SoundManager.instance.GetSoundValue();
        soundButton.isOn = soundSlider.value > 0;

        //enableDragToSell.isOn = false;

        languageDropdown.value = uiManager.GetLanguageID();

        if (myCharacter != null && myCharacter.userName == battleManager.GetQuickAccountUserName() + "_" + ClientManager.instance.activeRegion.RegionId)
        {
            profilePanel.LoadGuest();
        }
        else
        {
            profilePanel.LoadNormalUser();
        }

        gameObject.SetActive(true);

        //Reload Profile
        if (tabSettings.Current == TAB_PROFILE) 
        {
            profilePanel.OnLoadDataUI();
        }

        OnTabChange(TAB_DEVICE);
    }

    private void OnSetLanguageDataToJoystick()
    {
        joystickDropDown.options[0].text = UIManager.GetDialog(1103);
        joystickDropDown.options[1].text = UIManager.GetDialog(1104);
        joystickDropDown.options[2].text = UIManager.GetDialog(1105);
    }

    private void OnLoadJoystickText()
    {
        switch(uiManager.joystickType)
        {
            case JoystickType.Fixed:
                joystickText.text = UIManager.GetDialog(1103);
                break;

            case JoystickType.Floating:
                joystickText.text = UIManager.GetDialog(1104);
                break;

            case JoystickType.Dynamic:
                joystickText.text = UIManager.GetDialog(1105);
                break;

            default:
                BattleManager.Log(GameLogType.Error, "Joystick not exist!");
                break;
        }
    }

    private void OnTabChange(int tabIndex)
    {
        if (tabIndex == TAB_DEVICE)
        {

        }
        else if (tabIndex == TAB_GAMEPLAY)
        {
            gamePlayPanel.OnLoadDataUI();
        }
        else if (tabIndex == TAB_PROFILE)
        {
            profilePanel.OnLoadDataUI();
        }
        else if (tabIndex == TAB_HUD_LAYOUT)
        {
            hudLayoutPanel.OnLoadDataUI();
        }
    }

    protected override void OnClosed()
    {
        profilePanel.OnClosed();

        gameObject.SetActive(false);
    }

    public void CheckSaveBeforeClose()
    {
        hudLayoutPanel.OnSaveBeforeClose();
    }

    private void ExecuteClose()
    {
        Close();
    }

    public void NavigationToLinkEmail()
    {
        tabSettings.SetTab(2);
        profilePanel.OnSetTabLinkEmail();
    }

    public void OnChangePassSuccess()
    {
        profilePanel.OnChangePassSuccess();
        Close();
    }

    public void OnChangePassFail()
    {
        profilePanel.OnChangePassFail();
    }

    public void OnLinkAccountViewSuccess()
    {
        profilePanel.OnLinkAccountViewSuccess();
        Close();
    }

    public void OnLinkAccounFail()
    {
        profilePanel.OnLinkAccounFail();
    }

    //Action
    #region Media
    public void OnMusic()
    {
        if (musicButton.isOn)
        {
            SoundManager.instance.SetMusicValue(1);
        }
        else
            SoundManager.instance.SetMusicValue(0);

        musicSlider.value = SoundManager.instance.GetMusicValue();

        SoundManager.instance.PlayUISound("Click");
    }
    public void OnMusicValueChange(float value)
    {
        SoundManager.instance.SetMusicValue(value);

        if (value == 0)
        {
            musicButton.isOn = false;
        }
        else
        {
            musicButton.isOn = true;
        }
    }
    public void OnSound()
    {
        if (soundButton.isOn)
        {
            SoundManager.instance.SetSoundValue(1);
        }
        else
            SoundManager.instance.SetSoundValue(0);

        soundSlider.value = SoundManager.instance.GetSoundValue();

        SoundManager.instance.PlayUISound("Click");
    }
    public void OnSoundValueChange(float value)
    {
        SoundManager.instance.SetSoundValue(value);

        if (value == 0)
        {
            soundButton.isOn = false;
        }
        else
        {
            soundButton.isOn = true;
        }
    }

    #endregion

    #region Language

    public void OnLanguageValueChange(int value)
    {
        uiManager.SetLanguageID(value);
    }



    #endregion

    public void OnJoystickChangeValue(int value)
    {
        SoundManager.instance.PlayUISound("Click");
        uiManager.LoadJoyStick((JoystickType)value);
        OnLoadJoystickText();
    }

    public void OnFPSChanged(int index)
    {
        SoundManager.instance.PlayUISound("Click");
        FpsMode mode = (index == 0) ? FpsMode.Fps30 : FpsMode.Fps60;
        uiManager.LoadFps(mode);
    }

    public void OnDeleteAccount()
    {
        if (ClientManager.instance.isHaveDataWalletPassCode)
        {
            var walletPassCode = ClientManager.instance.walletPassCode;
            if (string.IsNullOrEmpty(walletPassCode))
            {
                CheckPin(RequestDeletePlayerData);
            }
            else
            {
                Notify(174, true, RequestDeletePlayerData);

            }
        }
        else
        {
            Notify(174, true, () => myCharacter.RequestDeletePlayerData(ClientManager.instance.GetApiToken()));
        }
    }

    private void RequestDeletePlayerData()
    {
        myCharacter.RequestDeletePlayerData(
            ClientManager.instance.GetApiToken(),
            ClientManager.instance.walletPassCode);
    }

    public void CheckPin(Action onSuccess)
    {
        uiManager.OpenView<PinView>();
        PinView.OnVerifyPinSuccess = onSuccess;
    }

    public void OnRateUs()
    {
#if UNITY_IOS
        Application.OpenURL(ClientManager.instance.iosLink);
#elif UNITY_ANDROID
        Application.OpenURL(ClientManager.instance.androidLink);
#elif UNITY_WEBGL

#elif UNITY_STANDALONE

#endif
    }
}
#endif
