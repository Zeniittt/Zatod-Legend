﻿using DG.Tweening;
#if ENABLE_MOCKUP
using com.cyborgAssets.inspectorButtonPro;
#endif
using MCP.DataModel.Utils;
using MCP.DataModels.BaseModels;
using MCP.Manager.Client;
using MCP.Mmo.Manager;
using Mirror;
using Newtonsoft.Json.Linq;
using PathologicalGames;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using static MCP.Unity.UnityUtils;
using static BattleManager;
using System.Text.RegularExpressions;
using MCP.Unity;
using static CharacterInventory;
using static GameConst;


public partial class UIManager : MonoBehaviour, IGetCardData, IServiceLocator<BaseView>
{
    private const float VillageBuildButtonRefreshInterval = 0.25f;

    private string currentBlessingTowerBuildingId = "";
    private bool ignoreBlessingTowerEnterUntilExit = false;
    private float villageBuildButtonRefreshTimer;
    private bool isVillageBuildButtonActive;
    private string activeVillageBuildButtonVillageId = "";
    private readonly HashSet<TrapBehavior> nearbyRepairTraps = new HashSet<TrapBehavior>();
    private TrapBehavior currentRepairTrap;
    private bool trapRepairPending;
    private float trapRepairPendingUntil;
    private float nextTrapRepairRefresh;

    public enum LoadingState
    {
        None,
        Connecting,
        Routing,
        Reconnecting,
        LoginInitProgress
    }
    public enum NotifyMenuPanel { None, NewClanChat, Tutorial, NewRequestJoinClan, NewQuest }

    public enum Sender { None, Admob, NPCQuest, NPCArtifact, Market, EventBoss1, System, AutoMerge }

    public enum GameEventIdIcon
    {
        None_Icon = 0, SeasonStart_Icon = 1, TRex_Icon = 2, ClanAndOrcVillage_Icon = 3, ClanWorldBoss_Icon = 4, MidSeasonReward_Icon = 5,
        Coloseum_Icon = 6, OrcRevenge_Icon = 7, FinalSeasonReward_Icon = 8, x3Diamond_Icon = 9, x2Gold_Icon = 10, x2Shard_Icon = 11,
        ClanArena_Icon = 12, Hunting_Icon = 13, Viking_Icon = 14, SeasonEventBoss_Icon = 15, SeasonEventScrollBoss = 16, x2Ingredient = 17,
        PkIsland = 18, WereWolf = 19, ClanMerchandise = 20, FactionWar = 21, SurvivalLand = 100, PoisonSlimeKing = 22, VillageProtection = 23,
        AreaClash = 24,
        ClanRaid = 25,
        VikingRush = 26
    }

    public enum GameEventIdPanel
    {
        None_Panel = 0, SeasonStart_Panel = 1, TRex_Panel = 2, ClanAndOrcVillage_Panel = 3, ClanWorldBoss_Panel = 4, MidSeasonReward_Panel = 5,
        Coloseum_Panel = 6, OrcRevenge_Panel = 7, FinalSeasonReward_Panel = 8, x3Diamond_Panel = 9, x2Gold_Panel = 10, x2Shard_Panel = 11,
        ClanArena_Panel = 12, Hunting_Panel = 13, Viking_Panel = 14, SeasonEventBoss_Panel = 15, SeasonEventScrollBoss = 16, x2Ingredient = 17,
        PkIsland = 18, WereWolf = 19, ClanMerchandise = 20, FactionWar = 21, SurvivalLand = 100, PoisonSlimeKing = 22
    }

    public enum MobType
    {
        NoneIcon = 0, Turtle = 1, Snailu = 2, Astromophy = 3, Mosqui = 4, RedDragon = 5, SpiderOverlord = 6,
        DevouringBlossom = 7, OrcWarlord = 8, BlueDragon = 9, SwarmLord = 10, LexiconWraith = 11, Grumbletroll = 12,
        RedTRex = 13, Orc = 14, OrcLeader = 15, OrcKing = 16, Monoevil = 17, Slither = 18, Spectre = 19, Graveling = 20,
        UndeadTRex = 21, OgreShaman = 22, OgreWarrior = 23, AxeOrc = 24, WoodenStickOrc = 25, SnowCow = 26, SnowMammoth = 27,
        WhiteWolf = 28, SnowBear = 29, Werewolf = 30, VikingVillageMain = 31, VikingVillageStorage = 32, VikingLeader = 33,
        VikingWarrior = 34, VikingVillageArcher = 35, VikingKing = 36, SnowBearRun = 37, MerchandiseBear = 38, MoonlitWarden = 39,
        MoonlitShadow = 40, MoonlitTiny = 41, NightmareWarden = 42, Dracula = 43, Bat = 44, VikingMage = 45, VikingPriest = 46,
        VikingKnight = 47, HighnoonPhantom = 48, VikingMainFury = 49, VikingLeaderFury = 50, VikingKingFury = 51, MerchandiseNoel = 52,
        BlizzardWarden = 53, BlizzardTiny = 54, NewYearWarden = 55, NewYearBlossom = 56, Snake = 57, HighnoonWarden = 58, Cacodaemon = 59,
        Aquasaur=60,Brachiosaurus=61,Crocodylosaurus=62,Pterosaur=63,Tyrannosaurus=64, PoisonSlimeKing = 65, UndeadTRexTournament = 66,
    }


    public static UIManager instance;
    private bool isReloading;
    public bool IsReloading => isReloading;

# if ENABLE_CLIENT
    [Header("HUD System")]
    [SerializeField] private HUDSystem hudSystem;
    public HUDSystem HUDSystem => hudSystem;
#endif
    public event Action<bool> OnMinimizeModeChange;
    public bool IsMinimizeMode { get; private set; }

    public void SetMinimizeMode(bool minimizeMode)
    {
        IsMinimizeMode = minimizeMode;
        OnMinimizeModeChange?.Invoke(minimizeMode);
    }

    public Canvas mainCanvas;
    [SerializeField] Canvas gateCanvas;
    [SerializeField] Canvas loginCanvas;

    public static bool isFontSizeZero = false;
    public static event Action<bool> OnFontSizeZero;

    [Header("BaseView")]
    public List<BaseView> views;
    private readonly List<BaseView> updateViews = new List<BaseView>();
    private int viewInitCompleted = 0;
    private readonly Dictionary<Type, List<BaseView>> viewsByType = new Dictionary<Type, List<BaseView>>();
    private readonly Dictionary<string, BaseView> viewsByTypeAndName = new Dictionary<string, BaseView>();

    [Header("Feature")]
    public List<FeatureRoute> featureRoutes;

    [Header("Joystick")]
    public JoystickType joystickType = JoystickType.Floating;
    public FixedJoystick fixedJoystick;
    public FloatingJoystick floatingJoystick;
    public DynamicJoystick dynamicJoystick;

    [SerializeField] ErrorCodeToDialogMapper errorCodeToDialog;
    [SerializeField] VipBonusToDialogMapper vipBonusToDialog;

    [Tooltip("Khi set type name sẽ được editor tự điền, name chỉ dùng để debug, lấy dialog thông qua type. Dialog này hiển thị Use title")]
    [SerializeField] EquipmentTypeDialog[] equipmentTypeUseTitle;
    [SerializeField] EquipmentTypeDialog[] equipmentTypeUnUseTitle;

    [SerializeField] Material materialUIGrey;
    [SerializeField] Material materialUIMaxStat;

    [SerializeField] GameObject chatUIPrefab;
    [SerializeField] GameObject logo18;

    public LayerMask infoLayerMask;
    public LayerMask mobLayerMask;
    public LayerMask uiLayerMask;

    public Transform ingredientTransform;

    private int arenaId;
    [HideInInspector]
    public List<ChatUI> chatUIPools = new List<ChatUI>();
    [HideInInspector]
    public List<MapItemBehavior> chestBehaviors = new List<MapItemBehavior>();
    [HideInInspector]
    public Dictionary<string, ChatUI> chatUIs = new Dictionary<string, ChatUI>();

    private List<ShopUI> shopUIs = new();

    public const string KEY_LANGUAGE_ID = "LanguageID";
    public const string SHOP_VIEW = "ShopView";
    public const string SHOP_HEALER_VIEW = "HealerShopView";
    public const string ARENA_SHOP_VIEW = "ArenaShopView";
    public const string SURVIVAL_INFO_VIEW = "SurvivalBattleInfoView";

    public const string SHOP_IAP_VIEW = "ShopIAPView";
    public const string CHANGE_NAME_VIEW = "ChangeNameView";
    public const string FORCE_CHANGE_NAME_VIEW = "ForceChangeNameView";
    public const string COLOSSEUM_VIEW = "ColosseumView";
    public const string CLAN_WAR_VIEW = "ClanWarView";
    public const string TOAST_VIEW_LEFT = "ToastViewLeft";
    public const string AUTO_CLOSE_NOTICE_VIEW = "AutoCloseNoticeView";
    public const string LINK_NOTICE_VIEW = "LinkNoticeView";
    public const string NOTICE_VIEW = "NoticeView";

    public const string BEGINNER_PACKAGE_VIEW = "BeginnerPackageView";

    public const string UNDEAD_LAND_MODE = "TeleportBackToCenterLandView";
    public const string BATTLE_MODE = "TeleportBattleModeView";

    public Camera cam;
    public Camera vfxCam;
    private float rateUsTime = 0;
    private bool isMouseDown = false;
    private float timeMouseDown;
    private readonly float threshHoldMouseDown = 0.5f;
    private Vector2 mouseDownPos;
    private static int languageId = 0;
    private float time;
    private float timeCheckInternet = 0;
    private int timeOut = 1;
    private float lastTimeClickUI;
    private float lastTimeClickSceneLayer = 0f;

    private StringBuilder stringBuilder = new StringBuilder(20);
    private const string FIRST_OPEN_HELP_DIALOG_IDS_KEY = "FirstOpenHelpDialogIds";
    private List<int> firstOpenHelpDialogIds;

    public void SetLastTimeClick() => lastTimeClickUI = time;
    public static bool IsHidenBody = false;

    private BattleManager battleManager;
    private AnimationHelper animationHelper;
    public static float orthographicSizeDefault;
    public GameObject loading;
    public Text tipsAndTrick;
    [SerializeField] private LoadingView loadingView;
    private LoadingState currentLoadingState = LoadingState.None;
    private bool waitingLoginViewReady = false;

    public bool isActiveSecondInventory;
    public int activeInventoryExtraRowCount;

#if ENABLE_CLIENT 
    [SerializeField] CanvasGroup iconFocus;
    [SerializeField] Image iconFocusImage;
    private CanvasGroup viewIconFocus;
    private Image viewIconFocusImage;
#endif 

    private bool isCameraZoomIn;
    private bool isWatchMode = false;
    public bool IsWatchMode
    {
        get => isWatchMode;
        private set
        {
            isWatchMode = value;
            FindView<HUDView>().OnWatchModeChange();
        }
    }
    public bool enableJoystick = true;

    public StringBuilder StringBuilder => stringBuilder;

    private ScreenOrientation lastScreenOrientation;

    public List<string> playerOutOfArena = new();

    public void SetIconFocus(ItemUI value)
    {
#if ENABLE_CLIENT
        if (!iconFocus)
            return;

        iconFocus.DOKill();
        iconFocus.alpha = 0f;
        globalItemUI = value;

        if (viewIconFocus)
        {
            viewIconFocus.DOKill();
            viewIconFocus.alpha = 0f;
        }

        if (!value)
        {
            if (viewIconFocus)
                viewIconFocus.transform.SetParent(iconFocus.transform.parent, false);
            return;
        }

        var owner = value.GetComponentInParent<BaseView>(true);
        var parent = owner ? owner.transform : iconFocus.transform.parent;
        var branch = value.transform;
        while (branch.parent != null && branch.parent != parent)
            branch = branch.parent;
        if (parent == null || branch.parent != parent)
            return;

        // Keep the serialized frame safe even if a source view is destroyed.
        if (!viewIconFocus)
        {
            viewIconFocus = Instantiate(iconFocus, parent, false);
            viewIconFocusImage = viewIconFocus.GetComponent<Image>();
            var layout = viewIconFocus.GetComponent<LayoutElement>();
            if (!layout)
                layout = viewIconFocus.gameObject.AddComponent<LayoutElement>();
            layout.ignoreLayout = true;
        }
        else
            viewIconFocus.transform.SetParent(parent, false);

        // Draw above the selected content branch, below later popup siblings.
        viewIconFocus.transform.SetAsLastSibling();
        viewIconFocus.transform.SetSiblingIndex(branch.GetSiblingIndex() + 1);
        value.SetFocus(viewIconFocusImage);
        viewIconFocus.transform.position = value.transform.position;
        viewIconFocus.DOFade(1f, 0.1f).SetLink(viewIconFocus.gameObject);
#endif
    }

    private ItemUI globalItemUI;

    [HideInInspector] public BadWordFilter badWordFilter;
    public static float TweenDuration = 0.2f;
    public static int ShineID = Shader.PropertyToID("_ShineLocation");

    public NetworkAuthenticatorMMO NetworkAuthenticatorMMO { get; private set; }
    public bool InitializedComplete { get => initializedComplete; private set => initializedComplete = value; }
    public string InitializationStepLabel { get; private set; } = "NotStarted";
    public int ViewInitCompletedCount => viewInitCompleted;
    public int ViewInitTotalCount => views != null ? views.Count : 0;
    public int GetArenaId()
    {
        return arenaId;
    }

    public void SetArenaId(int value)
    {
        arenaId = value;
    }

    public bool IsCameraZoomIn
    {
        get => isCameraZoomIn;
        set
        {
            if (isCameraZoomIn != value)
            {
                isCameraZoomIn = value;
                ClientManager.instance.SaveSettingCameraZoom(isCameraZoomIn);
            }
        }
    }

    public bool IsSleep
    {
        get => isSleep;
        set => isSleep = value;
    }
    public List<ShopUI> GetShopUIs()
    {
        return shopUIs;
    }

    public void AddShopUIs(ShopUI shopUI)
    {
        shopUIs.Add(shopUI);
    }

    public void SetShopUIs(List<ShopUI> value)
    {
        shopUIs = value;
    }

    public OnClickEquipment GetCurrentLogicOnClickEquipment()
    {
        int max = 0;
        currentLogicOnClickEquipment = null;
        foreach (var logic in listLogicOnClickEquipments)
        {

            if (logic.priority < max)
                continue;
            max = logic.priority;
            currentLogicOnClickEquipment = logic;
        }


        return currentLogicOnClickEquipment;
    }

    private Tween npcButtonTween;
    private Tween buildingButtonTween;

    [HideInInspector] public Card[] cardCache;
    [HideInInspector] public CharacterTitle[] titleCache;
    [HideInInspector] public Quest[] questCache;

    public List<CurrencyUI> currencyUIs;

    public static Dialog[] dialogCache;

    private bool initializedComplete = false;

    private Coroutine watchCoroutine;
    private Coroutine endSleepCoroutine;
    private Coroutine startSleepCoroutine;

    private bool isSleep = false;
    private DateTime startSleep;

    private const int timeSleepThreshold = 10;
    public PlayerLocalSetting playerLocalSetting;
    public DeviceLocalSetting deviceLocalSetting;
    [SerializeField] BaseView backView = null;

    public bool HaveBackView => backView != null;

    [SerializeField] OnClickEquipment currentLogicOnClickEquipment = null;
    public List<OnClickEquipment> listLogicOnClickEquipments = new();
    public static HashSet<OnClickEquipment> clickEquipmentSub = new();

    //datas
    public FAQDataHolder fAQDataHolder;

    #region Bot
    //TODO: refactor
    public bool haveInviteClan = false;
    public string clanInvite;
    public string userInvite;
    #endregion


    #region Editor

#if UNITY_EDITOR

    public BattleManager battlePrefab;
    public AssetManager assetManager;
#endif
    #endregion

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(this.gameObject);
            return;
        }

        InitializedComplete = false;
        InitializationStepLabel = "Awake";
#if ENABLE_CLIENT
        ConfigureWorldCameraStack(Camera.main, vfxCam);
#endif
        DontDestroyOnLoad(this.gameObject);
        StartCoroutine(Initialize());
    }

#if ENABLE_CLIENT
    // These cameras belong to separate shared prefabs. Bind their cross-instance
    // relationship here instead of relying on one platform scene's overrides.
    public static void ConfigureWorldCameraStack(Camera worldCamera, Camera overlayCamera)
    {
        if (!(UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline is
                UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset) ||
            worldCamera == null || overlayCamera == null || worldCamera == overlayCamera)
            return;

        var worldData = worldCamera.GetComponent<UnityEngine.Rendering.Universal.UniversalAdditionalCameraData>();
        if (worldData == null)
            worldData = worldCamera.gameObject.AddComponent<UnityEngine.Rendering.Universal.UniversalAdditionalCameraData>();
        var overlayData = overlayCamera.GetComponent<UnityEngine.Rendering.Universal.UniversalAdditionalCameraData>();
        if (overlayData == null)
            overlayData = overlayCamera.gameObject.AddComponent<UnityEngine.Rendering.Universal.UniversalAdditionalCameraData>();

        worldData.renderType = UnityEngine.Rendering.Universal.CameraRenderType.Base;
        overlayData.renderType = UnityEngine.Rendering.Universal.CameraRenderType.Overlay;
        worldData.SetRenderer(-1);
        overlayData.SetRenderer(-1);
        // New URP data defaults to clearing depth; preserve authored overrides.
        var stack = worldData.cameraStack;
        if (stack == null)
        {
            Debug.LogError("[UIManager] The default URP renderer must support world/VFX camera stacking.");
            return;
        }

        int first = stack.IndexOf(overlayCamera);
        if (first < 0) stack.Add(overlayCamera);
        else
            for (int i = stack.Count - 1; i > first; i--)
                if (stack[i] == overlayCamera) stack.RemoveAt(i);
    }
#endif

    private void OnDestroy()
    {
#if ENABLE_CLIENT
        if (viewIconFocus)
        {
            viewIconFocus.DOKill();
            Destroy(viewIconFocus.gameObject);
        }
#endif
        if (ClientManager.instance != null)
        {
            ClientManager.instance.OnLoginInitProgressChanged -= OnLoginInitProgressChanged;
        }
    }

    //UI Entry point
    private IEnumerator Initialize()
    {
        float bootStartTime = Time.realtimeSinceStartup;
        float stepStartTime = bootStartTime;

        InitializationStepLabel = "FrameSync";
        yield return new WaitForEndOfFrame();
        LogInitStepDuration("FrameSync", stepStartTime);
        stepStartTime = Time.realtimeSinceStartup;

        InitializationStepLabel = "PrepareLoadingUI";
        EnsureLoadingViewRef();

        if (ClientManager.instance != null)
        {
            ClientManager.instance.OnLoginInitProgressChanged -= OnLoginInitProgressChanged;
            ClientManager.instance.OnLoginInitProgressChanged += OnLoginInitProgressChanged;
        }

        ShowBlockingLoading(LoadingState.Connecting, "Preparing UI...");

        // ✅ SERVER-ONLY: Add null check for Camera.main (may not exist in headless mode)
        cam = Camera.main;
        if (cam == null)
        {
            Debug.LogWarning("[UIManager] Camera.main is null - running in headless mode?");
        }

#if ENABLE_CLIENT 

        SetIconFocus(null);

        SetActive(logo18, false);
#endif

        LoadDeviceLocalSetting();

        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        SetActive(tipsAndTrick, true);
        animationHelper = new AnimationHelper();

        NetworkAuthenticatorMMO = FindObjectOfType<NetworkAuthenticatorMMO>();

        LogInitStepDuration("PrepareLoadingUI", stepStartTime);
        stepStartTime = Time.realtimeSinceStartup;

        InitializationStepLabel = "WaitCoreManagers";
        yield return new WaitUntil(() => BattleManager.instance != null);
        yield return new WaitUntil(() => SoundManager.instance != null);
        //yield return new WaitUntil(() => NavigationManager.Instance != null);
        LogInitStepDuration("WaitCoreManagers", stepStartTime);
        stepStartTime = Time.realtimeSinceStartup;

        InitializationStepLabel = "CollectViews";
        battleManager = BattleManager.instance;
        // Cache data từ DataHolder (dùng RefreshDataCaches để có logic chung)
        RefreshDataCaches();

        viewInitCompleted = 0;

        if (gateCanvas != null)
        {
            var gateViews = gateCanvas.GetComponentsInChildren<BaseView>(true).ToList();
            views.AddRange(gateViews);
        }

        if (loginCanvas != null)
        {
            var gateViews = loginCanvas.GetComponentsInChildren<BaseView>(true).ToList();
            views.AddRange(gateViews);
        }

        RebuildViewLookupCache();
        LogInitStepDuration("CollectViews", stepStartTime);
        stepStartTime = Time.realtimeSinceStartup;

        InitializationStepLabel = "InitHudSystem";
        // HUDSystem phải init trước khi các BaseView register panels
#if ENABLE_CLIENT
        if (hudSystem != null) hudSystem.Initialize();
#endif
        LogInitStepDuration("InitHudSystem", stepStartTime);
        stepStartTime = Time.realtimeSinceStartup;

        var sw = System.Diagnostics.Stopwatch.StartNew();

        InitializationStepLabel = "InitializeViews";
        foreach (var view in views)
        {
            SetActive(view, true);
            StartCoroutine(InitView(view));

            if (sw.ElapsedMilliseconds > 60)
            {
                //60fps: ~15ms
                //30fps: ~30ms
                //15fps: ~60ms
                sw.Restart();
                yield return null;
            }
        }

        while (viewInitCompleted < views.Count)
        {
            yield return null;
        }
        RebuildViewUpdateList();
        LogInitStepDuration("InitializeViews", stepStartTime);
        stepStartTime = Time.realtimeSinceStartup;

        InitializationStepLabel = "RegisterEvents";
        Register();

#if ENABLE_CLIENT 
    InitializationStepLabel = "LoadBadWordFilter";
        badWordFilter = new BadWordFilter();
        badWordFilter.Load();
#endif
    LogInitStepDuration("RegisterAndFilters", stepStartTime);
    stepStartTime = Time.realtimeSinceStartup;

    InitializationStepLabel = "OpenCoreViews";
        SetUpScreenOrientation();
        yield return null;

        var loginView = OpenView<LoginView>();
        OpenView<CharacterView>();
        OpenView<InventoryView>();
        OpenView<TooltipView>();
        OpenView<PackageSuggestView>();
        OpenView<AutomationShortcutView>();

        var hud = OpenView<HUDView>();
        if (NavigationManager.Instance != null)
        {
            NavigationManager.Instance.HUDView = hud;
        }
#if ENABLE_CLIENT
        if (hudSystem != null) hudSystem.CompleteInitialConfigLoad();
#endif
        LogInitStepDuration("OpenCoreViews", stepStartTime);

        InitializedComplete = true;
        InitializationStepLabel = "Completed";
        IsSleep = false;
        waitingLoginViewReady = loginView != null;
        if (!waitingLoginViewReady)
        {
            HideLoading();
        }

        //ClientFeatureManager.Instance.LoadFeatureRoutes(featureRoutes);

        float totalMs = (Time.realtimeSinceStartup - bootStartTime) * 1000f;
        Debug.Log($"[UIManager] Initialize completed in {totalMs:F1} ms (views: {viewInitCompleted}/{views.Count})");

        //yield return new WaitForEndOfFrame();
        //DataHolder.Instance().LoadLanguageIDs(languageId);
    }

    private void LogInitStepDuration(string stepName, float stepStartTime)
    {
        float ms = (Time.realtimeSinceStartup - stepStartTime) * 1000f;
        Debug.Log($"[UIManager] Init step '{stepName}' took {ms:F1} ms");
    }

    private void OnLoginInitProgressChanged(ClientManager.LoginInitProgressInfo info)
    {
        if (info == null)
            return;

        if (info.IsCompleted)
        {
            currentLoadingState = LoadingState.None;
            SetGlobalLoadingActive(false);
            return;
        }

        currentLoadingState = LoadingState.LoginInitProgress;
        SetGlobalLoadingActive(true);
        RefreshLoadingUi(info.CurrentStep, info.Summary, info.Progress01);
    }

    private string GetLoadingStateLabel(LoadingState state)
    {
        switch (state)
        {
            case LoadingState.Routing:
                return "Routing to server...";
            case LoadingState.Reconnecting:
                return "Reconnecting...";
            case LoadingState.LoginInitProgress:
                return "Initializing...";
            case LoadingState.Connecting:
                return "Connecting to server...";
            default:
                return string.Empty;
        }
    }

    public void ShowBlockingLoading(LoadingState state, string stateLabel = null)
    {
        currentLoadingState = state;
        SetGlobalLoadingActive(true);

        EnsureLoadingViewRef();
        if (loadingView != null)
        {
            loadingView.SetBlockingState(stateLabel ?? GetLoadingStateLabel(state));
        }
    }

    public void HideLoading()
    {
        currentLoadingState = LoadingState.None;
        SetGlobalLoadingActive(false);
    }

    public void NotifyLoginViewReady(bool keepLoading, LoadingState keepState = LoadingState.None, string keepLabel = null)
    {
        if (!waitingLoginViewReady)
            return;

        waitingLoginViewReady = false;

        if (keepLoading)
        {
            if (keepState != LoadingState.None)
            {
                ShowBlockingLoading(keepState, keepLabel);
            }
            else
            {
                SetGlobalLoadingActive(true);
            }

            return;
        }

        HideLoading();
    }

    private void EnsureLoadingViewRef()
    {
        if (loadingView != null)
            return;

        if (loading != null)
        {
            loadingView = loading.GetComponentInChildren<LoadingView>(true);
        }
    }

    public void SetGlobalLoadingActive(bool active)
    {
        EnsureLoadingViewRef();

        if (loadingView != null)
        {
            loadingView.SetLoadingActive(active);
            return;
        }

        if (loading != null)
        {
            loading.SetActive(active);
        }
    }

    public void ResetLoadingProgressUi()
    {
        RefreshLoadingUi("Idle", string.Empty, 0f);
    }

    private void RefreshLoadingUi(string step, string summary, float progress01)
    {
        EnsureLoadingViewRef();
        if (loadingView != null)
        {
            loadingView.SetProgress(step, summary, progress01);
        }
    }

    private IEnumerator InitView(BaseView view)
    {
        yield return view.InitializeInternal(this);
        view.Close();
        viewInitCompleted++;
    }

    public void OnSetMyCharacter()
    {
        StartCoroutine(OnSetMyCharacterCO());
    }

    private IEnumerator OnSetMyCharacterCO()
    {
        if (ClientManager.instance.isBot)
        {
            FindView<LoginView>().CloseUiAndLoadingPanel();
            yield break;
        }

        while (ClientManager.instance.myCharacter == null || string.IsNullOrEmpty(ClientManager.instance.myCharacter.characterName))
        {
            yield return MCPCoroutines.WaitFor(0.2f);
        }

        bool isRegisterFlow = ClientManager.instance.loginType == LoginType.Register;


        while (BattleManager.instance.HaveGameDataConfig == false)
        {
            yield return null;
        }

        bool isPublisherVN = IsPublisherVn();
        SetActive(logo18, isPublisherVN);

        if (isRegisterFlow && isPublisherVN)
        {
            var accountIdentityView = OpenView<AccountIdentityView>();
            FindView<LoginView>().CloseUiAndLoadingPanel();
            CheckAccountInfoState();

            while (accountIdentityView.IsOpen)
            {
                yield return null;
            }

        }

        if (isRegisterFlow)
        {
            OpenView<ChangeNameView>(FORCE_CHANGE_NAME_VIEW);
        }

        if (ClientManager.instance.accountInfoLocal.state != AccountInfoState.None)
        {
            CheckAccountInfoState();
        }

        yield return MCPCoroutines.WaitFor(0.2f);
        LoadPlayerLocalSetting();

        yield return MCPCoroutines.WaitFor(0.1f);

        if (ClientManager.instance.myCharacter != null)
        {
            var changeNameView = FindView<ChangeNameView>();
            while (changeNameView != null && changeNameView.IsOpen)
            {
                yield return null;
            }
            var apiToken = ClientManager.instance.GetApiToken();
            ClientManager.instance.myCharacter.RequestGetBeginnerQuest(apiToken);

            //Login completed
            FindView<LoginView>().CloseUiAndLoadingPanel();
            if (ClientManager.instance.myCharacter.characterBody != null)
            {
                ClientManager.instance.myCharacter.OnUpdateStats();
            }
        }
        else
        {
            IngameNotifyManager.instance.Notify("Set Character error. Character data null");
        }

    }

    public bool IsPublisherVn()
    {
        if (BattleManager.instance.HaveGameDataConfig)
        {
            var gamedataConfig = BattleManager.instance.gameDataConfig;
            ClientManager.instance.LoadRemoteConfigCountryFromCache();

            bool isPublisherVN = string.Equals(gamedataConfig.publishers, GameConst.PUBLISHERS_VIETNAM, StringComparison.OrdinalIgnoreCase)
                && string.Equals(ClientManager.instance.remoteCountryCode, "VN", StringComparison.OrdinalIgnoreCase);
            return isPublisherVN;
        }
        else
        {
            return false;
        }
    }

    public bool IsVietnamWalletIdentityRequired(AccountInfo accountInfo = null)
    {
        // Vietnam identity rules only apply when the connected server is a Vietnam build.
        // The server publisher is received through GameDataConfig from the server.
        if (!IsServerPublisherVietnam())
        {
            return false;
        }

        return IsRemoteCountryVietnam();
    }

    public bool HasRequiredWalletIdentity(AccountInfo accountInfo)
    {
        return BattleManager.HasRequiredWalletIdentity(accountInfo, IsVietnamWalletIdentityRequired(accountInfo));
    }

    private bool IsServerPublisherVietnam()
    {
        return BattleManager.instance != null &&
               BattleManager.instance.HaveGameDataConfig &&
               BattleManager.instance.gameDataConfig != null &&
               string.Equals(BattleManager.instance.gameDataConfig.publishers,
                   GameConst.PUBLISHERS_VIETNAM, StringComparison.OrdinalIgnoreCase);
    }

    private bool IsRemoteCountryVietnam()
    {
        ClientManager.instance.LoadRemoteConfigCountryFromCache();
        return string.Equals(ClientManager.instance.remoteCountryCode, "VN", StringComparison.OrdinalIgnoreCase);
    }

    public bool EnsureWalletIdentityOrPrompt(BaseView viewToClose = null)
    {
        var accountInfo = ClientManager.instance.GetMyAccountInfo();
        if (HasRequiredWalletIdentity(accountInfo))
        {
            return true;
        }

        viewToClose?.Close();
        PromptMissingWalletIdentity(accountInfo);
        return false;
    }

    // Temporary marketplace rule: marketplace only requires a linked email.
    public bool EnsureMarketplaceEmailOrPrompt(BaseView viewToClose = null)
    {
        var accountInfo = ClientManager.instance.GetMyAccountInfo();
        if (accountInfo != null &&
            !string.IsNullOrEmpty(accountInfo.email) &&
            DataUtils.IsValidEmail(accountInfo.email))
        {
            return true;
        }

        viewToClose?.Close();
        PromptMissingMarketplaceEmail();
        return false;
    }

    public void PromptMissingMarketplaceEmail()
    {
        IngameNotifyManager.instance.Notify(926);
#if ENABLE_CLIENT
        var view = FindView<SettingView>();
        view.Load();
        view.NavigationToLinkEmail();
#endif
    }

    public void TryPromptRequiredPhoneIdentity(AccountInfo accountInfo)
    {
        bool hasPhone = !string.IsNullOrEmpty(accountInfo?.phoneNumber);
        bool hasIdentity = accountInfo?.identityInfo != null &&
                           !string.IsNullOrEmpty(accountInfo.identityInfo.fullName);

        if (accountInfo == null ||
            !IsVietnamWalletIdentityRequired(accountInfo) ||
            (hasPhone && hasIdentity) ||
            ClientManager.instance?.myCharacter == null ||
            !ClientManager.instance.myCharacter.IsInCenterLand())
        {
            return;
        }

        var identityView = FindView<AccountIdentityView>();
        if (identityView != null && identityView.IsOpen)
        {
            return;
        }

        IngameNotifyManager.instance.Notify(954);
        OpenRequiredPhoneIdentityView();
    }

    public void PromptMissingWalletIdentity(AccountInfo accountInfo)
    {
        if (IsVietnamWalletIdentityRequired(accountInfo))
        {
            IngameNotifyManager.instance.Notify(954);
            OpenRequiredPhoneIdentityView();
            return;
        }

        IngameNotifyManager.instance.Notify(926);
#if ENABLE_CLIENT
        var view = FindView<SettingView>();
        view.Load();
        view.NavigationToLinkEmail();
#endif
    }

    private AccountIdentityView OpenRequiredPhoneIdentityView()
    {
        return OpenView<AccountIdentityView>(new AccountIdentityViewParam
        {
            ForcePhoneRequired = true
        });
    }

    public bool IsMarketVietnamBlocked()
    {
        if (!BattleManager.instance.HaveGameDataConfig || BattleManager.instance.gameDataConfig == null)
        {
            return false;
        }

        return !BattleManager.instance.gameDataConfig.isOpenMarketVietnam && IsPublisherVn();
    }

    /// <summary>
    /// Tìm 1 View dựa trên type, nếu 1 type có nhiều view, truyền thêm prefab name của view
    /// </summary>
    public T FindView<T>(string name = "") where T : BaseView
    {
        Type requestedType = typeof(T);

        if (name.IsNullOrEmpty())
        {
            if (viewsByType.TryGetValue(requestedType, out List<BaseView> typedViews) && typedViews.Count > 0)
            {
                return typedViews[0] as T;
            }
        }
        else
        {
            string cacheKey = GetViewCacheKey(requestedType, name);
            if (viewsByTypeAndName.TryGetValue(cacheKey, out BaseView cachedView) && cachedView is T namedView)
            {
                return namedView;
            }
        }

        if (name.IsNullOrEmpty() == true)
        {
            for (int i = 0, count = views.Count; i < count; i++)
            {
                if (views[i] is T tView)
                {
                    CacheView(requestedType, views[i]);
                    return tView;
                }
            }
        }
        else
        {
            for (int i = 0, count = views.Count; i < count; i++)
            {
                if (views[i] is T tView && views[i].name == name)
                {
                    CacheView(requestedType, views[i]);
                    return tView;
                }
            }
        }
        return null;
    }

    private void RebuildViewLookupCache()
    {
        viewsByType.Clear();
        viewsByTypeAndName.Clear();

        for (int i = 0, count = views.Count; i < count; i++)
        {
            BaseView view = views[i];
            if (view == null)
            {
                continue;
            }

            Type viewType = view.GetType();
            if (!viewsByType.TryGetValue(viewType, out List<BaseView> typedViews))
            {
                typedViews = new List<BaseView>();
                viewsByType[viewType] = typedViews;
            }

            typedViews.Add(view);

            string cacheKey = GetViewCacheKey(viewType, view.name);
            if (!viewsByTypeAndName.ContainsKey(cacheKey))
            {
                viewsByTypeAndName[cacheKey] = view;
            }
        }
    }

    private void CacheView(Type requestedType, BaseView view)
    {
        if (view == null)
        {
            return;
        }

        if (!viewsByType.TryGetValue(requestedType, out List<BaseView> typedViews))
        {
            typedViews = new List<BaseView>();
            viewsByType[requestedType] = typedViews;
        }

        if (!typedViews.Contains(view))
        {
            typedViews.Add(view);
        }

        string cacheKey = GetViewCacheKey(requestedType, view.name);
        if (!viewsByTypeAndName.ContainsKey(cacheKey))
        {
            viewsByTypeAndName[cacheKey] = view;
        }
    }

    private string GetViewCacheKey(Type type, string name)
    {
        return type.FullName + "|" + name;
    }

#if ENABLE_MOCKUP
    [ProButton]
    public void EditorOpenView(string name)
    {
        OpenView<BaseView>(name);
    }
#endif

    public T OpenView<T>(string name = "") where T : BaseView
    {
        var view = FindView<T>(name);
        if (view == null)
            return null;

        return OpenView(view);
    }

    public T OpenView<T>(BaseView.BaseViewParam param, string name = "") where T : BaseView
    {
        var view = FindView<T>(name);
        if (view == null)
            return null;

        view.Preload();
        view.Load(param);

        return view;
    }

    public T OpenView<T>(T view) where T : BaseView
    {
        view.Preload();
        view.Load();

        return view;
    }

    public void BackView()
    {
        if (backView == null)
            return;

        backView.Load();
        backView = null;
    }

    public void LoadDefaultView()
    {
#if ENABLE_CLIENT
        var hudView = FindView<HUDView>();
        if(hudView != null)
        {
            if (IsMinimizeMode == false)
            {
                hudView.ApplyHUDLayoutSettingMode(false);
            }
        }
#endif
    }
    public void CloseDefaultView()
    {
#if ENABLE_CLIENT

        var hudView = FindView<HUDView>();
        if (hudView != null)
        {
            if (IsMinimizeMode == false)
            {
                hudView.ApplyHUDLayoutSettingMode(true);
            }
        }
        FindView<IngredientView>().Close();
#endif
    }

    public FeatureRoute FindFeatureRouteElement(FeatureId featureId)
    {
        for (int i = 0, count = featureRoutes.Count; i < count; i++)
        {
            if (featureRoutes[i].id == featureId)
            {
                return featureRoutes[i];
            }
        }

        return null;
    }
    public void RefreshDataCaches()
    {
        if (DataHolder.Instance() == null) return;

        cardCache = DataHolder.Instance().GetDatas<Card>();
        titleCache = DataHolder.Instance().GetDatas<CharacterTitle>();
        dialogCache = DataHolder.Instance().GetDatas<Dialog>();
        questCache = DataHolder.Instance().GetDatas<Quest>();
    }

    public Card GetCard(int itemId)
    {
        if (itemId < cardCache.Length && itemId >= 0)
        {
            return cardCache[itemId];
        }
        return null;
    }

    public CharacterTitle GetTitle(int itemId)
    {
        if (itemId < titleCache.Length && itemId >= 0)
        {
            return titleCache[itemId];
        }
        return null;
    }
    public Quest GetQuest(int itemId)
    {
        if (itemId < questCache.Length && itemId >= 0)
        {
            return questCache[itemId];
        }
        return null;
    }

    public void UpdateTimeText(float timeRemain, Text textComponent)
    {
        SetText(textComponent, GetTimeText(timeRemain));
    }

    public string GetTimeText(float timeRemain)
    {
        int hours = (int)timeRemain / 3600;
        int minutes = ((int)timeRemain % 3600) / 60;
        int seconds = (int)timeRemain % 60;

        stringBuilder.Clear();

        if (hours > 0)
        {
            stringBuilder.Append(hours.ToString("D2"));
            stringBuilder.Append(":");
        }

        stringBuilder.Append(minutes.ToString("D2"));
        stringBuilder.Append(":")
                     .Append(seconds.ToString("D2"));

        return stringBuilder.ToString();
    }

    public string DisplayTime(TimeSpan timeRemaining)
    {
        string formattedTime = $"{timeRemaining.Hours:D2}h:{timeRemaining.Minutes:D2}m:{timeRemaining.Seconds:D2}s";
        return formattedTime;
    }

    public TimeSpan GetTimeUntilNextDay()
    {
        DateTime now = battleManager.Now().AddHours(-battleManager.serverOffsetTime);
        DateTime nextDayUtc = DateTime.UtcNow.Date.AddDays(1);
        return nextDayUtc - now.ToUniversalTime();
    }

    public string RemoveRegionId(string input)
    {
        if (string.IsNullOrEmpty(input))
        {
            return string.Empty;
        }

        var regionID = BattleManager.instance.serverConfig.serverIndex;
        var value = "_" + regionID;
        return input.Replace(value, string.Empty);
    }

    public void Reload()
    {
        if (isReloading)
            return;

        isReloading = true;
        AvatarVisualHost.ReleaseAll();
        ClientManager.instance?.StopLoginInitCoroutine();

        if (ClientManager.instance.myCharacter != null)
            MmoApiManager.GetInstance().SendEvent("StopPlay", ClientManager.instance.myUsername + "_" + ClientManager.instance.originalServer, (int)ClientManager.instance.myCharacter.timePlay);
        BattleManager.instance.SetGameDataConfig(null);

        BattleManager.instance.isCharacterLoaded = false;

        ClientManager.instance.OnReload();

        BuildingPlacementController.CleanupActivePlacement();

        views.ForEach(v => v.OnManagerReload());
        ClearTransientSessionState();
        ExitWatchMode();
        EnableJoystick(true);

#if ENABLE_HELP
        if (HelpManager.instance != null)
        {
            HelpManager.instance.OnReload();
        }
#endif

        ClearPlayerLocalSetting();

        chestBehaviors.ForEach(chestBehavior => Destroy(chestBehavior.gameObject));
        chestBehaviors.Clear();


        CharacterBehavior[] characterBehaviors = FindObjectsOfType<CharacterBehavior>(true);
        foreach (CharacterBehavior characterBehavior in characterBehaviors)
        {
            Destroy(characterBehavior.gameObject);
        }
#if ENABLE_CLIENT
        SetIconFocus(null);
#endif
        rateUsTime = 0f;
        NavigationManager.Instance.Stop();
        DisableNpcButton();
        DisableBuildingButton();

        // ✅ SERVER-ONLY: Add null check for MapManager (may not exist in headless mode)
        if (MapManager.instance != null)
            MapManager.instance.ResetMap();

        Resources.UnloadUnusedAssets();
        isReloading = false;
    }

    public void ClearTransientSessionState()
    {
        ClearTrapRepairInteraction();
        backView = null;
        currentLogicOnClickEquipment = null;
        listLogicOnClickEquipments.Clear();
        clickEquipmentSub.Clear();
        OnFontSizeZero = null;
        PinView.OnVerifyPinSuccess = null;
    }

    void Update()
    {
#if ENABLE_CLIENT || UNITY_LOCAL_HOST

        if (InitializedComplete == false)
            return;

        for (int i = 0; i < updateViews.Count; i++)
        {
            var view = updateViews[i];
            if (view != null)
                view.UpdateInternal();
        }

        time += Time.deltaTime;
        UpdateVillageBuildButton(Time.deltaTime);
        UpdateTrapRepairButton();

        timeCheckInternet += Time.deltaTime;
        if (timeCheckInternet > timeOut + 1)
        {
            timeCheckInternet = 0;
            CheckInternet();
        }


#if !ENABLE_DIRECT_PAYMENT
        if (rateUsTime > ClientManager.instance.rateUsTime && ClientManager.instance.myCharacter != null
            && ClientManager.instance.myCharacter.IsStandingOn(RuntimeZoneType.Village))
        {
            if (LocalPrefs.KeyExists("RateUs") == false)
            {
                rateUsTime = 0;
                FindView<RateUsView>().Load();
            }
        }
        else
        {
            rateUsTime += Time.deltaTime;
        }
#endif

        //if (battleManager.networkManagerMMO != null && !battleManager.networkManagerMMO.isNetworkActive && battleManager.isInitialized)
        //{
        //    Reload();
        //}

        if (battleManager.isCharacterLoaded && !NetworkClient.isConnected)
        {
            Reload();
        }

        if (Input.GetMouseButtonDown(0))
        {
            isMouseDown = true;
            timeMouseDown = 0;
            mouseDownPos = Input.mousePosition;
        }

        if (isMouseDown)
        {
            timeMouseDown += Time.deltaTime;
        }

        if (isMouseDown && Input.GetMouseButtonUp(0))
        {
            isMouseDown = false;

            var distance = Vector2.Distance(Input.mousePosition, mouseDownPos);
            if (timeMouseDown <= threshHoldMouseDown && distance < 0.3f)
            {
                if (FindView<HUDView>().IsMenuPanelOpen)
                {
                    return;
                }

                foreach (var view in views)
                {
                    if (view.isBlockManagerRayscast) continue;

                    if (view.IsOpen && view.IsDefaultView == false)
                    {
                        return;
                    }

                }

                float diff = time - lastTimeClickUI;
                //Mới click 1 UI khác, thường xảy ra khi UI đó nằm trùng vị trí CharacterBody
                if (diff < 0.1f)
                {
                    return;
                }

                //Layer scene
                if (playerLocalSetting != null)
                {
                    if (playerLocalSetting.IsBlockOtherPlayerClick && playerLocalSetting.IsBlockBuildingClick)
                    {
                        return;
                    }

                    Ray ray = cam.ScreenPointToRay(Input.mousePosition);

                    RaycastHit2D hit = Physics2D.Raycast(ray.origin, ray.direction, 100f, infoLayerMask);

                    if (hit)
                    {
                        var character = hit.collider.transform.parent.GetComponent<CharacterBody>().characterBehavior;
                        var myClanID = ClientManager.instance.myCharacter.clanId;

                        if (playerLocalSetting.IsBlockBuildingClick == false && character.characterType == CharacterType.Building && character.clanId == myClanID)
                        {
                            if (BuildingPlacementController.Instance.IsPlacing)
                            {
                                return;
                            }

                            var buildingView = FindView<BuildingView>();
                            buildingView.TargetBuilding = (PlayerBehavior)character;
                            buildingView.Load();
                        }
                        else
                        {
                            if (playerLocalSetting.IsBlockOtherPlayerClick == false && character.characterType == CharacterType.Player)
                            {
                                var view = FindView<CharacterInfoView>();
                                view.SetTargetCharacter(character);
                                view.Load();
                            }
                        }
                        if (character.characterType == CharacterType.Npc && ((NpcBehavior)character).npcType == NpcType.Guard)
                        {
                            OpenFAQView();
                        }
                        else if (character.characterType == CharacterType.Npc && ((NpcBehavior)character).npcType == NpcType.Jail)
                        {
                            OpenUnlockJailView();
                        }
                    }
                }

            }

            timeMouseDown = 0;
        }

        if (Screen.orientation != lastScreenOrientation)
        {
            SetUpScreenOrientation();
        }
#endif
    }

    internal void RefreshViewUpdateRegistration(BaseView view)
    {
        if (view == null || views == null || !views.Contains(view))
            return;

        updateViews.Remove(view);
        if (view.UpdateOnClose || view.IsOpen)
            updateViews.Add(view);
    }

    private void RebuildViewUpdateList()
    {
        updateViews.Clear();
        if (views == null)
            return;

        for (int i = 0; i < views.Count; i++)
        {
            var view = views[i];
            if (view != null && (view.UpdateOnClose || view.IsOpen))
                updateViews.Add(view);
        }
    }

    public void SetUpScreenOrientation()
    {
        if (Screen.orientation == ScreenOrientation.Portrait || Screen.orientation == ScreenOrientation.PortraitUpsideDown)
        {
            //mainCanvas.matchWidthOrHeight = 0.5f;
            orthographicSizeDefault = 11;
            cam.orthographicSize = 11;
        }
        else
        {
            //mainCanvas.matchWidthOrHeight = 8.5f;
            orthographicSizeDefault = 5;
            cam.orthographicSize = 5;
        }
        if (MapManager.instance != null)
            MapManager.instance.Reload();

        lastScreenOrientation = Screen.orientation;

        //views.ForEach(v => v.OnScreenOrientationChange());
    }

    public void OnChangeLanguage()
    {
        views.ForEach(v => v.ChangeLanguage());
        foreach (var shop in shopUIs)
        {
            if (shop != null)
            {
                shop.ReloadBoxUI();
            }
        }

        // Temporary debug trace; can be removed after language refresh verification.
        BattleManager.Log(GameLogType.Debug, $"[Debug][ShopUI] Refreshed shop titles for language {languageId}.");
    }

    public void OnClickFontSizeZero(bool isHiddenName)
    {
        isFontSizeZero = isHiddenName;
        OnFontSizeZero?.Invoke(isFontSizeZero);
    }

    public void CloseAllView(bool includeDefaultView = false)
    {
        foreach (var view in views)
        {
            if (includeDefaultView)
            {
                if (view.IsOpen)
                {
                    view.Close();
                }
            }
            else
            {
                if (view.IsOpen && view.IsDefaultView == false)
                {
                    // Chỗ này cần hỏi lại anh Đạo
                    if (view is FactionWarHUDView || view is SurvivalBattleHUDView) continue;
                    view.Close();
                }
            }
        }
    }

    public void CheckInternet()
    {
        if (Application.internetReachability == NetworkReachability.NotReachable)
        {
            IsHaveInternet(false);
        }
    }

    public void IsHaveInternet(bool result)
    {
        if (result == false)
        {
            IngameNotifyManager.instance.Notify(537);
            PlayerBehavior.EndQuitClient();
        }
    }

    public void DoActionDelay(Action onComplete, float delay)
    {
        StartCoroutine(DoActionDelayCO(onComplete, delay));
    }

    private IEnumerator DoActionDelayCO(Action onComplete, float delay)
    {
        yield return MCPCoroutines.WaitFor(delay);
        onComplete?.Invoke();
    }

    public void AddLogicClickEquipment(OnClickEquipment onClickEquipment)
    {
        if (listLogicOnClickEquipments.Contains(onClickEquipment))
        {
            listLogicOnClickEquipments.Remove(onClickEquipment);
        }
        listLogicOnClickEquipments.Add(onClickEquipment);
    }

    public void RemoveLogicClickEquipment(OnClickEquipment onClickEquipment)
    {
        listLogicOnClickEquipments.Remove(onClickEquipment);
    }

    public static string GetDialog(int dialogId)
    {
        if (dialogCache == null)
        {
            return string.Empty;
        }

        if (dialogId >= dialogCache.Length || dialogId < 0)
        {
            return string.Empty;
        }

        var dialog = dialogCache[dialogId];
        if (dialog == null)
        {
            return string.Empty;
        }
        return dialog.GetName(languageId);
    }

    public static (string, string) GetFullDialog(int dialogId)
    {
        if (dialogCache == null)
        {
            return (string.Empty, string.Empty);
        }

        if (dialogId >= dialogCache.Length || dialogId < 0)
        {
            return (string.Empty, string.Empty);
        }

        var dialog = dialogCache[dialogId];
        if (dialog == null)
        {
            return (string.Empty, string.Empty);
        }
        return (dialog.GetName(languageId), dialog.GetDescription(languageId));
    }

    public (string, string) GetFullDialogMob(int mobId)
    {
        if (cardCache == null)
        {
            return (string.Empty, string.Empty);
        }

        if (mobId >= cardCache.Length || mobId < 0)
        {
            return (string.Empty, string.Empty);
        }

        var dialog = cardCache[mobId];
        if (dialog == null)
        {
            return (string.Empty, string.Empty);
        }
        return (dialog.GetName(languageId), dialog.GetDescription(languageId));
    }

    public (string, string) GetFullDialogQuest(int questId)
    {
        if (questCache == null)
        {
            return (string.Empty, string.Empty);
        }

        if (questId >= questCache.Length || questId < 0)
        {
            return (string.Empty, string.Empty);
        }

        var dialog = questCache[questId];
        if (dialog == null)
        {
            return (string.Empty, string.Empty);
        }
        return (dialog.GetName(languageId), dialog.GetDescription(languageId));
    }

    public string GetDialogStatVipBonus(VipBonusType vipBonusType)
    {
        var dialogId = vipBonusToDialog.GetDialogID(vipBonusType);
        if (dialogId == -1) return "";
        var dialog = GetDialog(dialogId);
        return dialog;
    }

    public static string FormatNumber(int value)
    {
        if (value >= 1000)
        {
            return Bignumber(value);
        }
        else
        {
            return value.ToString();
        }
    }

    private static string Bignumber(int value)
    {
        int intValue = (int)(value / 1000);
        float remainder = value % 1000;
        float remainderFractionalPart = remainder / 100;
        int intValueFractionalPart = Mathf.FloorToInt(remainderFractionalPart);

        var stringBuilder = UIManager.instance.StringBuilder.Clear();

        if (intValueFractionalPart > 0)
        {
            stringBuilder.Append(intValue)
                .Append(",")
                .Append(intValueFractionalPart)
                .Append("k");

            return stringBuilder.ToString();
        }
        else
        {
            stringBuilder.Append(intValue)
                .Append("k");
            return stringBuilder.ToString();
        }
    }

    public int GetLanguageID() => languageId;
    public void SetLanguageID(int index)
    {
        //DataHolder.Instance().Reload();
        //StartCoroutine(ChangeLanguageCoroutine(index));

        languageId = index;
        deviceLocalSetting.LanguageId = languageId;
        OnChangeLanguage();
    }

    //IEnumerator ChangeLanguageCoroutine(int index)
    //{
    //    while (!DataHolder.Instance().GetData<Dialog>(0).HaveData(languageId))
    //    {
    //        yield return null;
    //    }

    //    languageId = index;
    //    deviceLocalSetting.LanguageId = languageId;
    //    //PlayerPrefs.SetInt(KEY_LANGUAGE_ID, index);

    //    OnChangeLanguage();
    //    yield return null;
    //    DataHolder.Instance().LoadLanguageIDs(languageId);
    //    yield return null;
    //    dialogCache = DataHolder.Instance().GetDatas<Dialog>();

    //    //===========================================
    //    //languageId = index;
    //    //deviceLocalSetting.LanguageId = languageId;
    //    //OnChangeLanguage();
    //    //yield break;
    //}

    public void ExitWatchMode()
    {
        if (watchCoroutine != null)
        {
            StopCoroutine(watchCoroutine);
        }
        IsWatchMode = false;

        //Can be null on reload
        if (ClientManager.instance.myCharacter != null)
        {
            cam.GetComponent<CharacterCamera>().FlowMyPlayer();
        }
        FindView<HUDView>().DisableArenaUI();
        LoadDefaultView();
        EnableJoystick(true);
    }

    public void ExitPlacementWatchMode()
    {
        if (watchCoroutine != null)
        {
            StopCoroutine(watchCoroutine);
        }
        IsWatchMode = false;

        if (ClientManager.instance.myCharacter != null)
        {
            cam.GetComponent<CharacterCamera>().FlowMyPlayerSmooth();
        }
        FindView<HUDView>().DisableArenaUI();
        LoadDefaultView();
        EnableJoystick(true);
    }

    public void EnterInMatchMode()
    {
        if (watchCoroutine != null)
        {
            StopCoroutine(watchCoroutine);
        }
        IsWatchMode = false;
        cam.GetComponent<CharacterCamera>().FlowMyPlayer();
        LoadDefaultView();
        EnableJoystick(true);
    }


    public void EnterWatchMode()
    {
        if (IsWatchMode)
        {
            return;
        }

        SetLastTimeClick();
        SetWatchMode();
    }

    public void EnterPlacementWatchMode(Vector2 position, float cameraSize)
    {
        if (IsWatchMode)
        {
            return;
        }

        SetLastTimeClick();
        EnableJoystick(false);
        IsWatchMode = true;
        CloseDefaultView();
        cam.GetComponent<CharacterCamera>().SetMode(CharacterCamera.FlowMode.LockPlacementVillage, null, position, cameraSize);
    }

    public void SetWatchMode()
    {
        IsWatchMode = !IsWatchMode;

        if (IsWatchMode)
        {
            watchCoroutine = StartCoroutine(WatchCO(GetArenaId()));
        }
        else
        {
            if (watchCoroutine != null)
            {
                StopCoroutine(watchCoroutine);
            }

            cam.GetComponent<CharacterCamera>().FlowMyPlayer();
            FindView<HUDView>().DisableArenaUI();
            LoadDefaultView();
            EnableJoystick(true);
        }
    }

    private IEnumerator WatchCO(int arenaId)
    {
        IsWatchMode = false;
        var arenaBehaviorLocal = EventManager.instance.GetArenaBehaviorLocal(arenaId);
        if (arenaBehaviorLocal == null)
        {
            yield break;
        }
        EnableJoystick(false);

        IsWatchMode = true;

        CloseDefaultView();
        yield return MCPCoroutines.WaitFor(0.2f);

        var mode = CharacterCamera.FlowMode.LockArenaPVP;
        if (arenaBehaviorLocal.arenaConfig.arenaType == ArenaType.ClanWar)
        {
            mode = CharacterCamera.FlowMode.LockArenaClanWar;
        }
        cam.GetComponent<CharacterCamera>().SetMode(mode, null, arenaBehaviorLocal.transform.position, arenaBehaviorLocal.cameraSize);

        ArenaResponse arenaResponse = new()
        {
            ArenaID = arenaId,
            ArenaState = arenaBehaviorLocal.ClientGetState(),
            ResponseType = ArenaResponseType.ChangeState
        };
        HandleArenaResponse(arenaResponse);
    }

    public void SetUpCameraInfo()
    {
        var arenaBehaviorLocal = EventManager.instance.GetArenaBehaviorLocal(arenaId);
        if (arenaBehaviorLocal == null)
        {
            return;
        }

        FindView<HUDView>().IsInMatch = true;
        var characterCamera = cam.GetComponent<CharacterCamera>();
        var mode = CharacterCamera.FlowMode.LockArenaPVP;
        if (arenaBehaviorLocal.arenaConfig.arenaType == ArenaType.ClanWar)
        {
            mode = CharacterCamera.FlowMode.LockArenaClanWar;
        }
        characterCamera.SetMode(mode, null, arenaBehaviorLocal.transform.position, arenaBehaviorLocal.cameraSize);
    }

    public void SetUpCameraInMatch()
    {
        var arenaBehaviorLocal = EventManager.instance.GetArenaBehaviorLocal(arenaId);
        if (arenaBehaviorLocal == null)
        {
            return;
        }

        SetCameraInMatchMode(arenaBehaviorLocal);
    }

    public void LoadSettingCameraZoom(bool value)
    {
        isCameraZoomIn = value;
    }

    public void OnClickCameraZoom()
    {
        var arenaBehaviorLocal = EventManager.instance.GetArenaBehaviorLocal(arenaId);
        if (arenaBehaviorLocal == null)
        {
            return;
        }

        IsCameraZoomIn = !IsCameraZoomIn;
        SetCameraInMatchMode(arenaBehaviorLocal);
    }

    private void SetCameraInMatchMode(ArenaBehavior arenaBehaviorLocal)
    {
        FindView<HUDView>().IsInMatch = true;
        var characterCamera = cam.GetComponent<CharacterCamera>();

        if (IsCameraZoomIn)
        {
            characterCamera.FlowMyPlayer();
        }
        else
        {
            var mode = CharacterCamera.FlowMode.LockArenaPVP;
            if (arenaBehaviorLocal.arenaConfig.arenaType == ArenaType.ClanWar)
            {
                mode = CharacterCamera.FlowMode.LockArenaClanWar;
            }
            characterCamera.SetMode(mode, null, arenaBehaviorLocal.transform.position, arenaBehaviorLocal.cameraSize);
        }
    }

#if ENABLE_CLIENT
    public void ReloadBasementView()
    {
        var hudInventoryGroup = HUDSystem.Instance.GetElement(HUDElementId.InventoryGroup);
        if (hudInventoryGroup == null)
            return;
        int inventoryExtraOffset = Mathf.Max(0, activeInventoryExtraRowCount) * InventoryView.INVENTORY_ROW_HEIGHT;

        var inventoryView = FindView<InventoryView>();
        var characterView = FindView<CharacterView>();
        var hudView = FindView<HUDView>();
        var itemView = FindView<ItemView>();

        if (hudInventoryGroup.CurrentState == HUDElementState.On)
        {
            inventoryView.ChangePosAnchorRefUI(inventoryExtraOffset);
            characterView.MoveYRect(inventoryExtraOffset);
            hudView.MoveYRect(inventoryExtraOffset);
            itemView.MoveYRect(inventoryExtraOffset);
        }
        else if (hudInventoryGroup.CurrentState == HUDElementState.Off)
        {
            int offset = -InventoryView.INVENTORY_ROW_HEIGHT;
            inventoryView.ChangePosAnchorRefUI(offset);
            characterView.MoveYRect(offset);
            hudView.MoveYRect(offset);
            itemView.MoveYRect(offset);
        }

        //hudView.ReloadFunctionAndSkillGroups();
    }
#endif

    public void EnableJoystick(bool active)
    {
        enableJoystick = active;

        if (joystickType == JoystickType.Fixed)
        {
            fixedJoystick.gameObject.SetActive(active);
        }
        else if (joystickType == JoystickType.Floating)
        {
            floatingJoystick.gameObject.SetActive(active);
        }
        else if (joystickType == JoystickType.Dynamic)
        {
            dynamicJoystick.gameObject.SetActive(active);
        }
    }

    public void SetNotifyMenuPanel(NotifyMenuPanel notifyMenuPanel)
    {
        SetLegacyNotificationState(notifyMenuPanel, true);
        if (notifyMenuPanel == NotifyMenuPanel.NewQuest)
        {
            return;
        }

        FindView<HUDView>().NotifyMenuPanel(notifyMenuPanel, true);
    }

    public void OnClickClan(int tabIndex = -1)
    {
#if ENABLE_CLIENT

        ClanViewParam param = new()
        {
            IndexTabTarget = tabIndex
        };

        var myCharacter = ClientManager.instance.myCharacter;
        if (myCharacter == null)
        {
            BattleManager.Log(GameLogType.Debug, "My charater is null");
            return;
        }
        if (string.IsNullOrEmpty(myCharacter.clanId))
        {
            //Debug.Log("My charater clan id error");
            FindView<NoClanView>().Load(param);
            return;
        }
        else if (myCharacter.clanId == GameConst.ASSASIN_CLAN_KEY || myCharacter.clanId == GameConst.ROYALFORCE_CLAN_KEY)
        {
            FindView<NpcClanView>().Load(param);
            return;
        }
        else
        {
            StartCoroutine(ChangeTab());
        }
        IEnumerator ChangeTab()
        {
            var view = FindView<ClanView>();
            view.Load(param);
            yield return null;
        }
#endif
    }

    public void DisableChatNotifyIcon()
    {
        SetLegacyNotificationState(NotifyMenuPanel.NewClanChat, false);
        var hudView = FindView<HUDView>();
        if (NotifyDotManager.Instance.IsActive(NotificationKeys.ClanRequest))
        {
            hudView.NotifyMenuPanel(NotifyMenuPanel.NewRequestJoinClan, true);
        }
    }

    private void SetLegacyNotificationState(NotifyMenuPanel notifyMenuPanel, bool active)
    {
        switch (notifyMenuPanel)
        {
            case NotifyMenuPanel.NewClanChat:
                NotifyDotManager.Instance.SetState(NotificationKeys.ClanChatSystem, active);
                NotifyDotManager.Instance.SetState(NotificationKeys.ClanChatMember, active);
                break;
            case NotifyMenuPanel.NewRequestJoinClan:
                NotifyDotManager.Instance.SetState(NotificationKeys.ClanRequest, active);
                break;
            case NotifyMenuPanel.NewQuest:
                NotifyDotManager.Instance.RefreshQuestNotifications();
                break;
        }
    }

    public void OnArenaToastView(int dialogId)
    {
        if (dialogId == 368)
        {
            FindView<HUDView>().EnableArenaWin();
        }
        else if (dialogId == 369)
        {
            FindView<HUDView>().EnableArenaLose();
        }
        else if (dialogId == 372)
        {
            FindView<HUDView>().EnableArenaDraw();
        }
        else if (dialogId == 1008)
        {
            FindView<HUDView>().OnNotifyMiddle(UIManager.GetDialog(1008));
        }
        //Unlock camera
        cam.GetComponent<CharacterCamera>().FlowMyPlayer();
    }

    [ContextMenu("Test12")]
    public void Test1()
    {
        //https://dl.memuplay.com/new_market/img/com.megacombat.treasurehunter.icon.2024-08-02-11-43-06.png
        //https://discord.gg/gGFebazYYK
        IngameNotifyManager.instance.
            OnLinkNotify("https://dl.memuplay.com/new_market/img/com.megacombat.treasurehunter.icon.2024-08-02-11-43-06.png",
            "",
            true,
            0f);

    }

    public void OnCraftView()
    {
        FindView<CraftView>().Load();
    }
    public void OnIngredientView()
    {
        var view = FindView<IngredientView>();
        view.Load(ClientManager.instance.myCharacter);
        view.Load();
    }

    public void OnEnableDragDrop(bool isOn)
    {
        playerLocalSetting.IsEnableDragDrop = isOn;
        FindView<InventoryView>().IsEnableDragDrop = isOn;
    }

    public void OnEnterVillageBuilding(VillageBuilding villageBuilding)
    {
        string mainBuildingId = battleManager.GetMainBuildingId(villageBuilding);
        var mainBuilding = ClientManager.instance.GetLocalPlayerBehavior(mainBuildingId);
        if (mainBuilding == null)
            return;

        var myClanId = ClientManager.instance.myCharacter.clanId;
        if (string.IsNullOrEmpty(myClanId) || mainBuilding.clanId != myClanId)
            return;

        FindView<BuildingListView>().VillageId = villageBuilding.villageId;
        EnableNpcButton(UIManager.GetDialog(83), OnBuildingListView);
    }

    public void OnBuildingListView() 
    {
        SetLastTimeClick();
        FindView<BuildingListView>().Load();
    } 

    public void OnEnterVikingVillage()
    {
        EnableNpcButton(UIManager.GetDialog(1230), ConfimSummonViking);
    }

    private void ConfimSummonViking()
    {
        if (string.IsNullOrEmpty(ClientManager.instance.myCharacter.clanId))
        {
            IngameNotifyManager.instance.Notify(ErrorCode.ClanNotJoin);
            return;
        }

        IngameNotifyManager.instance.Notify(532, () => SummonViking());
    }

    private void SummonViking()
    {
        var euipmentId = ClientManager.instance.myCharacter.characterInventory.GetSummonViking();
        if (string.IsNullOrEmpty(euipmentId))
            return;
        ClientManager.instance.myCharacter.RequestUseItem(euipmentId, ClientManager.instance.GetApiToken());
    }

    public void OnEnterMerge() => EnableNpcButton(GetDialog(625), OnMergeIngredientView);
    private void OnMergeIngredientView() => FindView<MergeIngredientView>().Load();
    public IEnumerator CallbackAutoMergeIngredientCO(string equipmentID)
    {
        yield return null;

        float timeReload = 0;
        Equipment equipment = null;
        while (equipment == null)
        {
            equipment = ClientManager.instance.myCharacter.GetEquipment(equipmentID);
            timeReload += Time.deltaTime;

            if (timeReload > 10)
            {
                yield break;
            }

            yield return null;
        }

        //itemView.LoadData(equipment, true, myCharacter);
        var view = UIManager.instance.FindView<RewardView>();
        view.GetRewardPopUpUI().AppendEquipment(equipment).Process().Load();
    }

    public void OnEnterVillageGovernor() => EnableNpcButton(GetDialog(686), OnQuestView);
    private void OnQuestView()
    {
        FindView<HUDView>().GetButtonNPC().gameObject.SetActive(false);
        FindView<QuestView>().Load();
    }

    public void OnEnterClanManager() => EnableNpcButton(GetDialog(1116), OnClanManagerView);
    public void OnClanManagerView() => FindView<ClanManagerView>().Load();
    public void OnEnterShop()
    {
        FindView<HUDView>().GetButtonNPC().gameObject.SetActive(false);
        EnableNpcButton(GetDialog(503), OnShopView);
    }

    public void OnEnterArenaShop()
    {
        FindView<HUDView>().GetButtonNPC().gameObject.SetActive(false);
        EnableNpcButton(GetDialog(1117), OnArenaShopView);
    }

    public void OnUnlockJailView()
    {
        FindView<HUDView>().GetButtonNPC().gameObject.SetActive(false);
        EnableNpcButton(GetDialog(1121), OpenUnlockJailView);
    }

    public void OnShopView()
    {
        // ✅ SERVER-ONLY: Add null check for SoundManager (may not exist in headless mode)
        if (SoundManager.instance != null)
            SoundManager.instance.SpawnSound("FoundItem", 0, 1);

        FindView<ShopV2View>(SHOP_VIEW).Load();
    }

    public void OnArenaShopView()
    {
        // ✅ SERVER-ONLY: Add null check for SoundManager (may not exist in headless mode)
        if (SoundManager.instance != null)
            SoundManager.instance.SpawnSound("FoundItem", 0, 1);

        FindView<ShopView>(ARENA_SHOP_VIEW).Load();
    }

    public void OpenUnlockJailView()
    {
        FindView<UnlockJailView>().Load();
    }


    public void OpenHistoryRewardView()
    {
#if ENABLE_CLIENT
        FindView<HistoryRewardView>().Load();
#endif
    }

    public void OpenAnnouncementView()
    {
#if ENABLE_CLIENT
        FindView<AnnouncementView>().Load();
#endif
    }

    public void OnEnterColosseum() => EnableNpcButton(GetDialog(333), OpenColosseumView);
    public void OnEnterClanWar() => EnableNpcButton(GetDialog(691), OpenClanWarView);
    public void OnEnterEvent() => EnableNpcButton(GetDialog(1118), OpenEventView);
    private void OpenColosseumView() => FindView<ColosseumView>(COLOSSEUM_VIEW).Load();
    private void OpenClanWarView() => FindView<ColosseumView>(CLAN_WAR_VIEW).Load();
    private void OpenEventView() => FindView<EventView>().Load();
    public void OnEnterArtifact() => EnableNpcButton(GetDialog(318), OpenArtifactView);
    private void OpenArtifactView()
    {
        FindView<ArtifactView>().Load();
        FindView<HUDView>().GetButtonNPC().gameObject.SetActive(false);
    }
    public void OnEnterAssassin() => EnableNpcButton(GetDialog(689), OpenAssasinView);
    private void OpenAssasinView() => FindView<AssasinView>().Load();
    public void OnEnterRoyalGuard() => EnableNpcButton(GetDialog(688), OpenRoyalForceView);
    private void OpenRoyalForceView() => FindView<RoyalForceView>().Load();
    public void OnEnterChangeName() => EnableNpcButton(GetDialog(382), OpenChangeName);
    public void OnEnterGuardian() => EnableNpcButton("FAQ", OpenFAQView);
    public void OpenFAQView()
    {
#if ENABLE_CLIENT
        FindView<FAQView>().Load();
#endif
    }

    private void OpenChangeName() => FindView<ChangeNameView>(CHANGE_NAME_VIEW).Load();

    public void OnEnterTeleport()
    {
        if (BattleManager.IsCompleteBeginnerQuest(ClientQuestManager.Instance.GetMyBeginnerQuestData()))
        {
            EnableNpcButton(GetDialog(1119), OpenTeleportView);
        }
    }
    public void OnEnterHealerShop() => EnableNpcButton(GetDialog(1122), OpenHealerShop);
    private void OpenHealerShop() => FindView<ShopV2View>(SHOP_HEALER_VIEW).Load();

    public void OnEnterFactionWar() => EnableNpcButton(GetDialog(1006), OpenFactionWarView);
    private void OpenFactionWarView()
    {
        DisableNpcButton();
        FindView<FactionWarView>().Load();
    }

    public void OnEnterFactionWarUnregister() => EnableNpcButton(GetDialog(366), OpenFactionWarUnregisterView);
    private void OpenFactionWarUnregisterView()
    {
        DisableNpcButton();
        FindView<FactionWarUnregisterView>().Load();
    }

    public void OnEnterSurvivalWar() => EnableNpcButton(GetDialog(1123), OpenSurvivalBattleView);
    private void OpenSurvivalBattleView()
    {
        DisableNpcButton();
        FindView<SurvivalBattleView>().Load();
    }
    public void OnEnterNPCShip() => EnableNpcButton(GetDialog(1086), OpenShipLandView);
    private void OpenShipLandView() => FindView<ShipLandView>().Load();

    public void OnEnterNPCCosmeticShop() => EnableNpcButton(GetDialog(1334), OpenCosmeticShop);
    public void OpenCosmeticShop() => FindView<CosmeticShopView>().Load();


    private void OpenTeleportView() => FindView<TeleportView>().Load();

    public void OnEnterTeleportNPC()
    {
        var myChar = ClientManager.instance.myCharacter;
        if (myChar == null)
            return;

        if (myChar.IsInCenterLand())
        {
            EnableNpcButton(GetDialog(1120), OpenViewTeleportToUndeadLand);
        }
        else if (myChar.IsInUndeadLand())
        {
            EnableNpcButton(GetDialog(1119), OpenViewTeleportUndeadLandToCenterLand);
        }
        else if (myChar.IsInWarLand())
        {
            EnableNpcButton(GetDialog(1119), OpenViewTeleportBattleModeBackToCenterLand);
        }
        else if (myChar.IsInSurvivalLand())
        {
            EnableNpcButton(GetDialog(1119), OpenViewTeleportBattleModeBackToCenterLand);
        }
    }

    private void OpenViewTeleportToUndeadLand()
    {
        DisableNpcButton();
        OpenView<TeleportUndeadView>();
    }
    private void OpenViewTeleportUndeadLandToCenterLand()
    {
        DisableNpcButton();
        OpenView<TeleportBackToCenterLandView>(UNDEAD_LAND_MODE);
    }
    private void OpenViewTeleportBattleModeBackToCenterLand()
    {
        DisableNpcButton();
        OpenView<TeleportBackToCenterLandView>(BATTLE_MODE);
    }


    public void NavigationToUndeadView(BaseView sender)
    {
        backView = sender;
        FindView<TeleportUndeadView>().ViewUndeadLandPrize();
    }

    private void EnableNpcButton(string text, Action action)
    {
        if (npcButtonTween != null)
        {
            npcButtonTween.Kill();
        }

        var view = FindView<HUDView>();
        var button = view.GetButtonNPC();
        button.text.text = text;
        view.ClearActionOnButtonNpcPanel();
        view.OnClickButtonNpcPanel += action;
        npcButtonTween = button.transform.DOScaleX(1, TweenDuration).From(0.15f);
        button.gameObject.SetActive(true);
    }
    public void DisableNpcButton()
    {
        var button = FindView<HUDView>().GetButtonNPC();
        if (button.gameObject.activeSelf == false)
        {
            return;
        }

        if (npcButtonTween != null)
        {
            npcButtonTween.Kill();
        }

        npcButtonTween = button.transform.DOScaleX(0, TweenDuration).OnComplete(DeActive);

        void DeActive()
        {
            FindView<HUDView>().GetButtonNPC().gameObject.SetActive(false);
        }
    }

    private void UpdateVillageBuildButton(float deltaTime)
    {
        villageBuildButtonRefreshTimer += deltaTime;
        if (villageBuildButtonRefreshTimer < VillageBuildButtonRefreshInterval)
        {
            return;
        }

        villageBuildButtonRefreshTimer = 0f;
        RefreshVillageBuildButton(false);
    }

    internal void RefreshVillageBuildButton(bool force)
    {
        if (BuildingPlacementController.Instance.IsPlacing || !TryGetBuildableVillageId(out string villageId))
        {
            if (isVillageBuildButtonActive)
            {
                isVillageBuildButtonActive = false;
                activeVillageBuildButtonVillageId = "";
                DisableVillageBuildButton();
            }

            return;
        }

        if (!force && isVillageBuildButtonActive && activeVillageBuildButtonVillageId == villageId)
        {
            return;
        }

        FindView<BuildingListView>().VillageId = villageId;
        EnableVillageBuildButton();
        isVillageBuildButtonActive = true;
        activeVillageBuildButtonVillageId = villageId;
    }

    private bool TryGetBuildableVillageId(out string villageId)
    {
        villageId = "";

        if (ClientClanManager.Instance == null || ClientManager.instance == null || WorldManager.Instance == null)
        {
            return false;
        }

        var myCharacter = ClientManager.instance.myCharacter;
        if (myCharacter == null || myCharacter.GetHealth() <= 0)
        {
            return false;
        }

        var clanData = ClientClanManager.Instance.GetClanData();
        if (clanData == null || string.IsNullOrEmpty(clanData.villageId) || !clanData.CanBuild(myCharacter.userName))
        {
            return false;
        }

        VillageData clanVillage = BattleManager.instance != null ? BattleManager.instance.GetVillageData(clanData.villageId) : null;
        if (clanVillage == null || !myCharacter.IsPositionInsideVillage(clanVillage, myCharacter.transform.position))
        {
            return false;
        }

        villageId = clanVillage.id;
        return true;
    }

    private void EnableVillageBuildButton()
    {
        FindView<HUDView>().SetActiveBuildButtonUI(true);
    }

    public void DisableVillageBuildButton()
    {
        isVillageBuildButtonActive = false;
        activeVillageBuildButtonVillageId = "";

        FindView<HUDView>().SetActiveBuildButtonUI(false);
    }

    private void EnableBuildingButton(string text, Action action)
    {
        if (buildingButtonTween != null)
        {
            buildingButtonTween.Kill();
        }

        var view = FindView<HUDView>();
        var button = view.GetButtonBuilding();
        button.text.text = text;
        view.ClearActionOnButtonBuildingPanel();
        view.OnClickButtonBuildingPanel += action;
        buildingButtonTween = button.transform.DOScaleX(1, TweenDuration).From(0.15f);
        button.gameObject.SetActive(true);
    }

    public void DisableBuildingButton()
    {
        var button = FindView<HUDView>().GetButtonBuilding();
        if (button.gameObject.activeSelf == false)
        {
            return;
        }

        if (buildingButtonTween != null)
        {
            buildingButtonTween.Kill();
        }

        buildingButtonTween = button.transform.DOScaleX(0, TweenDuration).OnComplete(DeActive);

        void DeActive()
        {
            FindView<HUDView>().GetButtonBuilding().gameObject.SetActive(false);
        }
    }

    public void SuppressBuildingButtonUntilExit()
    {
        ignoreBlessingTowerEnterUntilExit = true;
        DisableBuildingButton();
    }

    public void OnExitBlessingTower()
    {
        ignoreBlessingTowerEnterUntilExit = false;
        DisableBuildingButton();
    }

    public void OnEnterBlessingTower(PlayerBehavior playerBehavior)
    {
        if (ignoreBlessingTowerEnterUntilExit)
            return;

        if (playerBehavior == null)
            return;

        currentBlessingTowerBuildingId = playerBehavior.userName;

        var hudView = FindView<HUDView>();
        hudView.ResetButtonBuildingBlessingBuff();

        bool loadedBlessingStat = false;
        if(BuildingEquipmentCache.TryGetBuildingPartStats(playerBehavior.userName, 
            BLESSING_TOWER_BUFF, out var stats))
        {
            loadedBlessingStat = TryLoadBlessingStatToButton(hudView, stats);
        }

        if (loadedBlessingStat == false && playerBehavior.characterEquipments != null)
        {
            var equipments = playerBehavior.characterEquipments.GetEquipments();
            BuildingEquipmentCache.Set(playerBehavior.userName, equipments);

            for (int i = 0; i < equipments.Count; i++)
            {
                var equipment = equipments[i];
                if (equipment == null || equipment.itemId != BLESSING_TOWER_BUFF)
                {
                    continue;
                }

                loadedBlessingStat = TryLoadBlessingStatToButton(hudView, equipment.GetStats(equipment.level));
                break;
            }
        }

        if (loadedBlessingStat == false)
        {
            DisableBuildingButton();

            if (ClientManager.instance != null && ClientManager.instance.myCharacter != null)
            {
                ClientManager.instance.myCharacter.RequestGetClanBuildingEquipment(ClientManager.instance.GetApiToken(), playerBehavior.userName);
            }

            return;
        }

        EnableBuildingButton(GetDialog(1448), OnReceiveBlessingBuff);
    }


    private void OnOpenBuildingListView()
    {
        SetLastTimeClick();

        var buildingListView = FindView<BuildingListView>();
        if(buildingListView != null)
        {
            buildingListView.Load();
        }
    }

    private bool TryLoadBlessingStatToButton(HUDView hudView, StatValue[] stats)
    {
        if (stats == null || stats.Length == 0)
        {
            return false;
        }

        hudView.OnLoadDataToButtonBuilding(stats[0].statType);
        return true;
    }
    public void OnReceiveBlessingBuff()
    {
        SetLastTimeClick();

        var myCharacter = ClientManager.instance.myCharacter;
        if (myCharacter == null || string.IsNullOrEmpty(currentBlessingTowerBuildingId))
            return;

        myCharacter.RequestReceiveBlessingBuff(currentBlessingTowerBuildingId, ClientManager.instance.GetApiToken());
    }

    public void OnEnterTrap(TrapBehavior trap)
    {
#if ENABLE_CLIENT || UNITY_LOCAL_HOST
        PlayerBehavior player = ClientManager.instance != null ? ClientManager.instance.myCharacter : null;
        if (trap == null || player == null || trap.OwnerCharacterId != player.userName) return;
        if (nearbyRepairTraps.Add(trap))
        {
            nextTrapRepairRefresh = 0;
            UpdateTrapRepairButton();
        }
#endif
    }

    public void OnExitTrap(TrapBehavior trap)
    {
        nearbyRepairTraps.Remove(trap);
        nextTrapRepairRefresh = 0;
        UpdateTrapRepairButton();
    }

    private void UpdateTrapRepairButton()
    {
#if ENABLE_CLIENT || UNITY_LOCAL_HOST
        if (!InitializedComplete) return;
        if (Time.unscaledTime < nextTrapRepairRefresh) return;
        nextTrapRepairRefresh = Time.unscaledTime + 0.1f;
        if (trapRepairPending && Time.unscaledTime >= trapRepairPendingUntil)
            trapRepairPending = false;

        PlayerBehavior player = ClientManager.instance != null ? ClientManager.instance.myCharacter : null;
        HUDView hud = FindView<HUDView>();
        currentRepairTrap = null;
        if (!NetworkClient.isConnected || player == null)
        {
            ClearTrapRepairInteraction();
            return;
        }

        if (player.GetHealth() > 0 && player.isActive && hud != null && hud.IsOpen &&
            !(WorldPlacementController.Current?.IsPlacing ?? false))
        {
            float nearestDistance = float.MaxValue;
            foreach (TrapBehavior trap in nearbyRepairTraps)
            {
                if (trap == null || !trap.gameObject.activeInHierarchy ||
                    trap.State != TrapState.AwaitingRepair || trap.OwnerCharacterId != player.userName ||
                    !trap.IsWithinRepairRange(player)) continue;
                float distance = ((Vector2)trap.transform.position - (Vector2)player.transform.position).sqrMagnitude;
                if (distance < nearestDistance || distance == nearestDistance &&
                    string.CompareOrdinal(trap.userName, currentRepairTrap?.userName) < 0)
                {
                    currentRepairTrap = trap;
                    nearestDistance = distance;
                }
            }
        }
        hud?.SetTrapRepairButtonState(currentRepairTrap != null, trapRepairPending, currentRepairTrap);
#endif
    }

    public void OnRepairTrap()
    {
#if ENABLE_CLIENT || UNITY_LOCAL_HOST
        // Revalidate at click, not only at the previous HUD refresh.
        nextTrapRepairRefresh = 0;
        UpdateTrapRepairButton();
        PlayerBehavior player = ClientManager.instance != null ? ClientManager.instance.myCharacter : null;
        if (trapRepairPending || currentRepairTrap == null || player == null) return;
        trapRepairPending = true;
        trapRepairPendingUntil = Time.unscaledTime + 10f;
        FindView<HUDView>()?.SetTrapRepairButtonState(true, true, currentRepairTrap);
        SetLastTimeClick();
        player.RequestRepairTrap(currentRepairTrap.userName, ClientManager.instance.GetApiToken());
#endif
    }

    public void OnRepairTrapResult(TrapRepairResult result)
    {
        trapRepairPending = false;
        nextTrapRepairRefresh = 0;
        UpdateTrapRepairButton();
        if (result != TrapRepairResult.Success)
            IngameNotifyManager.instance?.OnMiddleNotify(result switch
            {
                TrapRepairResult.NotOwner => "Only the Trap owner can repair it.",
                TrapRepairResult.OutOfRange => "Move into the Trap's interaction range to repair.",
                TrapRepairResult.InsufficientDiamond => "Repair requires 10 Diamond.",
                TrapRepairResult.NotRepairable => "This Trap is not awaiting repair, has expired, or has no repairs left.",
                _ => "Trap repair is currently unavailable.",
            });
    }

    private void ClearTrapRepairInteraction()
    {
        nearbyRepairTraps.Clear();
        currentRepairTrap = null;
        trapRepairPending = false;
        trapRepairPendingUntil = 0;
        nextTrapRepairRefresh = 0;
        FindView<HUDView>()?.SetTrapRepairButtonState(false, false);
    }

    public void TryDoActionPayTH(BaseView sender, int cost, Action actionPassCode, Action actionWithOutPassCode, int dialogId = 699)
    {
        var myCharacter = ClientManager.instance.myCharacter;
        if (myCharacter.characterWallet.token < cost)
        {
            IngameNotifyManager.instance.Notify(ErrorCode.InsufficientMoney, NavigationToTHShop);

            void NavigationToTHShop()
            {
                NavigationToBuyTH(sender);
                sender.Close();
            }

            return;
        }

        if (ClientManager.instance.isHaveDataWalletPassCode)
        {
            var walletPassCode = ClientManager.instance.walletPassCode;
            if (string.IsNullOrEmpty(walletPassCode))
            {
                CheckPin(actionPassCode);
            }
            else
            {
                IngameNotifyManager.instance.Notify(dialogId, actionPassCode);
            }
        }
        else
        {
            IngameNotifyManager.instance.Notify(dialogId, actionWithOutPassCode);
        }
    }

    public void CheckPin(Action onSuccess)
    {
        OpenView<PinView>();
        PinView.OnVerifyPinSuccess = onSuccess;
    }


    public void NavigationToBuyTH(BaseView sender)
    {
        backView = sender;

        var shopIAP = FindView<ShopView>(SHOP_IAP_VIEW);
        shopIAP.Load();
        shopIAP.ScrollBottom();
    }

    public void NavigationToIAP(BaseView sender)
    {
        backView = sender;
        var shopIAP = FindView<ShopView>(SHOP_IAP_VIEW);
        shopIAP.Load();
        shopIAP.SetTabIAP();
    }

    public void NavigationToSpendTH(BaseView sender)
    {
        backView = sender;

        var shopIAP = FindView<ShopView>(SHOP_IAP_VIEW);
        shopIAP.Load();
        shopIAP.ScrollTHBottom();
    }

    public void NavigationToShopTHSkipAd(BaseView sender)
    {
        backView = sender;

        var shopIAP = FindView<ShopView>(SHOP_IAP_VIEW);
        shopIAP.Load();
        shopIAP.ScrollToSkipAd();
    }

    public void NavigationToBuyAuto(BaseView sender, VipBonusType vipBonusType)
    {
        //backView = sender;
        var automationView = FindView<AutomationV2View>();
        automationView.Load();
        automationView.SwitchTabBuyAuto(vipBonusType);
    }

    public ShopUI GetShopUI(ShopId id)
    {
        foreach (var shop in shopUIs)
        {
            if (shop.shopId == id)
            {
                return shop;
            }
        }
        return null;
    }
    public FAQDataSO GetFaqStat(StatType statType)
    {
        return fAQDataHolder.GetStat(statType);
    }

    public FAQDataSO GetFaqIngredient(StatType statType)
    {
        return fAQDataHolder.GetIngredient(statType);
    }

    public void DisplayWiki(int mobId, bool displayAtTop, BaseView sender = null)
    {
        var data = fAQDataHolder.GetMobInfo(mobId);
        DisplayWiki(data, displayAtTop, sender);
    }

    public void DisplayWiki(FAQDataSO data, bool displayAtTop, BaseView sender = null)
    {
        FindView<HelpViewPopup>().SetView(data, displayAtTop, sender).Load();
    }

    public void DisplayWiki(QuestLevelData questData, FAQDataSO data, bool displayAtTop = false, BaseView sender = null)
    {

        FindView<HelpViewPopup>().SetView(questData, data, displayAtTop, sender).Load();
    }
    public void DisplayWiki(List<FAQDataSO> dataList, bool displayAtTop, BaseView sender = null)
    {
        FindView<HelpViewPopup>().SetView(dataList, displayAtTop, sender).Load();
    }
    public void OnGetGameDataConfig(GameDataConfig data)
    {
        if (data == null) return;
        var hudView = FindView<HUDView>();
        if (hudView != null)
        {
            hudView.OnGetGameDataConfig(data);
        }

        loadingView.OnGetGameDataConfig(data);
    }

    public void OnReceiveCurrency(CharacterInventory.OnReceiveCurrencyEvent param)
    {
        FindView<HUDView>().IncreaseCurrency(param.current, param.increase, (CurrencyID)param.currencyID);
        RefreshQuestAfterCurrencyChanged((CurrencyID)param.currencyID, param.current + param.increase);
    }

    private void OnCurrencyDataChanged(CharacterInventory.CurrencyEventData param)
    {
        RefreshQuestAfterCurrencyChanged(param.CurrencyID, param.NewValue);
    }

    private void OnQuestRelevantItemChanged(CharacterItems.QuestRelevantItemChangedEvent param)
    {
        RefreshQuestAfterRelevantDataChanged();
    }

    private void RefreshQuestAfterCurrencyChanged(CurrencyID currencyID, int newValue)
    {
        var myCharacter = ClientManager.instance?.myCharacter;
        if (myCharacter != null && currencyID == CurrencyID.CraftScore)
        {
            myCharacter.SetCraftNumber(newValue);
        }

        RefreshQuestAfterRelevantDataChanged();
    }

    private bool pendingQuestRelevantDataRefresh;

    private void RefreshQuestAfterRelevantDataChanged()
    {
        if (pendingQuestRelevantDataRefresh)
        {
            return;
        }

        pendingQuestRelevantDataRefresh = true;
        StartCoroutine(RefreshQuestAfterRelevantDataChangedCO());
    }

    private IEnumerator RefreshQuestAfterRelevantDataChangedCO()
    {
        yield return null;
        pendingQuestRelevantDataRefresh = false;

        var questView = FindView<DailyQuestsView>();
        if (questView != null && questView.GetDirtyCurrentTab(questView.TabIndex))
        {
            questView.MarkAllQuestTabsDirty();
            questView.ReloadCurrentTab();
        }

        NotifyDotManager.Instance.RefreshQuestNotifications();
    }

    public void OnEvenItemData(CharacterInventory.EvenItemData param)
    {
#if ENABLE_CLIENT
        InventoryView view = FindView<InventoryView>();
        CraftView craftView = FindView<CraftView>();
        MyCharacterInfoView myCharacterInfoView = FindView<MyCharacterInfoView>();
        switch (param.Op)
        {
            case CharacterInventory.EvenItemData.Operation.Remove:
                view.UITweenRemoveEquipment(param.LocalEquipment);
                craftView.OnRemoveEquipment(param.LocalEquipment);
                BuildingView buildingView = FindView<BuildingView>();
                if (buildingView.IsOpen)
                    buildingView.BuildingInfoUI.OnPlayerEquipmentRemoved(param.LocalEquipment);
                myCharacterInfoView.ReloadAll(param.LocalEquipment);
                break;

            default: break;
        }
#endif
    }
    private void OnMyAutomationStateChange(AutomationState state)
    {
        //Check cho trường hợp mới login vào 1 player trong pool
        if (ClientManager.instance.myCharacter == null ||
            ClientManager.instance.myCharacter.isDataInitialized == false)
        {
            return;
        }

        if (state == AutomationState.AutoFarmWithShield)
        {
            IngameNotifyManager.instance.OnToastView(GetDialog(924));
        }
    }

    public void OnDead(CharacterHealth.OnDead onDead)
    {
        DisableNpcButton();
        DisableBuildingButton();
        FindView<HUDView>().OnDead();
        FindView<ItemView>().Close();

        //TODO: tắt các view full màn hình
        FindView<CollectionView>().Close();
        FindView<ShopView>(SHOP_IAP_VIEW).Close();
        FindView<MarketPlaceView>().Close();
        FindView<DailyQuestsView>().Close();
#if ENABLE_CLIENT
        FindView<ClanView>().Close();
        FindView<WalletView>().Close();
#endif
    }

    public void OnRevive()
    {
        var hudView = FindView<HUDView>();
        SetMinimizeMode(false);
        hudView.ApplyHUDLayoutSettingMode(IsMinimizeMode);

        // ✅ SERVER-ONLY: Add null check for SoundManager (may not exist in headless mode)
        if (SoundManager.instance != null)
            SoundManager.instance.PlayUISound("Click");
    }

    public void LoadJoyStick(JoystickType joystickType)
    {
        enableJoystick = true;
        this.joystickType = joystickType;
        if (joystickType == JoystickType.Fixed)
        {

            fixedJoystick.gameObject.SetActive(true);
            floatingJoystick.gameObject.SetActive(false);
            dynamicJoystick.gameObject.SetActive(false);
        }
        else if (joystickType == JoystickType.Floating)
        {
            fixedJoystick.gameObject.SetActive(false);
            floatingJoystick.gameObject.SetActive(true);
            dynamicJoystick.gameObject.SetActive(false);
        }
        else
        {
            SetActive(fixedJoystick, false);
            SetActive(floatingJoystick, false);
            SetActive(dynamicJoystick, true);
        }

        deviceLocalSetting.Joystick = joystickType;
        //PlayerPrefs.SetInt("JoyStickType", (int)joystickType);
    }

    public void LoadFps(FpsMode mode)
    {
        Application.targetFrameRate = mode == FpsMode.Fps60 ? 60 : 30;
        deviceLocalSetting.FpsSetting = mode;
    }

    public float GetJoysticVertical()
    {
        if (enableJoystick == false)
            return 0;

#if UNITY_EDITOR
        if (Input.GetKey(KeyCode.UpArrow))
            return 1f;
        else if (Input.GetKey(KeyCode.DownArrow))
            return -1f;
        else
#endif
        if (joystickType == JoystickType.Fixed)
            return fixedJoystick.Vertical;
        else if (joystickType == JoystickType.Floating)
            return floatingJoystick.Vertical;
        else
            return dynamicJoystick.Vertical;
    }

    public float GetJoysticHorizontal()
    {
        if (enableJoystick == false)
            return 0;

#if UNITY_EDITOR
        if (Input.GetKey(KeyCode.RightArrow))
            return 1f;
        else if (Input.GetKey(KeyCode.LeftArrow))
            return -1f;
        else
#endif
        if (joystickType == JoystickType.Fixed)
            return fixedJoystick.Horizontal;
        else if (joystickType == JoystickType.Floating)
            return floatingJoystick.Horizontal;
        else
            return dynamicJoystick.Horizontal;
    }

    public void SetMaterialGrey<T>(T[] graphics) where T : Graphic
    {
        SetMaterial(graphics, materialUIGrey);
    }

    public void SetMaterialDefault<T>(T[] graphics) where T : Graphic
    {
        SetMaterial(graphics, default);
    }

    public void SetMaterialGrey(Graphic graphic)
    {
        graphic.material = materialUIGrey;
    }

    public void SetMaterialMaxStat(Graphic graphic)
    {
        graphic.material = materialUIMaxStat;
    }

    private void SetMaterial<T>(T[] renderers, Material material) where T : Graphic
    {
        for (int i = 0, length = renderers.Length; i < length; i++)
        {
            if (renderers[i] is Text || renderers[i] == null)
            {
                continue;
            }
            if (material == null)
            {
                renderers[i].material = default;
                continue;
            }
            if(renderers[i].material == null)
            {
                continue;
            }
            renderers[i].material = material;
        }
    }

    public RewardHistoryParam BuildHistoryParam(NotifyData notifyData, bool useRareColor)
    {
        string context = string.Empty;
        Sprite sender, body;
        Color color;

        sender = GetSenderIcon(notifyData.Source, notifyData.Sender, notifyData.BoxSourceId);
        body = null;
        color = new(0, 0, 0, 0);
        if (notifyData.Source == BoxSourceType.AutomationShop)
        {
            // Shop packages are Item records, not Card records.
            var item = DataHolder.Instance().GetData<Item>(notifyData.IntParam);
            body = UIRes.DB.defaultIcon;
            if (item != null)
            {
                context = GetFullDialog(item.dialogInfo).Item1;
                if (AssetManager.instance != null)
                    AssetManager.instance.LoadSprite(item.GetName(0), sprite => body = sprite ?? UIRes.DB.defaultIcon);
            }
        }
        else if (notifyData.NotifyType == NotifyType.QuestCompleted)
        {
            context = GetDialog(317);
            body = GetQuestIcon(notifyData.IntParam, notifyData.NotifyStateType);
        }
        else if (notifyData.NotifyType == NotifyType.AddItem)
        {
            context = GetItemContext(notifyData.IntParam);
            body = GetItemIcon(notifyData.IntParam, notifyData.RareType);

            if (useRareColor)
            {
                color = UIRes.GetColor(notifyData.RareType);
            }
        }
        else if (notifyData.NotifyType == NotifyType.AddTitle)
        {
            context = GetDialog(827);
            body = UIRes.DB.titleIcon;
            color = UIRes.GetColor(notifyData.RareType);
        }
        else if (notifyData.NotifyType == NotifyType.AddCurrency)
        {
            context = GetCurrencyDescription(notifyData.IntParam, notifyData.ActionType);

            body = UIRes.FindUIElement<CurrencyID, Sprite>(notifyData.CurrencyID);
            var rareType = ConvertCurrencyIdToRareTpe(notifyData.CurrencyID);
            color = UIRes.GetColor(rareType);
        }
        else if (notifyData.NotifyType == NotifyType.SoldItem)
        {
            if (notifyData.Source == BoxSourceType.Market || notifyData.Source == BoxSourceType.AutoSell)
            {
                context = GetItemContext(notifyData.IntParam);
                body = GetItemIcon(notifyData.IntParam, notifyData.RareType);

                if (useRareColor)
                {
                    color = UIRes.GetColor(notifyData.RareType);
                }
            }
        }

        return new RewardHistoryParam() { Color = color, Des = context, Sender = sender, Reward = body };
    }

    private Sprite GetQuestIcon(int questID, StatType questStatType)
    {
        var quest = DataHolder.Instance().GetData<Quest>(questID);
        if (quest == null)
        {
            return UIRes.DB.defaultIcon;
        }

        if (quest.questType == QuestType.PlayerStat)
            return UIRes.DB.FindUIElement<StatType, Sprite>(questStatType);
        else
            return UIRes.DB.FindUIElement<QuestType, Sprite>(quest.questType);
    }

    public Sprite GetItemIcon(int itemId, RareType rareType)
    {
        if (itemId < 0)
        {
            return null;
        }

        Card card = GetCard(itemId);
        if (card == null)
        {
            return UIRes.DB.defaultIcon;
        }

        var name = card.GetName(0);
        if (card.equipmentType == EquipmentType.Horse || card.equipmentType == EquipmentType.SkinHorse)
        {
            name = card.GetName(0) + "_" + rareType.ToString();
        }

        // ✅ SERVER-ONLY: Add null check for AssetManager (may not exist in headless mode)
        if (AssetManager.instance == null)
        {
            Debug.LogWarning("[UIManager] AssetManager.instance is null - returning default icon in headless mode");
            return UIRes.DB.defaultIcon;
        }

        Sprite itemIcon = null;
        AssetManager.instance.LoadSprite(name, (s) =>
        {
            itemIcon = s;
        });

        return itemIcon;
    }


    private RareType ConvertCurrencyIdToRareTpe(CurrencyID currencyID)
    {
        return currencyID switch
        {
            CurrencyID.Gold => RareType.Common,
            CurrencyID.Diamond => RareType.Rare,
            CurrencyID.Shard => RareType.Epic,
            CurrencyID.ArenaCoin => RareType.Legendary,
            _ => RareType.Common,
        };
    }

    private string GetCurrencyDescription(int amount, HistoryLogActionType actionType)
    {
        string sign = string.Empty;
        if(actionType == HistoryLogActionType.Add)
        {
            sign = "+";
        }
        else if (actionType == HistoryLogActionType.Lost)
        {
            sign = "-";
        }

        var stringBuilder = StringBuilder;
        stringBuilder.Clear();
        stringBuilder.Append(sign);
        stringBuilder.Append(amount);
        return stringBuilder.ToString();
    }

    [Obsolete]
    public Tvalue FindUIElement<Tid, Tvalue>(Tid id)
    {
        return UIRes.DB.FindUIElement<Tid, Tvalue>(id);
    }

    public string GetEquipmentTypeUse(EquipmentType equipmentType)
    {
        for (int i = 0, length = equipmentTypeUseTitle.Length; i < length; i++)
        {
            if (equipmentTypeUseTitle[i].EquipmentType == equipmentType)
            {
                return GetDialog(equipmentTypeUseTitle[i].DialogId);
            }
        }
        return GetDialog(52);
    }

    public string GetEquipmentTypeUnUse(EquipmentType equipmentType)
    {
        for (int i = 0, length = equipmentTypeUnUseTitle.Length; i < length; i++)
        {
            if (equipmentTypeUnUseTitle[i].EquipmentType == equipmentType)
            {
                return GetDialog(equipmentTypeUnUseTitle[i].DialogId);
            }
        }
        return GetDialog(55);
    }

    public string GetRareText(RareType rareType)
    {
        switch (rareType)
        {
            case RareType.Common: return GetDialog(65);
            case RareType.Rare: return GetDialog(66);
            case RareType.Epic: return GetDialog(67);
            case RareType.Legendary: return GetDialog(111);
            default: return string.Empty;
        }
    }

    [Obsolete]
    public Color GetColor(RareType rareType) => UIRes.DB.rarityColors[(int)rareType];
    [Obsolete]
    public Color GetColor(int index)
    {
        if (index >= UIRes.DB.rarityColors.Length)
        {
            index = UIRes.DB.rarityColors.Length - 1;
        }
        return UIRes.DB.rarityColors[index];
    }

    /// <summary>
    /// Trả về icon của người gửi box
    /// </summary>
    public Sprite GetSenderIcon(BoxSourceType boxSourceType, Sender sender, int boxSourceId)
    {
        if (boxSourceType == BoxSourceType.None || boxSourceType == BoxSourceType.Captcha)
        {
            return UIRes.FindUIElement<Sender, Sprite>(sender);
        }

        if (boxSourceType == BoxSourceType.Boss || boxSourceType == BoxSourceType.Mob)
        {
            var card = GetCard(boxSourceId);

            // ✅ SERVER-ONLY: Add null check for AssetManager (may not exist in headless mode)
            if (AssetManager.instance == null)
            {
                Debug.LogWarning("[UIManager] AssetManager.instance is null - returning null sprite in headless mode");
                return null;
            }

            Sprite result = null;
            AssetManager.instance.LoadSpriteWithOutDefault(card.GetName(0) + " Icon", sprite => result = sprite);
            return result;
        }
        else
        {
            return UIRes.FindUIElement<BoxSourceType, Sprite>(boxSourceType);
        }
    }

    /// <summary>
    /// Trả về tên của card trên editor
    /// </summary>
    public string GetItemContext(int cardId)
    {
        if (cardId < 0)
        {
            return string.Empty;
        }

        Card card = GetCard(cardId);
        if (card == null)
        {
            return string.Empty;
        }

        if (card.equipmentType == EquipmentType.Artifact)
        {
            return card.skillType.ToString();
        }
        else
        {
            return GetDialog(UIRes.FindUIElement<EquipmentType, int>(card.equipmentType));
        }
    }


    public void OnHitAoe(Vector2 appearPosition, bool isLocalPlayer, PlayerBehavior caster)
    {

    }

    public void SpawnChat(string username, string des, ChatID chatID)
    {
        var playerBehavior = ClientManager.instance.GetLocalPlayerBehavior(username);

        if (playerBehavior != null && playerBehavior.characterBody != null)
        {
            if (chatUIs.ContainsKey(playerBehavior.userName))
            {
                chatUIs[playerBehavior.userName].LoadData(playerBehavior, des, chatID);
            }
            else
            {
                if (chatUIPools.Count > 0)
                {
                    chatUIPools[0].LoadData(playerBehavior, des, chatID);
                    chatUIPools[0].transform.position = playerBehavior.transform.position + playerBehavior.characterBody.chatAnchor.localPosition;
                    chatUIs.Add(playerBehavior.userName, chatUIPools[0]);
                    chatUIPools.RemoveAt(0);

                }
                else
                {
                    GameObject go = Instantiate(chatUIPrefab);
                    ChatUI chatUI = go.GetComponent<ChatUI>();
                    chatUI.LoadData(playerBehavior, des, chatID);
                    chatUI.transform.transform.position = playerBehavior.transform.position + playerBehavior.characterBody.chatAnchor.localPosition;
                    chatUIs.Add(playerBehavior.userName, chatUI);
                }
            }
        }
    }

    public void DeSpawnChat(string playerName, ChatUI chatUI)
    {
        if (chatUIs.ContainsKey(playerName))
            chatUIs.Remove(playerName);
        if (!chatUIPools.Contains(chatUI))
        {
            chatUIPools.Add(chatUI);
        }
    }

    public string HandleInput(string content)
    {
        content = content.Trim();

        if (content.Length > BattleManager.instance.gameDataConfig.chatLimitText)
        {
            return content.Substring(0, 100);
        }

        return content;
    }

    public int GetAnimation(PlayerBehavior playerBehavior, CharacterState characterState)
    {
        return animationHelper.GetAnimation(playerBehavior, characterState);
    }
    public int GetAnimation(List<Equipment> equipments, CharacterState characterState)
    {
        return animationHelper.GetAnimation(equipments, characterState);
    }

    public int GetAnimationPetCollection(PlayerBehavior owner, CharacterState characterState)
    {
        return animationHelper.GetAnimationPetCollection(owner, characterState);
    }

    public int GetAnimationPetCollection(
        Animator animator,
        PlayerBehavior owner,
        CharacterState characterState)
    {
        return animationHelper.GetAnimationPetCollection(animator, owner, characterState);
    }

    public int GetAnimationPetCollection(List<Equipment> equipments, CharacterState characterState)
    {
        return animationHelper.GetAnimationPetCollection(equipments, characterState);
    }

    public int GetAnimationPetCollection(
        Animator animator,
        List<Equipment> equipments,
        CharacterState characterState)
    {
        return animationHelper.GetAnimationPetCollection(animator, equipments, characterState);
    }

    public void HandleArenaResponse(ArenaResponse arenaResponse)
    {
        if (arenaResponse.ArenaID == GameConst.ARENA_TEAM_BATTLE)
        {
            Debug.LogError("Response Error " + arenaResponse.ResponseType.ToString());
            return;
        }

        if (MapManager.instance != null)
            MapManager.instance.HandleArenaResponse(arenaResponse);

        if (arenaResponse.ResponseType == ArenaResponseType.ChangeState)
        {
            if (arenaResponse.ArenaState == ArenaState.EndMatch)
            {
                playerOutOfArena.Clear();
            }
        }

        if (arenaResponse.ArenaID != arenaId)
        {
            return;
        }

        if (arenaResponse.ResponseType == ArenaResponseType.OutOfArena)
        {
            playerOutOfArena.Add(ClientManager.instance.myCharacter.userName);
        }


        var arenaBehaviorLocal = EventManager.instance.GetArenaBehaviorLocal(arenaResponse.ArenaID);
        if (arenaBehaviorLocal == null)
        {
            Log(GameLogType.Error, "UIManager HandleArenaResponse: arena behavior local null");
            return;
        }

        if (arenaBehaviorLocal.arenaConfig.arenaType == ArenaType.PvP)
        {
            FindView<ColosseumView>(COLOSSEUM_VIEW).HandleServerResponse(arenaResponse);
        }
        else if (arenaBehaviorLocal.arenaConfig.arenaType == ArenaType.ClanWar)
        {
            FindView<ColosseumView>(CLAN_WAR_VIEW).HandleServerResponse(arenaResponse);
        }
    }

    public void OnNewArenaChangePhase(NewArenaData_ChangePhase data)
    {
        switch (data.NewPhase)
        {
            case ArenaPhase.Closing: break;
            case ArenaPhase.Init: break;
            case ArenaPhase.Matchmaking: break;
            case ArenaPhase.Battle: break;
            case ArenaPhase.End: break;
        }
    }

    public void OnLoadFactionWarHUDInfo(NewArenaProxy proxy, TeamBattleUI teamBattleUI, int maxScore, int maxMember, int maxBuilding)
    {
        var phaseMatch = proxy.currentPhase;
        var currentTimeMatch = (float)proxy.GetPhaseRemain();

        BattleManager.Log(GameLogType.Debug, $"LoadDataUI: Phase - {phaseMatch} | TimeMatch: {currentTimeMatch}");

        teamBattleUI.UpdateStateMatch(phaseMatch);
        teamBattleUI.UpdateTimeMatch(currentTimeMatch);

        var teamRedMember = proxy.GetTeamMembers(0).Count;
        var teamBlueMember = proxy.GetTeamMembers(1).Count;
        string teamRedMemberText = $"{teamRedMember}/{maxMember}";
        string teamBlueMemberText = $"{teamBlueMember}/{maxMember}";


        if (phaseMatch == ArenaPhase.Init || phaseMatch == ArenaPhase.Matchmaking)
        {
            teamBattleUI.DeActiveScoreText();
            teamBattleUI.UpdateTimeMatch("--:--");
            teamBattleUI.SetProgressZero();
            teamBattleUI.UpdateTeamMember(0, teamRedMemberText);
            teamBattleUI.UpdateTeamMember(1, teamBlueMemberText);
            teamBattleUI.UpdateTeamBuilding(0, $"{maxBuilding}/{maxBuilding}");
            teamBattleUI.UpdateTeamBuilding(1, $"{maxBuilding}/{maxBuilding}");
        }
        else if (phaseMatch == ArenaPhase.Battle)
        {
            var teamRedScore = proxy.GetTeamScore(0);
            var teamBlueScore = proxy.GetTeamScore(1);
            var percentTeamRed = maxScore > 0 ? teamRedScore / (float)maxScore : 0f;
            var percentTeamBlue = maxScore > 0 ? teamBlueScore / (float)maxScore : 0f;

            var teamRedBuilding = proxy.GetAliveMobCount(0);
            var teamBlueBuilding = proxy.GetAliveMobCount(1);
            string teamRedBuildingText = $"{teamRedBuilding}/{maxBuilding}";
            string teamBlueBuildingText = $"{teamBlueBuilding}/{maxBuilding}";


            // TODO: hỏi anh Lập config của maxBuilding
            teamBattleUI.UpdateTeamInfo(0, percentTeamRed, teamRedScore.ToString(), teamRedMemberText, teamBlueBuildingText);
            teamBattleUI.UpdateTeamInfo(1, percentTeamBlue, teamBlueScore.ToString(), teamBlueMemberText, teamBlueBuildingText);
        }
        else if (phaseMatch == ArenaPhase.Closing)
        {
            teamBattleUI.UpdateTimeMatch("--:--");
            teamBattleUI.DeActiveScoreText();
            teamBattleUI.UpdateTeamMember(0, "--/--");
            teamBattleUI.UpdateTeamMember(1, "--/--");
            teamBattleUI.UpdateTeamBuilding(0, "--/--");
            teamBattleUI.UpdateTeamBuilding(1, "--/--");
        }
    }


    public void UpdateMemberChangeBattleState(NewArenaData_ChangeBattleState data)
    {
        if (data.NewState != MemberInBattleState.Kicked || ClientManager.instance == null)
            return;

        var character = ClientManager.instance.myCharacter;
        if (character == null || data.TargetUsername != character.userName)
            return;

        if (data.ArenaID == GameConst.ARENA_TEAM_BATTLE)
        {
            var factionHud = FindView<FactionWarHUDView>();
            if (factionHud != null) factionHud.Close();
        }
        else if (data.ArenaID == GameConst.ARENA_SURVIVAL)
        {
            var survivalHud = FindView<SurvivalBattleHUDView>();
            if (survivalHud != null) survivalHud.Close();
        }
    }

    public void UpdateFactionWarTimeMatch(int arenaId, TeamBattleUI teamBattleUIComponent)
    {
        if (NewArenaManager_Client.TryGetProxy(arenaId, out var proxy))
        {
            var currentTime = (float)proxy.GetPhaseRemain();
            teamBattleUIComponent.UpdateTimeMatch(currentTime);
        }
    }



    public void HandleResponse(SeasonEventResponse response)
    {
        FindView<EventView>().HandleServerResponse(response);
    }

    public void OnLocalPlayerLandTypeChange(LandType newLandType)
    {
        ClientManager.instance.myLandType = newLandType;
        FindView<HUDView>().OnLocalPlayerLandTypeChange(newLandType);
    }

    public string GetRoleDialog(MemberRole memberRole)
    {
        string role = string.Empty;

        switch (memberRole)
        {
            case MemberRole.Leader:
                role = UIManager.GetDialog(1113);
                break;

            case MemberRole.Coleader:
                role = UIManager.GetDialog(1114);
                break;

            case MemberRole.Member:
                role = UIManager.GetDialog(85);
                break;

            default:
                BattleManager.Log(GameLogType.Error, "[MemberUI] Member role not exist!");
                break;
        }

        return role;
    }

    public string ParseServerDialog(string serverRawString)
    {
        if (string.IsNullOrEmpty(serverRawString)) return string.Empty;

        return Regex.Replace(serverRawString, @"\{DialogId=(\d+)\}", match =>
        {
            string id = match.Groups[1].Value;

            if (int.TryParse(id, out int dialogId))
            {
                return GetDialog(dialogId);
            }

            return match.Value; 
        });
    }

    //ClanRecruitment Method
    public ClanRecruitment BuildClanRecruitment(ClanRecruitSettingPanel clanRecruitSettingPanel)
    {
        ClanRecruitment clanRecruitment = new ClanRecruitment();
        clanRecruitment.isCruiting = clanRecruitSettingPanel.ClanRecruitmentData.isCruiting;
        clanRecruitment.recruitType = clanRecruitSettingPanel.ClanRecruitmentData.recruitType;
        foreach (Transform clanRecruit in clanRecruitSettingPanel.contentRecruitElements)
        {
            var clanRecruitElement = clanRecruit.GetComponent<ClanRecruitElementUI>();
            if (clanRecruitElement != null && clanRecruitElement.gameObject.activeInHierarchy)
            {
                if (clanRecruitElement.ClanRecruitCondition != null &&
                    Enum.IsDefined(typeof(ClanRecruitElement), clanRecruitElement.ClanRecruitCondition.recruitElementType))
                {
                    var condition = clanRecruitElement.ClanRecruitCondition;
                    clanRecruitment.recruitConditions.Add(condition);
                }
            }
        }

        return clanRecruitment;
    }

    #region AccountInfo
    private void CheckAccountInfoState()
    {
        var myAcccountInfo = ClientManager.instance.accountInfoLocal;
        if (myAcccountInfo.state == AccountInfoState.AddEmail)
        {
            var response = new AccountInfoResponse
            {
                ErrorCode = ErrorCode.Success,
                ResponseType = AccountInfoResponseType.AddEmail
            };
            HandleAccountInfoResponse(response);
        }
        else if (myAcccountInfo.state == AccountInfoState.RemoveEmail)
        {
            var response = new AccountInfoResponse
            {
                ErrorCode = ErrorCode.Success,
                ResponseType = AccountInfoResponseType.RemoveEmail
            };
            HandleAccountInfoResponse(response);
        }
        else if (myAcccountInfo.state == AccountInfoState.AddPhone)
        {

            var response = new AccountInfoResponse
            {
                ErrorCode = ErrorCode.Success,
                ResponseType = AccountInfoResponseType.AddPhone,
            };
            HandleAccountInfoResponse(response);
        }
        else if (myAcccountInfo.state == AccountInfoState.RemovePhone)
        {
            var response = new AccountInfoResponse
            {
                ErrorCode = ErrorCode.Success,
                ResponseType = AccountInfoResponseType.RemovePhone,
            };
            HandleAccountInfoResponse(response);
        }
    }

    public void HandleAccountInfoResponse(AccountInfoResponse response)
    {
        if (response.AccountInfo != null)
        {
            ClientManager.instance.SetMyAccountInfo(response.AccountInfo);
        }
        var otpView = FindView<OTPView>();
        switch (response.ResponseType)
        {
            case AccountInfoResponseType.AddEmail:
                if (response.ErrorCode == ErrorCode.Success)
                {
                    ClientManager.instance.SetAccountInfoLocalState(AccountInfoState.AddEmail);
                    IngameNotifyManager.instance.Notify(411);
                    otpView.SetState(AccountInfoResponseType.VerifyAddEmail);
                    otpView.Load();
                }
                else
                {
                    IngameNotifyManager.instance.Notify(response.ErrorCode);
                }
                break;
            case AccountInfoResponseType.AddPhone:
                if (response.ErrorCode == ErrorCode.Success)
                {
                    ClientManager.instance.SetAccountInfoLocalState(AccountInfoState.AddPhone);
                    IngameNotifyManager.instance.Notify(956);
                    otpView.SetState(AccountInfoResponseType.VerifyAddPhone);
                    otpView.Load();
                }
                else
                {
                    if (response.ErrorCode == ErrorCode.DataAlreadyExisted)
                    {
                        IngameNotifyManager.instance.Notify("Số điện thoại này đã được sử dụng");
                    }
                    else
                    {
                        IngameNotifyManager.instance.Notify(response.ErrorCode);
                    }
                }
                break;
            case AccountInfoResponseType.VerifyAddEmail:
                if (response.ErrorCode == ErrorCode.Success)
                {
                    ClientManager.instance.SetAccountInfoLocalState(AccountInfoState.None);
                    IngameNotifyManager.instance.Notify(414);
                    otpView.Close();

                    var view = FindView<AccountIdentityView>();
                    if (view.IsOpen)
                    {
                        view.hasVerifiedEmail = true;
                        view.UpdateEmailControls(true);
                    }
                }
                else
                {
                    IngameNotifyManager.instance.Notify(response.ErrorCode);
                    otpView.Clear();
                }
                break;
            case AccountInfoResponseType.VerifyAddPhone:
                if (response.ErrorCode == ErrorCode.Success)
                {
                    ClientManager.instance.SetAccountInfoLocalState(AccountInfoState.None);
                    IngameNotifyManager.instance.Notify(957);
                    otpView.Close();

                    var view = FindView<AccountIdentityView>();
                    if (view.IsOpen)
                    {
                        view.hasVerifiedPhoneNumber = true;
                        view.UpdatePhoneControls(true);
                    }
                }
                else
                {
                    IngameNotifyManager.instance.Notify(response.ErrorCode);
                    otpView.Clear();
                }
                break;
            case AccountInfoResponseType.RemoveEmail:
                if (response.ErrorCode == ErrorCode.Success)
                {
                    ClientManager.instance.SetAccountInfoLocalState(AccountInfoState.RemoveEmail);
                    IngameNotifyManager.instance.Notify(411);
                    otpView.SetState(AccountInfoResponseType.VerifyRemoveEmail);
                    otpView.Load();
                }
                else
                {
                    IngameNotifyManager.instance.Notify(response.ErrorCode);
                }
                break;
            case AccountInfoResponseType.RemovePhone:
                if (response.ErrorCode == ErrorCode.Success)
                {
                    ClientManager.instance.SetAccountInfoLocalState(AccountInfoState.RemovePhone);
                    IngameNotifyManager.instance.Notify(956);
                    otpView.SetState(AccountInfoResponseType.VerifyRemovePhone);
                    otpView.Load();
                }
                else
                {
                    IngameNotifyManager.instance.Notify(response.ErrorCode);
                }
                break;
            case AccountInfoResponseType.VerifyRemoveEmail:
                if (response.ErrorCode == ErrorCode.Success)
                {
                    ClientManager.instance.SetAccountInfoLocalState(AccountInfoState.None);
                    IngameNotifyManager.instance.Notify(417);
                    otpView.Close();

                    var view = FindView<AccountIdentityView>();
                    if (view.IsOpen)
                    {
                        view.SetEmail(string.Empty);
                        view.UpdateEmailControls(false);
                    }
                }
                else
                {
                    IngameNotifyManager.instance.Notify(response.ErrorCode);
                    otpView.Clear();
                }
                break;
            case AccountInfoResponseType.VerifyRemovePhone:
                if (response.ErrorCode == ErrorCode.Success)
                {
                    var view = FindView<AccountIdentityView>();
                    if (view.IsOpen)
                    {
                        view.SetPhone(string.Empty);
                        view.UpdatePhoneControls(false);
                    }
                    ClientManager.instance.SetAccountInfoLocalState(AccountInfoState.None);
                    IngameNotifyManager.instance.Notify(958);
                    otpView.Close();
                }
                else
                {
                    IngameNotifyManager.instance.Notify(response.ErrorCode);
                    otpView.Clear();
                }
                break;
            default:
                break;
        }
    }
    private void LoadPlayerLocalSetting()
    {
        GetPlayerLocalSetting();
        FindView<InventoryView>().OnSetMyCharacter();
        OnClickFontSizeZero(playerLocalSetting.IsHiddenName);
    }

    private void GetPlayerLocalSetting()
    {
        string settingKey = $"{ClientManager.instance.myUsername}{ClientManager.instance.originalServer}LocalSetting";
#if ENABLE_CLIENT
        playerLocalSetting = ES3Helper.LoadEncrypted(settingKey, new PlayerLocalSetting
        {
            IsHiddenName = false,
            IsBlockClickItem = false,
            IsBlockOtherPlayerClick = false,
            IsBlockBuildingClick = false,
            IsTurnOffOtherDamage = false,
            IsEnableDragDrop = false
        });
        playerLocalSetting.OnDataChanged = () => SaveSetting(settingKey, playerLocalSetting);
#endif
    }

    public void LoadDeviceLocalSetting()
    {
        GetDeviceLocalSetting();
        LoadFps(deviceLocalSetting.FpsSetting);
        languageId = deviceLocalSetting.LanguageId;
        LoadJoyStick(deviceLocalSetting.Joystick);
    }

    private void GetDeviceLocalSetting()
    {
        const string deviceSettingKey = "DeviceLocalSetting";
#if ENABLE_CLIENT
        deviceLocalSetting = ES3Helper.LoadEncrypted(deviceSettingKey, new DeviceLocalSetting
        {
            MusicVolume = 1f,
            SoundVolume = 1f,
            FpsSetting = FpsMode.Fps60,
            LanguageId = GetSystemLanguageId(),
            Joystick = JoystickType.Floating
        });

        deviceLocalSetting.OnDataChanged = () => SaveSetting(deviceSettingKey, deviceLocalSetting);

        if (LocalPrefs.KeyExists("MusicValue"))
        {
            deviceLocalSetting.MusicVolume = LocalPrefs.Load<float>("MusicValue", 0f);
            LocalPrefs.DeleteKey("MusicValue");
        }

        if (LocalPrefs.KeyExists("SoundValue"))
        {
            deviceLocalSetting.SoundVolume = LocalPrefs.Load<float>("SoundValue", 0f);
            LocalPrefs.DeleteKey("SoundValue");
        }

        if (LocalPrefs.KeyExists("JoyStickType"))
        {
            deviceLocalSetting.Joystick = (JoystickType)LocalPrefs.Load<int>("JoyStickType", 0);
            LocalPrefs.DeleteKey("JoyStickType");
        }

        if (LocalPrefs.KeyExists(KEY_LANGUAGE_ID))
        {
            deviceLocalSetting.LanguageId = LocalPrefs.Load<int>(KEY_LANGUAGE_ID, 0);
            LocalPrefs.DeleteKey(KEY_LANGUAGE_ID);
        }
#endif
    }

    private int GetSystemLanguageId()
    {
        for (int i = 0; i < DataHolder.Instance().languageIDs.Length; i++)
        {
            if (Application.systemLanguage.ToString() == DataHolder.Instance().GetLanguageName(i))
            {
                return i;
            }
        }
        return 0;
    }

    private void SaveSetting<T>(string key, T setting)
    {
#if ENABLE_CLIENT
        if (setting != null)
        {
            ES3Helper.SaveEncrypted(key, setting);
        }
#endif
    }

    public bool CanOpenFirstHelp(int dialogId)
    {
#if ENABLE_CLIENT
        if (dialogId <= 0)
        {
            Debug.LogError($"[UIManager] Invalid help dialogId: {dialogId}");
            return false;
        }

        if (firstOpenHelpDialogIds == null)
        {
            firstOpenHelpDialogIds = ES3Helper.LoadEncrypted(FIRST_OPEN_HELP_DIALOG_IDS_KEY, new List<int>());
            if (firstOpenHelpDialogIds == null)
            {
                firstOpenHelpDialogIds = new List<int>();
            }
        }

        if (firstOpenHelpDialogIds.Contains(dialogId))
        {
            return false;
        }

        firstOpenHelpDialogIds.Add(dialogId);
        SaveSetting(FIRST_OPEN_HELP_DIALOG_IDS_KEY, firstOpenHelpDialogIds);
        return true;
#else
        return false;
#endif
    }

    private void ClearPlayerLocalSetting()
    {
        if (playerLocalSetting != null)
        {
            playerLocalSetting.OnDataChanged = null;
            playerLocalSetting = null;
        }
    }

    #endregion

    #region Editor



#if ENABLE_SERVER_TEST

    [ContextMenu("LogValidViews")]
    public void LogValidViews()
    {
        // Lấy tất cả BaseView trong các con của UIManager
        BaseView[] baseViews = GetComponentsInChildren<BaseView>(true);

        foreach (BaseView view in baseViews)
        {
            view.GetComponentUI();
        }
#if UNITY_EDITOR
        UnityEditor.EditorUtility.SetDirty(this);
#endif
    }

    private bool HasNonNullValue<T>(T[] elements)
    {
        foreach (T element in elements)
        {
            // Nếu element không null, kiểm tra các field bên trong
            if (element != null)
            {
                foreach (var field in element.GetType().GetFields())
                {
                    object value = field.GetValue(element);
                    if (value != null) return true;
                }
            }
        }
        return false;
    }

    [ContextMenu(nameof(TestMap))]
    public void TestMap()
    {
        OpenView<AutomationV2View>();
    }

    //[ContextMenu(nameof(FakeQuest))]
    //public void FakeQuest()
    //{
    //    ClientManager.instance.myCharacter.RequestFakeQuestError();
    //}

    [ContextMenu(nameof(T1))]
    public void T1()
    {
        StartCoroutine(T1CO());
    }

    private IEnumerator T1CO()
    {
        for (int i = 0; i < 30; i++)
        {
            yield return new WaitForSeconds(0.1f);
            ClientManager.instance.myCharacter.RequestUnLockWalletInventorySlot(
                ClientManager.instance.GetApiToken(),
                ClientManager.instance.walletPassCode);
        }
    }

    [ContextMenu(nameof(T2))]
    public void T2()
    {
        StartCoroutine(T2CO());
    }

    private IEnumerator T2CO()
    {
        for (int i = 0; i < 30; i++)
        {
            yield return new WaitForSeconds(0.1f);

            var e = ClientManager.instance.myCharacter.characterInventory.GetEquipments()[0];

            ClientManager.instance.myCharacter.RequestSendItemToWallet(
                e.id,
                ClientManager.instance.GetApiToken());
        }
    }

    [ContextMenu(nameof(UnLockAndOrder))]
    public void UnLockAndOrder()
    {
        StartCoroutine(UnlockAndOrderCO());
    }

    private IEnumerator UnlockAndOrderCO()
    {
#if ENABLE_SERVER_TEST
        ClientManager.instance.myCharacter.RequestUnlockMaxWalletSlot();

        yield return new WaitForSeconds(1f);

        ClientManager.instance.myCharacter.RequestAddMaxIngredient();
#endif
        yield return new WaitForEndOfFrame();
    }

    public void OnUnlockAndOrderCompleted()
    {
        ClientManager.instance.myCharacter.RequestStartQuit(ClientManager.instance.GetApiToken());
        //StartCoroutine(OnUnlockAndOrderCompletedCO());
    }

    public static int turn = 0;
    private IEnumerator OnUnlockAndOrderCompletedCO()
    {
        int count = 360;
        turn++;

        if (turn >= 10)
            yield break;

        while (count > 0)
        {
            count -= 1;
            yield return MCPCoroutines.WaitFor(1f);
        }


        ClientManager.instance.myCharacter.RequestAddMaxIngredient();
    }



#endif
    public Ttype Find<Ttype>(string name = "") where Ttype : BaseView
    {
        return FindView<Ttype>(name);
    }

    [System.Serializable]
    public struct EquipmentTypeDialog
    {
        public string Name;
        public EquipmentType EquipmentType;
        public int DialogId;
    }

    [System.Serializable]
    public struct EventImage
    {
        public string Name;
        public GameEventId GameEventId;
        public Sprite Icon;
        public Sprite Panel;
    }

    [System.Serializable]
    public struct RewardHistoryParam
    {
        public string Des;
        public Sprite Sender;
        public Sprite Reward;
        public Color Color;
    }

    [System.Serializable]
    public class DeviceLocalSetting
    {
        [SerializeField] float musicVolume;
        [SerializeField] float soundVolume;
        [SerializeField] FpsMode fpsMode;
        [SerializeField] int languageId;
        [SerializeField] JoystickType joystickType;

        public float MusicVolume
        {
            get => musicVolume;
            set { musicVolume = value; OnDataChanged?.Invoke(); }
        }

        public float SoundVolume
        {
            get => soundVolume;
            set { soundVolume = value; OnDataChanged?.Invoke(); }
        }

        public FpsMode FpsSetting
        {
            get => fpsMode;
            set { fpsMode = value; OnDataChanged?.Invoke(); }
        }

        public int LanguageId
        {
            get => languageId;
            set { languageId = value; OnDataChanged?.Invoke(); }
        }

        public JoystickType Joystick
        {
            get => joystickType;
            set { joystickType = value; OnDataChanged?.Invoke(); }
        }

        public Action OnDataChanged;
    }

    [System.Serializable]
    public class PlayerLocalSetting
    {
        [SerializeField] bool isHiddenName;
        [SerializeField] bool isBlockClickItem;
        [SerializeField] bool isBlockOtherPlayerClick;
        [SerializeField] bool isBlockBuldingClick;
        [SerializeField] bool isTurnOffOtherDamage;
        [SerializeField] bool isEnableDragDrop;

        public bool IsHiddenName
        {
            get => isHiddenName;
            set { isHiddenName = value; OnDataChanged?.Invoke(); }
        }

        public bool IsBlockClickItem
        {
            get => isBlockClickItem;
            set { isBlockClickItem = value; OnDataChanged?.Invoke(); }
        }

        public bool IsBlockOtherPlayerClick
        {
            get => isBlockOtherPlayerClick;
            set { isBlockOtherPlayerClick = value; OnDataChanged?.Invoke(); }
        }

        public bool IsBlockBuildingClick
        {
            get => isBlockBuldingClick;
            set { isBlockBuldingClick = value; OnDataChanged?.Invoke(); }
        }

        public bool IsTurnOffOtherDamage
        {
            get => isTurnOffOtherDamage;
            set { isTurnOffOtherDamage = value; OnDataChanged?.Invoke(); }
        }

        public bool IsEnableDragDrop
        {
            get => isEnableDragDrop;
            set { isEnableDragDrop = value; OnDataChanged?.Invoke(); }
        }

        public Action OnDataChanged;
    }

    public enum FpsMode
    {
        Fps30,
        Fps60
    }
    #endregion
}

public interface ITooltip
{
    Vector2 GetOffsetPosition();
    Component GetValueAsComponent();

    bool GetTranslatedCondition();
}

public interface IGetCardData
{
    Card GetCard(int cardId);
}

public interface IServiceLocator<T>
{
    public Ttype Find<Ttype>(string name = "") where Ttype : T;
}

public interface IForceClose
{
    public void ForceClose();
}

public interface IForceOpen
{
    public void ForceOpen();
}
