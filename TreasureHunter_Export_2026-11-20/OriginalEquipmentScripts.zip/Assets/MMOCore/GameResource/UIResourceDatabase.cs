using MCP.DataModels.BaseModels;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UIManager;


[CreateAssetMenu(fileName = "UIResourceDatabase", menuName = "MegaCombat/Editor/Content/UI/Resource Database")]
public class UIResourceDatabase : ScriptableObject
{

#if ODIN_INSPECTOR
    public OdinAssetManager OdinAssetManager;
#endif


    // ============ Color sets ============
    public Color[] rarityColors;
    public Color[] rarityBackEyeColors;
    public Color[] rarityEyeColors;
    public Color[] rarityHairColors;
    public Color highlightTextColor;

    // ============ Icons / Sprites ============
    public Sprite titleIcon;
    public Sprite defaultIcon;
    public Sprite[] lockIcon;      // idx 0: lock, 1: unlock
    public Sprite[] watchIcon;     // idx 0: IconViewOff, 1: IconViewOn (serialized Resources database)
    public Sprite[] hidenNameIcon; // idx 0: on,   1: off
    public Sprite[] hidenBodyIcon; // idx 0: on,   1: off
    public Sprite[] zoomCameraNormalIcon; // idx 0: on,   1: off
    public Sprite[] minimizeIcon; // idx 0: on,   1: off
    public Sprite[] careEggPhaseIcon;
    public Sprite[] refreshIcon;
    public Sprite ingredientT4;

    // ============ GenericUIElements mappings ============
    public GenericUIElements<CurrencyID, Color> currencyColors;
    public GenericUIElements<MobType, Sprite> mobIcons;
    public GenericUIElements<Sender, Sprite> senderIcons;
    public GenericUIElements<BoxSourceType, Sprite> sourceTypeIcons;
    public GenericUIElements<CurrencyID, Sprite> currencyIcons;
    public GenericUIElements<CurrencyID, int> currencyDialogs;
    public GenericUIElements<int, Sprite> effectStatusIcons;
    public GenericUIElements<QuestType, Sprite> questStatIcons;
    public GenericUIElements<EquipmentType, Sprite> equipmentHintIcons;
    public GenericUIElements<StatType, Sprite> statIcons;
    public GenericUIElements<GameEventIdIcon, Sprite> eventIcons;
    public GenericUIElements<GameEventIdPanel, Sprite> eventPanels;
    public GenericUIElements<string, Sprite> captchaIcons;
    public GenericUIElements<EquipmentType, int> equipmentTypeDialogs;
    public GenericUIElements<int, List<Sprite>> emoteSprites;
    public GenericUIElements<ClanRecruitElement, Sprite> recruitIcons;
    public GenericUIElements<SeasonEventType,Sprite> loadingBanners;
    public GenericUIElements<SeasonEventType, FAQDataSO> cosmeticFAQs;

    public Tvalue FindUIElement<Tid, Tvalue>(Tid id)
    {
        // Box before dispatch: IL2CPP enum generic sharing can fold `id is SomeEnum`
        // to false when it is evaluated directly against a generic Tid parameter.
        var result = FindUIElementByRuntimeType(id, typeof(Tvalue));
        return result is Tvalue value ? value : default;
    }

    private object FindUIElementByRuntimeType(object id, System.Type valueType)
    {
        if (id is QuestType questType && valueType == typeof(Sprite))
        {
            var result = questStatIcons.Find(questType);
            return result;
        }
        else if (id is int idInt && valueType == typeof(Sprite))
        {
            var result = effectStatusIcons.Find(idInt);
            return result;
        }
        else if (id is EquipmentType equipmentType && valueType == typeof(Sprite))
        {
            var result = equipmentHintIcons.Find(equipmentType);
            return result;
        }
        else if (id is StatType statType && valueType == typeof(Sprite))
        {
            var result = statIcons.Find(statType);
            return result;
        }
        else if (id is CurrencyID currencyId && valueType == typeof(Sprite))
        {
            var result = currencyIcons.Find(currencyId);
            return result;
        }
        else if (id is CurrencyID currencyIdd && valueType == typeof(int))
        {
            var result = currencyDialogs.Find(currencyIdd);
            return result;
        }
        else if (id is Sender sender && valueType == typeof(Sprite))
        {
            var result = senderIcons.Find(sender);
            return result;
        }
        else if (id is EquipmentType equipment && valueType == typeof(int))
        {
            var result = equipmentTypeDialogs.Find(equipment);
            return result;
        }
        else if (id is GameEventIdIcon icon && valueType == typeof(Sprite))
        {
            var result = eventIcons.Find(icon);
            return result;
        }
        else if (id is GameEventIdPanel panel && valueType == typeof(Sprite))
        {
            var result = eventPanels.Find(panel);
            return result;
        }
        else if (id is string hashMD && valueType == typeof(Sprite))
        {
            var result = captchaIcons.Find(hashMD);
            return result;
        }
        else if (id is CurrencyID currencyID && valueType == typeof(Color))
        {
            var result = currencyColors.Find(currencyID);
            return result;
        }
        else if (id is BoxSourceType sourceType && valueType == typeof(Sprite))
        {
            var result = sourceTypeIcons.Find(sourceType);
            return result;
        }
        else if (id is int idEmote && valueType == typeof(List<Sprite>))
        {
            var result = emoteSprites.Find(idEmote);
            return result;
        }
        else if (id is ClanRecruitElement recruitType && valueType == typeof(Sprite))
        {
            var result = recruitIcons.Find(recruitType);
            return result;
        }
        else if (id is SeasonEventType eventType && valueType == typeof(Sprite))
        {
            var result = loadingBanners.Find(eventType);
            return result;
        }
        else if (id is SeasonEventType seasonEventType && valueType == typeof(FAQDataSO))
        {
            var result = cosmeticFAQs.Find(seasonEventType);
            return result;
        }

        return null;
    }

}

[System.Serializable]
public struct GenericUIElement<Tid, Tvalue>
{
    public string Name;
    public Tid Id;
    public Tvalue Value;
}

[System.Serializable]
public struct GenericUIElements<Tid, Tvalue>
{
    public GenericUIElement<Tid, Tvalue>[] Icons;

    public Tvalue Find(Tid id)
    {
        for (int i = 0; i < Icons.Length; i++)
        {
            if (Icons[i].Id.Equals(id))
                return Icons[i].Value;
        }
        return default(Tvalue);
    }

}
