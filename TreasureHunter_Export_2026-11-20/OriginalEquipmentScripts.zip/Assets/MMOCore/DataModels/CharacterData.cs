using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using Newtonsoft.Json;
using MegaCombat.Testing;
using MCP.DataModel.Utils;
using MCP.Mmo.DataModels.Common;
using MCP.Unity;
using static GameConst;

namespace MCP.DataModels.BaseModels
{

    [Serializable]
    public partial class CharacterData : BaseModel
    {
        [Newtonsoft.Json.JsonProperty] public string finalWarEntryKey { get; set; } = "";
        [Newtonsoft.Json.JsonProperty] public FinalWarReturnData finalWarReturn { get; set; }
        public string id = ""; //playfabId
#if ENABLE_SERVER_TEST
        [Newtonsoft.Json.JsonIgnore, System.NonSerialized] public bool isFinalWarTestBot;
#endif
        //public string saveId = "";
        public string characterName = "";
        public string originalServer = "";
        public string currentServer = "";
        public string lastServer = ""; // Server trước khi transfer (được set khi bắt đầu transfer)
        public string lastClanId = "";
        public MemberRole memberRole = MemberRole.Member;
        public CharacterType characterType = CharacterType.Player;
        public CharacterRole characterRole = CharacterRole.Player;

        public int cardId = -1;

        //Login season pass
        public bool isVip = false;
        public int seasonId = 0;
        //public string seasonStart = "";
        public int chestNumber = 0;
        public int killPlayerNumber = 0;
        public int killMobNumber = 0;
        public int preparationSafeTime = 0;
        public int killBossNumber = 0;
        public int protectionTime = 0;
        public int mergeNumber = 0;

        public int ingredientNumber = 0;

        public string teamId = "";
        public string clanId = "";
        public int arenaId = -1;
        public int jailId = -1;

        public float jailTime = 0;

        public List<Equipment> equipments = new List<Equipment>();
        public List<Equipment> inventory = new List<Equipment>();
        public List<Equipment> ingredients = new List<Equipment>();
        public List<Equipment> collections = new List<Equipment>();
        public List<Equipment> titleEquipment = new List<Equipment>();

        /// <summary>
        /// Skin Sets - Player sở hữu TẤT CẢ skin trong các set này
        /// Max 2 sets, mỗi set chứa tối đa 4 skin (Hair, Eye, FaceHair, Body)
        /// </summary>
        public List<List<Equipment>> skinSets = new List<List<Equipment>>();

        /// <summary>
        /// Index của skin set đang được sử dụng (0 hoặc 1)
        /// </summary>
        public int activeSkinSetIndex = 0;

        /// <summary>
        /// Equipment Sets
        /// Max 3 sets, 2 set đầu free, set thứ 3 phải unlock, reset vào cuối mùa
        /// Bao gồm: Weapon, Back, Helmet, Cloth, Boot, Mount, Pet, Artifact, Collection Horse, Collection Pet, SkinHorse
        /// </summary>
        public List<EquipmentSetData> equipmentSets = new List<EquipmentSetData>();

        public List<LeaderboardRewardEntry> leaderboardRewards = new List<LeaderboardRewardEntry>();

        public int health = 0;
        public float posX = 0;
        public float posY = 0;

        public string lastSave = "";
        public string lastUpdate = "";
        public string createdDate = "";
        public bool isOnline = true;
        public string lastLogin = "";
        public int adNumber = 0;
        public int adSkipNumber = 0;
        public int iapValue = 0;
        public int vipPoint = 0;
        public int seasonIAPValue = 0;
        public int seasonTHShop = 0;
        public int miraPurchaseNumber = 0;
        public int clanPurchasePetNumber = 0;
        public int anbePurchaseNumber = 0;
        public int totalPlayerTime = 0;
        public int delayHealTime = 0;
        public int changeNameNumber = 0;
        public int wrongCode = 0;
        public int suspectdNumber = 0;
        public int refundedNumber = 0;
        public int modNumber = 0;


        public int dailyPrisonNumber = 0;
        public int seasonPrisonNumber = 0;
        public int totalPrisonNumber = 0;

        public int totalChestNumber = 0;
        public int totalKillPlayerNumber = 0;
        public int totalKillMobNumber = 0;
        public int totalKillBossNumber = 0;
        public int totalMergeNumber = 0;
        public int totalCraftNumber = 0;
        public int totalTimePlay = 0;

        public int arenaCount = 0;
        public int clanArenaCount = 0;
        public int playerArena = 0;
        public float power = 0;

        //Tiến trình chơi của user, dùng để unlock tính năng và nhận quest
        public int progress = 0;

        public int totalCaptcha = 0;
        public int totalCorrectCaptcha = 0;
        public int currentWrongCaptcha = 0;
        public int totalWrongCaptcha = 0;
        public float newCaptchaTime = 0;

        public string lastAd = "";
        public string lastStartAd = "";
        public bool isSave = false;
        public string leaveClanTime = "";
        public string nextTimeUseSkill = "";
        public string walletPassCode = "";
        public string lastTimeAddReviveClanVillage = "";

        public QuestData questData = new QuestData();
        public QuestData cyclicQuestDataQuestPoint = new();
        public QuestData beginnerQuestData = new QuestData();
        public List<QuestData> achievements = new List<QuestData>();
        public List<QuestData> achievementsTeamBattle = new List<QuestData>();
        public QuestData achievementQuestPointQuestData = new();
        public List<int> listTutorialCompleted = new();
        public QuestData tutorial = new();

        /// <summary>
        /// Automation settings (server-authoritative, synced to client via RPC)
        /// </summary>
        public AutomationSetting automationSetting = new AutomationSetting();

        /// <summary>
        /// Persisted AutoShield cooldown remaining seconds.
        /// -1: no active cooldown state, 0: ready, >0: counting down.
        /// </summary>
        public int autoShieldRemainingSeconds = -1;

        public List<QuestData> dailyQuestDatas = new List<QuestData>();
        public QuestData dailyQuestDataQuestPoint = new();

        public List<QuestData> clanDailyQuestData = new();
        public List<QuestData> clanDailyQuestDataQuestPoint = new();
        public string clanDailyQuestCreateTime = "";
        public string clanDailyQuestPointCreateTime = "";

        public int cyclicQuestRerollNumber = 0; // Reroll quest kai
        public int dailyQuestRerollNumber = 0;
        public int achievementRerollNumber = 0;

        //Daily Reward (VIP & Combo)
        public List<PlayerDailyReward> playerDailyRewards = new List<PlayerDailyReward>();
        public List<PlayerVipStat> playerVipStats = new List<PlayerVipStat>();

        public string dailyQuestCreateTime = "";
        public List<QuestData> continuousLogin = new List<QuestData>();
        public QuestData questDataLogin = null;
        public int numberLoginOnSeason = 1;

        public List<Effect> effects = new List<Effect>();
        public List<Buff> buffs = new List<Buff>();
        public string lockTime = "";
        public string lastResetTime = "";
        public int todayAdNumber = 0;
        public int todayHitMapNumber = 0;
        public int todayCraftNumber = 0;
        public float todayPlayerTime = 0;
        // Captcha tracking: counts only valid manual hits in allowed zones
        public int todayCaptchaHitmap = 0; // reset daily
        public int seasonCaptchaHitmap = 0; // reset on season/month end only
        //public int autoToolScore = 0;


        //SeasonEvent
        public int numberRollSeasonEvent = 0;
        public int numberRollSeasonEventFree = 0;

        public LandType landType = LandType.CenterLand;
        public string landId;
        public string lockAreaId;

        //Box suggestion
        public List<BoxSuggestion> boxSuggestions = new();

        //Danh sách các Clan đã xin vào
        public List<string > appliedClans = new List<string>();

        // Social rewards claimed by this character. Server-authoritative.
        public List<string> claimedSocialRewards = new List<string>();

        // Thời gian kết thúc cấm chat player; empty means not muted.
        public string endMuteTime = "";

        /// <summary>
        /// Applies an Admin mute using the authoritative server time.
        /// When isAddition is true, duration is added to the existing valid end time;
        /// otherwise the end time is set from the current server time.
        /// </summary>
        public bool TryApplyMute(bool isAddition, int durations, DateTime now, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (durations <= 0)
            {
                errorMessage = "Mute duration must be greater than zero seconds.";
                return false;
            }

            DateTime baseTime = DataUtils.StringToTime(DataUtils.TimeToString(now));
            if (isAddition && !string.IsNullOrWhiteSpace(endMuteTime) &&
                TryParseMuteEndTime(out DateTime currentEndTime))
            {
                baseTime = currentEndTime;
            }

            try
            {
                endMuteTime = DataUtils.TimeToString(baseTime.AddSeconds(durations));
                return true;
            }
            catch (ArgumentOutOfRangeException)
            {
                errorMessage = "Mute end time is outside the supported date range.";
                return false;
            }
        }

        /// <summary>
        /// Clears the current mute immediately.
        /// </summary>
        public void ClearMute()
        {
            endMuteTime = string.Empty;
        }

        /// <summary>
        /// Returns whether the player is currently muted and clears stale/invalid values.
        /// </summary>
        public bool IsMuted(DateTime now, out bool wasCleared)
        {
            wasCleared = false;
            if (string.IsNullOrWhiteSpace(endMuteTime))
                return false;

            if (!TryParseMuteEndTime(out DateTime parsedMuteEndTime))
            {
                wasCleared = true;
                return false;
            }

            if (now > parsedMuteEndTime)
            {
                ClearMute();
                wasCleared = true;
                return false;
            }

            return true;
        }

        private bool TryParseMuteEndTime(out DateTime parsedMuteEndTime)
        {
            parsedMuteEndTime = default;
            bool canParse = DateTime.TryParseExact(
                endMuteTime,
                new[] { "yyyy-MM-ddTHH:mm:ss.fffZ", "yyyy-MM-ddTHH.mm.ss.fffZ" },
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None,
                out _) || DateTime.TryParse(
                    endMuteTime,
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.RoundtripKind,
                    out _);
            if (!canParse)
            {
                BattleManager.Log(GameLogType.Warning,
                    $"[CharacterData] Invalid endMuteTime for {id}; clearing stored value.");
                ClearMute();
                return false;
            }

            parsedMuteEndTime = DataUtils.StringToTime(endMuteTime);
            return true;
        }

        #region SkinSet Methods

        public const int MAX_SKIN_SETS = 2;
        public const int MAX_SKINS_PER_SET = 4;

        /// <summary>
        /// Lấy skin set đang active
        /// </summary>
        public List<Equipment> GetActiveSkinSet()
        {
            if (skinSets == null || skinSets.Count == 0)
                return new List<Equipment>();

            if (activeSkinSetIndex < 0 || activeSkinSetIndex >= skinSets.Count)
                return skinSets[0];

            return skinSets[activeSkinSetIndex];
        }

        /// <summary>
        /// Lấy skin set theo index
        /// </summary>
        public List<Equipment> GetSkinSet(int index)
        {
            if (skinSets == null || index < 0 || index >= skinSets.Count)
                return null;
            return skinSets[index];
        }

        /// <summary>
        /// Lấy skin từ set theo loại
        /// </summary>
        public Equipment GetSkinFromSet(int setIndex, EquipmentType skinType)
        {
            var set = GetSkinSet(setIndex);
            if (set == null) return null;

            return set.Find(e => e.equipmentType == skinType);
        }

        /// <summary>
        /// Lấy skin đang active theo loại
        /// </summary>
        public Equipment GetActiveSkin(EquipmentType skinType)
        {
            return GetSkinFromSet(activeSkinSetIndex, skinType);
        }

        /// <summary>
        /// Khởi tạo skin sets nếu chưa có
        /// </summary>
        public void InitializeSkinSets()
        {
            if (skinSets == null)
                skinSets = new List<List<Equipment>>();

            while (skinSets.Count < MAX_SKIN_SETS)
            {
                skinSets.Add(new List<Equipment>());
            }
        }

        /// <summary>
        /// Thêm/thay thế skin trong set
        /// </summary>
        /// <returns>Skin cũ bị thay thế (nếu có)</returns>
        public Equipment SetSkinInSet(int setIndex, Equipment skin)
        {
            if (skinSets == null || setIndex < 0 || setIndex >= skinSets.Count)
                return null;

            if (skin == null || !skin.IsSkin())
                return null;

            var set = skinSets[setIndex];
            Equipment oldSkin = null;

            // Tìm và xóa skin cũ cùng loại
            for (int i = set.Count - 1; i >= 0; i--)
            {
                if (set[i].equipmentType == skin.equipmentType)
                {
                    oldSkin = set[i];
                    set.RemoveAt(i);
                    break;
                }
            }

            // Thêm skin mới
            skin.state = EquipmentState.Character;
            set.Add(skin);

            return oldSkin; // Trả về skin cũ (bị mất)
        }

        /// <summary>
        /// Xóa skin khỏi set
        /// </summary>
        public Equipment RemoveSkinFromSet(int setIndex, EquipmentType skinType)
        {
            if (skinSets == null || setIndex < 0 || setIndex >= skinSets.Count)
                return null;

            var set = skinSets[setIndex];

            for (int i = set.Count - 1; i >= 0; i--)
            {
                if (set[i].equipmentType == skinType)
                {
                    var removed = set[i];
                    set.RemoveAt(i);
                    return removed;
                }
            }

            return null;
        }

        /// <summary>
        /// Kiểm tra set có rỗng không
        /// </summary>
        public bool IsSkinSetEmpty(int setIndex)
        {
            var set = GetSkinSet(setIndex);
            return set == null || set.Count == 0;
        }

        /// <summary>
        /// Lấy tất cả skin từ active set
        /// </summary>
        public List<Equipment> GetAllActiveSkins()
        {
            var result = new List<Equipment>();
            var activeSet = GetActiveSkinSet();

            if (activeSet != null)
            {
                foreach (var skin in activeSet)
                {
                    if (skin != null && skin.IsSkin())
                    {
                        result.Add(skin);
                    }
                }
            }

            return result;
        }

        #endregion

        #region EquipmentSet Methods

        public const int MAX_EQUIPMENT_SETS = 3;
        public const int MAX_EQUIPMENT_PER_SET = 14; // Weapon, Back, Helmet, Cloth, Boot, Mount, Pet, Artifact, Collection Horse, Collection Pet, SkinHorse


        /// <summary>
        /// Lấy equipment set đang active
        /// </summary>
        public EquipmentSetData GetActiveEquipmentSet()
        {
            if (equipmentSets == null || equipmentSets.Count == 0)
                return null;

            foreach (var set in equipmentSets)
            {
                if(set.isActive)
                {
                    return set;
                }
            }

            return null;
        }

        /// <summary>
        /// Lấy equipment set theo index
        /// </summary>
        public EquipmentSetData GetEquipmentSet(int index)
        {
            if (equipmentSets == null || index < 0 || index >= equipmentSets.Count)
                return null;
            return equipmentSets[index];
        }

        /// <summary>
        /// Khởi tạo equipment sets nếu chưa có
        /// </summary>
        public void InitializeEquipmentSets()
        {
            if (equipmentSets == null)
                equipmentSets = new List<EquipmentSetData>();

            int index = 0;  

            while (equipmentSets.Count < MAX_EQUIPMENT_SETS)
            {
                equipmentSets.Add(new EquipmentSetData()
                {
                    id = System.Guid.NewGuid().ToString(),
                    isActive = false,
                    equipmentInSets = new List<EquipmentInSet>()
                });
            }
            index++;
        }
/*
        /// <summary>
        /// Thêm/thay thế equipment trong set
        /// </summary>
        /// <returns>Equipment cũ bị thay thế (nếu có)</returns>
        public void AddEquipmentToSet(int setIndex, string equipmentId)
        {
            if (equipmentSets == null || setIndex < 0 || setIndex >= equipmentSets.Count)
                return;

            var set = equipmentSets[setIndex];
            set.equipmentInSets.Add(equipmentId);
        }*/
        #endregion

        public bool HaveEquipmentInventory(EquipmentType equipmentType)
        {
            foreach (Equipment e in inventory)
            {
                if (e.equipmentType == equipmentType)
                    return true;
            }

            return false;
        }

        public void Reset(int newSeasonId)
        {
            //Reset Wallet
            WalletData walletData = BattleManager.instance.GetWalletData(this.id);
            if (walletData == null)
            {
                Log("reset error. Wallet Data not found",GameLogType.Error);
                return;
            }

            // Leaderboard reward phải được tách trước:
            // - Fang phải được cộng ngay trong reset để ProtectItems() còn chạy đúng ngữ cảnh season transition.
            // - Phần item còn lại mới gửi mail, để người chơi nhận sau mà không làm mất logic protect.
            // - Sau khi xử lý xong thì mark reward as Claimed để tránh bị xử lý lại ở luồng khác.
            if (leaderboardRewards != null)
            {
                for (int i = leaderboardRewards.Count - 1; i >= 0; i--)
                {
                    var leaderboard = leaderboardRewards[i];

                    if (leaderboard.seasonId < this.seasonId - 1)
                    {
                        leaderboardRewards.RemoveAt(i);
                        continue;
                    }

                    if (leaderboard.seasonId != this.seasonId || leaderboard.status != RewardStatus.Pending)
                    {
                        continue;
                    }

                    var box = DataHolder.Instance().GetData<Box>(leaderboard.boxId);
                    if (box == null)
                    {
                        continue;
                    }

                    BattleManager.Log(GameLogType.Info, $"[LeaderboardReward] Before receive Fang, Player {id} have RexFang: {rexFang} | LegendFang: {legendFang} | MythicFang: {mythicFang}");

                    var itemPacks = BattleManager.GetItemPacksFromBox(box);
                    var fangItemPacks = new List<ItemPack>();
                    var mailItemPacks = new List<ItemPack>();

                    foreach (var itemPack in itemPacks)
                    {
                        if (itemPack == null)
                        {
                            continue;
                        }

                        if (itemPack.itemClass == ItemClass.Currency &&
                            (itemPack.itemId == (int)CurrencyID.RexFang ||
                             itemPack.itemId == (int)CurrencyID.LegendFang ||
                             itemPack.itemId == (int)CurrencyID.MythicFang))
                        {
                            fangItemPacks.Add(itemPack);
                            continue;
                        }

                        mailItemPacks.Add(itemPack);
                    }

                    if (fangItemPacks.Count > 0)
                    {
                        ReceiveCurrencies(BattleManager.GetCurrencyFromItemPacks(fangItemPacks));
                    }

                    if (mailItemPacks.Count > 0 && ServerMailManager.Instance != null)
                    {
                        // WARNING: these direct rewards are mailed after season rollover;
                        // creation timing affects title season; see PlayerBehavior.CalculateMailTitleSeason.
                        var rewardsJson = JsonConvert.SerializeObject(mailItemPacks);
                        ServerMailManager.Instance.CreateMail(
                            new List<string> { id },
                            rewardsJson,
                            "System",
                            "Leaderboard Reward",
                            "Season leaderboard reward has been sent to your mailbox.");
                    }

                    Log($"Claim Leaderboard Give Boxid: {box.id} | LeaderboardType: {leaderboard.leaderboardType}");
                    BattleManager.Log(GameLogType.Info, $"[LeaderboardReward] After receive Fang, Player {id} have RexFang: {rexFang} | LegendFang: {legendFang} | MythicFang: {mythicFang}");

                    leaderboard.status = RewardStatus.Claimed;
                    leaderboard.claimedAt = DataUtils.TimeToString(DateTime.UtcNow);
                }
            }

            // Final War cuối mùa 33: không bảo vệ đồ khi qua mùa, đồ rã bình thường, Fang cũng reset cùng mùa.
            // if (rexFang > 0 || legendFang > 0 || mythicFang > 0)
            // {
            //     BattleManager.Log(GameLogType.UserTracking,
            //         this.id + " Has fang permission (rexFang: " + rexFang +
            //         ", legendFang: " + legendFang + ", mythicFang: " + mythicFang + "). Start protecting items");
            //     ProtectItems(walletData);
            // }

            walletData.Reset(newSeasonId);

            //Reset Character
            //seasonStart = DataUtils.TimeToString(System.DateTime.Now);
            lastUpdate = DataUtils.TimeToString(System.DateTime.Now);

            //Reset Equipment
            List<Equipment> removes = new List<Equipment>();
            Equipment currentTitle = null;

            foreach (Equipment equipment in equipments)
            {
                if (equipment.equipmentType == EquipmentType.SkinTitle)
                {
                    currentTitle = equipment;
                    continue;
                }
            }

            var resetResult = GetResetEquipment(equipments);
            removes = resetResult.removes;
            diamond += resetResult.diamond;
            shard += resetResult.shard;

            foreach (Equipment equipment in removes)
            {
                if (equipment != null && equipments.Contains(equipment))
                    equipments.Remove(equipment);
            }

            removes.Clear();

            resetResult = GetResetEquipment(inventory);
            removes = resetResult.removes;
            diamond += resetResult.diamond;
            shard += resetResult.shard;

            foreach (Equipment equipment in removes)
            {
                if (equipment != null && inventory.Contains(equipment))
                    inventory.Remove(equipment);
            }

            removes.Clear();

            //Reset Ingredient
            removes = GetResetIngredient();

            foreach (Equipment equipment in removes)
            {
                if (equipment != null && ingredients.Contains(equipment))
                    ingredients.Remove(equipment);
            }

            removes.Clear();

            var questManager = QuestManager.instance.ServerGetInstance(this);
            //Try claim all achivement before reset
            foreach (var achievement in achievements)
            {
                if (achievement.questState == QuestState.Rewarded)
                {
                    continue;
                }
                var result = questManager.CheckQuest(achievement);
                if (result.errorCode != ErrorCode.Success)
                {
                    continue;
                }

                var achievementConfig = DataHolder.Instance().GetData<Quest>(achievement.questId);
                if (achievementConfig == null)
                {
                    continue;
                }

                var level = achievementConfig.GetLevel(achievement);
                if (level == null)
                {
                    continue;
                }

                var boxIds = level.boxIds;

                foreach (var id in boxIds)
                {
                    var box = DataHolder.Instance().GetData<Box>(id);
                    if (box == null)
                    {
                        continue;
                    }

                    bool isAllStat = Quest.IsDefaultAchievement(achievementConfig.questType);
                    this.ReceiveBox(box, isAllStat);
                }

                achievement.questState = QuestState.Rewarded;
            }


            foreach (var questData in achievementsTeamBattle)
            {
                if (questData.questState == QuestState.Rewarded)
                {
                    continue;
                }
                var result = questManager.CheckQuest(questData);
                if (result.errorCode != ErrorCode.Success)
                {
                    continue;
                }

                var achievementConfig = DataHolder.Instance().GetData<Quest>(questData.questId);
                if (achievementConfig == null)
                {
                    continue;
                }

                var level = achievementConfig.GetLevel(questData);
                if (level == null) continue;

                var boxIds = level.boxIds;

                foreach (var id in boxIds)
                {
                    var box = DataHolder.Instance().GetData<Box>(id);
                    if (box == null)
                    {
                        continue;
                    }

                    this.ReceiveBox(box);
                }

                questData.questState = QuestState.Rewarded;
            }

            //Log("complete reset achievement 6");

            ResetTitleStat(newSeasonId, currentTitle);

            //Reset vip
            ResetVipEndSeason();

            //Set New Season
            seasonId = newSeasonId;

            //Remove effect
            effects.Clear();
            buffs.Clear();

            //Add Stat
            totalChestNumber += chestNumber;
            totalCraftNumber += craftNumber;
            totalKillBossNumber += killBossNumber;
            totalKillMobNumber += killMobNumber;
            totalKillPlayerNumber += killPlayerNumber;
            totalMergeNumber += mergeNumber;
            totalTimePlay += totalPlayerTime;
            achievementRerollNumber = 0;
            bonusV3TransferTicket = 0;
            
            //Deduct change name
            if (changeNameNumber > 3)
                changeNameNumber--;

            //Reset Stat
            memberRole = MemberRole.Member;
            isVip = false;
            gold = 0;
            // Final War cuối mùa 33: Fang không dùng được qua mùa, reset cùng mùa.
            rexFang = 0;
            legendFang = 0;
            mythicFang = 0;
            skinExchange = 1;
            achievementQuestPoint = 0;
            dailyQuestPoint = 0;
            loginPoint = 0;
            health = 100;
            protectionTime = BattleManager.instance.beginerProtectionTime + BattleManager.instance.GetSeasonDays() * 3600;
            teamId = "";
            clanId = "";
            lastTimeAddReviveClanVillage = "";
            clanScore = 0;
            trophy = 0;
            chestNumber = 0;
            killPlayerNumber = 0;
            killMobNumber = 0;
            killBossNumber = 0;
            craftNumber = 0;
            mergeNumber = 0;
            totalPlayerTime = 0;
            arenaCount = 0;
            clanArenaCount = 0;
            teamBattleArenaCount = 0;
            killPlayerInTeamBattle = 0;
            questScore = 0;
            seasonIAPValue = 0;
            seasonTHShop = 0;
            seasonPrisonNumber = 0;
            seasonPrisonNumber = 0;
            mobfireCraftPoint = 0;
            // Reset captcha hitmaps for new season
            seasonCaptchaHitmap = 0;
            todayCaptchaHitmap = 0;
            clanPurchasePetNumber = 0;
            anbePurchaseNumber = 0;
            seasonTeamBattleScore = 0;
            seasonUndeadChestNumber = 0;
            seasonCenterLaneChestNumber = 0;

            //Reset Quest
            Quest quest = DataHolder.Instance().GetData<Quest>(questData.questId);
            if (quest != null)
            {
                QuestLevelData questLevelData = quest.GetLevel(questData);
                if (questLevelData is not null)
                {
                    bool needFix = (quest.questType == QuestType.CraftNumber || quest.questType == QuestType.GoldNumber || quest.questType == QuestType.KillBossNumber
                    || quest.questType == QuestType.KillMobNumber || quest.questType == QuestType.KillPlayerNumber || quest.questType == QuestType.OpenChestNumber
                    || quest.questType == QuestType.TrophyNumber);

                    if (needFix == false)
                    {
                        bool currencyReset = 
                            questLevelData.currencyRequire == CurrencyID.Gold ||
                            questLevelData.currencyRequire == CurrencyID.PlayerTrophy ||
                            questLevelData.currencyRequire == CurrencyID.CraftScore;

                        if (questLevelData.questType == QuestType.HaveCurrency && currencyReset)
                        {
                            needFix = true;
                        }
                    }

                    if (needFix)
                    {
                        questData.requireValue = questData.requireValue - questData.initialValue;
                        questData.initialValue = 0;
                    }
                }
            }

            if (tutorial != null)
            {
                quest = DataHolder.Instance().GetData<Quest>(tutorial.questId);
                if (quest != null)
                {
                    QuestLevelData questLevelData = quest.GetLevel(tutorial);
                    if (questLevelData is not null)
                    {
                        bool needFix = (questLevelData.questType == QuestType.CraftNumber
                        || questLevelData.questType == QuestType.KillBossNumber
                        || questLevelData.questType == QuestType.KillMobNumber
                        || questLevelData.questType == QuestType.KillPlayerNumber
                        || questLevelData.questType == QuestType.OpenChestNumber
                        || questLevelData.questType == QuestType.TrophyNumber
                        || questLevelData.questType == QuestType.KillMobSpecific);

                        if (needFix == false)
                        {
                            bool currencyReset = 
                                questLevelData.currencyRequire == CurrencyID.Gold ||
                                questLevelData.currencyRequire == CurrencyID.PlayerTrophy ||
                                questLevelData.currencyRequire == CurrencyID.CraftScore;

                            if (questLevelData.questType == QuestType.HaveCurrency && currencyReset)
                            {
                                needFix = true;
                            }
                        }

                        if (needFix)
                        {
                            tutorial.requireValue = tutorial.requireValue - tutorial.initialValue;
                            tutorial.initialValue = 0;
                        }
                    }
                }
                else
                {
#if !ENABLE_SERVER_TEST
                    BattleManager.Log(GameLogType.Warning, this.id + " tutorial null. Id " + tutorial.questId);
#endif
                }
            }

            //Log("complete reset quest 7");

            dailyQuestDataQuestPoint = null;
            achievements = new();
            achievementsTeamBattle = new();
            continuousLogin = new();
            dailyQuestDatas = new();
            dailyQuestCreateTime = string.Empty;
            numberLoginOnSeason = 0;

            clanDailyQuestData = new();

            clanDailyQuestDataQuestPoint = new();

            numberRollSeasonEvent = 0;
            numberRollSeasonEventFree = 0;

            //Position
            var landType = WorldManager.Instance.GetLandType(new UnityEngine.Vector2Int((int)posX, (int)posY));

            if (landType == LandType.CenterLand || landType == LandType.UndeadLand)
            {
                Random RNG = new Random();
                posX = RNG.Next(-5, 5);
                posY = RNG.Next(-5, 5);
            }

            //Log("complete reset position 8");

            //Save 
            BattleManager.instance.SaveWalletData(walletData);
            BattleManager.instance.SaveCharacterData(this);

            Log("Characterdata was reset succesfully " + newSeasonId);

            void Log(string value, GameLogType gameLogType = GameLogType.UserTracking)
            {
                BattleManager.Log(gameLogType, id + " " + value);
            }
        }

        public void ResetVipEndSeason()
        {
            playerDailyRewards.Clear();
            playerVipStats.Clear();
            UpdateVipReward();
        }

        public List<Equipment> GetResetIngredient()
        {
            return GetResetItems(ingredients, false).removes;
        }

        public (List<Equipment> removes, int diamond, int shard) GetResetEquipment(List<Equipment> source)
        {
            return GetResetItems(source, false);
        }

        private (List<Equipment> removes, int diamond, int shard) GetResetItems(List<Equipment> source, bool isTournamentReset)
        {
            List<Equipment> removes = new();
            int diamondSell = 0;
            int shardSell = 0;

            foreach (Equipment equipment in source)
            {
                if (equipment == null)
                    continue;

                Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
                bool isIngredientItem = equipment.equipmentType == EquipmentType.Ingredient
                    || equipment.equipmentType == EquipmentType.EventItem;

                bool shouldReset = isTournamentReset
                    ? equipment.madeBy.IsNonEmpty() && equipment.madeBy.Contains(BattleManager.TOURNAMENT_ID)
                    : isIngredientItem
                        ? card == null || card.isSeasonReset
                        : card != null && card.isSeasonReset;

                if (!shouldReset)
                {
                    continue;
                }

                if (isIngredientItem)
                {
                    removes.Add(equipment);
                    continue;
                }

                if (equipment.equipmentType == EquipmentType.SkinTitle)
                    continue;

                //Auto sell summon
                if (card.equipmentType == EquipmentType.Summon)
                {
                    diamondSell += equipment.GetSellCost().value;
                    removes.Add(equipment);
                    continue;
                }

                //Auto sell equipment to get Shards
                if (equipment.IsCrafted())
                {
                    shardSell += equipment.GetShardCost().value;
                    removes.Add(equipment);
                    continue;
                }

                removes.Add(equipment);

            }

            return (removes, diamondSell, shardSell);
        }

        private bool IsProtectedItem(Equipment equipment, Card card)
        {
            if (card == null || !card.isSeasonReset)
                return false;

            if (equipment.IsBaseEquipment() && equipment.IsCrafted())
                return true;

            if (equipment.IsElixir())
                return true;

            if (card.equipmentType == EquipmentType.Summon && card.canPutToMarket)
                return true;

            return false;
        }

        private bool IsProtectedIngredient(Equipment equipment, Card card)
        {
            if (equipment.equipmentType != EquipmentType.Ingredient)
                return false;

            if (card == null || !card.isSeasonReset)
                return false;

            if (card.cost != null && card.cost.Length > 0 && card.cost[0].GetCurrencyType() == CurrencyID.Gold)
                return true;

            return false;
        }

        public void ProtectItems(WalletData walletData)
        {
            List<Equipment> toProtect = new();

            foreach (var equipment in equipments)
            {
                Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
                if (IsProtectedItem(equipment, card))
                {
                    equipment.madeBy = BattleManager.GetTournamentMadeBy();
                    toProtect.Add(equipment);
                }
            }
            foreach (var e in toProtect) equipments.Remove(e);
            walletData.protectedCharacterItems.AddRange(toProtect);
            toProtect.Clear();

            foreach (var equipment in inventory)
            {
                Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
                if (IsProtectedItem(equipment, card))
                {
                    BattleManager.Log(GameLogType.Debug, this.id + " Protected inventory " +
                       card.equipmentType);
                    equipment.madeBy = BattleManager.GetTournamentMadeBy();
                    toProtect.Add(equipment);
                }
            }
            foreach (var e in toProtect) inventory.Remove(e);
            walletData.protectedCharacterItems.AddRange(toProtect);
            toProtect.Clear();

            foreach (var equipment in ingredients)
            {
                Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
                if (IsProtectedIngredient(equipment, card))
                {
                    equipment.madeBy = BattleManager.GetTournamentMadeBy();
                    toProtect.Add(equipment);
                }
            }
            foreach (var e in toProtect) ingredients.Remove(e);
            walletData.protectedCharacterItems.AddRange(toProtect);
            toProtect.Clear();

            foreach (var equipment in walletData.nfts)
            {
                Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
                if (IsProtectedItem(equipment, card))
                {
                    BattleManager.Log(GameLogType.Debug, this.id + " Protected wallet " +
                        card.equipmentType);
                    equipment.madeBy = BattleManager.GetTournamentMadeBy();
                    toProtect.Add(equipment);
                }
            }
            foreach (var e in toProtect) walletData.nfts.Remove(e);
            walletData.protectedWalletItems.AddRange(toProtect);
            toProtect.Clear();

            foreach (var equipment in walletData.ingredients)
            {
                Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
                if (IsProtectedIngredient(equipment, card))
                {
                    equipment.madeBy = BattleManager.GetTournamentMadeBy();
                    toProtect.Add(equipment);
                } 
            }
            foreach (var e in toProtect) walletData.ingredients.Remove(e);
            walletData.protectedWalletItems.AddRange(toProtect);

            int totalProtected = walletData.protectedCharacterItems.Count + walletData.protectedWalletItems.Count;
            if (totalProtected > 0)
            {
                BattleManager.Log(GameLogType.UserTracking,
                    this.id + " Protected " + totalProtected + " items before season reset" +
                    " (character: " + walletData.protectedCharacterItems.Count +
                    ", wallet: " + walletData.protectedWalletItems.Count + ")");
            }
        }
        /// <summary>
        /// dùng để trả lại đồ khi không đi tournament
        /// <para>chỉ sử dụng khi người chơi chưa qua tournament.</para>    
        /// </summary>
        public void RevertProtectedItems()
        {
            WalletData walletData = BattleManager.instance.GetWalletData(this.id);
            if (walletData == null)
            {
                BattleManager.Log(GameLogType.Error,"RevertProtectedItems error. Wallet Data not found");
                return;
            }

            int totalItems = walletData.protectedCharacterItems.Count + walletData.protectedWalletItems.Count;
            if (totalItems == 0)
            {
                BattleManager.Log(GameLogType.UserTracking,
                    this.id + " RevertProtectedItems: no protected items to revert");
                return;
            }

            int totalDiamond = 0;
            int totalShard = 0;

            bool needSaveCharacterData = false;
            bool needSaveWallet = false;

            if (walletData.protectedCharacterItems.Count > 0)
            {
                var equipmentItems = walletData.protectedCharacterItems
                    .FindAll(e => e.equipmentType != EquipmentType.Ingredient
                               && e.equipmentType != EquipmentType.EventItem);

                if (equipmentItems.Count > 0)
                {
                    var resetResult = GetResetEquipment(equipmentItems);
                    totalDiamond += resetResult.diamond;
                    totalShard += resetResult.shard;
                }

                walletData.protectedCharacterItems.Clear();
                needSaveCharacterData = true;
            }

            if (walletData.protectedWalletItems.Count > 0)
            {
                var equipmentItems = walletData.protectedWalletItems
                    .FindAll(e => e.equipmentType != EquipmentType.Ingredient
                               && e.equipmentType != EquipmentType.EventItem);

                if (equipmentItems.Count > 0)
                {
                    var resetResult = GetResetEquipment(equipmentItems);
                    totalDiamond += resetResult.diamond;
                    totalShard += resetResult.shard;
                }

                walletData.protectedWalletItems.Clear();
                needSaveWallet = true;
            }

            diamond += totalDiamond;
            shard += totalShard;

            if (needSaveCharacterData)
            {
                BattleManager.instance.SaveCharacterData(this);
            }

            if (needSaveWallet)
            {
                BattleManager.instance.SaveWalletData(walletData);
            }

            BattleManager.Log(GameLogType.UserTracking,
                this.id + " RevertProtectedItems: reverted " + totalItems + " items" +
                " (diamond: +" + totalDiamond + ", shard: +" + totalShard + ")");
        }

        /// <summary>
        /// dùng để reset đồ khi kết thúc tournament
        /// <para>chỉ hoạt động khi người từ tournament trở về server gốc.</para>    
        /// <para>logic reset hoạt động tương tự reset mùa nhưng chỉ có tác dụng với các món madeby tournament lấy từ battlemanager</para>
        /// </summary>
        public bool ResetTournamentItems()
        {
            WalletData walletData = BattleManager.instance.GetWalletData(this.id);
            if (walletData == null)
            {
                BattleManager.Log(GameLogType.Error, this.id + " ResetTournamentItems error. Wallet Data not found");
                return false;
            }

            int totalItems = 0;
            int totalDiamond = 0;
            int totalShard = 0;

            bool needSaveCharacterData = false;
            bool needSaveWallet = false;

            var characterResetTargets = new List<Equipment>[]
            {
                equipments,
                inventory,
                ingredients
            };

            foreach (var items in characterResetTargets)
            {
                var resetResult = GetResetItems(items, true);
                if (resetResult.removes.Count == 0)
                    continue;

                foreach (Equipment equipment in resetResult.removes)
                {
                    if (equipment != null)
                        items.Remove(equipment);
                }

                totalItems += resetResult.removes.Count;
                totalDiamond += resetResult.diamond;
                totalShard += resetResult.shard;
                needSaveCharacterData = true;
            }

            bool removedProtectedItems = walletData.RemoveProtectedItem();
            bool removedTournamentItems = walletData.RemoveTournamentItem();
            needSaveWallet = removedProtectedItems || removedTournamentItems;

            if (totalItems == 0 && !needSaveWallet)
            {
                BattleManager.Log(GameLogType.UserTracking,
                    this.id + " ResetTournamentItems: no tournament items to reset");
                return false;
            }

            diamond += totalDiamond;
            shard += totalShard;

            if (totalDiamond > 0 || totalShard > 0)
            {
                needSaveCharacterData = true;
            }

            if (needSaveCharacterData)
            {
                BattleManager.instance.SaveCharacterData(this);
            }

            if (needSaveWallet)
            {
                BattleManager.instance.SaveWalletData(walletData);
            }

            BattleManager.Log(GameLogType.UserTracking,
                this.id + " ResetTournamentItems: reset " + totalItems + " items" +
                " (diamond: +" + totalDiamond + ", shard: +" + totalShard + ")");

            return true;
        }

        public void ResetTitleStat(int newSeasonId, Equipment currentTitle)
        {
            if (currentTitle != null && currentTitle.madeBy.IsNonEmpty())
            {
                TryResetTitleStat(newSeasonId, currentTitle);
            }

            foreach (var item in titleEquipment)
            {
                if (item.equipmentType == EquipmentType.SkinTitle
                   && item.madeBy.IsNonEmpty())
                {
                    TryResetTitleStat(newSeasonId, item);
                }
            }
        }

        private void TryResetTitleStat(int newSeasonId, Equipment title)
        {
            if (int.TryParse(title.madeBy, out int titleSeasonId))
            {
                if (titleSeasonId < newSeasonId)
                {
                    ResetTitleStat(title);
                }
            }
            else
            {
                ResetTitleStat(title);

                BattleManager.Log(GameLogType.Error,
                $"{id} Title Error : SeasonId {title.madeBy} ItemID: {title.itemId}");
            }
        }

        private void ResetTitleStat(Equipment equipment)
        {
            equipment.stats = new StatValue[0];
        }

        public CharacterData()
        {

        }



        public CharacterData(PlayerBehavior playerBehavior)
        {
            this.id = playerBehavior.userName;
            this.characterName = playerBehavior.characterName;
            this.memberRole = playerBehavior.memberRole;
            this.characterRole = playerBehavior.characterRole;
            this.characterType = playerBehavior.characterType;
            this.isVip = playerBehavior.isHaveLoginSeasonPass;
            this.chestNumber = playerBehavior.GetChestNumber();
            this.protectionTime = (int)playerBehavior.protectionTime;
            this.killMobNumber = playerBehavior.GetKillMobNumber();
            this.killBossNumber = playerBehavior.GetKillBossNumber();
            this.killPlayerNumber = playerBehavior.GetKillPlayerNumber();
            this.craftNumber = playerBehavior.GetCraftNumber();
            this.teamId = playerBehavior.GetTeamId();
            this.clanId = playerBehavior.clanId;
            this.clanScore = playerBehavior.GetClanScore();
            this.arenaId = playerBehavior.GetArenaId();

            this.trophy = playerBehavior.GetTrophy();
            this.leaveClanTime = playerBehavior.GetLeaveClanTime();
            this.adSkipNumber = playerBehavior.characterInventory.adSkipNumber;
            this.totalPlayerTime = (int)playerBehavior.seasonTimePlay;
            this.todayPlayerTime = (int)playerBehavior.todayTimePlay;
            this.delayHealTime = (int)playerBehavior.delayHealTime;
            this.createdDate = playerBehavior.createdDate;
            this.nextTimeUseSkill = playerBehavior.characterInventory.nextTimeUseSkill;
            this.gold = playerBehavior.characterInventory.gold;
            this.diamond = playerBehavior.characterInventory.diamond;
            this.shard = playerBehavior.characterInventory.shard;
            this.clanCoin = playerBehavior.characterInventory.GetClanCoin();
            this.health = playerBehavior.GetHealth();
            this.posX = playerBehavior.transform.position.x;
            this.posY = playerBehavior.transform.position.y;
            this.arenaCoin = playerBehavior.characterInventory.arenaCoin;
            this.playerArena = playerBehavior.characterInventory.GetPlayerArena();
            this.power = playerBehavior.GetPower();
            this.arenaCount = playerBehavior.arenaCount;
            this.clanArenaCount = playerBehavior.clanArenaCount;
            this.lastSave = DataUtils.TimeToString(System.DateTime.Now);

#if ENABLE_CAPTCHA
            this.totalCaptcha = playerBehavior.totalCaptcha;
            this.totalCorrectCaptcha = playerBehavior.totalCorrectCaptcha;
            this.totalWrongCaptcha = playerBehavior.totalWrongCaptcha;
            this.currentWrongCaptcha = playerBehavior.currentWrongCaptcha;
#endif

            this.numberLoginOnSeason = 1;
            this.seasonTHShop = playerBehavior.seasonTHShop;
            this.seasonIAPValue = playerBehavior.seasonIAPValue;
            this.numberRollSeasonEvent = playerBehavior.numberRollSeasonEvent;
            this.numberRollSeasonEventFree = playerBehavior.numberRollSeasonEventFree;
            this.claimedSocialRewards = playerBehavior.claimedSocialRewards != null
                ? new List<string>(playerBehavior.claimedSocialRewards)
                : new List<string>();

            foreach (Equipment equipment in playerBehavior.characterEquipments.GetEquipments())
            {
                this.equipments.Add(equipment);
            }
            foreach (Equipment equipment in playerBehavior.characterInventory.GetEquipments())
            {
                this.inventory.Add(equipment);
            }
            foreach (Equipment equipment in playerBehavior.characterIngredient.GetEquipments())
            {
                this.ingredients.Add(equipment);
            }

            foreach (Equipment equipment in playerBehavior.characterCollection.GetEquipments())
            {
                this.collections.Add(equipment);
            }

            foreach (Effect effect in playerBehavior.characterEffects.GetEffects())
            {
                this.effects.Add(effect);
            }

            foreach (Buff buff in playerBehavior.characterBuffs.GetBuffs())
            {
                this.buffs.Add(buff);
            }
        }

        /// <summary>
        /// Receive currencies (extracted from ReceiveBox for reuse)
        /// </summary>
        public void ReceiveCurrencies(List<CurrencyData> currencyDatas)
        {
            ReceiveCurrencies(currencyDatas, BoxSourceType.None);
        }

        public void ReceiveCurrencies(List<CurrencyData> currencyDatas, BoxSourceType boxSourceType)
        {
            if (currencyDatas == null || currencyDatas.Count == 0)
                return;

            bool containsTH = currencyDatas.Any(currencyData =>
                currencyData != null && currencyData.GetCurrencyType() == CurrencyID.THCoin);
            if (containsTH && !BattleManager.IsTHRewardSourceAllowed(boxSourceType))
            {
                BattleManager.Log(this, LogAction.SuspiciousActivity,
                    $"Reason:THSourceNotAllowed|Context:CharacterData.ReceiveCurrencies|Source:{boxSourceType}");
                return;
            }

            foreach (CurrencyData currencyData in currencyDatas)
            {
                if (currencyData.GetCurrencyType() == CurrencyID.AutomationTile)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.THCoin)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.Diamond)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.Gold)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.Shard)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.AchievementQuestPoint)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.ClanTrophy)
                {
                    if (boxSourceType != BoxSourceType.Leaderboard)
                    {
                        BattleManager.instance.AddCurrencyData(id, currencyData);
                        ClanData clanData = BattleManager.instance.GetClanData(this.clanId);
                        if (clanData != null && PlayerBehavior.IsUserClan(this.clanId))
                        {

                            BattleManager.LogClan(
                                clanData,
                                LogAction.ClanTrophy,
                                $"Event:AdminGift|SourcePlayer:{characterName}|PlayerId:{id}",
                                value: currencyData.value.ToString(),
                                characterName: characterName);
                        }
                    }
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.PlayerTrophy)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.ArenaCoin)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.SkinExchange)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.RexFang)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.LegendFang)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.MythicFang)
                {
                    BattleManager.Log(GameLogType.UserTracking, $"{id} Before receive Mythic Fang - Current: {mythicFang}");
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                    BattleManager.Log(GameLogType.UserTracking, $"{id} Received Mythic Fang: {currencyData.value}, total: {mythicFang}");
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.BonusV3TransferTicket)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.DailyQuestPoint)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.LoginPoint)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.PlayerClanScore)
                {
                    if (clanId.IsNonEmpty() && PlayerBehavior.IsUserClan(clanId))
                    {
                        clanScore += currencyData.value;
                    }
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.ClanCoin)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.ClanScore)
                {
                    if (clanId.IsNonEmpty() && PlayerBehavior.IsUserClan(clanId))
                    {
                        var clanData = BattleManager.instance.GetClanData(clanId);
                        if (clanData != null)
                        {
                            BattleManager.instance.AddCurrencyData(id, currencyData);
                            BattleManager.LogClan(
                                clanData,
                                LogAction.ClanScore,
                                $"Event:AdminGift|SourcePlayer:{characterName}|PlayerId:{id}|Delta:{currencyData.value}|Final:{clanData.score}",
                                value: currencyData.value.ToString(),
                                characterName: characterName);
                        }
                    }
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.ClanDiamond)
                {
                    if (clanId.IsNonEmpty() && PlayerBehavior.IsUserClan(clanId))
                    {
                        var clanData = BattleManager.instance.GetClanData(clanId);
                        if (clanData != null)
                        {
                            BattleManager.instance.AddCurrencyData(id, currencyData);
                            BattleManager.LogClan(
                                clanData,
                                LogAction.ClanDiamond,
                                $"Event:AdminGift|SourcePlayer:{characterName}|PlayerId:{id}|Delta:{currencyData.value}|Final:{clanData.diamond}",
                                value: currencyData.value.ToString(),
                                characterName: characterName);
                        }
                    }
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.VipScore)
                {
                    AddVipPoint(currencyData.value);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.IAPValue)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.TeamBattleScore ||
                         currencyData.GetCurrencyType() == CurrencyID.CenterLandChestNumber ||
                         currencyData.GetCurrencyType() == CurrencyID.UndeadLandChestNumber ||
                         currencyData.GetCurrencyType() == CurrencyID.PlayerArena)
                {
                    // Offline: truoc day bi bo qua. AddCurrencyData cong vao CharacterData (season value) va cap nhat bang xep hang.
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.CraftScore)
                {
                    craftNumber += currencyData.value;
                }
                else if (currencyData.GetCurrencyType() == CurrencyID.SkipAd)
                {
                    BattleManager.instance.AddCurrencyData(id, currencyData);
                }
            }
        }

        /// <summary>
        /// Receive equipments (extracted from ReceiveBox for reuse)
        /// </summary>
        public void ReceiveEquipments(List<Equipment> equipments, bool isAllStat = false)
        {
            if (equipments == null || equipments.Count == 0)
                return;

            for (int i = 0; i < equipments.Count; i++)
            {
                var e = equipments[i];

                if (e.equipmentType == EquipmentType.Ingredient || e.equipmentType == EquipmentType.EventItem)
                {
                    e.state = EquipmentState.Ingredient;
                    ingredients.Add(e);
                }
                else if (e.IsCollection())
                {
                    e.state = EquipmentState.Collection;
                    collections.Add(e);
                }
                else if (e.equipmentType == EquipmentType.SkinTitle)
                {
                    e.state = EquipmentState.Title;
                    if (int.TryParse(e.madeBy, out var previousSeasonId))
                    {
                        e.madeBy = (previousSeasonId - 1).ToString();
                    }
                    titleEquipment.Add(e);
                }
                else
                {
                    e.state = EquipmentState.Inventory;
                    inventory.Add(e);
                }

                if (isAllStat)
                {
                    BattleManager.Log(this, LogAction.ReciveEndSeasonReward, "1", e.ToJson());
                }
            }
        }

        public void ReceiveBox(Box box, bool isAllStat = false)
        {
            ReceiveBox(box, BoxSourceType.None, isAllStat);
        }

        public void ReceiveBox(Box box, BoxSourceType boxSourceType, bool isAllStat = false)
        {
            RewardCurrencyInspectionResult thInspection =
                BattleManager.InspectBoxForCurrency(box, CurrencyID.THCoin);
            if (thInspection.ContainsCurrency && !BattleManager.IsTHRewardSourceAllowed(boxSourceType))
            {
                BattleManager.Log(this, LogAction.SuspiciousActivity,
                    $"Reason:THSourceNotAllowed|Context:CharacterData.ReceiveBox|Source:{boxSourceType}|BoxId:{box?.id ?? -1}|RewardPath:{thInspection.Path}");
                return;
            }

            List<ItemPack> itemPacks = BattleManager.GetItemPacksFromBox(box);

            var equipments = BattleManager.GetEquipmentsFromItemPacks(itemPacks, isAllStat);
            var currencyDatas = BattleManager.GetCurrencyFromItemPacks(itemPacks);

            // Handle VipBonusStat from item packs
            var vipStats = BattleManager.GetVipBonusTypeFromItemPacks(itemPacks);
            if (vipStats != null && vipStats.Count > 0)
            {
                foreach (var playerVipStat in vipStats)
                {
                    // Add to CharacterData.playerVipStats
                    if (!this.playerVipStats.Contains(playerVipStat))
                    {
                        this.playerVipStats.Add(playerVipStat);

                        // Process VipStat (add to announcement, numberRollSeasonEventFree, automationTile, etc.)
                        BattleManager.ProcessPlayerVipStat(this, playerVipStat);
                    }
                }
            }

            // Use extracted methods
            ReceiveEquipments(equipments, isAllStat);
            ReceiveCurrencies(currencyDatas, boxSourceType);
        }

        /*
        public bool AddTrophy(int value, bool isArena = false)
        {
#if ENABLE_SERVER

            //Sẽ chuyển sang pvp player point 
            return false;

            if (BattleManager.IsTournament)
            {
                return false;
            }    

            //if (IsCompletedTutorial() == false)
            //    return false;

            if (isArena)
            {
                trophy += value;
            }
            else
            {
                int maxPlayerTrophy = BattleManager.instance.gameDataConfig.maxPlayerTrophy;

                if (trophy < maxPlayerTrophy - value)
                {
                    trophy += value;
                }
                else if (trophy < maxPlayerTrophy)
                {
                    trophy = maxPlayerTrophy;
                }
            }

            BattleManager.instance.CheckTopPlayers(this);
            return true;
#endif
            return false;
        }

        */

        public void AddPrisonNumber(int number)
        {
#if ENABLE_SERVER
            dailyPrisonNumber += number;
            seasonPrisonNumber += number;
            totalPrisonNumber += number;
#endif
        }

        public bool IsCompletedTutorial()
        {
            if (questNumber > 0)
                return true;

            var questId = questData.questId;

            if (questId == -1)
                return false;

            var quest = DataHolder.Instance().GetData<Quest>(questId);
            if (quest == null)
                return false;

            if (quest.IsTutorial() == false)
                return true;

            if (quest.IsTutorial() && questData.questState == QuestState.Rewarded)
                return true;

            return false;
        }

        public void AddKillPlayerInTeamBattle(int number)
        {
            killPlayerInTeamBattle += number;
        }

        public void SetKillPlayerInTeamBattle(int number)
        {
            killPlayerInTeamBattle = number;
        }

        public void AddTeamBattleArenaCount(int number)
        {
            teamBattleArenaCount += number;
        }

        public void SetTeamBattleArenaCount(int number)
        {
            teamBattleArenaCount = number;
        }

        public int GetIapValue()
        {
            return iapValue;
        }

        public int GetVipLevel()
        {
            return (int)MathF.Sqrt(vipPoint / 50);
        }

        public void SetIapValue(int value)
        {
            iapValue = value;
        }

        public int GetVipPoint()
        {
            return vipPoint;
        }

        public bool AddVipPoint(int value)
        {
            var oldVip = GetVipLevel();
            vipPoint += value;
            var newVip = GetVipLevel();
            var diff = newVip - oldVip;
            if (diff > 0)
            {
                //On vip level changed
                UpdateVipReward();
                return true;
            }
            else
            {
                return false;
            }
        }

        public float GetVipStatValue(VipBonusType vipBonusType)
        {
            float value = 0;
#if ENABLE_SERVER
            foreach (PlayerVipStat playerVipStat in playerVipStats)
            {
                if (playerVipStat.vipBonusType == vipBonusType)
                    value += playerVipStat.vipValue;
            }
#endif
            return value;
        }

        public PlayerVipStat GetPlayerVipStat(VipBonusType vipBonusType)
        {
#if ENABLE_SERVER
            foreach (PlayerVipStat playerVipStat in playerVipStats)
            {
                if (playerVipStat.vipBonusType == vipBonusType)
                    return playerVipStat;
            }
#endif
            return null;
        }

        public float GetVipStatAutomationTileValue()
        {
            float value = 0;
#if ENABLE_SERVER
            foreach (PlayerVipStat playerVipStat in playerVipStats)
            {
                if (BattleManager.IsVipTypeAutomationTile(playerVipStat.vipBonusType))
                {
                    value += playerVipStat.vipValue;
                }
            }
#endif
            return value;
        }


        /// <summary>Reconcile only the configured VIP-level FilterMarket benefit without replaying other rewards.</summary>
        public bool EnsureVipFilterMarket()
        {
#if ENABLE_SERVER
            if (characterType != CharacterType.Player)
                return false;

            int vipLevel = GetVipLevel();
            if (vipLevel <= 0)
                return false;

            var data = DataHolder.Instance();
            int count = data.GetDataCount<Item>();
            for (int i = 0; i < count; i++)
            {
                var item = data.GetData<Item>(i);
                if (item == null || !item.isAvailable || item.itemType != ItemType.Vip ||
                    item.vipLevel <= 0 || item.vipLevel > vipLevel || item.vipStats == null)
                    continue;

                foreach (var bonus in item.vipStats)
                {
                    if (bonus.vipBonusType != VipBonusType.FilterMarket || !(bonus.value > 0f) || float.IsInfinity(bonus.value))
                        continue;

                    PlayerVipStat existing = null;
                    if (playerVipStats != null)
                    {
                        foreach (var stat in playerVipStats)
                        {
                            if (stat == null || stat.vipBonusType != VipBonusType.FilterMarket) continue;
                            if (stat.vipLevel >= 0 && stat.vipValue > 0f) return false;
                            if (existing == null || stat.vipValue > existing.vipValue) existing = stat;
                        }
                    }

                    if (existing != null)
                    {
                        existing.vipLevel = i;
                        if (!(existing.vipValue > 0f)) existing.vipValue = bonus.value;
                    }
                    else
                    {
                        playerVipStats ??= new List<PlayerVipStat>();
                        playerVipStats.Add(new PlayerVipStat { vipBonusType = VipBonusType.FilterMarket, vipValue = bonus.value, vipLevel = i });
                    }
                    return true;
                }
            }
#endif
            return false;
        }

        //Call when change in vip point
        public void UpdateVipReward()
        {
            EnsureVipFilterMarket();
            int vipLevel = GetVipLevel();
            if (vipLevel == 0)
            {
                playerDailyRewards.Clear();

                List<PlayerVipStat> removes = new();

                foreach (var stat in playerVipStats)
                {
                    //Thue theo thang'
                    if (stat.vipLevel == -1)
                        continue;

                    removes.Add(stat);
                }

                foreach (var stat in removes)
                {
                    playerVipStats.Remove(stat);
                }
                return;
            }

            int n = DataHolder.Instance().GetDataCount<Item>();
            int count = 0;
            for (int i = 0; i < n; i++)
            {
                Item item = DataHolder.Instance().GetData<Item>(i);
                if (item.isAvailable == false)
                    continue;

                if (item.itemType != ItemType.Vip)
                    continue;

                bool isNewVip = true;
                foreach (PlayerDailyReward dailyReward in this.playerDailyRewards)
                {
                    if (dailyReward.itemId == i)
                    {
                        isNewVip = false;
                        break;
                    }
                }

                if (isNewVip)
                {
                    PlayerDailyReward instanceReward = new()
                    {
                        itemId = i,
                        boxId = item.boxId,
                        remaining = 1,
                        itemType = ItemType.Vip,
                        rewardState = RewardState.Ready
                    };
                    this.playerDailyRewards.Add(instanceReward);

                    if (item.dailyBoxIds.Length > 0)
                    {
                        PlayerDailyReward playerDailyReward = new()
                        {
                            itemId = i,
                            boxId = item.dailyBoxIds[0],
                            remaining = -1,
                            itemType = ItemType.Vip,
                            rewardState = RewardState.Ready
                        };
                        this.playerDailyRewards.Add(playerDailyReward);
                    }


                    if (item.vipStats.Length > 0)
                    {
                        for (int j = 0; j < item.vipStats.Length; j++)
                        {
                            PlayerVipStat playerVipStat = new()
                            {
                                vipBonusType = item.vipStats[j].vipBonusType,
                                vipValue = item.vipStats[j].value,
                                vipLevel = i // ??
                            };

                            //TODO: config
                            bool isStack = playerVipStat.vipBonusType == VipBonusType.FreeEventRoll ||
                                           playerVipStat.vipBonusType == VipBonusType.FreeAnnouncement ||
                                           playerVipStat.vipBonusType == VipBonusType.EvoRate ||
                                           playerVipStat.vipBonusType == VipBonusType.GoldRate ||
                                           playerVipStat.vipBonusType == VipBonusType.IngredientRate ||
                                           playerVipStat.vipBonusType == VipBonusType.UpgradeCost ||
                                           playerVipStat.vipBonusType == VipBonusType.MarketTax ||
                                           playerVipStat.vipBonusType == VipBonusType.CraftCost ||
                                           playerVipStat.vipBonusType == VipBonusType.DiamondRate ||
                                           playerVipStat.vipBonusType == VipBonusType.LimitReviveClan;

                            PlayerVipStat current = null;

                            if (isStack == false)
                            {
                                foreach (var v in playerVipStats)
                                {
                                    if (v.vipBonusType == playerVipStat.vipBonusType)
                                    {
                                        current = v;
                                        break;
                                    }
                                }
                            }

                            if (current != null)
                            {
                                //Chuyển các vip đã thuê theo tháng sang unlock vĩnh viễn
                                current.vipLevel = i;
                            }
                            else
                            {
                                this.playerVipStats.Add(playerVipStat);
                                BattleManager.ProcessPlayerVipStat(this, playerVipStat);
                            }
                        }
                    }
                }
                else
                {
                    UpdateVipStatLevel(item, i);
                }

                count++;
                if (count >= vipLevel)
                    return;
            }
        }

        public bool ContainsVipStat(PlayerVipStat playerVipStat)
        {
            foreach (var item in playerVipStats)
            {
                if (item.vipBonusType == playerVipStat.vipBonusType &&
                    item.vipLevel == playerVipStat.vipLevel)
                {
                    return true;
                }
            }

            return false;
        }


        public void ResetVipStat()
        {
            int vipLevel = GetVipLevel();

            this.playerVipStats.Clear();

            int n = DataHolder.Instance().GetDataCount<Item>();
            int count = 0;
            for (int i = 0; i < n; i++)
            {
                Item item = DataHolder.Instance().GetData<Item>(i);
                if (item.isAvailable == false)
                    continue;

                if (item.itemType != ItemType.Vip)
                    continue;

                if (item.vipStats.Length > 0)
                {
                    for (int j = 0; j < item.vipStats.Length; j++)
                    {
                        PlayerVipStat playerVipStat = new()
                        {
                            vipBonusType = item.vipStats[j].vipBonusType,
                            vipValue = item.vipStats[j].value,
                            vipLevel = i // ??
                        };

                        this.playerVipStats.Add(playerVipStat);
                        // Process VipStat (add to announcement, numberRollSeasonEventFree, automationTile, etc.)
                        BattleManager.ProcessPlayerVipStat(this, playerVipStat);
                    }
                }

                count++;
                if (count >= vipLevel)
                    return;
            }
        }

        // Chuyển vip stat từ thuê theo tháng sang vĩnh viễn
        private void UpdateVipStatLevel(Item item, int vipLevel)
        {
            if (item.vipStats.Length == 0)
            {
                return;
            }

            for (int j = 0; j < item.vipStats.Length; j++)
            {
                var type = item.vipStats[j].vipBonusType;
                bool isStatAuto = BattleManager.ListVipStatAuto.Contains(type)
                    || BattleManager.IsVipTypeAutomationTile(type);

                if (isStatAuto)
                {

                    for (int i = 0; i < playerVipStats.Count; i++)
                    {
                        if (playerVipStats[i].vipBonusType == type)
                        {
                            playerVipStats[i].vipLevel = vipLevel;
                            BattleManager.Log(GameLogType.Debug, id + " update vip Level");
                        }
                    }
                }
            }
        }

        public bool HashNoAchievement()
        {
            return achievements == null || achievements.Count == 0;
        }

        public void GenSeasonAchievement()
        {
#if ENABLE_SERVER
            achievements = new();

            var quests = DataHolder.Instance().GetDatas<Quest>();
            var questAchievement = quests.Where((q) => q.isAvailable && q.questCategory == QuestCategory.Achivement
            && q.questResetSchedule == QuestResetSchedule.Season
            && q.id != GameConst.ACHIEVEMENT_QUEST_POINT_ID).ToList();



            var defaultAchievement = questAchievement.Where(q => q.isAvailable
            && Quest.IsDefaultAchievement(q.questType)).ToList();

            var achievementGeneral = questAchievement.Where(q => Quest.IsDefaultAchievement(q.questType) == false).ToList();
            var seasonHardness = GetSeasonHardness();

            var questManager = QuestManager.instance.ServerGetInstance(this);
            var multi = achievementGeneral.Where(q => q.isAvailable
            && q.isMultiLevel
            && q.hardness <= seasonHardness
            && q.questType != QuestType.AchievementQuestPoint).ToList();

            int maxAchievement = 8;
            maxAchievement += (int)GetVipStatValue(VipBonusType.AchivementNumber);

            for (int i = 0; i < maxAchievement; i++)
            {
                var quest = UnityUtils.GetRandomValue(multi);
                var questData = new QuestData
                {
                    questId = quest.Id(),
                    questState = QuestState.Inprogress,
                    receivedStep = 0,
                    questLevel = 0,
                    totalStep = quest.levels.Count,
                };
                questManager.SetQuestValue(questData, quest.levels[0], quest);
                achievements.Add(questData);
                multi.Remove(quest);
            }

            var achievementQuestPoint = DataHolder.Instance().GetData<Quest>(GameConst.ACHIEVEMENT_QUEST_POINT_ID);
            achievementQuestPointQuestData = new QuestData
            {
                questId = GameConst.ACHIEVEMENT_QUEST_POINT_ID,
                questState = QuestState.Inprogress,
                receivedStep = 0,
                questLevel = 0,
                totalStep = achievementQuestPoint.levels.Count,
            };
            questManager.SetQuestValue
            (
                achievementQuestPointQuestData,
                achievementQuestPoint.levels[0],
                achievementQuestPoint
            );

            foreach (var quest in defaultAchievement)
            {
                var questData = new QuestData
                {
                    questId = quest.Id(),
                    questState = QuestState.Inprogress,
                    receivedStep = 0,
                    questLevel = 0,
                    totalStep = quest.levels.Count,
                };

                questManager.SetQuestValue(questData, quest.levels[0], quest);
                achievements.Add(questData);
            }
#endif
        }

        public bool HashNoTeamBattleAchievement()
        {
            return achievementsTeamBattle == null || achievementsTeamBattle.Count == 0;
        }

        public void GenTeamBattleAchievement()
        {
#if ENABLE_SERVER
            achievementsTeamBattle = new();

            var quests = DataHolder.Instance().GetDatas<Quest>();
            var questAchievement = quests.Where((q) => q.isAvailable && q.questCategory == QuestCategory.AchievementTeamBattle
            && q.questResetSchedule == QuestResetSchedule.Season).ToList();


            var questManager = QuestManager.instance.ServerGetInstance(this);

            for (int i = 0; i < questAchievement.Count; i++)
            {
                var quest = questAchievement[i];
                var questData = new QuestData
                {
                    questId = quest.Id(),
                    questState = QuestState.Inprogress,
                    receivedStep = 0,
                    questLevel = 0,
                    totalStep = quest.levels.Count,
                };
                questManager.SetQuestValue(questData, quest);
                achievementsTeamBattle.Add(questData);
            }
#endif
        }

        public bool HasNoDailyQuest()
        {
            return string.IsNullOrEmpty(dailyQuestCreateTime) ||
                dailyQuestDatas == null || dailyQuestDatas.Count == 0;
        }

        public bool IsDailyQuestOutdated(DateTime now)
        {
            var timeCreate = DataUtils.StringToTime(dailyQuestCreateTime);
            return now.Date > timeCreate.Date;
        }


        public void CheckClanDailyQuest(DateTime now)
        {
#if ENABLE_SERVER
            if (!ClanData.CanCreateClanDailyQuest(this))
            {
                return;
            }

            if (IsClanDailyQuestOutdated(now))
            {
                if (clanDailyQuestData != null)
                {
                    clanDailyQuestData.Clear();
                }
                clanDailyQuestCreateTime = DataUtils.TimeToString(now);

                QuestFactory questFactory = new QuestFactory();
                var quests = questFactory.GetQuestAvaiable(QuestCategory.ClanDailyQuest, this);

                var questList = quests.ToList();
                var questManager = QuestManager.instance.ServerGetInstance(this);

                for (int i = 0; i < 5; i++)
                {
                    var quest = UnityUtils.GetRandomValue(questList);
                    questList.Remove(quest);

                    var questData = questFactory.CreateQuestDataByQuestConfig(
                        quest,
                        questManager,
                        QuestCategory.ClanDailyQuest
                    );

                    clanDailyQuestData.Add(questData);
                }

                //clanDailyQuestDataQuestPoint.Clear();

                BattleManager.Log(GameLogType.Debug, $"name: {id} | clan daily quest count: {clanDailyQuestData.Count}");
            }
#endif
        }

        public void CreateClanDailyQuestPoint(int numberMember, System.DateTime now)
        {
#if ENABLE_SERVER
            if (!ClanData.CanCreateClanDailyQuest(this))
            {
                BattleManager.Log(GameLogType.Debug, $"[CreateClanDailyQuestPoint] {id} does not meet clan quest requirements. Return.");

                return;
            }

            QuestFactory questFactory = new();
            var clanData = BattleManager.instance.GetClanData(clanId);
            var questManager = QuestManager.instance.ServerGetInstance(this);

            var configs = questFactory.GetQuestAvaiable(QuestCategory.ClanDailyQuestPoint, this);
            if (configs == null || configs.Length == 0) return;

            List<QuestData> questDatas = new();

            for (int i = 0; i < configs.Length; i++)
            {
                var questData = questFactory.CreateQuestDataByQuestConfig(configs[i],
                    questManager,
                    QuestCategory.ClanDailyQuestPoint);

                questDatas.Add(questData);
            }

            foreach (var entry in questDatas)
                entry.requireValue = TrophyRules.ClanQuestThreshold(entry.questId, numberMember);

            clanDailyQuestDataQuestPoint = questDatas;
            clanDailyQuestPointCreateTime = DataUtils.TimeToString(now);

            BattleManager.Log(GameLogType.Debug, $"[CreateClanDailyQuestPoint] name: {id} | clandailyquestpoint count: {GetClanDailyQuestPoint().Count}");
#endif
        }

        public void ResetClanDailyQuestPointData()
        {
            if (clanDailyQuestDataQuestPoint == null)
            {
                clanDailyQuestDataQuestPoint = new();
            }
            else
            {
                clanDailyQuestDataQuestPoint.Clear();
            }

            clanDailyQuestPointCreateTime = string.Empty;
        }

        public bool TryCreateClanDailyQuestPointData(ClanData clanData, out bool isFirstInitialization)
        {
            isFirstInitialization = false;
#if ENABLE_SERVER
            if (clanData == null || ClanData.IsNoClanOrClanNPC(clanId))
            {
                return false;
            }

            var now = BattleManager.instance.ServerNow();
            if (!HasNoClanDailyQuestPoint() && !IsClanDailyQuestPointOutdated(now))
            {
                return false;
            }

            var require = BattleManager.instance.gameDataConfig.MinClanMemberUnlockQuest;
            if (!clanData.HasEnoughMemberForCreateDailyQuestPoint(require))
            {
                return false;
            }

            if (clanData.IsClanDailyQuestPointOutdated(now))
            {
                isFirstInitialization = string.IsNullOrEmpty(clanData.clanDailyQuestPointResetTime);
                clanData.ResetClanDailyQuestPoint(now);
                clanData.numberMemberOnCreateDailyQuestPoint = clanData.GetNumberMember();
                BattleManager.instance.SaveClanData(clanData);
            }

            CreateClanDailyQuestPoint(clanData.numberMemberOnCreateDailyQuestPoint, now);
            return true;
#endif
            return false;
        }

        public List<QuestData> GetClanDailyQuestPoint()
        {
#if ENABLE_SERVER
            return clanDailyQuestDataQuestPoint;
#endif
            return null;
        }

        public bool HasNoClanDailyQuestPoint()
        {
            return string.IsNullOrEmpty(clanDailyQuestPointCreateTime) ||
                clanDailyQuestDataQuestPoint == null || clanDailyQuestDataQuestPoint.Count == 0;
        }
        public bool IsClanDailyQuestPointOutdated(DateTime now)
        {
#if ENABLE_SERVER_TEST
            if (HasNoClanDailyQuestPoint())
            {
                return true;
            }
#endif

            if (string.IsNullOrEmpty(clanDailyQuestPointCreateTime))
            {
                return true;
            }

            var timeCreate = DataUtils.StringToTime(clanDailyQuestPointCreateTime);
            return now.Date > timeCreate.Date;
        }

        public bool HasNoClanDailyQuest()
        {
            return string.IsNullOrEmpty(clanDailyQuestCreateTime) ||
                clanDailyQuestData == null || clanDailyQuestData.Count == 0;
        }

        public bool IsClanDailyQuestOutdated(DateTime now)
        {
#if ENABLE_SERVER_TEST
            if (HasNoClanDailyQuest())
            {
                return true;
            }
#endif

            if (string.IsNullOrEmpty(clanDailyQuestCreateTime))
            {
                return true;
            }

            var timeCreate = DataUtils.StringToTime(clanDailyQuestCreateTime);
            return now.Date > timeCreate.Date;
        }

        public void ResetClanDailyQuestForJoin(DateTime now)
        {
#if ENABLE_SERVER
            if (clanDailyQuestData == null)
            {
                clanDailyQuestData = new();
            }
            else
            {
                clanDailyQuestData.Clear();
            }

            if (clanDailyQuestDataQuestPoint == null)
            {
                clanDailyQuestDataQuestPoint = new();
            }
            else
            {
                clanDailyQuestDataQuestPoint.Clear();
            }

            clanDailyQuestCreateTime = DataUtils.TimeToString(now);
            clanDailyQuestPointCreateTime = DataUtils.TimeToString(now);
#endif
        }

        public bool IsClanQuestLockedForToday(DateTime now)
        {
#if ENABLE_SERVER
            return clanDailyQuestData?.Count == 0 &&
                clanDailyQuestDataQuestPoint?.Count == 0 &&
                !IsClanDailyQuestOutdated(now) &&
                !IsClanDailyQuestPointOutdated(now);
#endif
            return false;
        }

        public void LockClanQuest()
        {
            if (clanDailyQuestData != null)
            {
                foreach (var item in clanDailyQuestData)
                {
                    item.questState = QuestState.Rewarded;
                }
            }

            if (clanDailyQuestDataQuestPoint != null)
            {
                foreach (var item in clanDailyQuestDataQuestPoint)
                {
                    item.questState = QuestState.Rewarded;
                }
            }
        }

        public void LockClanDailyQuestPoint()
        {
            if (clanDailyQuestDataQuestPoint == null)
            {
                return;
            }

            foreach (var item in clanDailyQuestDataQuestPoint)
            {
                if (item != null)
                {
                    item.questState = QuestState.Rewarded;
                }
            }
        }

        public void GenerateContinuosLogins()
        {
#if ENABLE_SERVER
            continuousLogin = new();
            var questManager = QuestManager.instance.ServerGetInstance(this);

            //Generation Login
            var freeLogin = DataHolder.Instance().GetData<Quest>(GameConst.CONTINUOUS_LOGIN_0);
            var questData = LocalFactory(freeLogin, GameConst.CONTINUOUS_LOGIN_0);
            questManager.SetQuestValue(questData, freeLogin.levels[0], freeLogin);
            continuousLogin.Add(questData);

            //Generation VIP login
            var vipLogin = DataHolder.Instance().GetData<Quest>(GameConst.VIP_CONTINUOUS_LOGIN_0);
            var questDataVip = LocalFactory(vipLogin, GameConst.VIP_CONTINUOUS_LOGIN_0);

            questManager.SetQuestValue(questDataVip, vipLogin.levels[0], vipLogin);
            continuousLogin.Add(questDataVip);

            var loginPoint = DataHolder.Instance().GetData<Quest>(GameConst.CONTINUOUS_COMPLETED_0);
            var questDataLoginPoint = LocalFactory(loginPoint, GameConst.CONTINUOUS_COMPLETED_0);

            questManager.SetQuestValue(questDataLoginPoint, loginPoint.levels[0], loginPoint);
            questDataLogin = questDataLoginPoint;

            QuestData LocalFactory(Quest quest, int id)
            {
                return new QuestData()
                {
                    questId = id,
                    questState = QuestState.Inprogress,
                    receivedStep = 0,
                    totalStep = quest.levels.Count,
                    questLevel = 0
                };
            }
#endif
        }

        public void AddNumberRollSeasonEventFree()
        {
            numberRollSeasonEventFree++;
            //numberRollSeasonEventFree += (int)GetVipStatValue(VipBonusType.FreeEventRoll);
        }

        public void AddAnnouncement()
        {
            announcement += (int)GetVipStatValue(VipBonusType.FreeAnnouncement);
        }

        public void AddAutomationTile()
        {
            automationTile = (int)GetVipStatAutomationTileValue();
        }

        /// <summary>
        /// Reset daily VIP stats trước khi cộng thêm (tạm thời chỉ reset AutomationTile)
        /// </summary>
        public void ResetDailyPlayerVipStat()
        {
#if ENABLE_SERVER
            // Reset AutomationTile về 0
            automationTile = 0;
#endif
        }

        /// <summary>
        /// Duyệt qua toàn bộ playerVipStats và cộng thêm value tương ứng vào các biến
        /// </summary>
        public void AddDailyPlayerVipStat()
        {
#if ENABLE_SERVER
            foreach (PlayerVipStat playerVipStat in playerVipStats)
            {
                BattleManager.ProcessPlayerVipStat(this, playerVipStat);
            }
#endif
        }

        /// <summary>
        /// Sinh 7 quest hằng ngày theo quy luật:
        /// • 4 EASY   hardness 0‑2 nhưng KHÔNG vượt quá minHardness  
        /// • 2 NORMAL hardness 3‑4, nhưng trần cứng = minHardness  
        /// • 1 HARD   hardness đúng bằng minHardness  
        /// Tất cả 7 quest phải khác nhau.
        /// </summary>
        public void GenDailyQuest(DateTime now)
        {
#if ENABLE_SERVER
            dailyQuestDatas = new List<QuestData>();
            var questManager = QuestManager.instance.ServerGetInstance(this);

            var questDailyQuestPoint = DataHolder.Instance().GetData<Quest>(GameConst.QUEST_DAILY_QUEST_POINT);
            var questDataDailyQuestPoint = new QuestData
            {
                questId = GameConst.QUEST_DAILY_QUEST_POINT,
                questState = QuestState.Inprogress,
                receivedStep = 0,
                questLevel = 0,
                totalStep = questDailyQuestPoint.levels.Count,
                questRareType = RareType.Common
            };
            questManager.SetQuestValue(questDataDailyQuestPoint, questDailyQuestPoint.levels[0], questDailyQuestPoint);
            this.dailyQuestDataQuestPoint = questDataDailyQuestPoint;

            var candidates = GetDailyQuestsAvailable();

            int minHardness = GetHardness(totalPlayerTime + totalTimePlay);

            if (candidates.Count == 0)
            {
                BattleManager.Log(GameLogType.Error, "No daily‑quest available!");
                return;
            }

            //EASY
            int maxEasyNumber = 4;
            maxEasyNumber += (int)GetVipStatValue(VipBonusType.DailyQuestNumber);
            int easyMax = UnityEngine.Mathf.Min(2, minHardness);
            AddRandomQuests(candidates.Where(q => q.hardness <= easyMax), maxEasyNumber);

            //NORMAL
            int normalMin = (minHardness < 3) ? minHardness : 3;
            int normalMax = UnityEngine.Mathf.Min(4, minHardness);
            AddRandomQuests(candidates.Where(q =>
                q.hardness >= normalMin && q.hardness <= normalMax), 2);

            //HARD
            AddRandomQuests(candidates.Where(q => q.hardness == minHardness), 1);


            //Nếu không đủ 7 quest thì add ngẫu nhiên, ko quan tâm độ khó, trùng hay ko trùng
            if (dailyQuestDatas.Count < 7)
            {
                var missing = 7 - dailyQuestDatas.Count;
                var fallbackPool = candidates.ToList();

                for (int i = 0; i < missing; i++)
                {
                    Quest quest = Unity.UnityUtils.GetRandomValue(fallbackPool);

                    fallbackPool.Remove(quest);

                    var data = new QuestData
                    {
                        questId = quest.id,
                        questState = QuestState.Inprogress,
                        receivedStep = 0,
                        totalStep = 1,
                        questRareType = RareType.Common
                    };
                    questManager.SetQuestValue(data, quest);
                    dailyQuestDatas.Add(data);
                }
            }

            dailyQuestCreateTime = now.ToString();
            dailyQuestRerollNumber = 0;
            dailyQuestPoint = 0;

            void AddRandomQuests(IEnumerable<Quest> poolEnum, int count)
            {
                List<Quest> pool = poolEnum
                    .Where(q => dailyQuestDatas.All(d => d.questId != q.id))
                    .ToList();
                var questManager = QuestManager.instance.ServerGetInstance(this);

                for (int i = 0; i < count && pool.Count > 0; i++)
                {
                    Quest quest = UnityUtils.GetRandomValue(pool);
                    pool.Remove(quest);

                    var data = new QuestData
                    {
                        questId = quest.id,
                        questState = QuestState.Inprogress,
                        receivedStep = 0,
                        questLevel = 0,
                        totalStep = quest.levels.Count,
                        questRareType = RareType.Common
                    };
                    questManager.SetQuestValue(data, quest);
                    dailyQuestDatas.Add(data);
                }
            }
#endif
        }


        /// <summary>
        /// Gets a list of available daily quests based on season progress and difficulty.
        /// </summary>
        public List<Quest> GetDailyQuestsAvailable()
        {
            List<Quest> randomDaily = new();
            var quests = DataHolder.Instance().GetDatas<Quest>();
            var seasonDay = DateTime.Now - DataUtils.StringToTime(BattleManager.instance.serverConfig.startSeasonDate);
            int minHardness = GetHardness(totalPlayerTime + totalTimePlay);

            for (int i = 0, length = quests.Length; i < length; i++)
            {
                Quest q = quests[i];

                if (q.questCategory != QuestCategory.DailyQuest || !q.isAvailable)
                {
                    continue;
                }

                if (q.Id() == GameConst.ACHIEVEMENT_QUEST_POINT_ID)
                {
                    continue;
                }

                bool isQuestTypeForDaily = q.questType != QuestType.CompleteQuest
                                        && q.questType != QuestType.ContinuosLogin
                                        && q.questType != QuestType.UsedTHInShop;

                if (isQuestTypeForDaily == false)
                {
                    continue;
                }

                if (q.dayAvailable > seasonDay.TotalDays || q.hardness > minHardness)
                {
                    continue;
                }

                if (q.IsGameEventRequirementSatisfied() == false)
                {
                    continue;
                }

                randomDaily.Add(q);
            }

            return randomDaily;
        }
        public List<Quest> GetClanDailyQuestsAvailable()
        {
            List<Quest> randomDaily = new();
            var quests = DataHolder.Instance().GetDatas<Quest>();
            var seasonDay = DateTime.Now - DataUtils.StringToTime(BattleManager.instance.serverConfig.startSeasonDate);
            int minHardness = GetHardness(totalPlayerTime + totalTimePlay);
            var qm = QuestManager.instance.ServerGetInstance(this);
            for (int i = 0, length = quests.Length; i < length; i++)
            {
                Quest q = quests[i];

                if (q.questCategory != QuestCategory.ClanDailyQuest || !q.isAvailable)
                {
                    continue;
                }

                if (q.dayAvailable > seasonDay.TotalDays || q.hardness > minHardness)
                {
                    continue;
                }

                if (q.IsGameEventRequirementSatisfied() == false)
                {
                    continue;
                }

                bool isAvailable = true;
                foreach (var conditions in q.questReciveConditions)
                {
                    if (conditions.Check(qm.QuestProperties) == false)
                    {
                        isAvailable = false;
                        break;
                    };
                }
                if(isAvailable == false)
                {
                    continue;
                }

                randomDaily.Add(q);
            }

            return randomDaily;
        }


        public static int GetHardness(int totalTimes)
        {
            int minHardness;

            if (totalTimes == 0)
            {
                return 0;
            }
            var hour = totalTimes / 3600;

            if (hour > 76)
            {
                minHardness = 7;
            }
            else if (hour > 64)
            {
                minHardness = 6;
            }
            else if (hour > 52)
            {
                minHardness = 5;
            }
            else if (hour > 48)
            {
                minHardness = 4;
            }
            else if (hour > 36)
            {
                minHardness = 3;
            }
            else if (hour > 24)
            {
                minHardness = 2;
            }
            else if (hour > 8)
            {
                minHardness = 1;
            }
            else
            {
                minHardness = 0;
            }
            return minHardness;
        }

        /// <summary>
        /// Tính xem player này đã chơi được mấy mùa
        /// </summary>
        public int GetSeasonHardness()
        {
#if ENABLE_SERVER
            var createdDay = DataUtils.StringToTime(createdDate);
            var now = DateTime.Now;

            int seasonPlay = (now.Year - createdDay.Year) * 12 + now.Month - createdDay.Month;

            if (seasonPlay <= 0)
                return 0;
            else if (seasonPlay == 1)
                return 1;
            else if (seasonPlay == 2)
                return 2;
            else
                return 3;
#endif
            return 99;
        }

        public void GenClanDailyQuest()
        {

        }
    }

    [Serializable]
    public class KeyData : BaseModel
    {
        public string id = "";
        public int itemId = -1;
        public int posX = 0;
        public int posY = 0;
        public string ownerId = "";
        public double timeRemain = 0;
        public string chestId = "";

        public KeyData()
        {

        }

        public KeyData(KeyData keyData)
        {
            this.id = keyData.id;
            this.posX = keyData.posX;
            this.posY = keyData.posY;
            this.ownerId = keyData.ownerId;
            this.timeRemain = keyData.timeRemain;
            this.chestId = keyData.chestId;
        }
    }

    [Serializable]
    public class ChestData : BaseModel
    {
        public string id = "";
        public int itemId = -1;
        public int posX = 0;
        public int posY = 0;
        public double timeRemain = 0;
        public bool isOpening = false;
        public float openTime = 0;
        public string keyId = "";

        public ChestData()
        {

        }

        public ChestData(ChestData chestData)
        {
            this.id = chestData.id;
            this.posX = chestData.posX;
            this.posY = chestData.posY;
            this.timeRemain = chestData.timeRemain;
            this.isOpening = chestData.isOpening;
            this.openTime = chestData.openTime;
            this.keyId = chestData.keyId;
        }
    }

    [Serializable]
    public class CharacterBrief : BaseModel
    {
        public string id = ""; //playfabId
        public string characterName = "";
        public string clanId = "";
        public int cardId = -1;
        public int titleId = -1;
        public ClanMember clanMember = new ClanMember();
        public int clanScore = 0;
        public int trophy = 0;
        public List<EquipmentVisual> equipments = new List<EquipmentVisual>();
        public int health = 0;
        public float posX = 0;
        public float posY = 0;
        public bool isOnline = false;
        public int buildingLevel = 0;

        public CharacterBrief()
        {

        }

        public CharacterBrief(CharacterData characterData, ClanMember member)
        {
            this.id = characterData.id;
            this.characterName = characterData.characterName;
            if (this.characterName == "")
                this.characterName = characterData.id;
            this.clanId = characterData.clanId;
            this.clanScore = characterData.clanScore;
            this.cardId = characterData.cardId;
            this.trophy = characterData.trophy;
            this.titleId = -1;

            if(characterData.equipments != null)
            {
                foreach (Equipment e in characterData.equipments)
                {
                    if (e == null) continue;

                    if (e.equipmentType == EquipmentType.Body || e.equipmentType == EquipmentType.Eye ||
                        e.equipmentType == EquipmentType.Hair || e.equipmentType == EquipmentType.FaceHair ||
                        e.equipmentType == EquipmentType.BuildingPart || e.equipmentType == EquipmentType.Avatar)
                    {
                        EquipmentVisual e1 = new EquipmentVisual(e);
                        this.equipments.Add(e1);
                    }
                    else if (e.equipmentType == EquipmentType.SkinTitle)
                    {
                        if (int.TryParse(e.madeBy, out var titleId))
                        {
                            this.titleId = titleId;
                        }
                    }
                }
            }


            var currentSkinSet = characterData.GetActiveSkinSet();
            if(currentSkinSet != null)
            {
                foreach (var equipment in currentSkinSet)
                {
                    if (equipment == null) continue;

                    EquipmentVisual e1 = new EquipmentVisual(equipment);
                    this.equipments.Add(e1);
                }
            }


            this.health = characterData.health;
            this.posX = characterData.posX;
            this.posY = characterData.posY;
            this.isOnline = characterData.isOnline;
            if (member != null)
            {
                clanMember.playerName = member.playerName;
                clanMember.memberRole = member.memberRole;
                clanMember.storePermission = member.storePermission;
            }

            if (characterData.characterType == CharacterType.Building)
            {
                foreach (var e in equipments)
                {
                    buildingLevel += e.level + (int)e.rareType * 3;
                }
                this.equipments.Clear();
            }
        }
    }

    [Serializable]
    public class Equipment : BaseModel
    {
        private const int DefaultRandomMultiplierMaxStatChancePerThousand = 20;
        public const int BlueprintMarketMinPrice = 10;
        public const int BlueprintMarketMaxPrice = 1000;

        public string id = "";
        public int itemId = -1;
        public int level = 0;
        public string madeBy = "";
        public RareType rareType = RareType.Common;
        public EquipmentType equipmentType = EquipmentType.Item;
        public StatValue[] stats = new StatValue[0];
        public bool isLock = false;
        public EquipmentState state = EquipmentState.New;
        public float sortingOrder = 0;


        public Equipment()
        {
            this.id = Guid.NewGuid().ToString();
        }

        public Equipment(int itemId, MapType mapType)
        {
            this.id = Guid.NewGuid().ToString();
            this.itemId = itemId;
            CreateStats(mapType);
            //CreateSkills(rareType);
        }

        public Equipment(int itemId, RareType rareType, bool isAllStat = false)
        {
            this.id = Guid.NewGuid().ToString();
            this.itemId = itemId;
            this.rareType = rareType;

            Card card = DataHolder.Instance().GetData<Card>(itemId);

            if (card != null)
            {
                if (card.IsCollection())
                {
                    stats = new StatValue[0];
                    CreateStatsMultipler();
                }
                else
                {
                    if (card.equipmentType == EquipmentType.Ingredient || card.equipmentType == EquipmentType.EventItem)
                        this.state = EquipmentState.Ingredient;
                    else
                        this.state = EquipmentState.New;

                    CreateStats(rareType, isAllStat);
                }
            }
        }


        public Equipment(bool isCollection, int itemId, RareType rareType)
        {
            this.id = Guid.NewGuid().ToString();
            this.itemId = itemId;
            this.rareType = rareType;

            if (isCollection)
            {
                stats = new StatValue[0];
                CreateStatsMultipler();
            }
        }

        public Equipment(Equipment equipment)
        {
            DataUtils.CopyObject(this, equipment);
        }



        public StatValue[] GetStats(int level = 0)
        {
            StatValue[] lvStats = new StatValue[0];
            for (int i = 0; i < stats.Length; i++)
            {
                StatValue stat = new StatValue(stats[i]);
                stat.value = stat.GetValue(level, this.equipmentType);
                lvStats = DataUtils.Add(stat, lvStats);
            }

            return lvStats;
        }

        public float GetStat(StatType statType)
        {
            foreach (StatValue statValue in GetStats(level))
            {
                if (statValue.statType == statType)
                    return statValue.value;
            }
            return 0;
        }

        public Stat[] GetStatsEffect()
        {
            StatValue[] stats = GetStats(level);
            List<StatValue> buffs = new();

            foreach (var stat in stats)
            {
                if (BattleManager.IsArtifactIgnoreStat(stat.statType))
                {
                    buffs.Add(stat);
                }
            }

            Stat[] result = new Stat[buffs.Count];

            for (int i = 0; i < buffs.Count; i++)
            {
                result[i] = new Stat()
                {
                    statDataType = StatDataType.Multipler,
                    statType = buffs[i].statType,
                    value = buffs[i].value,
                    statValueType = buffs[i].statValueType
                };

            }
            return result;
        }

        void CreateStats(MapType mapType, bool isAllStat = false)
        {
            int bonus = 10;
            if (mapType == MapType.Wheat)
                bonus = 20;
            else if (mapType == MapType.Rock)
                bonus = 30;
            else if (mapType == MapType.Undead_Grass)
                bonus = 15;
            else if (mapType == MapType.Undead_Wheat)
                bonus = 25;
            else if (mapType == MapType.Undead_Rock)
                bonus = 35;
            else if (mapType == MapType.White_Grass)
                bonus = 20;
            else if (mapType == MapType.White_Wheat)
                bonus = 30;
            else if (mapType == MapType.White_Rock)
                bonus = 40;

            if(BattleManager.instance.GetServerSeason() < 3)
                bonus += 15 - BattleManager.instance.GetServerSeason() * 5;

            Card card = DataHolder.Instance().GetData<Card>(itemId);
            Random RNG = new Random();
            int n1 = RNG.Next(0, 1000);
            if (n1 > 990 - bonus)
                rareType = RareType.Epic;
            else if (n1 > 880 - bonus * 10)
                rareType = RareType.Rare;
            else
                rareType = RareType.Common;

            //if (card.isTradable || card.isLimited)
            //rareType = card.rareType;

#if ENABLE_SERVER_BETA
            if (rareType == RareType.Common || rareType == RareType.Rare)
                rareType = RareType.Epic;
#endif

            CreateStats(rareType, isAllStat);
        }

        void CreateStats(RareType rareType, bool isAllStat = false)
        {
            Random RNG = new();
            Card card = DataHolder.Instance().GetData<Card>(itemId);
            int n2 = RNG.Next(0, 1000);
            int id1 = -1;
            int id2 = -1;
            this.equipmentType = card.equipmentType;

            int maxStatChancePerThousand = DefaultRandomMultiplierMaxStatChancePerThousand;
            if (BattleManager.TryGetGameDataConfig(out var gameDataConfig, logWarning: false))
                maxStatChancePerThousand = gameDataConfig.RateMultiplierMaxStatChancePerThousand;

            // Try tạo stat random cho Blessing Tower Buff
            if (TryCreateRandomMultiplierStats(card, RNG, BLESSING_TOWER_BUFF,
                    BattleManager.RandomStatBuildingPart, maxStatChancePerThousand))
                return;

            if (card.useForCraft && card.equipmentType != EquipmentType.Item && card.equipmentType != EquipmentType.Body
                && card.equipmentType != EquipmentType.Ingredient && card.equipmentType != EquipmentType.BuildingPart
                && card.equipmentType != EquipmentType.Artifact && card.equipmentType != EquipmentType.Blueprint
                && !isAllStat)
            {
                if (rareType == RareType.Common)
                {
                    if (n2 < 900)
                        id1 = RNG.Next(0, 3);
                    if (n2 < 500)
                        id2 = RNG.Next(0, 3);
                }
                else if (rareType == RareType.Rare)
                {
                    if (n2 < 500)
                        id1 = RNG.Next(0, 3);
                    if (n2 < 300)
                        id2 = RNG.Next(0, 3);
                }
                else if (rareType == RareType.Epic)
                {
                    if (n2 < 100)
                        id1 = RNG.Next(0, 3);
                    if (n2 < 20)
                        id2 = RNG.Next(0, 3);
                }
                else if (rareType == RareType.Legendary)
                {

                }
            }

            if (card.stats.Length == 1)
            {
                id1 = -1;
                id2 = -1;
            }


            int index = 0;

            this.stats = new StatValue[card.stats.Length];
            for (int i = 0; i < card.stats.Length; i++)
            {
                var s = card.stats[i];
                StatValue newStat = new StatValue();
                if (index == id1 || index == id2)
                    newStat.value = 0;
                else
                    newStat.value = GetRandomByRare(s.minValue, s.maxValue, rareType);
                newStat.statType = s.statType;
                newStat.statValueType = s.statValueType;
                this.stats[i] = newStat;
                index++;
            }
         
        }

        private bool TryCreateRandomMultiplierStats(
            Card card,
            Random rng,
            int targetCardId,
            StatType[] randomStatTypes,
            int maxStatChancePerThousand)
        {
            if (CanCreateRandomMultiplierStats(card, targetCardId) == false ||
                randomStatTypes == null || randomStatTypes.Length == 0)
                return false;

            StatType statType = randomStatTypes[rng.Next(0, randomStatTypes.Length)];
            List<StatValue> newStats = new()
            {
                CreateRandomMultiplierStat(statType, StatValueType.Add, rng)
            };

            bool canRollMaxStat = rareType == RareType.Epic || rareType == RareType.Legendary;
            if (canRollMaxStat && CanRollRandomMultiplierMaxStat(statType) &&
                rng.Next(0, 1000) < maxStatChancePerThousand)
            {
                newStats.Add(CreateRandomMultiplierStat(statType, StatValueType.Max, rng));
            }

            stats = newStats.ToArray();
            return true;
        }

        private static bool CanCreateRandomMultiplierStats(Card card, int targetCardId)
        {
            if (card == null || card.id != targetCardId)
                return false;

            return card.stats == null || card.stats.Length == 0;
        }

        private static bool CanRollRandomMultiplierMaxStat(StatType statType)
        {
            return statType != StatType.Health && statType != StatType.Damage && statType != StatType.Speed;
        }

        private static StatValue CreateRandomMultiplierStat(StatType statType, StatValueType statValueType, Random rng)
        {
            return new StatValue
            {
                statType = statType,
                statDataType = StatDataType.Multipler,
                statValueType = statValueType,
                value = rng.Next(1000, 3001) / 1000f
            };
        }

        void CreateStatsMultipler()
        {
            Card card = DataHolder.Instance().GetData<Card>(itemId);
            this.equipmentType = card.equipmentType;

            var statValue = new StatValue(BattleManager.CreateRandomPVPStat());
            this.stats = DataUtils.Add(statValue, stats);
        }

        public void ResetStats()
        {
            this.stats = new StatValue[0];
            CreateStats(this.rareType);
        }

        public bool Craft(Equipment equipment, int count)
        {
            Random RNG = new Random();
            int n = RNG.Next(0, 1000);

            if (equipment.GetStat(StatType.SuccessChance) == 100)
                count = 0;

            if (n < 10 * equipment.GetStat(StatType.SuccessChance) - 10 * count)
            {
                foreach (StatValue addStatValue in equipment.stats)
                {
                    if (addStatValue.statType == StatType.SuccessChance || addStatValue.statType == StatType.CraftChance)
                        continue;

                    bool isNew = true;
                    foreach (StatValue statValue in this.stats)
                    {
                        if (statValue.statType == addStatValue.statType)
                        {
                            if (this.equipmentType == EquipmentType.Artifact
                                && BattleManager.IsArtifactIgnoreStat(statValue.statType))
                            {
                                if (statValue.statValueType == StatValueType.Add)
                                {
                                    LogicAddStatArtifact(equipment, addStatValue, statValue);
                                }
                                else if (statValue.statValueType == StatValueType.Max)
                                {
                                    var card = DataHolder.Instance().GetData<Card>(this.itemId);
                                    LogicMaxStatArtifact(equipment, addStatValue, statValue, card.skillType);
                                }

                            }
                            else
                            {
                                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType);
                            }
                            isNew = false;
                        }
                    }

                    //For Artifact only same stat can add to equipment
                    if (isNew && equipmentType != EquipmentType.Artifact)
                    {
                        StatValue newStatValue = new StatValue(addStatValue, equipment.level, equipment.equipmentType);
                        this.stats = DataUtils.Add(newStatValue, this.stats);
                    }
                }

                return true;
            }
            else
            {
                return false;
            }
        }

        private static void LogicAddStatArtifact(Equipment equipment, StatValue addStatValue, StatValue statValue)
        {
            float ratio = 1f;
            if (statValue.value < 0)
                ratio = -1;

            if (statValue.statType == StatType.Health)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 100f * ratio;
            }
            else if (statValue.statType == StatType.Speed)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 0.8f * ratio;
            }
            else if (statValue.statType == StatType.Damage)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 15f * ratio;
            }
            else if (statValue.statType == StatType.Critical)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.Defense)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.CriticalBonus)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.Dodge)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.Accuracy)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.LifeSteal)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.Counterattack)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.PoisonStat)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.Multitarget)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.FreezeStat)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.FireStat)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.HealLongTime)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.Wind)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }            
            else if (statValue.statType == StatType.Summon)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else if (statValue.statType == StatType.Invincible)
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
            else
            {
                statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
            }
        }

        private static void LogicMaxStatArtifact(Equipment equipment, StatValue addStatValue, StatValue statValue, SkillType skillType)
        {
            float ratio = 1f;
            if (skillType == SkillType.DebuffAOE)
                ratio = -1;

            statValue.value += addStatValue.GetValue(equipment.level, equipment.equipmentType) / 10f * ratio;
        }


        float GetRandomByRare(float min, float max, RareType rareType)
        {
            if (max > min)
            {
                Random RNG = new Random();
                float n1 = 0;
                float n2 = 0;
                float range = max - min;
                if (rareType == RareType.Common)
                {
                    n1 = min;
                    n2 = min + range * 0.25f;
                }
                else if (rareType == RareType.Rare)
                {
                    n1 = min + range * 0.25f;
                    n2 = min + range * 0.5f;
                }
                else if (rareType == RareType.Epic)
                {
                    n1 = min + range * 0.5f;
                    n2 = min + range * 0.75f;
                }
                else if (rareType == RareType.Legendary)
                {
                    n1 = min + range * 0.75f;
                    n2 = max;
                }

                return RNG.Next((int)(1000 * n1), (int)(1000 * n2)) / 1000f;
            }
            else
            {
                Random RNG = new Random();
                float n1 = 0;
                float n2 = 0;
                float range = min - max;
                if (rareType == RareType.Common)
                {
                    n1 = min;
                    n2 = min - range * 0.25f;
                }
                else if (rareType == RareType.Rare)
                {
                    n1 = min - range * 0.25f;
                    n2 = min - range * 0.5f;
                }
                else if (rareType == RareType.Epic)
                {
                    n1 = min - range * 0.5f;
                    n2 = min - range * 0.75f;
                }
                else if (rareType == RareType.Legendary)
                {
                    n1 = min - range * 0.75f;
                    n2 = max;
                }

                return RNG.Next((int)(1000 * n2), (int)(1000 * n1)) / 1000f;
            }

        }

        public CurrencyData GetUpgradeCost()
        {
            Card card = DataHolder.Instance().GetData<Card>(itemId);
            CurrencyData[] currencyDatas = card.GetUpgradeCost(level);
            CurrencyData currencyData = new CurrencyData();
            if (currencyDatas.Length > 0)
            {
                currencyData.value = (int)(currencyDatas[0].value * (1 + (int)rareType));
                currencyData.currencyId = currencyDatas[0].currencyId;
            }

            return currencyData;
        }

        public CurrencyData GetUpgradeCost(int lv)
        {
            Card card = DataHolder.Instance().GetData<Card>(itemId);
            CurrencyData[] currencyDatas = card.GetUpgradeCost(lv);
            if (currencyDatas.Length > 0)
            {
                return currencyDatas[0];
            }
            else
                return null;
        }

        public CurrencyData GetCraftCost()
        {
            Card card = DataHolder.Instance().GetData<Card>(itemId);
            CurrencyData[] currencyDatas = card.cost;
            CurrencyData currencyData = new CurrencyData();
            if (currencyDatas.Length > 0)
            {
                currencyData.value = (int)(5 * currencyDatas[0].value * (1 + (int)rareType));
                if (card.IsSkin())
                    currencyData.value /= 2;
                currencyData.currencyId = currencyDatas[0].currencyId;
            }

            return currencyData;
        }

        public int GetCraftChance()
        {
            return 80 - (1 + (int)rareType) * 5 + level;
        }

        public CurrencyData GetSellCost()
        {
            CurrencyData sellCost = new CurrencyData();
            Card card = DataHolder.Instance().GetData<Card>(itemId);
            CurrencyData[] currencyDatas = card.cost;

            if (currencyDatas.Length > 0)
            {
                sellCost.currencyId = currencyDatas[0].currencyId;
                sellCost.value = currencyDatas[0].value / 2;
            }

            for (int i = 0; i < level; i++)
            {
                // Some cards (e.g. Summon) have no upgrade cost table; a missing entry must not abort the season reset at server start.
                var upgradeCost = GetUpgradeCost(i);
                if (upgradeCost != null)
                    sellCost.value += upgradeCost.value / 2;
            }

            sellCost.value *= (int)rareType + 1;

            return sellCost;
        }

        public CurrencyData GetShardCost()
        {
            float cost = 0;

            foreach (StatValue statValue in stats)
            {
                if (statValue.statType == StatType.Health)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 50f;
                }
                else if (statValue.statType == StatType.Speed)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 0.4f;
                }
                else if (statValue.statType == StatType.Damage)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 7.5f;
                }
                else if (statValue.statType == StatType.Critical)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 5f;
                }
                else if (statValue.statType == StatType.Defense)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 5f;
                }
                else if (statValue.statType == StatType.CriticalBonus)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 5f;
                }
                else if (statValue.statType == StatType.Dodge)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 4f;
                }
                else if (statValue.statType == StatType.Accuracy)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 4f;
                }
                else if (statValue.statType == StatType.LifeSteal)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 2f;
                }
                else if (statValue.statType == StatType.Counterattack)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 2f;
                }
                else if (statValue.statType == StatType.InventorySlot)
                {
                    cost += statValue.GetValue(level, this.equipmentType);
                }
                else if (statValue.statType == StatType.IngredientSlot)
                {
                    cost += statValue.GetValue(level, this.equipmentType);
                }
                else if (statValue.statType == StatType.IngredientRate)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 2f;
                }
                else if (statValue.statType == StatType.DiamondRate)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 2f;
                }
                else if (statValue.statType == StatType.GoldRate)
                {
                    cost += statValue.GetValue(level, this.equipmentType) / 4f;
                }
                else if (statValue.statType == StatType.PoisonStat)
                {
                    cost += statValue.GetValue(level, this.equipmentType);
                }
                else if (statValue.statType == StatType.Multitarget)
                {
                    cost += statValue.GetValue(level, this.equipmentType);
                }
                else if (statValue.statType == StatType.FreezeStat)
                {
                    cost += statValue.GetValue(level, this.equipmentType);
                }
                else if (statValue.statType == StatType.FireStat)
                {
                    cost += statValue.GetValue(level, this.equipmentType);
                }
                else if (statValue.statType == StatType.HealLongTime)
                {
                    cost += statValue.GetValue(level, this.equipmentType);
                }
                else if (statValue.statType == StatType.Wind)
                {
                    cost += statValue.GetValue(level, this.equipmentType);
                }
                else if (statValue.statType == StatType.Summon)
                {
                    cost += statValue.GetValue(level, this.equipmentType);
                }
                else if (statValue.statType == StatType.Invincible)
                {
                    cost += statValue.GetValue(level, this.equipmentType);
                }
            }

            Card card = DataHolder.Instance().GetData<Card>(itemId);
            cost -= 5;
            cost = cost * cost / 40;

            if (cost > 5)
                cost += (int)rareType * (int)rareType;

            if (!card.isTradable)
                cost = cost / 3;

            if (card.isTradable && BattleManager.instance != null && BattleManager.instance.GetEventRunning(GameEventId.x2Shard))
                cost *= 2;

            if (IsSkin())
                cost *= 2;

            if (cost < 1)
                cost = 0;

            if (IsElixir())
            {
                cost = 0;
            }    

            CurrencyData shardCost = new()
            {
                currencyId = GameConst.SHARD_ID,
                value = (int)cost
            };
            return shardCost;
        }


        public int GetMarketCost()
        {
            if (equipmentType == EquipmentType.Blueprint)
                return BlueprintMarketMaxPrice;

            float cost = 0;
            Card card = DataHolder.Instance().GetData<Card>(itemId);
            int month = BattleManager.instance.GetServerSeason();


            if (equipmentType == EquipmentType.Ingredient)
            {
                cost = 10;
                foreach (StatValue statValue in stats)
                {
                    if (statValue.statType == StatType.Health)
                    {
                        cost = 6;
                    }
                    else if (statValue.statType == StatType.Speed)
                    {
                        cost = 6;
                    }
                    else if (statValue.statType == StatType.Damage)
                    {
                        cost = 6;
                    }
                    else if (statValue.statType == StatType.Critical)
                    {
                        cost = 6;
                    }
                    else if (statValue.statType == StatType.Defense)
                    {
                        cost = 6;
                    }
                    else if (statValue.statType == StatType.CriticalBonus)
                    {
                        cost = 15;
                    }
                    else if (statValue.statType == StatType.Dodge)
                    {
                        cost = 15;
                    }
                    else if (statValue.statType == StatType.Accuracy)
                    {
                        cost = 15;
                    }
                    else if (statValue.statType == StatType.LifeSteal)
                    {
                        cost = 30;
                    }
                    else if (statValue.statType == StatType.Counterattack)
                    {
                        cost = 30;
                    }
                    else if (statValue.statType == StatType.InventorySlot)
                    {
                        cost = 10;
                    }
                    else if (statValue.statType == StatType.IngredientSlot)
                    {
                        cost = 10;
                    }
                    else if (statValue.statType == StatType.IngredientRate)
                    {
                        cost = 40;
                    }
                    else if (statValue.statType == StatType.DiamondRate)
                    {
                        cost = 40;
                    }
                    else if (statValue.statType == StatType.GoldRate)
                    {
                        cost = 6;
                    }
                    else if (statValue.statType == StatType.PoisonStat)
                    {
                        cost = 45;
                    }
                    else if (statValue.statType == StatType.Multitarget)
                    {
                        cost = 45;
                    }
                    else if (statValue.statType == StatType.FreezeStat)
                    {
                        cost = 45;
                    }
                    else if (statValue.statType == StatType.FireStat)
                    {
                        cost = 45;
                    }
                    else if (statValue.statType == StatType.HealLongTime)
                    {
                        cost = 45;
                    }
                    else if (statValue.statType == StatType.Wind)
                    {
                        cost = 45;
                    }
                    else if (statValue.statType == StatType.Summon)
                    {
                        cost = 50;
                    }
                    else if (statValue.statType == StatType.Invincible)
                    {
                        cost = 50;
                    }
                }

                if (month < 2)
                    cost *= 2f;
                else if (month < 3)
                    cost *= 1.7f;
                else
                    cost *= 1.5f;

                return (int)cost;
            }

            if (equipmentType == EquipmentType.Summon)
            {
                if (itemId == 80)
                    cost = 20;
                else
                    cost = 40;


                if (month < 2)
                    cost *= 1.5f;
                else if (month < 3)
                    cost *= 1.2f;

                return (int)cost;
            }
            else if (equipmentType == EquipmentType.Scroll)
            {
                cost = 1000;
                return (int)cost;
            }                

            float ingredientNumber = 1;
            float ingredientCost = 0;
            float ingredientScale = 1;
            float ingredientPrice = 5;
            float totalIngredientNumber = 0;

            foreach (StatValue statValue in stats)
            {
                if (statValue.statType == StatType.Health)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 50f);
                    ingredientPrice = 5;
                }
                else if (statValue.statType == StatType.Speed)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 0.4f);
                    ingredientPrice = 5;
                }
                else if (statValue.statType == StatType.Damage)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 7.5f);
                    ingredientPrice = 5;
                }
                else if (statValue.statType == StatType.Critical)
                {
                    ingredientNumber = (int)UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 5;
                }
                else if (statValue.statType == StatType.Defense)
                {
                    ingredientNumber = (int)UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 5;
                }
                else if (statValue.statType == StatType.CriticalBonus)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 15;
                }
                else if (statValue.statType == StatType.Dodge)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 15;
                }
                else if (statValue.statType == StatType.Accuracy)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 15;
                }
                else if (statValue.statType == StatType.LifeSteal)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 30;
                }
                else if (statValue.statType == StatType.Counterattack)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 30;
                }
                else if (statValue.statType == StatType.InventorySlot)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType));
                    ingredientPrice = 10;
                }
                else if (statValue.statType == StatType.IngredientSlot)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType));
                    ingredientPrice = 10;
                }
                else if (statValue.statType == StatType.IngredientRate)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 40;
                }
                else if (statValue.statType == StatType.DiamondRate)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 40;
                }
                else if (statValue.statType == StatType.GoldRate)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 5;
                }
                else if (statValue.statType == StatType.PoisonStat)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 45;
                }
                else if (statValue.statType == StatType.Multitarget)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 45;
                }
                else if (statValue.statType == StatType.FreezeStat)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 45;
                }
                else if (statValue.statType == StatType.FireStat)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 45;
                }
                else if (statValue.statType == StatType.HealLongTime)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 45;
                }
                else if (statValue.statType == StatType.Wind)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 45;
                }
                else if (statValue.statType == StatType.Summon)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 45;
                }
                else if (statValue.statType == StatType.Invincible)
                {
                    ingredientNumber = UnityEngine.Mathf.Abs(statValue.GetValue(0, this.equipmentType) / 5f);
                    ingredientPrice = 45;
                }

                //Scale to level 0
                ingredientNumber = ingredientNumber / 2.357f;

                totalIngredientNumber += ingredientNumber;

                ingredientCost += ingredientNumber * ingredientPrice;
            }

            if (totalIngredientNumber >= 16)
            {
                if (IsSkin())
                    ingredientScale = 8f;
                else if (equipmentType == EquipmentType.Artifact)
                    ingredientScale = 9f;
                else
                    ingredientScale = 7f;
            }
            else if (totalIngredientNumber >= 15)
            {
                if (IsSkin())
                    ingredientScale = 7f;
                else if (equipmentType == EquipmentType.Artifact)
                    ingredientScale = 8f;
                else
                    ingredientScale = 6f;
            }
            else if (totalIngredientNumber >= 14)
            {
                if (IsSkin())
                    ingredientScale = 6f;
                else if (equipmentType == EquipmentType.Artifact)
                    ingredientScale = 7f;
                else
                    ingredientScale = 5f;
            }
            else if (totalIngredientNumber >= 13)
            {
                if (IsSkin())
                    ingredientScale = 4f;
                else if (equipmentType == EquipmentType.Artifact)
                    ingredientScale = 5f;
                else
                    ingredientScale = 3.5f;
            }
            else if (totalIngredientNumber >= 12)
            {
                if (IsSkin())
                    ingredientScale = 3f;
                else if (equipmentType == EquipmentType.Artifact)
                    ingredientScale = 4f;
                else
                    ingredientScale = 2.5f;
            }
            else if (totalIngredientNumber >= 11)
            {
                if (IsSkin())
                    ingredientScale = 2.2f;
                else if (equipmentType == EquipmentType.Artifact)
                    ingredientScale = 3f;
                else
                    ingredientScale = 2f;
            }
            else if (totalIngredientNumber >= 10)
            {
                if (IsSkin())
                    ingredientScale = 1.6f;
                else if (equipmentType == EquipmentType.Artifact)
                    ingredientScale = 2f;
                else
                    ingredientScale = 1.5f;
            }
            else if (totalIngredientNumber >= 9)
                ingredientScale = 1.2f;
            else if (totalIngredientNumber >= 7)
                ingredientScale = 1f;
            else if (totalIngredientNumber >= 6)
                ingredientScale = 0.7f;
            else if (totalIngredientNumber >= 5)
                ingredientScale = 0.5f;
            else if (totalIngredientNumber >= 4)
                ingredientScale = 0.3f;
            else if (totalIngredientNumber >= 3)
                ingredientScale = 0.2f;
            else
                ingredientScale = 0.1f;

            ingredientCost *= ingredientScale;

            if (equipmentType != EquipmentType.Artifact)
                cost = (GetSellCost().value + GetCraftCost().value) / 15;
            else
                cost = (GetSellCost().value + GetCraftCost().value) / 5;

            cost += ingredientCost;

            if (month < 2)
                cost *= 1.5f;
            else if (month < 3)
                cost *= 1.2f;

            if (cost < 10)
                cost = 10;

            cost *= 8;
            //if (cost > 5000)
            //    cost = 5000;

            return (int)cost;
        }

        public float GetScore()
        {
            float score = 0;
            for (int i = 0; i < stats.Length; i++)
            {
                score += stats[i].GetValue(level, this.equipmentType) * (1 + (int)this.rareType);
            }

            if (GetSellCost().currencyId == 2)
                score *= 5;

            return score;
        }
        public bool IsCollection()
        {
            return equipmentType == EquipmentType.SkinClan || IsFlatCollection() || IsCollectionPet() || IsCollectionHorse();
        }
        public bool IsFlatCollection()
        {
            // collection cộng thẳng chỉ số, không cộng theo %
            return equipmentType == EquipmentType.Avatar || equipmentType == EquipmentType.SkinHorse || equipmentType == EquipmentType.Emote;
        }
        public bool IsCollectionPet()
        {
            return equipmentType == EquipmentType.SkinIdlePet || equipmentType == EquipmentType.SkinRunPet;
        }
        public bool IsCollectionHorse()
        {
            return equipmentType == EquipmentType.SkinAttack || equipmentType == EquipmentType.SkinRun || equipmentType == EquipmentType.SkinIdle
                || equipmentType == EquipmentType.SkinDeath;
        }

        public bool IsSkinEquiped()
        {
            if (state != EquipmentState.Character)
            {
                return false;
            }

            return IsSkin();
        }

        public bool IsSkin()
        {
            return equipmentType == EquipmentType.Body || equipmentType == EquipmentType.Eye || equipmentType == EquipmentType.Hair
                || equipmentType == EquipmentType.FaceHair;
        }

        public bool IsBasicGear()
        {
            return IsBasicGearType(equipmentType);
        }

        public static bool IsBasicGearType(EquipmentType equipmentType)
        {
            return equipmentType == EquipmentType.Helmet ||
                   equipmentType == EquipmentType.Cloth ||
                   equipmentType == EquipmentType.Back ||
                   equipmentType == EquipmentType.Boot ||
                   equipmentType == EquipmentType.Weapons;
        }

        public bool IsEquipmentInEquipmentSet()
        {
            return equipmentType == EquipmentType.Helmet ||
                   equipmentType == EquipmentType.Cloth ||
                   equipmentType == EquipmentType.Back ||
                   equipmentType == EquipmentType.Boot ||
                   equipmentType == EquipmentType.Weapons ||
                   equipmentType == EquipmentType.Horse ||
                   equipmentType == EquipmentType.Pet ||
                   equipmentType == EquipmentType.Artifact ||
                   equipmentType == EquipmentType.SkinAttack ||
                   equipmentType == EquipmentType.SkinRun ||
                   equipmentType == EquipmentType.SkinIdle ||
                   equipmentType == EquipmentType.SkinRunPet ||
                   equipmentType == EquipmentType.SkinIdlePet ||
                   equipmentType == EquipmentType.SkinHorse;
        }

        /// <summary>
        /// Item-only eligibility for ordinary Player death-drop selection.
        /// Actor/zone checks, weapon exceptions and Limited/Key handling are separate.
        /// </summary>
        public bool CanDropOnDeath()
        {
            if (IsCollection() || IsModEquipment() ||
                equipmentType == EquipmentType.SkinTitle || equipmentType == EquipmentType.Key)
                return false;

            var card = DataHolder.Instance().GetData<Card>(itemId);
            return card != null && !card.isTradable;
        }

        public bool IsModEquipment()
        {
#if ENABLE_SERVER
            return itemId == 1302 || itemId == 1303 || itemId == 1304 || itemId == 1305 || itemId == 1306;
#endif
            return false;
        }
        public bool IsBaseEquipment()
        {
            return equipmentType == EquipmentType.Helmet || equipmentType == EquipmentType.Cloth ||
                    equipmentType == EquipmentType.Boot || equipmentType == EquipmentType.Weapons ||
                    equipmentType == EquipmentType.Horse || equipmentType == EquipmentType.Pet ||
                    equipmentType == EquipmentType.Back || equipmentType == EquipmentType.Artifact;

        }

        /// <summary>
        /// Allow-list of equipment types that <c>LogicUseItem</c> (CmdUseItem) has an explicit branch for:
        /// wearable gear, skins, collections, titles and consumables. Everything else (BuildingPart, Building, Mob,
        /// Npc, ArtifactShard, Chest, Trap, Blueprint, Ingredient, EventItem, undefined values...) must never fall
        /// into the generic "wear gear" fallback. Fail-closed: a new EquipmentType must be added here on purpose.
        /// </summary>
        public static bool IsUseItemSupportedType(EquipmentType type)
        {
            switch (type)
            {
                // Gear worn through the generic equip branch
                case EquipmentType.Helmet:
                case EquipmentType.Cloth:
                case EquipmentType.Boot:
                case EquipmentType.Back:
                case EquipmentType.Weapons:
                case EquipmentType.Horse:
                case EquipmentType.Pet:
                case EquipmentType.Artifact:
                // Skins (IsSkin)
                case EquipmentType.Hair:
                case EquipmentType.FaceHair:
                case EquipmentType.Eye:
                case EquipmentType.Body:
                // Collections (IsCollection)
                case EquipmentType.SkinClan:
                case EquipmentType.Avatar:
                case EquipmentType.SkinHorse:
                case EquipmentType.Emote:
                case EquipmentType.SkinIdlePet:
                case EquipmentType.SkinRunPet:
                case EquipmentType.SkinAttack:
                case EquipmentType.SkinRun:
                case EquipmentType.SkinIdle:
                case EquipmentType.SkinDeath:
                // Title
                case EquipmentType.SkinTitle:
                // Consumables and special branches
                case EquipmentType.Item:
                case EquipmentType.Scroll:
                case EquipmentType.Summon:
                case EquipmentType.BuffItem:
                case EquipmentType.Egg:
                case EquipmentType.Key:
                    return true;
                default:
                    return false;
            }
        }

        public bool IsElixir()
        {
            return itemId == GameConst.ELIXIR_1 || itemId == GameConst.ELIXIR_2 || itemId == GameConst.ELIXIR_3 ||
                    itemId == GameConst.ELIXIR_4 || itemId == GameConst.ELIXIR_5 || itemId == GameConst.ELIXIR_6;
        }

        public bool IsCrafted()
        {
            return string.IsNullOrEmpty(madeBy) == false;
        }

        /// <summary>
        /// Item-only eligibility as a campfire or Forge craft target.
        /// Player, ingredients, recipe outputs and costs are checked by the craft flow.
        /// </summary>
        public bool CanCraft()
        {
            return CanCraft(checkTemporaryState: true);
        }

        /// <summary>Intrinsic craft property, independent of lock and current storage/equipped state.</summary>
        public bool HasCraftProperty()
        {
            return CanCraft(checkTemporaryState: false);
        }

        private bool CanCraft(bool checkTemporaryState)
        {
            if (madeBy != "" || IsCollection() ||
                equipmentType == EquipmentType.SkinTitle || equipmentType == EquipmentType.Egg ||
                equipmentType == EquipmentType.Ingredient || equipmentType == EquipmentType.EventItem)
                return false;

            if (checkTemporaryState && equipmentType == EquipmentType.Blueprint)
            {
                if (isLock || (state != EquipmentState.Inventory && state != EquipmentState.New))
                    return false;
            }
            else if (checkTemporaryState && isLock && !IsSkin())
            {
                return false;
            }

            var card = DataHolder.Instance().GetData<Card>(itemId);
            return card != null && card.useForCraft;
        }

        public bool CanLock()
        {
            return IsBaseEquipment() || IsSkin() || equipmentType == EquipmentType.Summon;
        }

        // Dùng chung client + server
        public ErrorCode CanSendToWallet(Card card)
        {
            return GetWalletEligibility(card, checkTemporaryState: true);
        }

        /// <summary>Intrinsic wallet property; performing a transfer still requires action validation.</summary>
        public bool HasWalletProperty(Card card)
        {
            return GetWalletEligibility(card, checkTemporaryState: false) == ErrorCode.Success;
        }

        private ErrorCode GetWalletEligibility(Card card, bool checkTemporaryState)
        {
            if (card == null)
            {
                return ErrorCode.ItemTypeMismatch;
            }

            if (checkTemporaryState && (state == EquipmentState.Character || state == EquipmentState.Trading))
            {
                return ErrorCode.InvalidItemState;
            }

            if (card.canPutToWallet == false)
            {
                return ErrorCode.WalletNotSupportItem;
            }

            if (equipmentType == EquipmentType.Ingredient)
            {
                if (rareType != RareType.Legendary)
                {
                    return ErrorCode.ItemNotLegendary;
                }
                else
                {
                    return ErrorCode.Success;
                }
            }
            else
            {
                return ErrorCode.Success;
            }
        }

        // Dùng chung client + server
        public ErrorCode CanCreateMarketOrder()
        {
            var card = DataHolder.Instance().GetData<Card>(itemId);
            return CanCreateMarketOrder(card);
        }

        // Dùng chung client + server
        public ErrorCode CanCreateMarketOrder(Card card)
        {
            return GetMarketEligibility(card, checkTemporaryState: true);
        }

        /// <summary>Intrinsic market property, retaining crafted/level/rarity requirements.</summary>
        public bool HasMarketProperty(Card card)
        {
            return GetMarketEligibility(card, checkTemporaryState: false) == ErrorCode.Success;
        }

        private ErrorCode GetMarketEligibility(Card card, bool checkTemporaryState)
        {
            if (card == null)
            {
                return ErrorCode.ItemTypeMismatch;
            }

            if (card.canPutToMarket == false)
            {
                return ErrorCode.TradeWalletItemIsNotTradable;
            }

            if (checkTemporaryState && state == EquipmentState.Trading)
            {
                return ErrorCode.InvalidItemState;
            }

            if (checkTemporaryState && isLock)
            {
                return ErrorCode.ItemIsLocked;
            }

            if (card.marketRequireData.needCrafted)
            {
                if (string.IsNullOrEmpty(madeBy))
                {
                    return ErrorCode.ItemNotCrafted;
                }
            }

            if (level < card.marketRequireData.minLevelRequire)
            {
                return ErrorCode.LevelTooLow;
            }

            if (rareType < card.marketRequireData.rareRequire)
            {
                return ErrorCode.ItemNotLegendary;
            }

            return ErrorCode.Success;
        }

        public ErrorCode CanSendToClanStorage(Card card)
        {
            if (card == null)
            {
                return ErrorCode.ItemTypeMismatch;
            }

            if (card.canPutToClanStore == false)
            {
                return ErrorCode.TradeWalletItemIsNotTradable;
            }

            return ErrorCode.Success;
        }
    }

    [Serializable]
    public class FinalWarReturnData
    {
        public string originServer = "";
        public string originClan = "";
        public MemberRole memberRole = MemberRole.Member;
        public bool storePermission;
        public int clanScore;
        public string leaveClanTime = "";
        public List<QuestData> clanDailyQuestData;
        public List<QuestData> clanDailyQuestDataQuestPoint;
        public string clanDailyQuestCreateTime = "";
        public string clanDailyQuestPointCreateTime = "";
        public bool departureCompleted;
        public string entryKey = "";
        public string returnKey = "";
    }

    [Serializable]
    public class Effect : BaseModel
    {
        [Newtonsoft.Json.JsonProperty] public string finalWarSourceClan { get; set; }
        public int effectId = -1;
        public string endTime = "";
        public Stat[] stats = new Stat[0];

        public bool HaveStat(StatType statType)
        {
            for (int i = 0, length = stats.Length; i < length; i++)
            {
                if (stats[i].statType == statType)
                {
                    return true;
                }
            }
            return false;
        }
    }

    [Serializable]
    public class Buff : BaseModel
    {
        public int buffId = -1;
        public float remaninngTime = 0;
        public Stat[] stats = new Stat[0];
    }

    [Serializable]
    public class CharacterSkill : BaseModel
    {
        public SkillType skillType = SkillType.None;
        public string availableTime = "";
    }

    #region Player info

    /// <summary>
    /// Tất cả các thông tin player có thể public cho player khác
    /// </summary>
    [Serializable]
    public class GamePlayerInfo : BaseModel
    {
        public int pvpCount;
        public int clanWarCount;
        public int questScore;
        public int craftNumber;
        public int chestNumber;
        public int killMobNumber;
        public int killBossNumber;
        public int killPlayerNumber;
        public int trophy;
        public string leaveClanTime = string.Empty;
        public List<PlayerVipStat> playerVipStat = new();
        public float jailTime;
        public List<BoxSuggestion> boxSuggestions = new();
        public string lastServer;
    }

    /// <summary>
    /// Response data for SkinSets request
    /// Sent from server to client when client opens MyCharacterInfoView
    /// </summary>
    [Serializable]
    public class SkinSetsResponse : BaseModel
    {
        public int activeSkinSetIndex;
#if ODIN_INSPECTOR
        [Sirenix.OdinInspector.ListDrawerSettings(DefaultExpandedState = true, ShowIndexLabels = true)]
        [Sirenix.OdinInspector.LabelText("Skin Sets")]
#endif
        public List<List<Equipment>> skinSets = new();
    }

    /// <summary>
    /// Lightweight skin data for network transfer
    /// Contains only essential info needed to display skin preview
    /// </summary>
    [Serializable]
    public class SkinSlotData
    {
        public int itemId;
        public int rareType;
        public int equipmentType;
        public int level;
        public bool isLock;

        /// <summary>
        /// Convert to Equipment for display purposes
        /// </summary>
        public Equipment ToEquipment()
        {
            return new Equipment(itemId, (RareType)rareType)
            {
                equipmentType = (EquipmentType)equipmentType,
                level = level,
                isLock = isLock,
            };
        }
    }

    #endregion

    #region Account Info

    public struct AccountInfoResponse
    {
        public AccountInfoResponseType ResponseType;
        public ErrorCode ErrorCode;
        public AccountInfo AccountInfo;

        public override string ToString()
        {
            return $"ResponseType {ResponseType} - {ErrorCode}";
        }
    }

    public enum AccountInfoResponseType
    {
        None,
        AddEmail,
        VerifyAddEmail,
        RemoveEmail,
        VerifyRemoveEmail,
        AddPhone,
        VerifyAddPhone,
        RemovePhone,
        VerifyRemovePhone,
        ForgotPassword,
        VerifyForgotPassowrd,
    }

    [Serializable]
    public class AccountInfo : BaseModel
    {
        public string username = "";
        public string password = "";
        public string deviceId = "";
        public string pushNotiId = "";
        public string email = "";
        public string submitEmail = "";
        public string emailOTP = "";
        public System.DateTime lastOTPTime;
        public string phoneNumber = "";
        public string submitPhoneNumber = "";
        public string phoneOTP = "";
        public System.DateTime lastPhoneOtpTime;
        public AuthenticateMethod authenticateMethod = AuthenticateMethod.Megacombat;
        public string googleId = "";
        public string facebookId = "";
        public string appleId = "";
        public string created = "";
        public string lastlogin = "";
        public string lastSave = "";
        public string originalServer = "";
        public string currentServer = "";
        public string platform = "";
        public string version = "";
        public string ip = "";
        public bool deleted = false;
        public bool banned = false;
        public string countryCode = "";
        public string countryName = "";
        public string publisher = "";
        public int bannedReason = 0;
        public AccountState accountState;

        public IdentityInfo identityInfo;

        public enum AccountState
        {
            Active = 0,           // Account is active and available
            TRANSFER_PENDING = 1, // Account is being transferred
            InActive = 2          // Account has been transferred away (inactive on this server)
        }
    }




    [Serializable]
    public class IdentityInfo : BaseModel
    {
        public string fullName;
        public string dateOfBirth;

        public string identityNumber;
        public string issuedDate;
        public string issuedPlace;

        public string address;
        public string gender;
    }


    #endregion

    [Serializable]
    public class CharacterUploadData : BaseModel
    {
        public CharacterData characterData;
        public WalletData walletData = new WalletData();

        public CharacterUploadData(PlayerBehavior playerBehavior, WalletData walletData)
        {
            this.characterData = new CharacterData(playerBehavior);
            this.walletData.CopyObject(walletData);
        }
    }

    [Serializable]
    public class MobData : BaseModel
    {
        public string id = "";
        public int mobId = 0;
        public int health = 0;
        public int liveTime = 0;
        public string teamId = "";
        public int arenaId = -1;
        public int posX = 0;
        public int posY = 0;
        public int deadTime = 0;
        public string clanName = "";
        public string mobName = "";
        public int[] abilityTriggerNumber;
    }

    [Serializable]
    public class TrapData : BaseModel
    {
        public TrapState state = TrapState.Deploying;
        public int repairCount = 0;
        public long repairDeadlineUnixSeconds = 0;
        public string id = "";
        public int trapCardId = -1;
        public string ownerCharacterId = "";
        public string clanId = "";
        public string teamId = "";
        public int posX = 0;
        public int posY = 0;
        public LandType landType;
        public int health = 0;
        public float remainingArmTime = 0;
        public float remainingLifetime = 0;
        public StatValue[] stats = new StatValue[0];
    }

    [Serializable]
    public class VikingVillageData : BaseModel
    {
        public int posX = 0;
        public int posY = 0;
        public VikingVillageBehavior.State state;
        public List<MobData> mobData = new List<MobData>();
        public VillageData villageData;
    }

    [Serializable]
    public class SceneData : BaseModel
    {
        // JSON-only: legacy snapshots have no trustworthy Trap season.
        [JsonProperty] public int? trapSeasonId { get; set; }

        public bool ResetTrapsForSeason(int currentSeasonId)
        {
            if (trapSeasonId == currentSeasonId)
                return false;

            if (trapDatas == null)
                trapDatas = new List<TrapData>();
            else
                trapDatas.Clear();
            trapSeasonId = currentSeasonId;
            return true;
        }

        public List<ClanChatDatas> clanChats = new List<ClanChatDatas>();
        public List<MobData> mobDatas = new List<MobData>();
        public List<MobData> orcVillage = new List<MobData>();
        public List<TrapData> trapDatas = new List<TrapData>();
        public List<VikingVillageData> vikingVillageData = new List<VikingVillageData>();
        public ChestData chestData = new ChestData();
        public List<ChestData> undeadChestDatas = new List<ChestData>();
        public KeyData keyData = new KeyData();
        public List<KeyData> undeadKeyDatas = new List<KeyData>();
        public List<ChatData> globalChats = new();
        public float timeGoldEvent = 0;
        public float timeIngredientEvent = 0;
        public float timeShardEvent = 0;
        public float timeDiamondEvent = 0;
        public float timePkIslandEvent = 0;
        public float timeWolfEvent = 0;
        public bool x2Ingredient = false;
        public bool x3DiamondEvent = false;
        public bool x2GoldEvent = false;
        public bool x2ShardEvent = false;
        public bool isPkIslandEvent = false;
        public bool isWolfEvent = false;
    }

    [Serializable]
    public class SeasonResetData : BaseModel
    {
        public Dictionary<string, CharacterData> characterDataReset = new();
        public Dictionary<string, WalletData> walletDataReset = new();
    }

    [Serializable]
    public class LoginData : BaseModel
    {
        public string username = "";
        public int wrongLogin = 0;
        public string deviceID = "";
        public string ipAddress = "";
        public DateTime lockTime;

        public LoginData(string user, string ip)
        {
            username = user;
            ipAddress = ip;
        }

        public void Reset()
        {
            wrongLogin = 0;
            lockTime = System.DateTime.Now;
        }

        public void Lock()
        {
            wrongLogin++;
            if (wrongLogin >= 10)
            {
                lockTime = DateTime.Now.AddSeconds(180);
                //UnityEngine.Debug.Log(username + " was lock for " + wrongLogin + " time wrong pass until " + lockTime.ToString());
            }
        }

        public bool IsLock()
        {
            if (lockTime == null)
                return false;

            if (DateTime.Now >= lockTime)
                return false;
            else
                return true;
        }
    }

    [Serializable]
    public class IpData : BaseModel
    {
        public List<string> usernames = new List<string>();
        public IpData(string user)
        {
            usernames.Add(user);
        }
    }

    [Serializable]
    public class PlayerDailyReward : BaseModel
    {
        public int itemId = 0;
        public int boxId = 0;
        public ItemType itemType = ItemType.Vip;
        public RewardState rewardState = RewardState.None;
        public string createdTime = "";
        public int remaining = 0;
    }

    [Serializable]
    public class PlayerVipStat : BaseModel
    {
        public int vipLevel = 0;
        public VipBonusType vipBonusType = VipBonusType.None;
        public float vipValue = 0;
    }

    [Serializable]
    public class ClanChatDatas : BaseModel
    {
        public string clanName = "";
        public List<ChatData> chatDatas = new List<ChatData>();
    }

    public enum CountdownType
    {
        None,
        OnlineOnly,
        RealTime
    }

    [Serializable]
    public class BoxSuggestion : BaseModel
    {
        public string guId;
        public string ownerCharacterName = "";
        public int itemId;
        public CountdownType countdownType;
        public string startTime;
        public string endTime;
        public int count = 1;
        public CurrencyData price;

        public double remainingOnlineTime;

        public double GetRemainingTime(DateTime currentServerTime)
        {
            if (countdownType == CountdownType.RealTime)
            {
                var end = DataUtils.StringToTime(endTime);
                return (end - currentServerTime).TotalSeconds;
            }
            else if (countdownType == CountdownType.OnlineOnly)
            {
                return remainingOnlineTime;
            }
            else
            {
                return -1;
            }
        }

        public bool IsExpired(DateTime currentServerTime)
        {
            if (countdownType == CountdownType.RealTime)
            {
                var end = DataUtils.StringToTime(endTime);
                return currentServerTime > end;
            }
            else if (countdownType == CountdownType.OnlineOnly)
            {
                return remainingOnlineTime <= 0;
            }
            else
            {
                return true;
            }

        }
    }

}

