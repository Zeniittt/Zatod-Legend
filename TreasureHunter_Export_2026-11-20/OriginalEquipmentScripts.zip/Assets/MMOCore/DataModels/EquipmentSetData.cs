using MCP.DataModel.Utils;
using MCP.DataModels.BaseModels;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class EquipmentSetData : BaseModel
{
    public string id;
    public bool isActive;
    public List<EquipmentInSet> equipmentInSets = new List<EquipmentInSet>();

    // Read-only shared policy; the server must supply its own authoritative storage.
    public bool CanReapply(List<Equipment> equipped, List<Equipment> inventory, List<Equipment> collection)
    {
        if (equipmentInSets == null || equipped == null)
            return false;

        bool differs = false;
        foreach (var saved in equipmentInSets)
        {
            if (saved == null || string.IsNullOrEmpty(saved.id))
                return false;

            bool isEquipped = ContainsEquipment(equipped, saved);
            if (!isEquipped && !ContainsEquipment(inventory, saved) && !ContainsEquipment(collection, saved))
                return false;

            if (!isEquipped)
                differs = true;
        }

        int equippedCount = 0;
        foreach (var equipment in equipped)
        {
            if (equipment != null && equipment.IsEquipmentInEquipmentSet())
                equippedCount++;
        }

        return differs || equippedCount != equipmentInSets.Count;
    }

    private static bool ContainsEquipment(List<Equipment> equipments, EquipmentInSet saved)
    {
        if (equipments == null)
            return false;

        foreach (var equipment in equipments)
        {
            if (equipment != null && equipment.id == saved.id && equipment.equipmentType == saved.equipmentType &&
                equipment.IsEquipmentInEquipmentSet())
                return true;
        }

        return false;
    }

    public EquipmentSetData()
    {
    }

    public EquipmentSetData(EquipmentSetData equipmentSetData)
    {
        this.id = equipmentSetData.id;
        this.isActive = equipmentSetData.isActive;
        this.equipmentInSets = new List<EquipmentInSet>(equipmentSetData.equipmentInSets);
    }

    public EquipmentSetData(string id, bool isActive, List<EquipmentInSet> equipmentInSets)
    {
        this.id = id;
        this.isActive = isActive;
        this.equipmentInSets = equipmentInSets;
    }
}

[Serializable]
public class EquipmentInSet : BaseModel
{
    public string id;
    public EquipmentType equipmentType;

    public EquipmentInSet()
    {
    }

    public EquipmentInSet(string id, EquipmentType equipmentType)
    {
        this.id = id;
        this.equipmentType = equipmentType;
    }
}
