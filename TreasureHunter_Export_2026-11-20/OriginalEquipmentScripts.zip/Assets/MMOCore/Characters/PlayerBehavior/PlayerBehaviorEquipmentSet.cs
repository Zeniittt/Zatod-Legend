﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using MCP.DataModel.Utils;
using MCP.DataModels.BaseModels;
using Mirror;
using Newtonsoft.Json;

public partial class PlayerBehavior
{
#if ENABLE_SERVER
    /// <summary>
    /// Local storage for equipmentSets (copy from characterData on load)
    /// </summary>
    private List<EquipmentSetData> equipmentSetsData = new();
    private float swtichSetPendingTime;

#endif

    private void ResetEquipmentSetsData()
    {
#if ENABLE_SERVER
        equipmentSetsData = new List<EquipmentSetData>();
#endif
    }

    /// <summary>
    /// Load equipmentSets from characterData into local fields
    /// Called from LogicLoadCharacterData
    /// </summary>
    private void LogicLoadEquipmentSets(CharacterData characterData)
    {
#if ENABLE_SERVER
        equipmentSetsData = new List<EquipmentSetData>();

        // Migrate legacy skins first if needed
        MigrateLegacyEquipmentToEquipmentSets(characterData);

        // Copy skinSets from characterData
        if (characterData.equipmentSets != null)
        {
            foreach (var set in characterData.equipmentSets)
            {
                if (set != null)
                {
                    equipmentSetsData.Add(set);
                }
                else
                {
                    equipmentSetsData.Add(new EquipmentSetData()
                    {
                        id = System.Guid.NewGuid().ToString(),
                        isActive = false,
                        equipmentInSets = new List<EquipmentInSet>()
                    });
                }
            }
        }

        while (equipmentSetsData.Count < CharacterData.MAX_EQUIPMENT_SETS)
        {
            equipmentSetsData.Add(new EquipmentSetData()
            {
                id = System.Guid.NewGuid().ToString(),
                isActive = false,
                equipmentInSets = new List<EquipmentInSet>()
            });
        }
#endif
    }

    /// <summary>
    /// Sync equipmentSetsData back to characterData before save
    /// </summary>
    private void SyncEquipmentSetsToCharacterData(CharacterData characterData)
    {
#if ENABLE_SERVER
        characterData.equipmentSets = new List<EquipmentSetData>();
        foreach (var set in equipmentSetsData)
        {
            if (set != null)
            {
                characterData.equipmentSets.Add(set);
            }
            else
            {
                characterData.equipmentSets.Add(new EquipmentSetData()
                {
                    id = System.Guid.NewGuid().ToString(),
                    isActive = false,
                    equipmentInSets = new List<EquipmentInSet>()
                });
            }
        }
        BattleManager.instance.SavePlayerData(this);
#endif
    }

    #region Equipment Helper Methods

    private EquipmentSetData GetActiveEquipmentSetData()
    {
#if ENABLE_SERVER
        if (equipmentSetsData == null || equipmentSetsData.Count == 0)
            return null;
        
        foreach (var set in equipmentSetsData)
        {
            if (set.isActive)
            {
                return set;
            }
        }

        return null;
#else
        return null;
#endif
    }

    private void SetActiveSetEquipment(string setId, bool isActive)
    {
#if ENABLE_SERVER
        if (equipmentSetsData == null || string.IsNullOrEmpty(setId))
            return;
        foreach (var set in equipmentSetsData)
        {
            if (set.id == setId)
            {
                set.isActive = isActive;
                break;
            }
        }
#endif
    }

    private EquipmentSetData GetEquipmentSetDataById(string setId)
    {
#if ENABLE_SERVER
        if (equipmentSetsData == null || setId.IsNullOrEmpty())
            return null;
        foreach(var set in equipmentSetsData)
        {
            if(set.id == setId)
            {
                return set;
            }
        }

        return null;
#else
        return null;
#endif
    }

    private void InitializeEquipmentSetsData()
    {
#if ENABLE_SERVER
        if (equipmentSetsData == null)
            equipmentSetsData = new List<EquipmentSetData>();

        while (equipmentSetsData.Count < CharacterData.MAX_EQUIPMENT_SETS)
        {
            equipmentSetsData.Add(new EquipmentSetData()
            {
                id = System.Guid.NewGuid().ToString(),
                isActive = false,
                equipmentInSets = new List<EquipmentInSet>()
            });
        }
#endif
    }

    private EquipmentSetData SetAllEquipmentInSetData(string setId, List<EquipmentInSet> equipmentInSets)
    {
#if ENABLE_SERVER
        if (equipmentSetsData == null || setId.IsNullOrEmpty())
            return null;

        if (equipmentInSets == null)
            return null;

        var oldSet = GetEquipmentSetDataById(setId);
        var newSet = GetEquipmentSetDataById(setId);
        newSet.equipmentInSets = equipmentInSets;

        return oldSet;
#else
        return null;
#endif
    }

    /// <summary>
    /// Tìm equipment trong tất cả equipmentSets theo equipment id
    /// Trả về (setIndex, equipmentIndex) nếu tìm thấy, (-1, -1) nếu không
    /// </summary>
//    private void FindAndRemoveEquipmentInEquipmentSetsData(string equipmentId)
//    {
//#if ENABLE_SERVER
//        if (equipmentSetsData == null || string.IsNullOrEmpty(equipmentId))
//            return;

//        int count = 0;
//        for (int setIndex = 0; setIndex < equipmentSetsData.Count; setIndex++)
//        {
//            var set = equipmentSetsData[setIndex];
//            if (set == null || set.Count == 0) continue;

//            for (int i = set.Count - 1; i >= 0; i--)
//            {
//                if (set[i].id == equipmentId)
//                {
//                    set.RemoveAt(i);
//                    count++;
//                }
//            }
//        }

//        BattleManager.Log(GameLogType.Debug, $"[CmdCraftItem] Removed {count} equipment(s) from equipment sets due to crafting failure of equipment ID: {equipmentId}");

//        var characterData = BattleManager.instance.GetCharacterData(userName);
//        if (characterData != null)
//        {
//            SyncEquipmentSetsToCharacterData(characterData);
//        }

//        // Notify thành công với data của set được add
//        string responseJson = JsonConvert.SerializeObject(equipmentSetsData);
        
//        TargetEquipmentSetsChangeAll(connectionToClient, responseJson);
//#endif
//    }

//    private void FindAndReplaceEquipmentInEquipmentSetsData(string equipmentId, Equipment newEquipment)
//    {
//#if ENABLE_SERVER
//        if (equipmentSetsData == null || string.IsNullOrEmpty(equipmentId) || newEquipment == null)
//            return;

//        int count = 0;

//        for (int setIndex = 0; setIndex < equipmentSetsData.Count; setIndex++)
//        {
//            var set = equipmentSetsData[setIndex];
//            if (set == null || set.Count == 0) continue;

//            for (int i = set.Count - 1; i >= 0; i--)
//            {
//                if (set[i].id == equipmentId)
//                {
//                    set[i] = newEquipment;
//                    count++;
//                }
//            }
//        }

//        BattleManager.Log(GameLogType.Debug, $"[CmdCraftItem] Replaced {count} equipment(s) in equipment sets with old equipmentID: {equipmentId} | new equipment ID: {newEquipment.id} due to crafting success");

//        var characterData = BattleManager.instance.GetCharacterData(userName);
//        if (characterData != null)
//        {
//            SyncEquipmentSetsToCharacterData(characterData);
//        }

//        // Notify thành công với data của set được add
//        string responseJson = JsonConvert.SerializeObject(equipmentSetsData);

//        TargetEquipmentSetsChangeAll(connectionToClient, responseJson);
//#endif
//    }

    /// <summary>
    /// Xóa equipment khỏi equipmentSetsData theo equipment id
    /// Trả về (setIndex, removedEquipment) nếu tìm thấy, (-1, null) nếu không
    /// </summary>
/*    private (int setIndex, Equipment removedEquipment) RemoveEquipmentFromEquipmentSetsDataById(string equipmentId)
    {
#if ENABLE_SERVER
        if (equipmentSetsData == null || string.IsNullOrEmpty(equipmentId))
            return (-1, null);

        for (int setIndex = 0; setIndex < equipmentSetsData.Count; setIndex++)
        {
            var set = equipmentSetsData[setIndex];
            if (set == null) continue;

            for (int i = set.Count - 1; i >= 0; i--)
            {
                if (set[i].id == equipmentId)
                {
                    var removed = set[i];
                    set.RemoveAt(i);
                    return (setIndex, removed);
                }
            }
        }
#endif
        return (-1, null);
    }
*/
    #endregion

    #region EquipmentSet Request Methods

    //----------------------------------------------------------------
    //Request EquipmentSet - Add Equipment To Set
    //----------------------------------------------------------------
    /// <summary>
    /// Request thêm equipment từ inventory vào equipment set
    /// </summary>
    [Client]
    public void RequestSaveEquipmentSet(List<string> equipmentIds, string setId, int apiToken)
    {
        if (!NetworkClient.isConnected) return;

        CmdSaveEquipmentSet(equipmentIds, setId, apiToken);
    }

    [Command]
    public void CmdSaveEquipmentSet(List<string> equipmentIds, string setId, int apiToken)
    {
#if ENABLE_SERVER
        if (GetHealth() <= 0) return;
        if (!ServerValidateApiToken(apiToken, nameof(CmdSaveEquipmentSet))) return;

        if(equipmentIds.Count > CharacterData.MAX_EQUIPMENT_PER_SET)
        {
            Log(LogAction.SaveEquipmentSet,
                $"[CmdSaveEquipmentSet] EquipmentIds Count {equipmentIds.Count} more than EquipmentSet Coun config");
            return;
        }

        BattleManager.Log(GameLogType.Debug, $"Start AddEquipmentsToSet setId={setId}, Count={equipmentIds.Count}, equipmentIds={string.Join(",", equipmentIds)}, userName={userName}");

        List<EquipmentInSet> validEquipments = new List<EquipmentInSet>();
        HashSet<EquipmentType> equipmentTypeExist = new HashSet<EquipmentType>();

        var equippeds = characterEquipments.GetEquipments();
        var collections = characterCollection.GetEquipments();
        var inventories = characterInventory.GetEquipments();

        if (equipmentIds != null)
        {
            foreach (var equipmentId in equipmentIds)
            {
                Equipment found = equippeds.FirstOrDefault(x => x.id == equipmentId)
                        ?? collections.FirstOrDefault(x => x.id == equipmentId)
                        ?? inventories.FirstOrDefault(x => x.id == equipmentId);

                if (found == null)
                {
                    BattleManager.Log(GameLogType.Debug, $"[CmdSaveEquipmentSet] Equipment not found in any storage: equipmentId={equipmentId}, userName={userName}");
                    continue;
                }

                if (found.IsEquipmentInEquipmentSet() == false)
                {
                    BattleManager.Log(GameLogType.Debug, $"[CmdSaveEquipmentSet] Equipment is not EquipmentInEquipmentSet: setId={setId}, equipmentId={found.itemId}, equipmentType={found.equipmentType}, userName={userName}");
                    continue;
                }

                if (equipmentTypeExist.Add(found.equipmentType) == false)
                {
                    BattleManager.Log(GameLogType.Debug, $"[CmdSaveEquipmentSet] Equipment have EquipmentType is exist in this set: setId={setId}, equipmentId={found.itemId}, equipmentType={found.equipmentType}, userName={userName}");
                    continue;
                }

                validEquipments.Add(new EquipmentInSet
                {
                    id = found.id,
                    equipmentType = found.equipmentType
                });

                BattleManager.Log(GameLogType.Debug, $"[CmdSaveEquipmentSet] Equipment have been added to set: setId={setId}, equipmentId={found.itemId}, userName={userName}");
            }
        }

        // Khởi tạo equipment sets nếu cần
        InitializeEquipmentSetsData();

        // Thay thế toàn bộ set cũ bằng set mới
        var oldSet = SetAllEquipmentInSetData(setId, validEquipments);

        // Log nếu có equipment bị replace
        if (oldSet != null)
        {
            Log(LogAction.UseSkin,
                $"OldSetCount={oldSet.equipmentInSets.Count};NewSetCount={validEquipments.Count};Set={setId}",
                $"{{\"oldSet\":{JsonConvert.SerializeObject(oldSet)},\"newSet\":{JsonConvert.SerializeObject(validEquipments)}}}");
        }

        // Nếu đang active set này thì cập nhật visual
        if (GetActiveEquipmentSetData().id == setId)
        {
            BattleManager.Log(GameLogType.Debug, $"[CmdSaveEquipmentSet] Reload skins from active set after add equipment: setIndex={setId}, userName={userName}");
            ReloadEquipmentsFromActiveSet();
        }

        // Sync to characterData and save
        var characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData != null)
        {
            SyncEquipmentSetsToCharacterData(characterData);
        }

        var setData = GetEquipmentSetDataById(setId);


        // Notify thành công với data của set được add
        string responseJson = JsonConvert.SerializeObject(setData);
        TargetSaveEquipmentSet(connectionToClient, setId, responseJson);
#endif
    }

    [TargetRpc]
    public void TargetSaveEquipmentSet(NetworkConnection conn, string setId, string setDataJson)
    {
        ClientManager.instance.OnEquipmentsAddedToSet(setId, setDataJson);
    }

    //----------------------------------------------------------------
    //Request EquipmentSet - Switch Equipment Set
    //----------------------------------------------------------------

    [Client]
    public void RequestSwitchEquipmentSet(string setId, int apiToken)
    {
        if (!NetworkClient.isConnected) return;

        CmdSwitchEquipmentSet(setId, apiToken);
    }

    [Command]
    public void CmdSwitchEquipmentSet(string setId, int apiToken)
    {
#if ENABLE_SERVER
        if (GetHealth() <= 0) return;
        if (!ServerValidateApiToken(apiToken, nameof(CmdSwitchEquipmentSet))) return;

        if(swtichSetPendingTime > 0)
        {
            TargetEquipmentSetSwitchedFailure(connectionToClient, NotifyType.MiddleNotify);
            return;
        }

        // Validate set exists
        if (equipmentSetsData == null)
        {
            BattleManager.Log(GameLogType.Debug, $"[CmdSwitchEquipmentSet] Set not found: setId={setId}, userName={userName}");
            return;
        }

        EquipmentSetData oldActiveSet = GetActiveEquipmentSetData();
        if (oldActiveSet.id == setId && !oldActiveSet.CanReapply(
                characterEquipments.GetEquipments(), characterInventory.GetEquipments(), characterCollection.GetEquipments()))
        {
            BattleManager.Log(GameLogType.Debug, $"[CmdSwitchEquipmentSet] Currently, This set is active: setId={setId}, userName={userName}");
            return;
        }

        EquipmentSetData setTarget = null;
        int setIndex = -1;

        for (int i = 0; i < equipmentSetsData.Count; i++) 
        {
            if (equipmentSetsData[i].id == setId)
            {
                setTarget = equipmentSetsData[i];
                setIndex = i;
                break;
            }
        }

        if (setTarget == null)
        {
            BattleManager.Log(GameLogType.Debug, $"[CmdSwitchEquipmentSet] Set target is null: setId={setId}, userName={userName}");
            return;
        }

        var characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData == null) return;

        var equipmentSetVip = characterData.GetVipStatValue(VipBonusType.EquipmentSet); 
        if (equipmentSetVip < 0)
        {
            BattleManager.Log(GameLogType.Debug, $"[CmdSwitchEquipmentSet] Set target is null: setIndex={setId}, userName={userName}");
            TargetEquipmentSetSwitchedFailure(connectionToClient, NotifyType.Notify);
            return;
        }

        if (setIndex == 2) // Set thứ 3, cần phải check unlock
        {
            var equipmentSet3 = characterData.GetVipStatValue(VipBonusType.EquipmentSet3);
            if (equipmentSet3 < 0)
            {
                BattleManager.Log(GameLogType.Debug, $"[CmdSwitchEquipmentSet] Set target is null: setIndex={setId}, userName={userName}");
                TargetEquipmentSetSwitchedFailure(connectionToClient, NotifyType.Notify);
                return;
            }
        }

        BattleManager.Log(GameLogType.Debug, $"TargetSet: Count={setTarget.equipmentInSets.Count}");
        
        foreach(var equipmentSet in equipmentSetsData)
        {
            equipmentSet.isActive = false;
        }
        setTarget.isActive = true;

        // Log switch
        Log(LogAction.SwitchEquipmentSet, $"OldSetId={oldActiveSet.id};NewSet={setTarget.id}", "");

        // Reload visual với equipment set mới
        ReloadEquipmentsFromActiveSet();

        if (BattleManager.TryGetGameDataConfig(out var gameDataConfig, logWarning: false))
        {
            swtichSetPendingTime = gameDataConfig.SwitchSetPendingTime;
        }

        SyncEquipmentSetsToCharacterData(characterData);

        TargetEquipmentSetSwitched(connectionToClient, setId);
#endif
    }

    [TargetRpc]
    public void TargetEquipmentSetSwitched(NetworkConnectionToClient networkConnectionToClient, string setId)
    {
#if ENABLE_CLIENT
        ClientManager.instance.OnSwitchEquipmentSetResponse(setId);
#endif
    }

    [TargetRpc]
    public void TargetEquipmentSetSwitchedFailure(NetworkConnectionToClient networkConnectionToClient, NotifyType notifyType)
    {
#if ENABLE_CLIENT
        if(notifyType == NotifyType.Notify)
        {
            IngameNotifyManager.instance.Notify("Bạn không có quyền sử dụng set đồ này");
        }
        else if(notifyType == NotifyType.MiddleNotify)
        {

        }
#endif
    }

    //----------------------------------------------------------------
    //Request EquipmentSet - Get EquipmentSets Data
    //----------------------------------------------------------------
    /// <summary>
    /// Request to get equipmentSets data from server
    /// Called when client opens MyCharacterInfoView
    /// </summary>
    [Client]
    public void RequestGetEquipmentSets(int apiToken)
    {
        if (!NetworkClient.isConnected) return;
        CmdGetEquipmentSets(apiToken);
    }

    [Command]
    public void CmdGetEquipmentSets(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdGetEquipmentSets))) return;
        SyncEquipmentSet();
#endif
    }

    private void SyncEquipmentSet()
    {
#if ENABLE_SERVER
        var response = new List<EquipmentSetData>();

        foreach (var set in equipmentSetsData)
        {
            if (set != null)
            {
                response.Add(set);
            }
        }

        var activeSet = GetActiveEquipmentSetData();

        string responseJson = JsonConvert.SerializeObject(response);
        TargetRpcGetEquipmentSets(connectionToClient, responseJson, activeSet.id);
#endif
    }

    [TargetRpc]
    public void TargetRpcGetEquipmentSets(NetworkConnection conn, string responseJson, string currentActiveSetId)
    {
#if ENABLE_CLIENT
        ClientManager.instance.OnGetEquipmentSets(responseJson, currentActiveSetId);
#endif
    }

    #endregion

    #region EquipmentSet Helper Actions

    /// <summary>
    /// Kiểm tra xem có loại EquipmentType đó tồn tại trong list Equipment chưa
    /// </summary>
    /// <param name="equipments"></param>
    /// <param name="type"></param>
    /// <returns></returns>
    private bool HasEquipmentTypeInSet(List<EquipmentInSet> equipments, EquipmentType type)
    {
        return equipments.Any(e => e.equipmentType == type);
    }

    /// <summary>
    /// Helper: Reload equipment từ active set
    /// </summary>
    private void ReloadEquipmentsFromActiveSet()
    {
#if ENABLE_SERVER
        // Xóa equipment cũ khỏi characterEquipments
        RemoveAllEquipmentsFromEquipmentAndAddToCharacterOriginal();

        // Load equipment mới từ active set
        var activeSet = GetActiveEquipmentSetData();

        if(activeSet.equipmentInSets.Count > 0)
        {
            foreach (var equipmentInSet in activeSet.equipmentInSets)
            {
                BattleManager.Log(GameLogType.Debug, $"Equip Equipment in Set: equipmentId={equipmentInSet.id} | equipmentType={equipmentInSet.equipmentType}");
                LogicUseItem(equipmentInSet.id, "", useSwapRateLimited: false);
            }
        }

        if (characterVisual != null)
        {
            characterVisual.LoadEquipments();
        }
        OnUpdateStats();
#endif
    }

    private Equipment RemoveEquipmentFromInventoryOrCollection(string equipmentId)
    {
        var inventoryEquipments = characterInventory.GetEquipments();
        for (int i = 0; i < inventoryEquipments.Count; i++)
        {
            if (inventoryEquipments[i].id == equipmentId)
            {
                var equipment = inventoryEquipments[i];
                characterInventory.RemoveEquipment(equipmentId);
                return equipment;
            }
        }

        var collectionEquipments = characterCollection.GetEquipments();
        for (int i = 0; i < collectionEquipments.Count; i++)
        {
            if (collectionEquipments[i].id == equipmentId)
            {
                var equipment = collectionEquipments[i];
                characterCollection.RemoveEquipment(equipmentId);
                return equipment;
            }
        }

        return null;
    }

    private void RemoveAllEquipmentsFromEquipmentAndAddToCharacterOriginal()
    {
#if ENABLE_SERVER
        var equipmentsToRemove = new List<Equipment>();

        foreach (var eq in characterEquipments.GetEquipments())
        {
            if (eq.IsEquipmentInEquipmentSet())
            {
                equipmentsToRemove.Add(eq);
            }
        }
        foreach (var equipment in equipmentsToRemove)
        {
            characterEquipments.RemoveEquipment(equipment.id);
            if(equipment.IsCollection())
            {
                equipment.state = EquipmentState.Collection;
                characterCollection.AddEquipment(equipment);
            }
            else
            {
                equipment.state = EquipmentState.Inventory;
                characterInventory.AddEquipment(equipment);
            }
        }
#endif
    }

    /// <summary>
    /// Migrate equipment từ equipments cũ sang equipmentSets mới
    /// Chạy một lần khi player cũ load data lần đầu sau update
    /// </summary>
    private void MigrateLegacyEquipmentToEquipmentSets(CharacterData characterData)
    {
#if ENABLE_SERVER
        // Nếu đã có equipmentSets với equipment thì không cần migrate
        if (characterData.equipmentSets != null && characterData.equipmentSets.Count > 0)
        {
            bool hasAnyEquipment = false;
            foreach (var set in characterData.equipmentSets)
            {
                if (set != null && set.equipmentInSets.Count > 0)
                {
                    hasAnyEquipment = true;
                    break;
                }
            }
            if (hasAnyEquipment)
            {
                return; // Đã migrate rồi
            }
        }

        // Khởi tạo equipmentSets
        characterData.InitializeEquipmentSets();

        // Tìm và migrate equipment từ equipments sang equipmentSets[0]
        var equipmentsToMigrate = new List<string>();
/*        foreach (var eq in characterData.equipments)
        {
            if (eq.IsEquipmentInEquipmentSet())
            {
                equipmentsToMigrate.Add(eq.id);
            }
        }

        characterData.equipmentSets[0].equipmentInSets.Clear();
        // Di chuyển skin sang equipmentSet[0]
        foreach (var equipmentId in equipmentsToMigrate)
        {
            characterData.AddEquipmentToSet(0, equipmentId);
        }*/

        // Set active set = 0
        characterData.equipmentSets[0].isActive = true;

        if (equipmentsToMigrate.Count > 0)
        {
            BattleManager.Log(GameLogType.Debug, $"MigrateLegacyEquipment;Count={equipmentsToMigrate.Count}");
        }
#endif
    }


    // Phần này đổi sang là unlock equipment set thứ 3
    //----------------------------------------------------------------
    //Request SkinSet - Buy Skin Exchange Currency
    //----------------------------------------------------------------

    /*/// <summary>
    /// Request to buy SkinExchange currency with 500 TH Coin
    /// </summary>
    [Client]
    public void RequestBuySkinExchange(int apiToken, string walletPassCode)
    {
        if (!NetworkClient.isConnected) return;
        CmdBuySkinExchange(apiToken, walletPassCode);
    }

    [Command]
    public void CmdBuySkinExchange(int apiToken, string walletPassCode)
    {
#if ENABLE_SERVER
        if (GetHealth() <= 0) return;
        if (!ServerValidateApiToken(apiToken, nameof(CmdBuySkinExchange))) return;

        var isCorrect = CheckWalletPassCode(walletPassCode);
        if (isCorrect == false)
        {
            return;
        }

        LogicBuySkinExchange();
#endif
    }

    private void LogicBuySkinExchange()
    {
#if ENABLE_SERVER
        const int AMOUNT_SKIN_EXCHANGE = 1;

        int costTH = BattleManager.instance.gameDataConfig.CostTHBuyExchangeSkinSet;

        CurrencyData cost = new()
        {
            currencyId = GameConst.TH_COIN_ID,
            value = costTH
        };

        if (!HaveEnoughMoney(cost))
        {
            return;
        }

        PayCost(cost);
        EconomyManager.RecordThBurn(costTH, "skin_exchange_purchase");

        characterInventory.AddSkinExchange(AMOUNT_SKIN_EXCHANGE);

        // Log
        Log(LogAction.BuyShopTH,
            $"BuySkinExchange|Cost:{costTH}TH|Amount:{AMOUNT_SKIN_EXCHANGE}",
            value: costTH.ToString());

        // Save
        BattleManager.instance.SavePlayerData(this);
#endif
    }

    //----------------------------------------------------------------
    //Request SkinSet - Buy Exchange and Apply Skin Set
    //----------------------------------------------------------------

    /// <summary>
    /// Request mua exchange và apply skin set trong một lần gọi
    /// Nếu có đủ SkinExchange thì chỉ apply, nếu không thì mua rồi apply
    /// </summary>
    [Client]
    public void RequestBuyExchangeAndApplySkinSet(int setIndex, int apiToken, string walletPassCode)
    {
        if (!NetworkClient.isConnected) return;
        if (setIndex < 0 || setIndex > 1) return;

        CmdBuyExchangeAndApplySkinSet(setIndex, apiToken, walletPassCode);
    }

    [Command]
    public void CmdBuyExchangeAndApplySkinSet(int setIndex, int apiToken, string walletPassCode)
    {
#if ENABLE_SERVER
        if (GetHealth() <= 0) return;
        if (!ServerValidateApiToken(apiToken, nameof(CmdBuyExchangeAndApplySkinSet))) return;

        var isCorrect = CheckWalletPassCode(walletPassCode);
        if (isCorrect == false)
        {
            return;
        }

        // Validate set exists
        if (skinSetsData == null || setIndex >= skinSetsData.Count)
        {
            BattleManager.Log(GameLogType.Debug, $"[CmdBuyExchangeAndApplySkinSet] Set not found: setIndex={setIndex}, userName={userName}");
            return;
        }

        var targetSet = skinSetsData[setIndex];
        if (targetSet == null || targetSet.Count == 0)
        {
            BattleManager.Log(GameLogType.Debug, $"[CmdBuyExchangeAndApplySkinSet] Set empty: setIndex={setIndex}, userName={userName}");
            return;
        }

        // Check SkinExchange currency hiện tại
        int currentSkinExchange = characterInventory.GetSkinExchange();
        int requiredSkinExchange = 1;

        // Nếu không đủ SkinExchange thì mua trước
        if (currentSkinExchange < requiredSkinExchange)
        {
            int costTH = BattleManager.instance.gameDataConfig.CostTHBuyExchangeSkinSet;

            CurrencyData cost = new CurrencyData()
            {
                currencyId = GameConst.TH_COIN_ID,
                value = costTH
            };

            if (!HaveEnoughMoney(cost))
            {
                BattleManager.Log(GameLogType.Debug, $"[CmdBuyExchangeAndApplySkinSet] Not enough TH Coin: userName={userName}, required={costTH}");
                TargetBuyExchangeAndApplySkinSetFailed(connectionToClient, ErrorCode.InsufficientMoney);
                return;
            }

            PayCost(cost);
            EconomyManager.RecordThBurn(costTH, "skin_exchange_purchase");
            characterInventory.AddSkinExchange(1);

            Log(LogAction.BuyShopTH,
                $"BuySkinExchange|Cost:{costTH}TH|Amount:1",
                value: costTH.ToString());
        }

        CurrencyData switchCost = new()
        {
            currencyId = (int)CurrencyID.SkinExchange,
            value = requiredSkinExchange
        };

        PayCost(switchCost);

        // Đổi active skin set index
        int oldSetIndex = activeSkinSetIndexData;
        activeSkinSetIndexData = setIndex;

        Log(LogAction.SwitchSkinSet,
            $"OldSet={oldSetIndex};NewSet={setIndex}",
            "");

        // Reload visual với skin set mới
        ReloadSkinsFromActiveSet();

        // Sync to characterData and save
        var characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData != null)
        {
            SyncSkinSetsToCharacterData(characterData);
        }

        TargetBuyExchangeAndApplySkinSetSuccess(connectionToClient, setIndex);
#endif
    }

    [TargetRpc]
    public void TargetBuyExchangeAndApplySkinSetSuccess(NetworkConnectionToClient networkConnectionToClient, int newSetIndex)
    {
#if ENABLE_CLIENT
        UIManager.instance.FindView<MyCharacterInfoView>().OnSkinSetSwitched(newSetIndex);
#endif
    }

    [TargetRpc]
    public void TargetBuyExchangeAndApplySkinSetFailed(NetworkConnectionToClient networkConnectionToClient, ErrorCode errorCode)
    {
#if ENABLE_CLIENT
        if (IngameNotifyManager.instance != null)
        {
            IngameNotifyManager.instance.Notify(errorCode);
        }
#endif
    }*/

    #endregion
}
