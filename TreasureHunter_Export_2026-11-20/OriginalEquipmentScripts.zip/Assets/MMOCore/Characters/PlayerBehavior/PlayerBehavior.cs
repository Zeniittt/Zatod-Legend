using MCP.DataModel.Utils;
using MCP.DataModels.BaseModels;
using MCP.Mmo.DataModels.Common;
using MCP.Mmo.Manager;
using MCP.Mmo.Manager.Admin;
using MCP.Manager;
using MCP.Unity;
using MegaCombat.Testing;

#if ENABLE_MMO_WEB_API && ENABLE_CLIENT 
using MCP.Mmo.Manager;
#endif
using Mirror;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PathologicalGames;

using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using UnityEngine;
using UnityEngine.Serialization;
using static CharacterHealth;
using static GameConst;
using static MCP.Unity.UnityUtils;
using static ServerLeaderBoardManager;
using MCP.Ability;

#if ENABLE_CHEAT_DETECTOR
using CodeStage.AntiCheat.Time;
using MCP.Unity;
#endif

public partial class PlayerBehavior : CharacterBehavior
{
    [TargetRpc]
    public void RpcTrapExplosionVfx(NetworkConnectionToClient connection, int trapCardId, Vector3 position, float radius, string explosionVfxPrefabName)
    {
#if !ENABLE_SERVER && !ENABLE_ADMIN
        if (string.IsNullOrEmpty(explosionVfxPrefabName))
            return;

        Transform vfx = PoolManager.Pools["VFX"].Spawn(explosionVfxPrefabName, position, Quaternion.identity);
        vfx.GetComponent<AutoDestroy>()?.PlayVFX();
#endif
    }

    private readonly Collider2D[] skillColliderBuffer = new Collider2D[64];
    //[SyncVar]
    //public int titleId = 0;
    [SyncVar]
    [HideInInspector]
    public float protectionTime = 0;
    [SyncVar]
    [HideInInspector]
    public float preparationSafeTime = 0;
    [SyncVar, HideInInspector]
    public int trophy = 0;
    [SyncVar, HideInInspector]
    public int jailId = -1;
    [SyncVar]
    [HideInInspector] public bool arenaWinner = false;
    [SyncVar]
    public float speed = 0;
    [SyncVar]
    public bool isWatchingAd = false;
    [SyncVar]
    private double lastHitTimeForAd = -999d;
    private double lastWatchAdProtectionStartTime = -999d;

    public PlayerRole playerRole = PlayerRole.Player;

    //TODO: remove sync var
    [SyncVar]
    public MemberRole memberRole = MemberRole.Member;

    //TODO: remove sync var
    [SyncVar]
    public CharacterRole characterRole = CharacterRole.Player;
    public string createdDate = "";

    // Server login state only; never serialize an unresolved role to peer clients.
    [System.NonSerialized] internal bool isNetworkRolePending;

    [HideInInspector]
    public float timeQuit = 0;
    [HideInInspector]
    public bool isQuiting = false;
    [HideInInspector]
    public PlayerSessionState playerSessionState = PlayerSessionState.None;
    [HideInInspector]
    public DisconnectReason lastDisconnectReason = DisconnectReason.Unknown;
    MapObject mapObject;
    MapObject lastMapObject;
    [HideInInspector]
    public CharacterEquipments characterEquipments;
    [HideInInspector]
    public CharacterInventory characterInventory;
    [HideInInspector]
    public CharacterIngredient characterIngredient;
    [HideInInspector]
    public CharacterCollection characterCollection;
    [HideInInspector]
    public CharacterVisual characterVisual;
    [HideInInspector]
    public CharacterWallet characterWallet;
    [HideInInspector]
    public CharacterTitleEquipment characterTitleEquipment;
    [HideInInspector]
    public AuthorativePlayerMovement authorativePlayerMovement;
    public PlayerAuto playerAuto;
    //[HideInInspector]

    public string[] hitBlockSounds;
    public bool isHaveLoginSeasonPass = false;
#if ENABLE_AUTO_BOT
    private BotBehaviour bot;
#endif
    float timeWatchAd = 0;
    float saveTime = 0;
    float protectionSendTime = 0;
    int numberAdLimited = 0;
    public int hackNumber = 0;
    public int totalHackNumber = 0;
    public int seasonTHShop = 0;
    public int seasonIAPValue = 0;

    Vector2Int lastBlockId = Vector2Int.zero;
    private int idleFrame = 0;

    #region Season Event

    public int numberRollSeasonEvent;
    public int numberRollSeasonEventFree;

    #endregion

    public List<string> currenOrderIds = new List<string>();

    public float deadTime = 0;
    public float seasonTimePlay = 0;
    public float totalTimePlay = 0;
    public float todayTimePlay = 0;
    [HideInInspector] public bool isDead = false;
    PlayerSkill playerSkill;
    float maxDelayHeal = 60;
    public MapData mapData;

    public float timePlay = 0;
    public string ipAddress = "";
    public string platform = "";
    public string version = "";
    public bool isBanned = false;
    public string password = "";
    public bool isVerifiedMod = true;
    public float timeCheckMod = 0;
    public float maxTimeCheckMod = 120;
    public float timeCheckDailyReset = 0;
    public float timeCheckReviveClanVillage = 3600;
    public bool isProtected = true;
    public int equipmentScore = 0;

    //Damage
    public float greenDamage = 0;
    public float undeadDamage = 0;
    public float whiteDamage = 0;

    public bool isPlayerInfoLoaded = false;

    /// <summary>
    /// Tọa độ làng viking đang đứng
    /// </summary>
    //private string vikingVillageId;

    //Activation Code
    public List<string> activationCodes = new List<string>();
    public List<string> claimedSocialRewards = new List<string>();
    public System.DateTime lastInputCode;
    public int wrongCode = 0;
    public float revivedHP = 0;

    public string lastTimeForgotPasscode = "";
    public string lastTimeOTP = "";

    public bool IsRevived => revivedHP > 0;



    public TutorialStep tutorialStep = TutorialStep.None;

    private float outOfCombatTime = 0;

    //building
    public BuildingSyncBehavior buildingSync;

    //Mail
    [HideInInspector] public List<Equipment> inventoryMail = new();
    [HideInInspector] public List<Equipment> ingredientMail = new();

    [HideInInspector] public float jailTime = 0;

    public string lastTimeAddReviveClanVillage = "";

    [HideInInspector] public List<BoxSuggestion> boxSuggestions = new();
    [HideInInspector] public string currentServer;

    [SyncVar(hook = nameof(HookLocalAutomationState))]
    public AutomationState automationState = AutomationState.None;

#if ENABLE_SERVER
    public int todayWatchAdNumber = 0;
    public string lastWatchAdTime = "";
    public System.DateTime lastMergeTime;
    public System.DateTime lastCraftTime;
    public System.DateTime lastSellTime;
    private const float SellCommandCooldownSeconds = 1f;

    //Request
    public int requestApiNumber = 0;
    public System.DateTime requestTime;
    public System.DateTime lastTimeCheckQuestSuggestion = System.DateTime.Now;

    private const int BasicGearSwapLimitPerSecond = 2;
    private const float BasicGearSwapWindowSeconds = .5f;
    private readonly List<float> basicGearSwapTimestamps = new();

    private bool IsBasicGearSwapRateLimited()
    {
        float now = Time.unscaledTime;

        // Keep only swap actions within the rolling 1-second window.
        for (int i = basicGearSwapTimestamps.Count - 1; i >= 0; i--)
        {
            if (now - basicGearSwapTimestamps[i] > BasicGearSwapWindowSeconds)
            {
                basicGearSwapTimestamps.RemoveAt(i);
            }
        }

        if (basicGearSwapTimestamps.Count >= BasicGearSwapLimitPerSecond)
        {
            return true;
        }

        basicGearSwapTimestamps.Add(now);
        return false;
    }

#endif

    //=========== Components
    private UpdateHandlerBase updateHandler;
    public float MaxDelayHeal { get => maxDelayHeal; set => maxDelayHeal = value; }
    public int IdleFrames { get => idleFrame; set => idleFrame = value; }
    public float OutOfCombatTime { get => outOfCombatTime; set => outOfCombatTime = value; }

    public float TimeWatchAd { get => timeWatchAd; set => timeWatchAd = value; }
    public const float WATCH_AD_HIT_COOLDOWN = 30f;

    public void MarkHitForAdCooldown(CharacterBehavior attacker)
    {
        if (!IsAdCooldownAttacker(attacker))
            return;

        lastHitTimeForAd = NetworkTime.time;
    }

    public bool IsInWatchAdHitCooldown()
    {
        return NetworkTime.time - lastHitTimeForAd < WATCH_AD_HIT_COOLDOWN;
    }

    public float GetWatchAdHitCooldownRemaining()
    {
        return Mathf.Max(0f, WATCH_AD_HIT_COOLDOWN - (float)(NetworkTime.time - lastHitTimeForAd));
    }

    public bool IsInAdRestrictedZone()
    {
        var currentPos = transform.position.ToVector2Int();
        return IsInZoneIgnoreAutomation(currentPos);
    }

    public bool CanWatchRealAd(out string errorMessage)
    {
        errorMessage = "";

        if (IsInAdRestrictedZone())
        {
            errorMessage = "Character is in ad restricted zone";
            return false;
        }

        if (IsInWatchAdHitCooldown())
        {
            errorMessage = $"Character was hit recently. Remaining:{GetWatchAdHitCooldownRemaining():F1}s";
            return false;
        }

        return true;
    }

    private bool IsAdCooldownAttacker(CharacterBehavior attacker)
    {
        if (attacker == null)
            return false;

        if (attacker is PlayerBehavior)
            return true;

        return attacker is MobBehavior mob && mob.isSummonMob && !string.IsNullOrEmpty(mob.summonerName);
    }

    public float ProtectionSendTime { get => protectionSendTime; set => protectionSendTime = value; }
    protected override void Awake()
    {
        base.Awake();

        characterEquipments = this.GetComponent<CharacterEquipments>();
        characterInventory = this.GetComponent<CharacterInventory>();
        characterIngredient = this.GetComponent<CharacterIngredient>();
        characterVisual = this.GetComponent<CharacterVisual>();
        authorativePlayerMovement = this.GetComponent<AuthorativePlayerMovement>();
        playerAuto = this.GetComponent<PlayerAuto>();
        playerSkill = this.GetComponentInChildren<PlayerSkill>();
        characterEffects = this.GetComponent<CharacterEffects>();
        characterBuffs = this.GetComponent<CharacterBuffs>();
        characterCollection = this.GetComponent<CharacterCollection>();
        characterWallet = this.GetComponent<CharacterWallet>();
        characterTitleEquipment = this.GetComponent<CharacterTitleEquipment>();
        updateHandler = this.GetComponent<UpdateHandlerBase>();
        updateHandler.Init(this);
    }

    private void OnEnable()
    {
        // Reset() removed - no longer needed since we're not pooling players
    }

    public override void OnStartClient()
    {
        base.OnStartClient();
        if (characterType == CharacterType.Player)
        {
            maxDelayHeal = 0;
        }

        StartCoroutine(LoadMyCharacterDataCoroutine());
        if (isLocalPlayer)
        {
            EnableCollider(true);
            UpdateLandData();
        }
    }

    IEnumerator LoadMyCharacterDataCoroutine()
    {
        if (!ClientManager.instance.localPlayerBehaviors.Contains(this))
            ClientManager.instance.localPlayerBehaviors.Add(this);

        SetDirection();
        if (isLocalPlayer)
        {

            yield return null;
            BattleManager.Log(GameLogType.GameInit,
                $"[LoadMyCharacterData] Requesting character data. User={ClientManager.instance.myUsername}_{ClientManager.instance.originalServer}, Region={ClientManager.instance.activeRegion?.RegionId}");
            RequestLoadCharacterData(
                ClientManager.instance.myUsername + "_" + ClientManager.instance.originalServer,
                ClientManager.instance.GetPassword(),
                ClientManager.instance.GetVersion(),
                GetDeviceOS(),
                ClientManager.instance.myIp.Get(),
                GetDeviceID(),
                BattleManager.instance.buildId);
        }
        else
        {
            //Disable building base
            if (this.characterType == CharacterType.Building)
            {
#if !ENABLE_ADMIN
                // ✅ SERVER-ONLY: Add null check for MapManager
                HideCurrentBuildingBase();
#endif
            }
        }
    }

    public override void OnStartServer()
    {
        base.OnStartServer();
        isInitialized = true;
        isVerifiedMod = true;
#if ENABLE_SERVER
        lastMergeTime = System.DateTime.Now;
        lastCraftTime = System.DateTime.Now;
        lastSellTime = System.DateTime.Now;
#endif


        if (this.characterType == CharacterType.Building)// && this.mobId == BattleManager.MAIN_BUILDING_ID)
        {
#if ENABLE_SERVER_TEST
            maxDelayHeal = 180;
#else
            maxDelayHeal = 3600;
#endif
        }
        else
            maxDelayHeal = 0;

        //CheckZoneType();
        //delayHealTime = maxDelayHeal;
    }
    // Reset() removed - no longer needed since we're not pooling players
    // Each new player is instantiated fresh, not reused from a pool
    public override void OnStopClient()
    {
        //Disable building base
#if !ENABLE_ADMIN
        if (this.characterType == CharacterType.Building)
        {
            BuildingBaseBehavior buildingBaseBehavior = null;

            if (mobId == GameConst.MACHANDISE_BUILDING)
            {
                //TODO: use original
                var splits = userName.Split('_');
                if (float.TryParse(splits[1], out float x) == false)
                {
                    return;
                }

                if (float.TryParse(splits[2], out float y) == false)
                {
                    return;
                }

                // ✅ SERVER-ONLY: Add null check for MapManager
                if (MapManager.instance == null) return;

                buildingBaseBehavior = MapManager.instance.GetBuildingBase((int)x, (int)y);
            }
            else
            {
                buildingBaseBehavior = MapManager.instance.GetBuildingBase((int)transform.position.x, (int)transform.position.y);
            }

            if (buildingBaseBehavior != null)
                buildingBaseBehavior.SetDisplay(true);
        }
#endif
    }

    public override void Initialize()
    {
#if ENABLE_CLIENT 
        if (isInitialized)
            return;

        if (playerAuto != null)
            playerAuto.DisableAutoMode(ClientManager.instance.GetClientToken());

        LoadCharacterBody();

        // ✅ SERVER-ONLY: Add null check for characterBody (may be null in headless mode if PoolManager is missing)
        if (characterBody == null)
        {
            Debug.LogWarning("[PlayerBehavior] characterBody is null after LoadCharacterBody() - running in headless mode?");
            return;
        }

#if !ENABLE_ADMIN

        SetActive(characterBody.protectionIcon, false);
        SetActive(characterBody.wantedIcon, false);
        SetActive(characterBody.arenaIcon, false);
        SetActive(characterBody.autoIcon, false);
        SetActive(characterBody.autoWithShieldIcon, false);
        SetActive(characterBody.watchAdIcon, false);
        SetActive(characterBody.tiredIcon, false);

#endif

#if !ENABLE_ADMIN
        characterBody.playerNameText.text = this.characterName;
        if (characterBody.clanNameText != null)
        {
            characterBody.clanNameText.text = clanId;
        }
#endif
        OnUpdateStats();

        isInitialized = true;

        //Debug.Log("Initialzie character Behavior completed " + this.userName);
#endif
    }

    public override void LoadCharacterBody()
    {
#if !ENABLE_ADMIN
        if (characterBody == null)
        {
            if (characterType == CharacterType.Player)
            {
                // Player Body (visual/rendering) is pooled because it can be reused
                // Player entity (PlayerBehavior script) is NOT pooled - instantiated fresh each session
                if (PoolManager.Pools == null || !PoolManager.Pools.ContainsKey("Characters"))
                {
                    Debug.LogWarning("[PlayerBehavior] PoolManager.Pools['Characters'] not found - running in headless mode?");
                    return;
                }

                Transform t = PoolManager.Pools["Characters"].Spawn("Player Body");
                characterBody = t.GetComponent<PlayerBody>();
                characterBody.LoadData(this);
                CheckCharacterBody();
            }
            else if (characterType == CharacterType.Building)
            {
                // Buildings still use pool for mob bodies (not player pool)
                if (PoolManager.Pools == null || !PoolManager.Pools.ContainsKey("Characters"))
                {
                    Debug.LogWarning("[PlayerBehavior] PoolManager.Pools['Characters'] not found - running in headless mode?");
                    return;
                }

                var name = DataHolder.Instance().GetData<Card>(mobId).GetName(0);

                Transform t = PoolManager.Pools["Characters"].Spawn(name + " Body");
                characterBody = t.GetComponent<CharacterBody>();
                characterBody.LoadData(this);

                t.gameObject.SetActive(true);

                CheckCharacterBody();
            }
        }
        else
        {
            CheckCharacterBody();
            characterBody.LoadData(this);
        }

        if (characterType == CharacterType.Building && buildingSync != null)
        {
            buildingSync.OnClientInitBody();
        }

        if (characterType == CharacterType.Building)
        {
            HideCurrentBuildingBase();
        }

        if (characterType == CharacterType.Building &&
            mobId == GameConst.MACHANDISE_BUILDING && characterBody != null)
        {
            // Match the left-facing placement preview, including a reused Body's previous facing.
            direction = Direction.L;
            lastDirection = Direction.R;
            SetDirection();
            SyncVisualLastPosition(characterBody.transform.position);
        }
#endif
    }

    private void HideCurrentBuildingBase()
    {
#if ENABLE_CLIENT && !ENABLE_ADMIN
        if (MapManager.instance == null)
            return;

        BuildingBaseBehavior buildingBaseBehavior = MapManager.instance.GetBuildingBase(
            Mathf.RoundToInt(transform.position.x),
            Mathf.RoundToInt(transform.position.y));
        if (buildingBaseBehavior != null)
            buildingBaseBehavior.SetDisplay(false);
#endif
    }

    private IEnumerator ApplyLocalVisualPrefsAfterLoad()
    {
        yield return null;

        if (!isLocalPlayer || ClientManager.instance == null)
            yield break;

        EquipmentType[] hiddenTypes = { EquipmentType.Hair, EquipmentType.FaceHair, EquipmentType.Helmet };
        for (int i = 0; i < hiddenTypes.Length; i++)
        {
            EquipmentType equipmentType = hiddenTypes[i];
            string key = ClientManager.instance.myUsername + equipmentType;
            if (!LocalPrefs.KeyExists(key) || characterVisual == null || characterVisual.GetEquipment(equipmentType) == null)
                continue;

            bool hidden = LocalPrefs.Load<int>(key, 0) > 0;
            if (characterVisual.IsEquipmentHidden(equipmentType) != hidden)
            {
                RequestHideEquipment(hidden, equipmentType, ClientManager.instance.GetApiToken());
            }
        }
    }

    public void Log(LogAction logAction, string description, string actionObject = "", string value = "")
    {
        BattleManager.Log(this, logAction, description, actionObject, value);

#if ENABLE_SERVER
        if (logAction != LogAction.AutoToolDetected)
            return;

        // Ignore queued detections after the player has already been jailed so one
        // burst cannot immediately build toward another sentence.
        if (IsInJail() && jailTime > 0)
            return;

        if (IsInBeginnerLand())
            return;

        CharacterData characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData == null)
            return;

        characterData.suspectdNumber++;

        const int autoToolJailThreshold = 10;
        if (characterData.suspectdNumber < autoToolJailThreshold)
        {
            BattleManager.instance.SaveCharacterData(characterData);
            return;
        }

        const int baseJailHours = 12;
        int jailHours = baseJailHours * (1 + characterData.totalPrisonNumber);
        if (LogicLockJail(userName, jailHours, BannedReason.Auto))
        {
            characterData.suspectdNumber = 0;
        }

        BattleManager.instance.SaveCharacterData(characterData);
#endif
    }

    public override void CheckCharacterBody()
    {
        base.CheckCharacterBody();
    }

    private void SetAutomationState()
    {
#if ENABLE_SERVER
        var state = AutomationState.None;

        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);

        bool autoFarm = IsAutoFarm();
        bool autoMove = !autoFarm && IsAutoMove();

        if (autoFarm)
        {
            state = IsAutoShieldActived() ? AutomationState.AutoFarmWithShield : AutomationState.AutoFarm;
        }
        else if (autoMove)
        {
            state = AutomationState.AutoMove;
        }

        if (state != this.automationState)
            this.automationState = state;
#endif
    }

    private void HookLocalAutomationState(AutomationState old, AutomationState newState)
    {
        if (isLocalPlayer)
        {
            EventDispatcher.Raise(newState);
        }
    }


    public void Dead()
    {
#if ENABLE_SERVER
        ServerDisableAutomationAndSync(
            "PlayerDead",
            disableAutoFarm: true,
            disableAutoMove: true,
            disableAutoShield: false,
            disableAutoShieldActivated: false,
            clearTargetMove: true); // ✅ FIX: Clear targetMove khi chết
#endif
        SetCharacterState(CharacterState.Dead);
        delayHealTime = 0;
        outOfCombatTime = 0;

        if (NewArenaManager_Server.TryGetArena(GetArenaId(), out var arena) && arena != null)
        {
            arena.LogicDead(this);
        }
    }

#if ENABLE_CLIENT

    protected override void Update()
    {
#if ENABLE_AUTO_BOT
        #region Bot
        if (isInitialized && isClient && ClientManager.instance.isBot && isLocalPlayer)
        {
            if (bot == null)
            {
                bot = ClientManager.instance.GetBot(this);
            }

            bot.OnUpdate();
        }
        #endregion
#endif

        if (isInitialized && isClient)
        {
            ClientUpdate();
        }

        if (isInitialized && !isServer && !isLocalPlayer)
        {
            if (timePlay > 3)
                isDataInitialized = true;

            timePlay += Time.deltaTime;
        }
    }
#endif

    [Client]
    private void ClientUpdate()
    {
        if (!BattleManager.instance.isMapInitialized)
            return;

        if (characterBody == null)
            return;

        if (characterBody.animator == null)
            return;

        if (isLocalPlayer)
        {
            UpdateLandData();
        }
        else if (Time.frameCount % 10 == 0)
        {
            UpdateLandData();
        }

        if (!characterBody.isShowBody)
        {
            if (!isLocalPlayer)
            {
                characterBody.transform.position = transform.position;
            }

            return;
        }

        ClientCheckName();

        delayHealTime += Time.deltaTime;

        var clientBoxSuggestions = ClientManager.instance.GetBoxSuggestions();
        if (clientBoxSuggestions != null && isLocalPlayer)
        {
            foreach (var box in clientBoxSuggestions)
            {
                if (box.countdownType == CountdownType.OnlineOnly && box.remainingOnlineTime > 0)
                {
                    box.remainingOnlineTime -= Time.deltaTime;
                }
            }
        }

        if (isLocalPlayer && isQuiting)
        {
            timeQuit += Time.deltaTime;
        }

        if (GetHealth() <= 0)
        {
            delayHealTime = 0;
            ClientSetCharacterState(CharacterState.Dead);
            if (isLocalPlayer && !isDead)
            {
                isDead = true;

                // ✅ SERVER-ONLY: Add null check for SoundManager
                if (SoundManager.instance != null)
                    SoundManager.instance.PlaySounds(deadSounds);

                if (ClientManager.instance.isBot)
                {
                    //RequestRevive(false, ClientManager.instance.GetApiToken());
                }
                else
                {
                    if (mapObject != null)
                    {
                        DisableMapObjectOutline(mapObject);
                    }

                    if (enermy != null)
                    {
                        DisableTargetOutline(enermy);
                    }
                    ClientManager.instance.OnDead();
                }
            }

            SetupVisual();
            return;
        }

        ClientOnUpdatePlayerAlive();
    }

    [Client]
    private void ClientOnUpdatePlayerAlive()
    {
        var delay = delayHealTime;

        if (healTime > 1 && delay > maxDelayHeal && heal > 0 && characterHealth.IsFull() == false)
        {
            healTime = 0;
            EventDispatcher.Raise(new OnAddHealthValue()
            {
                Position = transform.position,
                Value = (int)heal,
            });
        }
        else if (healTime > 1 && delay > maxDelayHeal && heal < 0 && GetHealth() > 0)
        {
            healTime = 0;
            EventDispatcher.Raise(new OnAddHealthValue()
            {
                Position = transform.position,
                Value = (int)heal,
            });
        }
        else
        {
            healTime += Time.deltaTime;
        }

        ClientCheckDameOverTime();

        var bodyPosition = characterBody.transform.position;

        int x = Mathf.RoundToInt(bodyPosition.x);
        int y = Mathf.RoundToInt(bodyPosition.y);

        if (mapObject != null && mapObject.mapData.id != x.ToString() + "_" + y.ToString())
        {
            mapObject = null;

            if (isLocalPlayer)
            {
                DisableMapObjectOutline(mapObject);
            }
        }

        Vector2 dir = Vector2.zero;
        if (isLocalPlayer)
        {
            dir = GetAuthoritativeLocalDirection(bodyPosition);

            bodyPosition = characterBody.transform.position;
        }
        else if (characterType == CharacterType.Building)
        {
            dir = (bodyPosition - lastPosition).normalized;
            bodyPosition = transform.position;
        }
        else
        {
            dir = (bodyPosition - lastPosition).normalized;
        }

        Vector2 merchandiseMovementDelta = (Vector2)characterBody.transform.position - (Vector2)lastPosition;
        Direction merchandiseDirectionBeforeState = direction;

        if (isLocalPlayer && dir != Vector2.zero && isQuiting)
        {
            RequestCancelQuit(ClientManager.instance.GetApiToken());
        }

        // --- Enemy targeting ---
        if (enermies.Count > 0 && (enermy == null || !enermies.Contains(enermy)))
        {
            DataUtils.Shuffle(enermies, this.GetHealth());
            foreach (CharacterBehavior targetBehavior in enermies)
            {
                if (targetBehavior.characterType == CharacterType.Building &&
                    (string.IsNullOrEmpty(clanId) || clanId == ASSASIN_CLAN_KEY || clanId == ROYALFORCE_CLAN_KEY))
                    continue;

                if (CanAttack(targetBehavior))
                    enermy = targetBehavior;
            }
        }

        ClientHandleCharacterState(dir);

        // Merchandise is a Building, but its moving visual follows the Mob/Bear facing rule.
        // Apply this after attack/map-tile state handling so those branches cannot suppress it.
        UpdateMerchandiseDirection(merchandiseMovementDelta, merchandiseDirectionBeforeState);

        if (ClientManager.instance.myCharacter != null &&
            ClientManager.instance.myCharacter.GetLandType() == LandType.UndeadLand)
        {
            //Clear current enermy
            if (enermy != null && enermy.characterBody != null && (enermy.characterHealth.value <= 0 ||
                !CanAttack(enermy)))
            {
                DisableTargetOutline(enermy);

                if (GetCharacterState() == CharacterState.Attack)
                {
                    ClientSetCharacterState(CharacterState.Idle);
                }

                if (enermies.Contains(enermy))
                {
                    enermies.Remove(enermy);
                }
                enermy = null;
            }
        }
        else
        {
            //Clear current enermy
            if (enermy != null && enermy.characterBody != null && (enermy.characterHealth.value <= 0 ||
                (enermy.characterBody.transform.position - bodyPosition).sqrMagnitude > 2.25f ||
                (enermy.clanId == clanId && clanId != "" && GetArenaId() == -1 &&
                IsStandingOn(RuntimeAreaController.RuntimeAreaType.ArenaFreeForAll))))
            {
                DisableTargetOutline(enermy);

                if (GetCharacterState() == CharacterState.Attack)
                {
                    ClientSetCharacterState(CharacterState.Idle);
                }

                if (enermies.Contains(enermy))
                {
                    enermies.Remove(enermy);
                }
                enermy = null;
            }
        }



        //TODO: sync var hook
        characterBody.playerNameText.color = GetTrophy() >= 10 ? Color.red : characterBody.playerNameColor;

        //TODO: sync var hook
        UpdateIcons();

        if (automationState != AutomationState.None)
        {
            if (automationState == AutomationState.AutoFarmWithShield)
            {
                SetActive(characterBody.autoIcon, false);
                SetActive(characterBody.autoWithShieldIcon, true);
            }
            else
            {
                SetActive(characterBody.autoIcon, true);
                SetActive(characterBody.autoWithShieldIcon, false);
            }
        }
        else
        {
            SetActive(characterBody.autoIcon, false);
            SetActive(characterBody.autoWithShieldIcon, false);
        }

        if (isLocalPlayer == false && this.characterBody.gameObject.activeSelf)
        {
            bool isBlessingTower = characterType == CharacterType.Building && mobId == GameConst.BLESSING_TOWER_ID;

            if (!isBlessingTower)
            {
                EnableCollider(IsStandingOnPVP() && protectionTime <= 0);
            }
        }

        SetupVisual();
    }

    [Client]
    private void UpdateMerchandiseDirection(Vector2 delta, Direction previousDirection)
    {
        if (characterType != CharacterType.Building || mobId != GameConst.MACHANDISE_BUILDING)
            return;

        if (delta.sqrMagnitude <= 0.0001f || Mathf.Abs(delta.x) <= 0.01f)
        {
            direction = previousDirection;
            return;
        }

        direction = delta.x > 0f ? Direction.R : Direction.L;
        SetDirection();
    }

    private Vector2 GetAuthoritativeLocalDirection(Vector2 bodyPosition)
    {
        if (!IsAutoMode() && UIManager.instance != null)
        {
            Vector2 dir = new Vector2(
                UIManager.instance.GetJoysticHorizontal(),
                UIManager.instance.GetJoysticVertical());

            if (dir.sqrMagnitude > 1f)
                dir.Normalize();

            return dir;
        }

        if (IsAutoMode())
        {
            return GetAutoLocalDirection(bodyPosition);
        }

        return Vector2.zero;
    }

    private Vector2 GetAutoLocalDirection(Vector2 bodyPosition)
    {
        // When auto mode starts, the cached visual delta may still describe
        // the previous manual movement direction. Prefer the current auto
        // target so the first auto frame does not briefly face backwards.
        if (TryGetAutoFacingDirection(bodyPosition, out Vector2 autoFallbackDir))
        {
            return autoFallbackDir;
        }

        Vector2 bodyDelta = (Vector2)bodyPosition - (Vector2)lastPosition;
        if (bodyDelta.sqrMagnitude > 0.0001f)
        {
            return bodyDelta.normalized;
        }

        return Vector2.zero;
    }

    [Client]
    private void ClientHandleCharacterState(Vector2 dir)
    {
        var bodyPos = characterBody.transform.position;
        int x = Mathf.RoundToInt(bodyPos.x);
        int y = Mathf.RoundToInt(bodyPos.y);

        bool isV2LocalPlayer = isLocalPlayer;
        bool isV2LocalMovingByInput = false;
        bool isAutoMove = isLocalPlayer && IsAutoMove();
        bool isAutoFarmNavigating = isLocalPlayer
            && IsAutoFarm()
            && playerAuto != null
            && playerAuto.AutoState != PlayerAuto.State.BreakBlock
            && playerAuto.AutoState != PlayerAuto.State.Arrived;
        if (isV2LocalPlayer && !IsAutoMode() && UIManager.instance != null)
        {
            Vector2 joystickInput = new Vector2(
                UIManager.instance.GetJoysticHorizontal(),
                UIManager.instance.GetJoysticVertical());
            isV2LocalMovingByInput = joystickInput.sqrMagnitude > 0.0001f;
        }

        var state = GetCharacterState();
        if (state != CharacterState.OpenChest)
        {
            if (enermy != null && enermy.characterBody != null && ((Vector2)bodyPos - (Vector2)enermy.characterBody.transform.position).sqrMagnitude < 2.25f)
            {
                ClientSetCharacterState(CharacterState.Attack);
            }
            else if (MapManager.instance.HaveMap(x, y)
                && (!isV2LocalPlayer || !isV2LocalMovingByInput)
                && !isAutoFarmNavigating
                && !isAutoMove)
            {
                ClientSetCharacterState(CharacterState.Attack);
                if (characterType == CharacterType.Player && mapObject == null)
                {
                    // ✅ SERVER-ONLY: Add null check for MapManager
                    if (MapManager.instance == null) return;

                    mapObject = MapManager.instance.GetMapObject(x, y);
                    if (mapObject != null)
                    {
                        if (isLocalPlayer)
                            EnableMapObjectOutline(mapObject);
                        lastMapObject = mapObject;
                        if (isLocalPlayer)
                            MapManager.instance.LastMapPosition = new Vector2(x, y);
                    }
                }
            }
            else
            {
                ClientExitAttackState(dir);
            }
        }


        state = GetCharacterState();
        if (state == CharacterState.OpenChest)
        {

        }
        else if (state == CharacterState.Attack)
        {
            if (characterBody != null)
                characterBody.animator.speed = 1;
            if (enermy != null)
            {
                EnableTargetOutline(enermy);

                if (isClient && isLocalPlayer)
                {
                    ClientManager.instance.SetCombatModeClient(enermy);
                }

                Vector3 enemyPos = enermy.characterBody != null
                    ? enermy.characterBody.transform.position
                    : enermy.transform.position;

                float deltaXToEnemy = enemyPos.x - bodyPos.x;
                if (Mathf.Abs(deltaXToEnemy) > 0.2f)
                {
                    direction = deltaXToEnemy > 0f ? Direction.R : Direction.L;
                }
            }
            else if (mapObject != null)
            {
                // Keep the current facing direction for tiles.
                // Tile attacks should inherit the last movement direction instead of flipping
                // based on mapObject position every frame.
                if (!isLocalPlayer)
                {
                    if (hitTime > hitSpeed)
                    {
                        hitTime = 0;
                        if (MapManager.instance != null)
                        {
                            mapObject.mapData.health = (int)(mapObject.mapData.health * 5 / 6);
                            mapObject.LoadData();
                            //SoundManager.instance.PlaySounds(hitBlockSounds);
                            //VfxManager.instance.OnMapHitEffect(mapObject.transform.position);
                            EventDispatcher.Raise(new OnSendMapPosition
                            {
                                position = mapObject.transform.position,
                            });
                        }
                    }
                    else
                    {
                        hitTime += Time.deltaTime;
                    }
                }
            }
        }
        else
        {
            ClientExitAttackState(dir);
        }
    }

    [Client]
    private void ClientExitAttackState(Vector2 dir)
    {
        if (isLocalPlayer)
        {
            Vector2 joystickDir = Vector2.zero;
            if (UIManager.instance != null)
            {
                joystickDir = new Vector2(
                    UIManager.instance.GetJoysticHorizontal(),
                    UIManager.instance.GetJoysticVertical());
                if (joystickDir.sqrMagnitude > 1f)
                    joystickDir.Normalize();
            }

            if (!IsAutoMode() && joystickDir.sqrMagnitude > 0.0001f)
            {
                characterBody.animator.speed = 0.5f + joystickDir.magnitude / 2f;
                ClientSetCharacterState(CharacterState.Run);
                timeRun = 0;

                if (joystickDir.x > 0)
                {
                    direction = Direction.R;
                }
                else if (joystickDir.x < 0)
                {
                    direction = Direction.L;
                }
            }
            else if (IsAutoMode())
            {
                Vector2 bodyDelta = (Vector2)characterBody.transform.position - (Vector2)lastPosition;
                // Use the target direction immediately when auto mode starts;
                // bodyDelta can still contain the last manual movement frame.
                Vector2 autoDir = dir.sqrMagnitude > 0.0001f
                    ? dir.normalized
                    : bodyDelta.normalized;
                if (autoDir.sqrMagnitude > 0.0001f)
                {
                    characterBody.animator.speed = 0.5f + autoDir.magnitude / 2f;
                    ClientSetCharacterState(CharacterState.Run);
                    timeRun = 0;

                    if (autoDir.x > 0)
                    {
                        direction = Direction.R;
                    }
                    else if (autoDir.x < 0)
                    {
                        direction = Direction.L;
                    }
                }
                else
                {
                    characterBody.animator.speed = 1f;
                    ClientSetCharacterState(CharacterState.Idle);
                }
            }
            else
            {
                characterBody.animator.speed = 1f;
                ClientSetCharacterState(CharacterState.Idle);
            }

            return;
        }

        var bodyPos = characterBody.transform.position;
        float distance = Vector2.Distance(bodyPos, lastPosition);

        if (enermy != null)
        {
            DisableTargetOutline(enermy);
        }

        if (distance > 0)
        {
            characterBody.animator.speed = 0.5f + dir.magnitude / 2;
            ClientSetCharacterState(CharacterState.Run);
            timeRun = 0;

            //set direction & animation
            if (dir.x > 0)
            {
                direction = Direction.R;
            }
            else if (dir.x < 0)
                direction = Direction.L;
        }
        else if (timeRun > 0.3f || isLocalPlayer)
        {
            characterBody.animator.speed = 1;
            ClientSetCharacterState(CharacterState.Idle);
        }
        else
        {
            timeRun += Time.deltaTime;
        }
    }

    private bool TryGetAutoFacingDirection(Vector2 bodyPosition, out Vector2 autoDir)
    {
        autoDir = Vector2.zero;

        if (!isLocalPlayer || !IsAutoMode() || playerAuto == null)
            return false;

        if (IsAutoFarm() && !playerAuto.HasActiveAutoFarmTarget())
            return false;

        Vector2 toTarget = (Vector2)playerAuto.targetPosition - bodyPosition;
        if (toTarget.sqrMagnitude > 0.0001f)
        {
            autoDir = toTarget.normalized;
            return true;
        }

        return false;
    }

    [Client]
    private void ClientCheckName()
    {
        timeCheckName += Time.deltaTime;
        if (timeCheckName > maxTimeCheckName)
        {
            characterBody.SetName();
            timeCheckName = 0;
        }
    }

    [ClientCallback]
    protected override void DoAnimation(CharacterState characterState)
    {
        if (characterBody.gameObject.activeSelf && characterBody.animator.gameObject.activeSelf && UIManager.instance != null)
        {
            if (UIManager.instance == null)
                return;

            var hash = UIManager.instance.GetAnimation(this, characterState);
            if (hash == -1)
            {
                characterBody.animator.Play(characterState.ToString().ToLower());
            }
            else
            {
                characterBody.animator.Play(hash);
            }
        }
    }


    public override int GetGold() => characterInventory.gold;

    public void AddGold(int value) => characterInventory.AddGold(value);

    public void SetGold(int value) => characterInventory.SetGold(value);

    public bool HasNoInventorySlot()
    {
        return characterInventory.GetEquipmentCount() >= GetFinalInventorySlot();
    }

    public bool HasNoIngredientSlot()
    {
        return characterIngredient.GetEquipmentCount() >= GetFinalIngredientSlot();
    }



    // Write an already-owned equipment back into the container that really holds its id. Never routes by
    // equipment.state (collection/title/New/Lock items used to be upserted into the inventory = duplicated) and
    // never creates the item in a container that does not already hold it.
    void ResetEquipment(Equipment equipment)
    {
        if (equipment == null || string.IsNullOrEmpty(equipment.id))
            return;

        string id = equipment.id;
        switch (EquipmentContainerRules.Resolve(
                    characterInventory != null && characterInventory.GetEquipment(id) != null,
                    characterEquipments != null && characterEquipments.GetEquipment(id) != null,
                    characterIngredient != null && characterIngredient.GetEquipment(id) != null,
                    characterCollection != null && characterCollection.GetEquipment(id) != null,
                    characterTitleEquipment != null && characterTitleEquipment.GetEquipment(id) != null))
        {
            case EquipmentContainerKind.Inventory:
                characterInventory.ResetEquipment(equipment);
                break;
            case EquipmentContainerKind.Equipments:
                characterEquipments.ResetEquipment(equipment);
                break;
            case EquipmentContainerKind.Ingredient:
                characterIngredient.ResetEquipment(equipment);
                break;
            case EquipmentContainerKind.Collection:
                characterCollection.ResetEquipment(equipment);
                break;
            case EquipmentContainerKind.Title:
                characterTitleEquipment.ResetEquipment(equipment);
                break;
        }
    }

    public bool HaveEnoughMoneys(CurrencyData[] cost)
    {
        if (cost == null || cost.Length == 0)
        {
            return true;
        }

        return BattleManager.instance.HaveEnoughCurrencyDatas(this.userName, new List<CurrencyData>(cost));
    }

    public bool HaveEnoughMoney(CurrencyData cost)
    {
        return BattleManager.instance.HaveEnoughCurrencyData(this.userName, cost);
    }

    public void AddArenaCoin(int value)
    {
        CurrencyData currencyData = new() { currencyId = GameConst.ARENA_COIN_ID, value = value };
        BattleManager.instance.gameLogicBehavior.TargetReceiveCurrency(this.connectionToClient, characterInventory.arenaCoin, currencyData);
        AddCost(currencyData);
    }

    void AddCosts(CurrencyData[] cost)
    {
        for (int i = 0; i < cost.Length; i++)
        {
            AddCost(cost[i]);
        }
    }

    void AddCost(CurrencyData cost)
    {
#if ENABLE_SERVER
        BattleManager.instance.AddCurrencyData(this.userName, cost);
#endif
    }

    void PayCosts(CurrencyData[] cost)
    {
        for (int i = 0; i < cost.Length; i++)
        {
            PayCost(cost[i]);
        }
    }

    public void PayCost(CurrencyData cost)
    {
        if (cost.currencyId == GameConst.GOLD_ID)
        {
            if (GetGold() >= cost.value)
            {
                BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData { currencyId = cost.currencyId, value = -cost.value });
            }
        }
        else if (cost.currencyId == GameConst.DIAMOND_ID)
        {
            if (characterInventory.diamond >= cost.value)
            {
                BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData { currencyId = cost.currencyId, value = -cost.value });
                BattleManager.instance.AddTransaction(this.userName, -1, -cost.value, "Upgrade/Craft/CreateClan");
            }
        }
        else if (cost.currencyId == GameConst.SHARD_ID)
        {
            if (characterInventory.shard >= cost.value)
            {
                BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData { currencyId = cost.currencyId, value = -cost.value });
            }
        }
        else if (cost.currencyId == GameConst.TH_COIN_ID)
        {
            WalletData walletData = BattleManager.instance.GetWalletData(this.userName);
            if (walletData != null)
            {
                if (walletData.token >= cost.value)
                {
                    BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData { currencyId = cost.currencyId, value = -cost.value });
                }
            }
        }
        else if (cost.currencyId == GameConst.ARENA_COIN_ID)
        {
            if (characterInventory.arenaCoin >= cost.value)
            {
                BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData { currencyId = cost.currencyId, value = -cost.value });
            }
        }
        else if (cost.GetCurrencyType() == CurrencyID.Announcement)
        {
            if (characterInventory.GetAnnouncement() >= cost.value)
            {
                BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData { currencyId = cost.currencyId, value = -cost.value });
            }
        }
        else if (cost.GetCurrencyType() == CurrencyID.ClanCoin)
        {
            if (characterInventory.clanCoin >= cost.value)
            {
                BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData { currencyId = cost.currencyId, value = -cost.value });
            }
        }
        else if (cost.GetCurrencyType() == CurrencyID.SkinExchange)
        {
            if (characterInventory.GetSkinExchange() >= cost.value)
            {
                BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData { currencyId = cost.currencyId, value = -cost.value });
            }
        }
        else if (cost.GetCurrencyType() == CurrencyID.FreeEventRoll)
        {
            if (numberRollSeasonEventFree >= cost.value)
            {
                BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData { currencyId = cost.currencyId, value = -cost.value });
            }
        }
        else if (cost.currencyId == GameConst.REX_FANG_ID || cost.GetCurrencyType() == CurrencyID.RexFang)
        {
            if (characterInventory.GetRexFang() >= cost.value)
            {
                BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData { currencyId = cost.currencyId, value = -cost.value });
            }
        }
        else if (cost.GetCurrencyType() == CurrencyID.BonusV3TransferTicket)
        {
            if (characterInventory.GetBonusV3TransferTicket() >= cost.value)
            {
                BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData { currencyId = cost.currencyId, value = -cost.value });
            }
        }
        else if (cost.GetCurrencyType() == CurrencyID.NumberRollSkinCosmeticToday)
        {
            if (characterInventory.GetNumberRollSKinCosmeticToday() >= cost.value)
            {
                BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData { currencyId = cost.currencyId, value = -cost.value });
            }
        }
    }

    public CurrencyData[] GetCostTransferServer(ServerInfo server, bool useTransferTicket)
    {
        var gameDataConfig = BattleManager.instance.gameDataConfig;

        if (server.serverType == ServerType.FinalWar || BattleManager.IsFinalWar) return new CurrencyData[0];
        if (server.serverType == ServerType.Tournament)
        {
            return new CurrencyData[]
            {
                new() { currencyId = REX_FANG_ID, value = 1 },
            };
        }
        else
        {
            if (BattleManager.IsTournament)
            {
                return new CurrencyData[]
                {
                    new() { currencyId = REX_FANG_ID, value = 0 },
                };
            }
            else
            {
                if (useTransferTicket)
                {   
                    if (characterInventory.GetBonusV3TransferTicket() > 0)
                    {
                        BattleManager.Log(GameLogType.UserTracking, userName + "use transfer ticket. Current ticket " + characterInventory.GetBonusV3TransferTicket());

                        return new CurrencyData[]
                        {
                            new() { currencyId = (int)CurrencyID.BonusV3TransferTicket, value = 1 },
                            new() { currencyId = (int)CurrencyID.THCoin, value = gameDataConfig.CostBuyTransferTicket },
                        };
                    }
                }    

                CurrencyData costTH = new CurrencyData { currencyId = TH_COIN_ID, value = gameDataConfig.CostDefaultServerTransfer };

                if (this.characterEquipments != null)
                {
                    var equipementCount = 0;
                    foreach (var equipment in this.characterEquipments.equipments.Values)
                    {
                        if (equipment != null && equipment.equipmentType != EquipmentType.Hair && equipment.equipmentType != EquipmentType.Eye
                                && equipment.equipmentType != EquipmentType.FaceHair && equipment.equipmentType != EquipmentType.Body)
                        {
                            equipementCount++;
                        }
                    }

                    var cost = equipementCount * gameDataConfig.CostEachItemServerTransfer;

                    BattleManager.Log(GameLogType.Debug, "EquipmentCount: " + equipementCount);
                    BattleManager.Log(GameLogType.Debug, "EquipmentCost: " + cost);

                    costTH.value += cost;
                }

                if (this.characterInventory != null)
                {
                    var equipementCount = this.characterInventory.GetEquipmentCount();
                    var cost = equipementCount * gameDataConfig.CostEachItemServerTransfer;

                    BattleManager.Log(GameLogType.Debug, "EquipmentCount: " + equipementCount);
                    BattleManager.Log(GameLogType.Debug, "EquipmentCost: " + cost);

                    costTH.value += cost;
                }

                if (this.characterIngredient != null)
                {
                    var ingredientCount = this.characterIngredient.GetEquipmentCount();
                    var cost = ingredientCount * gameDataConfig.CostEachItemServerTransfer;

                    BattleManager.Log(GameLogType.Debug, "IngredientCount: " + ingredientCount);
                    BattleManager.Log(GameLogType.Debug, "IngredientCost: " + cost);

                    costTH.value += cost;
                }

                if (this.characterWallet != null)
                {
                    WalletData walletData = null;
#if ENABLE_SERVER
                    walletData = BattleManager.instance.GetWalletData(this.userName);
#elif ENABLE_CLIENT
                walletData = ClientManager.instance.myWalletData;
#endif
                    if (walletData != null)
                    {
                        var count = walletData.nfts.Count + walletData.ingredients.Count;
                        var cost = count * gameDataConfig.CostEachItemServerTransfer;

                        BattleManager.Log(GameLogType.Debug, "WalletCount: " + count);
                        BattleManager.Log(GameLogType.Debug, "WalletCost: " + cost);

                        costTH.value += cost;
                    }
                }

                if (this.characterCollection != null)
                {
                    var count = this.characterCollection.GetEquipmentCount();
                    var cost = count * gameDataConfig.CostEachItemServerTransfer;

                    BattleManager.Log(GameLogType.Debug, "CollectionCount: " + count);
                    BattleManager.Log(GameLogType.Debug, "CollectionCost: " + cost);

                    costTH.value += cost;
                }

                costTH.value = Mathf.Min(costTH.value, 2000);

                CurrencyData[] currencyDatas = new CurrencyData[]
                {
                    costTH,
                };

                return currencyDatas;
            }

        }
    }

    public int GetCraftSlot(bool slotTradeable)
    {
        var min = GameConst.CRAFT_SLOT_DEFAULT;
        var max = GameConst.CRAFT_SLOT_MAX;

        if (slotTradeable)
        {
            min = GameConst.CRAFT_SLOT_TRADE_DEFAULT;
            max = GameConst.CRAFT_SLOT_TRADE_MAX;
        }

        return Mathf.Clamp(min + (int)Mathf.Sqrt(GetCraftNumber() / 5), min, max);

    }

    public int GetCraftLevel(bool slotTradeable)
    {
        return (int)Mathf.Sqrt(GetCraftNumber() / 5);
    }

    public float GetCraftProgress(bool slotTradeable)
    {
        int currentLevel = GetCraftLevel(slotTradeable);
        int nextLevel = currentLevel + 1;

        float currentLevelCraftCount = currentLevel * currentLevel * 5;
        float nextLevelCraftCount = nextLevel * nextLevel * 5;

        if (GetCraftNumber() >= nextLevelCraftCount)
            return 1.0f;

        float progress = (GetCraftNumber() - currentLevelCraftCount) / (nextLevelCraftCount - currentLevelCraftCount);

        return Mathf.Clamp01(progress);
    }


    public int GetFinalIngredientSlot()
    {
        return GetFinalSlot(GetIngredientSlot());
    }

    public float GetIngredientSlot()
    {
        return GetIngredientSlot(GetIngredientSlotStat());
    }

    private float GetIngredientSlot(float ingredientSlotStat)
    {
        if (BattleManager.instance == null)
        {
            return 0;
        }

        if (this.characterType == CharacterType.Player)
        {
            if (BattleManager.instance.gameDataConfig == null)
            {
                return Mathf.Clamp(ingredientSlotStat,
                8,
                40);
            }
            else
            {
                return Mathf.Clamp(ingredientSlotStat,
                BattleManager.instance.gameDataConfig.basicIngredientSlot,
                BattleManager.instance.gameDataConfig.maxPlayerIngredientSlot);
            }

        }
        else
        {
            return Mathf.Clamp(ingredientSlotStat, 0, 56);
        }
    }

    public float GetIngredientSlotStat()
    {
        if (this.characterType == CharacterType.Player)
        {
            int basicIngredientSlot = 16;
            if (BattleManager.instance.gameDataConfig != null)
            {
                basicIngredientSlot = BattleManager.instance.gameDataConfig.basicIngredientSlot;
            }

            return basicIngredientSlot + statData.GetStat(StatType.IngredientSlot).value;
        }
        else
            return statData.GetStat(StatType.IngredientSlot).value;
    }

    public int GetFinalInventorySlot()
    {
        return GetFinalSlot(GetInventorySlot());
    }

    public float GetInventorySlot()
    {
        return GetInventorySlot(GetInventorySlotStat());
    }

    private float GetInventorySlot(float inventorySlotStat)
    {
        if (this.characterType == CharacterType.Player)
        {
            int basicInventorySlot = GameConst.BASIC_INVENTORY_SLOT;
            int maxInventorySlot = GameConst.MAX_INVENTORY_SLOT;

            if (BattleManager.instance != null && BattleManager.instance.gameDataConfig != null)
            {
                if (BattleManager.instance.gameDataConfig.basicInventorySlot > 0)
                {
                    basicInventorySlot = BattleManager.instance.gameDataConfig.basicInventorySlot;
                }

                if (BattleManager.instance.gameDataConfig.maxPlayerInventorySlot > 0)
                {
                    maxInventorySlot = BattleManager.instance.gameDataConfig.maxPlayerInventorySlot;
                }
            }

            maxInventorySlot = Mathf.Max(basicInventorySlot, maxInventorySlot);
            return Mathf.Clamp(inventorySlotStat, basicInventorySlot, maxInventorySlot);
        }
        else
            return Mathf.Clamp(inventorySlotStat, 0, 56);
    }

    public float GetInventorySlotStat()
    {
        if (this.characterType == CharacterType.Player)
        {
            int basicInventorySlot = GameConst.BASIC_INVENTORY_SLOT;
            if (BattleManager.instance.gameDataConfig != null)
            {
                basicInventorySlot = BattleManager.instance.gameDataConfig.basicInventorySlot;
            }
            return basicInventorySlot + statData.GetStat(StatType.InventorySlot).value;
        }
        else
            return statData.GetStat(StatType.InventorySlot).value;
    }

    private int GetFinalSlot(float slot)
    {
        if (slot - Mathf.FloorToInt(slot) > 0.9f)
            return Mathf.FloorToInt(slot) + 1;
        else
            return Mathf.FloorToInt(slot);
    }

    public int GetFinalIngredientSlotAfterStatChange(float ingredientSlotStatDelta)
    {
        return GetFinalSlot(GetIngredientSlot(GetIngredientSlotStat() + ingredientSlotStatDelta));
    }

    public int GetFinalInventorySlotAfterStatChange(float inventorySlotStatDelta)
    {
        return GetFinalSlot(GetInventorySlot(GetInventorySlotStat() + inventorySlotStatDelta));
    }

    public bool CanUnEquipEquipment(Equipment equipment, out bool inventorySlotIsFull, out bool ingredientSlotIsFull)
    {
        inventorySlotIsFull = false;
        ingredientSlotIsFull = false;

        if (equipment == null)
        {
            return false;
        }

        if (equipment.IsCollection() || equipment.equipmentType == EquipmentType.SkinTitle)
        {
            return true;
        }

        float inventorySlotStat = equipment.GetStat(StatType.InventorySlot);
        int finalInventorySlotAfterUnEquip = GetFinalInventorySlotAfterStatChange(-inventorySlotStat);
        int inventoryCountAfterUnEquip = characterInventory.GetEquipmentCount() + 1;

        if (inventoryCountAfterUnEquip > finalInventorySlotAfterUnEquip)
        {
            inventorySlotIsFull = true;
        }

        float ingredientSlotStat = equipment.GetStat(StatType.IngredientSlot);
        if (ingredientSlotStat > 0)
        {
            int finalIngredientSlotAfterUnEquip = GetFinalIngredientSlotAfterStatChange(-ingredientSlotStat);
            int ingredientCount = characterIngredient.GetEquipmentCount();

            if (ingredientCount > finalIngredientSlotAfterUnEquip)
            {
                ingredientSlotIsFull = true;
            }
        }

        return inventorySlotIsFull == false && ingredientSlotIsFull == false;
    }

    [Client]
    public void EnableMapObjectOutline(MapObject mapObject)
    {
        if (isLocalPlayer)
        {
            if (mapObject != null)
                mapObject.EnableOutline();
        }
    }

    [Client]
    public void DisableMapObjectOutline(MapObject mapObject)
    {
        if (isLocalPlayer)
        {
            if (mapObject != null)
                mapObject.DisableOutline();
        }
    }



    public float GetRawStatData(StatType statType, bool fetch = false)
    {
        if (fetch)
        {
            UpdateRawStat();
        }

        return rawStatData.GetStat(statType).value;
    }

    public override StatData UpdateRawStat()
    {
        rawStatData.ResetStats();
        foreach (var entry in characterEquipments.equipments)
        {
            Equipment e = entry.Value;

            if (e.equipmentType != EquipmentType.Artifact &&
                e.equipmentType != EquipmentType.SkinTitle)
            {
                if (e.equipmentType == EquipmentType.Avatar || e.equipmentType == EquipmentType.SkinHorse || e.IsCollection() == false)
                {
                    rawStatData.AddStats(e.GetStats(e.level));
                }
            }
        }

        if (characterEquipments.collectionsValidEmote.Count >= GameConst.MAX_COLLECTION_EMOTE)
        {
            var statDataCollection = new StatData();
            foreach (var collection in characterEquipments.collectionsValidEmote)
            {
                var stats = collection.GetStats(collection.level);
                rawStatData.AddStats(stats);
            }
        }

        if (characterEquipments.collectionsValid.Count >= GameConst.MAX_COLLECTION)
        {
            var statDataCollection = new StatData();
            foreach (var collection in characterEquipments.collectionsValid)
            {
                var stats = collection.GetStats(collection.level);
                statDataCollection.AddStats(stats);
            }
            rawStatData.AddEffect(statDataCollection);
        }

        if (characterEquipments.collectionsValidPet.Count >= GameConst.MAX_COLLECTION_PET)
        {
            var statDataCollection = new StatData();
            foreach (var collection in characterEquipments.collectionsValidPet)
            {
                var stats = collection.GetStats(collection.level);
                statDataCollection.AddStats(stats);
            }
            rawStatData.AddEffect(statDataCollection);
        }

        return rawStatData;
    }

    private float GetEffectMax(StatType statType)
    {
        if (characterEffects != null)
        {
            return characterEffects.GetEffectMax(statType);
        }

        return 0;
    }

    public float SpeedCaculater(float speed)
    {
        if (speed > 3)
        {
            return 3 + Mathf.Pow(speed - 3, 0.5f) + Random.Range(-0.3f, 0.3f);
        }
        else if (speed < 0)
        {
            return 0;
        }
        return speed;
    }


    public Equipment GetEquipment(string id)
    {
        Equipment equipment = null;
        equipment = characterInventory.GetEquipment(id);
        if (equipment == null)
            equipment = characterEquipments.GetEquipment(id);
        if (equipment == null)
            equipment = characterIngredient.GetEquipment(id);
        if (equipment == null && characterCollection != null)
            equipment = characterCollection.GetEquipment(id);
        if (equipment == null && characterTitleEquipment != null)
            equipment = characterTitleEquipment.GetEquipment(id);
        return equipment;
    }

    public List<Equipment> GetCraftEquipments()
    {
        List<Equipment> items = ClientManager.instance.myCharacter.characterEquipments.GetCraftEquipments();
        items.AddRange(ClientManager.instance.myCharacter.characterInventory.GetCraftEquipments());
        return items;
    }

    public List<Equipment> GetClanStoreInventoryEquipments()
    {
        var items = ClientManager.instance.myCharacter.characterInventory.GetEquipments();
        var result = new List<Equipment>();

        foreach (var item in items)
        {
            Card card = DataHolder.Instance().GetData<Card>(item.itemId);
            if (card == null)
            {
                continue;
            }

            if (card.isTradable && card.equipmentType != EquipmentType.Summon)
            {
                continue;
            }

            if (card.equipmentType == EquipmentType.Key)
            {
                continue;
            }
            result.Add(item);
        }

        return result;
    }

    public Equipment GetInventoryEquipment(EquipmentType equipmentType)
    {
        return characterInventory.GetEquipment(equipmentType);
    }

    [ClientRpc]
    public void RpcAddHeal(int value)
    {
        characterHealth.OnAddHealth(value);
    }

    public override (int gold, List<Equipment> equipments) GetDeathDrops()
    {
#if ENABLE_SERVER_TEST
        if (isFinalWarTestBot) return (0, new List<Equipment>());
#endif
#if ENABLE_SERVER
        List<Equipment> equipmentDrops = new List<Equipment>();
        int goldDrop = 0;


        List<Equipment> equipments = characterInventory.GetEquipments();
        equipments.AddRange(characterIngredient.GetEquipments());
        if (characterType == CharacterType.Player) { equipments.AddRange(characterEquipments.GetEquipments()); }

        int itemLostAmount = 0;

        var areaStandingOn = GetRuntimeAreaController();
        if (areaStandingOn != null)
        {
            itemLostAmount = Mathf.Min(equipments.Count, areaStandingOn.EquipmentLostAmount);
            BattleManager.Log(GameLogType.Debug, "areaStandingOn Lost amount " + areaStandingOn.EquipmentLostAmount);

            goldDrop = (int)(GetGold() * areaStandingOn.GoldLostRate);
        }

        BattleManager.Log(GameLogType.Debug, "Lost amount " + itemLostAmount);

        DataUtils.Shuffle(equipments);

        //Prefer lost weapons first

        if (itemLostAmount > 0 && Random.Range(0, 100) > 80 && seasonTimePlay > 10000 && IsStandingOn(RuntimeZoneType.White))
        {
            var weapons = characterEquipments.GetEquipment(EquipmentType.Weapons);
            if (weapons != null)
            {
                equipmentDrops.Add(weapons);
                return (goldDrop, equipmentDrops);
            }
        }

        foreach (Equipment e in equipments)
        {
            if (equipmentDrops.Count >= itemLostAmount) break;
            if (e.IsCollection() || e.IsModEquipment() ||
                e.equipmentType == EquipmentType.SkinTitle || e.equipmentType == EquipmentType.Key ||
                ClanPetStableHelper.IsStablePetProtectedFromDrop(this, e)) continue;

            Card card = DataHolder.Instance().GetData<Card>(e.itemId);
            if (!card.isTradable || this.characterType == CharacterType.Building)
            {
                equipmentDrops.Add(e);
            }
        }


        return (goldDrop, equipmentDrops);
#else
        return default;
#endif
    }

    //[Server]
    //public override List<Equipment> GetEquipmentsOnDead()
    //{
    //    List<Equipment> lostEquipment = new List<Equipment>();
    //    List<Equipment> equipments = characterInventory.GetEquipments();
    //    equipments.AddRange(characterIngredient.GetEquipments());
    //    if (characterType == CharacterType.Player)
    //    {
    //        equipments.AddRange(characterEquipments.GetEquipments());
    //    }

    //    int current = GetGold();
    //    int newGold = current;
    //    int n = 0;

    //    if (this.mapZoneType == MapZoneType.White || this.mapZoneType == MapZoneType.Viking)
    //    {
    //        newGold = current * 2 / 3;
    //        n = 1;
    //    }
    //    else if (this.mapZoneType == MapZoneType.Undead)
    //    {
    //        newGold = current * 2 / 3;
    //        n = 1;
    //    }
    //    else if (this.mapZoneType == MapZoneType.Village ||
    //        this.mapZoneType == MapZoneType.SafeZone ||
    //        this.mapZoneType == MapZoneType.FireCraft ||
    //        this.mapZoneType == MapZoneType.RegisterZone)
    //    {
    //        newGold = current * 9 / 10;
    //    }
    //    else if (this.mapZoneType == MapZoneType.Arena) { n = 0; }
    //    else if (this.mapZoneType == MapZoneType.RegisterZone) { n = 0; }
    //    else { newGold = current * 4 / 5; }

    //    SetGold(newGold);

    //    if (characterType == CharacterType.Building)
    //    {
    //        n = equipments.Count / 3 + 2;
    //    }
    //    if (n > equipments.Count)
    //        n = equipments.Count;



    //    DataUtils.Shuffle(equipments);
    //    int count = 0;

    //    if (n > 0)
    //    {
    //        foreach (Equipment e in equipments)
    //        {
    //            if (e.IsCollection() || e.IsModEquipment() ||
    //                e.equipmentType == EquipmentType.SkinTitle || e.equipmentType == EquipmentType.Key)
    //            {
    //                continue;
    //            }

    //            Card card = DataHolder.Instance().GetData<Card>(e.itemId);
    //            if (!card.isTradable || this.characterType == CharacterType.Building)
    //            {
    //                characterEquipments.RemoveEquipment(e.id);
    //                characterInventory.RemoveEquipment(e.id);
    //                characterIngredient.RemoveEquipment(e.id);

    //                Log(LogAction.LostEquipment, "1", e.ToJson());
    //                int n1 = Random.Range(0, 100);
    //                if (n1 < 70)
    //                {
    //                    lostEquipment.Add(e);
    //                }
    //                count++;
    //                if (count >= n)
    //                    break;
    //            }
    //        }
    //    }

    //    if (mobId == GameConst.STORAGE_BUILDING_ID)
    //    {
    //        foreach (var equipment in lostEquipment)
    //        {
    //            if (equipment.state == EquipmentState.Lock)
    //            {
    //                if (equipment.equipmentType == EquipmentType.Ingredient)
    //                {
    //                    equipment.state = EquipmentState.Ingredient;
    //                }
    //                else
    //                {
    //                    equipment.state = EquipmentState.Inventory;
    //                }
    //            }
    //        }
    //    }

    //    return lostEquipment;
    //}

    //[Server]
    //public override CurrencyData[] GetCurrencyDataOnDead(float goldRate = 1, float diamondRate = 1)
    //{
    //    CurrencyData[] currencyDatas = new CurrencyData[1];
    //    currencyDatas[0] = new CurrencyData();
    //    currencyDatas[0].currencyId = GameConst.GOLD_ID;

    //    var isStandingOnArena = IsStandingOn(RuntimeAreaController.AreaType.Arena);

    //    //if (mapZoneType == MapZoneType.Undead || mapZoneType == MapZoneType.White || mapZoneType == MapZoneType.Viking)
    //    if (IsStandingOn(RuntimeAreaType.Undead, RuntimeAreaType.White))
    //    {
    //        currencyDatas[0].value = GetGold() / 6;
    //    }
    //    //else if (this.mapZoneType == MapZoneType.Village || this.mapZoneType == MapZoneType.SafeZone
    //    //    || this.mapZoneType == MapZoneType.FireCraft || this.mapZoneType == MapZoneType.RegisterZone
    //    //    || this.mapZoneType == MapZoneType.RegisterZone)
    //    else if (IsStandingOn(RuntimeAreaType.Grass) && !isStandingOnArena)
    //    {
    //        currencyDatas[0].value = GetGold() / 20;
    //    }
    //    //else if (this.mapZoneType == MapZoneType.Arena)
    //    else if (isStandingOnArena)
    //    {
    //        currencyDatas[0].value = 0;
    //    }
    //    else
    //    {
    //        currencyDatas[0].value = GetGold() / 10;
    //    }

    //    if (currencyDatas[0].value < 0)
    //    {
    //        currencyDatas[0].value = 0;
    //    }

    //    return currencyDatas;
    //}

    [Server]
    public override void AddEquipmentsOnKill(List<Equipment> equipments, CurrencyData[] currencyDatas)
    {
#if ENABLE_SERVER_TEST
        if (isFinalWarTestBot) return;
#endif
#if ENABLE_SERVER
        foreach (CurrencyData currencyData in currencyDatas)
        {
            if (currencyData.currencyId == GameConst.GOLD_ID)
            {
                if (this.connectionToClient != null)
                    BattleManager.instance.gameLogicBehavior.TargetReceiveCurrency(this.connectionToClient, GetGold(), currencyData);
                AddGold(currencyData.value);
            }
            else if (currencyData.currencyId == GameConst.DIAMOND_ID)
            {
                if (this.connectionToClient != null)
                    BattleManager.instance.gameLogicBehavior.TargetReceiveCurrency(this.connectionToClient, characterInventory.diamond, currencyData);
                characterInventory.diamond += currencyData.value;
                //BattleManager.instance.AddTransaction(this.userName, -1, currencyData.value, "Kill Other Mob");
            }
            else if (currencyData.currencyId == GameConst.SHARD_ID)
            {
                if (this.connectionToClient != null)
                    BattleManager.instance.gameLogicBehavior.TargetReceiveCurrency(this.connectionToClient, characterInventory.shard, currencyData);
                characterInventory.shard += currencyData.value;
                //BattleManager.instance.AddTransaction(this.userName, -1, currencyData.value, "Kill Other Mob");
            }
        }

        foreach (Equipment e in equipments)
        {
            if (e.equipmentType == EquipmentType.Ingredient || e.equipmentType == EquipmentType.EventItem)
            {
                if (characterIngredient.GetEquipmentCount() < this.GetFinalIngredientSlot())
                {
                    characterIngredient.AddEquipment(e);
                }
                else
                {
                    CurrencyData sellCost = e.GetSellCost();
                    if (sellCost.currencyId == GameConst.GOLD_ID)
                    {
                        AddGold(sellCost.value);
                    }
                    else if (sellCost.currencyId == GameConst.DIAMOND_ID)
                    {
                        characterInventory.diamond += sellCost.value;
                        BattleManager.instance.AddTransaction(this.userName, -1, sellCost.value, "Sell Mob Ingredient");
                    }

                }
            }
            else
            {
                if (characterInventory.GetEquipmentCount() < this.GetFinalInventorySlot())
                {
                    if (e.state == EquipmentState.Character)
                    {
                        e.state = EquipmentState.Inventory;
                    }
                    characterInventory.AddEquipment(e);
                }
                else
                {
                    CurrencyData sellCost = e.GetSellCost();
                    if (sellCost.currencyId == GameConst.GOLD_ID)
                        AddGold(sellCost.value);
                    else if (sellCost.currencyId == GameConst.DIAMOND_ID)
                    {
                        characterInventory.diamond += sellCost.value;
                        BattleManager.instance.AddTransaction(this.userName, -1, sellCost.value, "Sell Mob Equipment");
                    }

                }
            }

        }
#endif
    }

    [Server]
    public override void LostEquipments(List<Equipment> equipments, int gold)
    {
#if ENABLE_SERVER
        foreach (var e in equipments)
        {
            SafeRemoveEquipment(e);
        }

        AddGold(-gold);
#endif
    }



    [ServerCallback]
    public override List<Equipment> GetLimitedEquipmentOnDead()
    {
        List<Equipment> lostEquipment = new List<Equipment>();
        List<Equipment> equipments = characterEquipments.GetEquipments();
        equipments.AddRange(characterInventory.GetEquipments());
        foreach (Equipment e in equipments)
        {
            if (e.equipmentType == EquipmentType.SkinTitle || e.IsCollection())
            {
                continue;
            }

            if (ClanPetStableHelper.IsStablePetProtectedFromDrop(this, e))
            {
                continue;
            }
            Card card = DataHolder.Instance().GetData<Card>(e.itemId);
            if (card.isLimited)
            {
                bool success = SafeRemoveEquipment(e);
                if (success)
                {
                    lostEquipment.Add(e);
                }
            }
        }
        return lostEquipment;
    }

    [ServerCallback]
    public override void AddLimitedEquipmentsOnKill(List<Equipment> equipments)
    {
        foreach (Equipment e in equipments)
        {
            if (characterInventory.GetEquipmentCount() < this.GetFinalInventorySlot())
            {
                characterInventory.AddEquipment(e);
            }
        }
    }

    protected override void OnTriggerEnter2D(Collider2D collision)
    {
        base.OnTriggerEnter2D(collision);

        if (isClient)
        {
            OnClientTriggerEnter2D(collision);
        }
        else
        {
            MapItemBehavior target = collision.GetComponent<MapItemBehavior>();
            if (target != null && target.MapItemType == MapItemType.Chest)
            {
                ServerTryOpenChest(target);
            }
        }
    }


    [Server]
    private void ServerTryOpenChest(MapItemBehavior mapItemBehavior)
    {
#if ENABLE_SERVER
        if (mapItemBehavior is ChestBehavior chest)
        {
            var keys = characterInventory.GetEquipments(EquipmentType.Key);
            if (keys == null)
                return;

            Card item = DataHolder.Instance().GetData<Card>(chest.ItemId);
            if (item == null)
                return;

            foreach (var key in keys)
            {
                if (key.itemId == item.keyId)
                {
                    SetCharacterState(CharacterState.OpenChest);
                    BattleManager.Log(GameLogType.Debug, userName + " Server try open chest " + GetCharacterState());
                    ServerLogicStartOpenChest(chest, key.id);
                }
            }
        }
#endif
    }


    [Client]
    private void OnClientTriggerEnter2D(Collider2D collision)
    {
        if (isLocalPlayer)
        {
            ZoneBehavior zoneBehavior = collision.GetComponent<ZoneBehavior>();
            OnLocalPlayerEnterZoneBehavior(zoneBehavior);
        }

        MapItemBehavior target = collision.GetComponent<MapItemBehavior>();
        if (target != null && target.MapItemType == MapItemType.Chest)
        {
            OnLocalPlayerEnterChest(target);
        }
    }

    [Client]
    private void OnLocalPlayerEnterChest(MapItemBehavior chestBehavior)
    {
        if (isLocalPlayer == false)
            return;

        Equipment key = characterInventory.GetEquipment(EquipmentType.Key);
        if (key == null)
        {
            if (IngameNotifyManager.instance != null)
                IngameNotifyManager.instance.OnToastView(UIManager.GetDialog(25));
        }
        else
        {
            var distance = Vector2.Distance(transform.position, chestBehavior.transform.position);
            if (distance <= GameConst.OPEN_CHEST_DISTANCE)
            {
                SetCharacterState(CharacterState.OpenChest);
                if (SoundManager.instance != null)
                    SoundManager.instance.PlayUISound("OpenChest");
            }
        }
    }

    [Client]
    private void OnLocalPlayerEnterZoneBehavior(ZoneBehavior zoneBehavior)
    {
        if (zoneBehavior == null)
        {
            return;
        }

        if (zoneBehavior.mapZoneType == MapZoneType.Viking)
        {
            if (string.IsNullOrEmpty(characterInventory.GetSummonViking()) == false)
            {
                if (UIManager.instance != null)
                    UIManager.instance.OnEnterVikingVillage();
            }
        }
    }

    protected override void OnTriggerExit2D(Collider2D collision)
    {
        base.OnTriggerExit2D(collision);
        if (isServer)
        {

        }
        else
        {
            MapItemBehavior target = collision.GetComponent<MapItemBehavior>();
            if (target != null)
            {
                if (target.MapItemType == MapItemType.Chest)
                {
                    if (isLocalPlayer && GetCharacterState() == CharacterState.OpenChest)
                    {
                        SetCharacterState(CharacterState.Idle);
                    }
                }
            }

            if (isLocalPlayer)
            {
                //Enable button summon viking
                ZoneBehavior zoneBehavior = collision.GetComponent<ZoneBehavior>();

                if (zoneBehavior != null && zoneBehavior.mapZoneType == MapZoneType.Viking)
                {
                    if (UIManager.instance != null)
                        UIManager.instance.DisableNpcButton();
                }
            }
        }
    }

    #region Client Server Action

    //----------------------------------------------------------------
    // Request Get Server Time
    //----------------------------------------------------------------

    [Client]
    public void RequestGetServerTime()
    {
        if (!NetworkClient.isConnected)
            return;

        CmdGetServerTime();
    }

    [Command]
    public void CmdGetServerTime()
    {
        RpcGetServerTimeCallback(this.connectionToClient, DataUtils.TimeToString(System.DateTime.Now));
    }

    [TargetRpc]
    public void RpcGetServerTimeCallback(NetworkConnectionToClient networkConnectionToClient, string serverTime)
    {
        BattleManager.instance.CalculateOffsetTime(serverTime);
    }

    [Client]
    public void RequestGetServerOffsetTime()
    {
        if (!NetworkClient.isConnected)
            return;

        BattleManager.instance.isServerOffsetTimeSynced = false;
        CmdGetServerOffsetTime();
    }

    [Command]
    private void CmdGetServerOffsetTime()
    {
        RpcGetServerOffsetTime(connectionToClient, BattleManager.instance.serverOffsetTime);
    }

    [TargetRpc]
    private void RpcGetServerOffsetTime(NetworkConnectionToClient networkConnectionToClient, int serverOffsetTime)
    {
        BattleManager.instance.serverOffsetTime = serverOffsetTime;
        BattleManager.instance.isServerOffsetTimeSynced = true;
#if ENABLE_ADMIN
        AdminManager.instance?.OnCompleteGetServerOffsetTime(serverOffsetTime);
#endif
#if ENABLE_CLIENT && !ENABLE_ADMIN
        if (EventManager.instance != null && EventManager.instance.HaveLocalData)
        {
            UIManager.instance?.FindView<LeaderboardV2View>()?.LeaderboardInit();
            UIManager.instance?.FindView<SeasonProgressView>()?.CreateSeasonGameEventData(EventManager.instance.GetLocalGameEvent());
        }
#endif
    }
    //----------------------------------------------------------------
    // Request Suspect Account
    //----------------------------------------------------------------

    //#if ENABLE_DIRECT_PAYMENT
    public void RequestCheckClient(int apiToken, HashBuild hashBuild, int buildId)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdCheckClient(apiToken, hashBuild, buildId);
    }

    [TargetRpc]
    public void RpcCheckClient(NetworkConnectionToClient networkConnectionToClient)
    {
        ClientManager.instance.CheckClient();
    }

    [Command]
    void CmdCheckClient(int apiToken, HashBuild hashBuild, int buildId)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdCheckClient)))
            return;

        if (hashBuild != null && hashBuild.hashFiles.Count > 0)
        {
            isVerifiedMod = true;
            bool checkHashBuild = true;
            AccountInfo accountInfo = BattleManager.instance.GetAccountInfo(this.userName);
            if (accountInfo != null)
            {
                foreach (HashFile clientHashFile in hashBuild.hashFiles)
                {

                    bool isServerMissingFile = true;
                    List<HashFile> serverHashFiles = BattleManager.instance.GetHashFiles(buildId, clientHashFile.key);

                    if (serverHashFiles != null && serverHashFiles.Count > 0)
                    {
                        foreach (HashFile serverHashFile in serverHashFiles)
                        {
                            if (serverHashFile.key == clientHashFile.key)
                            {
                                isServerMissingFile = false;
                                if (serverHashFile.value != clientHashFile.value)
                                {
                                    if (serverHashFile.key.Contains("classes2.dex") || serverHashFile.key.Contains("classes3.dex"))
                                    {
                                        Log(LogAction.ModDetected,
                                            $"Reason:HashMismatch|File:{clientHashFile.key}|ClientHash:{clientHashFile.value}|ServerHash:{serverHashFile.value}|BuildID:{buildId}");
                                        //checkHashBuild = false;
                                        //isVerifiedMod = false;

                                    }
                                }
                                else
                                {
                                    //BattleManager.Log(GameLogType.Info,"Correct ClientHash " + clientHashFile.key + "|ClientHash:" + clientHashFile.value + "|BuildID:" + buildId);
                                }
                            }
                        }
                    }
                    else
                        isServerMissingFile = false;


                    if (isServerMissingFile)
                    {
                        //isVerifiedMod = false;
                        Log(LogAction.SuspiciousActivity,
                            $"Action:VerifyHash|Result:ServerMismatch|ClientHash:{clientHashFile.key}:{clientHashFile.value}|BuildId:{buildId}");
                    }

                }

                List<HashFile> allServerHashFiles = BattleManager.instance.GetHashFiles(buildId);

                if (allServerHashFiles != null && allServerHashFiles.Count > 0)
                {
                    foreach (HashFile serverHashFile in allServerHashFiles)
                    {
                        bool isClientMissingFile = true;
                        foreach (HashFile clientHashFile in hashBuild.hashFiles)
                        {
                            if (serverHashFile.key == clientHashFile.key)
                            {
                                isClientMissingFile = false;
                                break;
                            }
                        }

                        if (isClientMissingFile)
                        {
                            //isVerifiedMod = false;
                            Log(LogAction.SuspiciousActivity,
                                $"Action:VerifyHash|Result:ClientMismatch|ServerHash:{serverHashFile.key}:{serverHashFile.value}|BuildId:{buildId}");
                            //break;
                        }
                    }
                }


                /*
                if (checkHashBuild)
                {
                    BattleManager.Log(GameLogType.Debug, this.userName + " all hash build is correct with buildID " + buildId);
                }
                else
                    Log(LogAction.ModDetected, $"Reason:HashIncorrect|BuildID:{buildId}");
                */
            }
        }

        //isVerifiedMod = false;
#endif
    }

    //#endif


    //----------------------------------------------------------------
    // Request Suspect Account
    //----------------------------------------------------------------
    public void RequestSendIOSBuildHash(int apiToken, string version, int buildId, string hash)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdSendIOSBuildHash(apiToken, version, buildId, hash);
    }

    [Command]
    void CmdSendIOSBuildHash(int apiToken, string version, int buildId, string hash)
    {
#if ENABLE_SERVER

        /*
        if (!ServerValidateApiToken(apiToken, nameof(CmdSendIOSBuildHash)))
            return;

        
        string serverHash = DataUtils.Md5Sum("Mega" + version + buildId);

        if (serverHash == hash)
        {
            isVerifiedMod = true;
            BattleManager.Log(GameLogType.Suspect, this.userName + " IOS verify ok " + version + " buildID " + buildId);
        }
        else
        {
            isVerifiedMod = false;
            BattleManager.Log(GameLogType.Suspect, this.userName + " IOS verify fail " + version + " buildID " + buildId);
        }*/

#endif
    }


    //----------------------------------------------------------------
    // Request Mod
    //----------------------------------------------------------------
    public void RequestSendMod(string type, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdSendMod(type, apiToken);
    }

    [Command]
    void CmdSendMod(string type, int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdSendMod)))
            return;

        if (type != "Mod")
        {
            //this.isVerifiedMod = false;
            Log(LogAction.ModDetected, $"Type:{type}");
        }
#endif
    }

    //----------------------------------------------------------------
    //Change character name
    //----------------------------------------------------------------
    [Client]
    public void RequestChangeName(string newName, string regionId, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdChangeName(newName, regionId, apiToken);
    }

    [Command]
    public void CmdChangeName(string newName, string regionId, int apiToken)
    {
#if ENABLE_SERVER


        if (string.IsNullOrEmpty(newName) || characterName == newName)
        {
            return;
        }

        var nameRegion = newName + "_" + regionId;
        if (characterName == nameRegion)
        {
            return;
        }

        if (IsPlayernameExist(newName))
        {
            RpcChangePlayernameCallback(this.connectionToClient, false, "");
            return;
        }

        if (!ServerValidateApiToken(apiToken, nameof(CmdChangeName)))
            return;

        CurrencyData cost = new() { currencyId = GameConst.DIAMOND_ID, value = GetChangeNameCost() };

        if (HaveEnoughMoney(cost) || characterName == userName)
        {
            if (characterName != userName)
                PayCost(cost);
            characterInventory.changeNameNumber++;

            Log(LogAction.ChangeName, $"Old:{characterName}|New:{newName}");
            characterName = newName;

            // Leaderboard is now managed by database system
            // No need to manually reset

            BattleManager.instance.SavePlayerData(this);
            RpcChangePlayernameCallback(this.connectionToClient, true, characterName);
        }
#endif
    }

    public int GetChangeNameCost()
    {
        return BattleManager.instance.gameDataConfig.costChangeName * characterInventory.changeNameNumber * characterInventory.changeNameNumber;
    }

    [TargetRpc]
    public void RpcChangePlayernameCallback(NetworkConnectionToClient networkConnectionToClient, bool success, string targetPlayername)
    {
        if (UIManager.instance == null)
            return;

        if (success)
        {
            IngameNotifyManager.instance.OnToastView(UIManager.GetDialog(215));
            UIManager.instance.FindView<ChangeNameView>(UIManager.CHANGE_NAME_VIEW).Close();
            UIManager.instance.FindView<ChangeNameView>(UIManager.FORCE_CHANGE_NAME_VIEW).Close();

        }
        else
        {
            IngameNotifyManager.instance.Notify(216);
        }
    }

    private bool IsPlayernameExist(string characterName)
    {
        return AdapterStorage.singleton.CharacterExists(characterName);
    }

    //----------------------------------------------------------------
    //Load Character Data
    //----------------------------------------------------------------

    [Client]
    public void RequestLoadCharacterData(
        string userName,
        string passwordHash,
        string version,
        string platform,
        string ip,
        string deviceId,
        int buildID)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdLoadCharacterData(userName, passwordHash, version, platform, ip, deviceId, buildID);
    }

    [Command]
    public void CmdLoadCharacterData(
        string userName,
        string passwordHash,
        string version,
        string platform,
        string ip,
        string deviceId,
        int buildID)
    {
#if ENABLE_SERVER

        if (userName == "")
        {
            BattleManager.Log(GameLogType.Warning,
                $"[CmdLoadCharacterData] Reject load: empty username. ConnId={connectionToClient?.connectionId}");
            return;
        }

        string requestedUserName = userName;
        if (BattleManager.instance.networkManagerMMO != null
            && connectionToClient != null
            && BattleManager.instance.networkManagerMMO.onlinePlayers.TryGetValue(connectionToClient, out string authenticatedUserName)
            && !string.IsNullOrEmpty(authenticatedUserName))
        {
            userName = authenticatedUserName;
            if (requestedUserName != authenticatedUserName)
            {
                BattleManager.Log(GameLogType.Warning,
                    $"[CmdLoadCharacterData] Client username '{requestedUserName}' replaced by authenticated account '{authenticatedUserName}'. ConnId={connectionToClient.connectionId}");
            }
        }
        else
        {
            BattleManager.Log(GameLogType.Warning,
                $"[CmdLoadCharacterData] Reject load: authenticated account not found. Requested={requestedUserName}, ConnId={connectionToClient?.connectionId}");
            return;
        }

        AccountInfo accountInfo = BattleManager.instance.GetAccountInfo(userName);

        if (accountInfo == null)
        {
            BattleManager.Log(GameLogType.Warning,
                $"[CmdLoadCharacterData] Reject load: account info not found. User={userName}, Requested={requestedUserName}, ConnId={connectionToClient?.connectionId}");
            return;
        }

        if (accountInfo.banned)
        {
            BattleManager.Log(GameLogType.Warning,
                $"[CmdLoadCharacterData] Reject load: account banned. User={userName}, ConnId={connectionToClient?.connectionId}");
            return;
        }

        if (accountInfo.password != passwordHash)
        {
            BattleManager.Log(GameLogType.Warning,
                $"[CmdLoadCharacterData] Reject load: password mismatch. User={userName}, ConnId={connectionToClient?.connectionId}");
            return;
        }
        CharacterData characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData == null)
            characterData = BattleManager.instance.CreateCharacterData(userName);

        if (characterData == null)
        {
            BattleManager.Log(GameLogType.Error,
                $"[CmdLoadCharacterData] Reject load: character data unavailable. User={userName}, ConnId={connectionToClient?.connectionId}");
            return;
        }

        if (!PlayerSessionService.TryRegisterOnlinePlayer(this, userName, out PlayerBehavior existingPlayerBehavior))
        {
            if (existingPlayerBehavior == this)
            {
                BattleManager.Log(GameLogType.Warning,
                    $"[CmdLoadCharacterData] Duplicate self-call ignored for {userName}. ConnId={connectionToClient?.connectionId}");
                return;
            }

            BattleManager.Log(GameLogType.Error,
                $"[CmdLoadCharacterData] Rejecting duplicate load for {userName}. ExistingConnId={existingPlayerBehavior?.connectionToClient?.connectionId}, NewConnId={connectionToClient?.connectionId}");
            PlayerSessionService.RejectNewDuplicateSession(this);
            return;
        }

        characterData.isOnline = true;

        // A friend removed while this character lived on another server leaves a one-way entry; drop it before the list is sent.
        ServerFriendManager.ReconcileOneWayFriends(characterData, FriendReconcileSource.Login);

        EnsureApiTokenInitialized();

        if (characterData.characterType == CharacterType.Player)
        {
            BattleManager.FixQuest(characterData);
        }

        LogicLoadCharacterData(characterData, false);

        if (characterData.killMobNumber > 10000)
            isProtected = false;

        this.version = accountInfo.version;
        this.platform = accountInfo.platform;
        this.password = accountInfo.password;
        this.isBanned = accountInfo.banned;
        //BattleManager.Log(GameLogType.Info, userName + " Platform " + this.platform + " version " + this.version + " ip " + ip + " device " + deviceId);


        List<string> removes = new List<string>();
        foreach (var e in characterInventory.equipments)
        {
            if (e.Value != null && e.Value.equipmentType == EquipmentType.Key)
            {
                RemoveKeyIfAlreadyTimeOut(removes, e);
            }
        }

        foreach (string id in removes)
        {
            characterInventory.RemoveEquipment(id);
        }

        removes.Clear();

        characterData.lastLogin = DataUtils.TimeToString(System.DateTime.Now);

        // Sync leaderboard rewards xuống client khi load character data
        // Đảm bảo client có đầy đủ thông tin về rewards ngay khi login
        SyncAllLeaderboardRewardsToClient();



        //Teleport after RpcLoadCharacter (temp solution)
        var beginnerQuest = characterData.beginnerQuestData;
        bool isCompleteBeginnerQuest = BattleManager.IsCompleteBeginnerQuest(beginnerQuest);

        bool isDoingBeginnerQuest = beginnerQuest != null &&
                                    beginnerQuest.questId != -1 &&
                                    beginnerQuest.questState == QuestState.Inprogress;


        bool isDoingCyclicQuest = characterData.questData != null &&
                                  characterData.questData.questId != -1;

        var teleported = false;

        // Nếu chưa complete beginner quest và cũng chưa có cyclic quest
        if (!isCompleteBeginnerQuest && !isDoingCyclicQuest)
        {
            if (landId != WorldManager.BEGINNER_LAND_NAME)
            {
                // Login teleport: disable automation (keepAutoMode = false, mặc định)
                teleported = TeleportToLand(WorldManager.BEGINNER_LAND_NAME);
                BattleManager.Log(GameLogType.Warning, userName + " force move to beginner land (new account, no beginner/cyclic progress)");
            }
        }

        // Recreate missing tutorial data for a player still in Beginner Land.
        if (beginnerQuest == null || beginnerQuest.questId == -1)
        {
            if (landId == WorldManager.BEGINNER_LAND_NAME)
            {
                QuestFactory questFactory = new QuestFactory();
                characterData.beginnerQuestData = questFactory.CreateBeginnerQuest(characterData);
                BattleManager.Log(GameLogType.Warning, userName + " was create new tutorial quest data");
            }
        }

        //Nếu đang có quest beginner mà ở center thì bắt về lại beginner
        if (isDoingBeginnerQuest)
        {
            if (landId == WorldManager.CENTER_LAND_NAME)
            {
                // Login teleport: disable automation (keepAutoMode = false, mặc định)
                teleported = TeleportToLand(WorldManager.BEGINNER_LAND_NAME);
                BattleManager.Log(GameLogType.Warning, userName + " force move to beginner land ");

                var maxBeginnerLevel = DataHolder.Instance().GetData<Quest>(BEGINNER_QUEST_ENTRY).levels.Count;
                if (beginnerQuest.totalStep < maxBeginnerLevel)
                {
                    LogicConvertBeginnerQuest(characterData, characterData.beginnerQuestData);
                }
            }

        }
        else if (isDoingCyclicQuest)
        {
            if (landId == WorldManager.BEGINNER_LAND_NAME)
            {
                // Login teleport: disable automation (keepAutoMode = false, mặc định)
                teleported = TeleportToLand(WorldManager.CENTER_LAND_NAME);
                BattleManager.Log(GameLogType.Warning, userName + " force move to center land ");
            }
        }

        // Player was saved in an event land (War/Survival/Undead) whose event is no longer running (for example it was offline when the event ended): send them back to Center Land.
        if (!teleported && leaveClosedEventLandOnLogin)
        {
            leaveClosedEventLandOnLogin = false;
            teleported = TeleportToLand(WorldManager.CENTER_LAND_NAME, keepAutoMode: true);
            if (teleported)
            {
                Log(LogAction.ChangeLand, "To:CenterLand (event land closed)");
                if (connectionToClient != null) RpctTeleportToCenterLand(connectionToClient);
            }
        }

        if (!teleported)
        {
            teleported = landId == WorldManager.MAZE_LAND_NAME && !BotDetectManager.IsCaptured(userName) ? false : //Teleport to center if in maze land but not lock there
                               (characterData.health == 0 && characterType == CharacterType.Player) ? //Teleport to center if dead
                               TeleportInCurrent() : TeleportInCurrent(new Vector2(characterData.posX, characterData.posY), true, keepAutoMode: true);

            if (!teleported)
            {
                TeleportToLand(WorldManager.CENTER_LAND_NAME, keepAutoMode: true);
            }
            else if (landId == WorldManager.MAZE_LAND_NAME) //Is Teleported to MazeLand
            {
                BotDetectManager.OnCaptureReconnect(this);
            }
        }


        if (GetArenaId() != -1)
        {
            if (NewArenaManager_Server.TryGetArena(GetArenaId(), out NewArena arena))
            {
                if (arena.IsRegistered(userName, out _, out _))
                {
                    TargetOnNewArenaReconnect(GetArenaId());
                }
                else
                {
                    BattleManager.Log(GameLogType.Warning, $"Username want to reconnect to {GetArenaId()} but arena don't have this player resigter" +
                                                           $" This likely won't happen since we had corrected data in LogicLoad");
                }
            }
            else
            {
                BattleManager.Log(GameLogType.Warning, $"Username want to reconnect to {GetArenaId()} but can't find arena's instance." +
                    $" This likely won't happen since we had corrected data in LogicLoad");
            }
        }

        // Send the initial snapshot only after all login teleports have completed.
        // The client uses this position to initialize the body/camera/map atomically.
        RpcLoadCharacterData(
            this.connectionToClient,
            createdDate,
            GetLandType(),
            new Vector2(transform.position.x, transform.position.y),
            claimedSocialRewards.ToArray());

        //BattleManager.Log(GameLogType.UserTracking, userName + " - " + characterName + " Initialized " + characterData.posX + " " + characterData.posY);
        isDataInitialized = true;
        isInitialized = true;
        isActive = true;
        PlayerSessionService.CompleteNetworkVisibility(this);
#endif
    }
    private void RemoveKeyIfAlreadyTimeOut(List<string> removes, KeyValuePair<string, Equipment> e)
    {
#if ENABLE_SERVER
        if (e.Value.itemId != DIAMOND_KEY_ID && e.Value.itemId != UNDEAD_KEY_ID) return;

        var landId = e.Value.itemId == DIAMOND_KEY_ID ? WorldManager.CENTER_LAND_NAME : WorldManager.UNDEAD_LAND_NAME;

        var keyBehavior = ChestKeyManager.Instance.GetKey(landId);

        if (keyBehavior == null || keyBehavior.ownerId != userName)
        {
            removes.Add(e.Value.id);
        }
        else
        {
            keyBehavior.owner = this;
        }
#endif
    }
    // Set while loading a character who was left in an event land after its event ended; consumed by the login teleport.
    private bool leaveClosedEventLandOnLogin;

    /// <summary>War/Survival lands are open only while their NewArena is running; Undead land only during the PkIsland event. Other lands are always open.</summary>
    private static bool IsEventLandOpen(string landName)
    {
#if ENABLE_SERVER
        if (landName == WorldManager.WAR_LAND_NAME) return IsNewArenaOpen(GameConst.ARENA_TEAM_BATTLE);
        if (landName == WorldManager.SURVIVAL_LAND_NAME) return IsNewArenaOpen(GameConst.ARENA_SURVIVAL);
        if (landName == WorldManager.UNDEAD_LAND_NAME) return BattleManager.instance.GetEventRunning(GameEventId.PkIsland);
#endif
        return true;
    }

    private static bool IsNewArenaOpen(int arenaId)
    {
#if ENABLE_SERVER
        return NewArenaManager_Server.TryGetArena(arenaId, out var arena) && arena.CurrentPhase != ArenaPhase.Closing;
#else
        return true;
#endif
    }

    public void LogicLoadCharacterData(CharacterData characterData, bool isNew)
    {
#if ENABLE_SERVER

        userName = characterData.id;
        characterName = characterData.characterName;
        memberRole = characterData.memberRole;
        characterRole = characterData.characterRole;
        characterType = characterData.characterType;
        isHaveLoginSeasonPass = characterData.isVip;
        SetChestNumber(characterData.chestNumber);
        SetProgress(characterData.progress);
        SetUndeadChestNumber(characterData.seasonUndeadChestNumber);
        SetCenterLandChestNumber(characterData.seasonCenterLaneChestNumber);
        SetTeamBattleScore(characterData.seasonTeamBattleScore);
        protectionTime = characterData.protectionTime;
        preparationSafeTime = characterData.preparationSafeTime;
        SetKillMobNumber(characterData.killMobNumber);
        SetKillBossNumber(characterData.killBossNumber);
        SetKillMobFireCraftNumber(characterData.mobfireCraftPoint);
        SetKillPlayerNumber(characterData.killPlayerNumber);
        SetCraftNumber(characterData.craftNumber);
        SetTeamId(characterData.teamId);
        clanId = characterData.clanId;
        SetClanScore(characterData.clanScore);
        SetTrophy(characterData.trophy);
        SetArenaId(characterData.arenaId);
        jailId = characterData.jailId;
        jailTime = characterData.jailTime;
        SetLeaveClanTime(characterData.leaveClanTime);
        mobId = characterData.cardId;
        characterInventory.adSkipNumber = characterData.adSkipNumber;
        seasonTimePlay = characterData.totalPlayerTime;
        totalTimePlay = characterData.totalTimePlay + characterData.totalPlayerTime;
        delayHealTime = characterData.delayHealTime;
        createdDate = characterData.lastUpdate;
        characterInventory.nextTimeUseSkill = characterData.nextTimeUseSkill;
        characterInventory.changeNameNumber = characterData.changeNameNumber;
        characterInventory.walletPassCode = characterData.walletPassCode;
        arenaWinner = false;
        arenaCount = characterData.arenaCount;
        clanArenaCount = characterData.clanArenaCount;
        seasonIAPValue = characterData.seasonIAPValue;
        seasonTHShop = characterData.seasonTHShop;
        claimedSocialRewards = characterData.claimedSocialRewards != null
            ? new List<string>(characterData.claimedSocialRewards)
            : new List<string>();
        currentServer = characterData.currentServer;
        SetTeamBattleArenaCount(characterData.teamBattleArenaCount);
        SetKillPlayerInTeamBattle(characterData.killPlayerInTeamBattle);
        if (this.characterType == CharacterType.Building)
            this.delayHealTime = characterData.timeCheckReviveClanVillage;

        var land = WorldManager.Instance.GetLandData(new Vector2(characterData.posX, characterData.posY).ToVector2Int());
        this.SetLandType(land == null ? LandType.CenterLand : land.GetLandType());

        this.landId = characterData.landId;
        this.lockAreaId = characterData.lockAreaId;
        //Correct landId
        this.landId = !landId.IsNullOrEmpty() ? landId :
                                                land == null ? WorldManager.CENTER_LAND_NAME : land.landName;

        this.boxSuggestions = characterData.boxSuggestions;
        this.lastTimeOTP = string.Empty;

        lastBlockId = Vector2Int.zero;

        if (characterType == CharacterType.Player)
        {
            characterData.UpdateVipReward();
            LogicLoadPlayerAutomation(characterData);

            if (BattleManager.IsFinalWar) BattleManager.instance.RestoreFinalWarItems(characterData);
            if (BattleManager.IsTournament)
            {
                var walletData = BattleManager.instance.GetWalletData(userName);
                int itemCount = BattleManager.instance.RestoreItemForCharacter(walletData, userName);
                if (itemCount > 0)
                {
                    BattleManager.instance.SaveWalletData(walletData);
                }    
            }    
        }

        SetTodayHitMapNumber(characterData,true);
        SetMirraPurchase(characterData);
        SetClanPurchasePet(characterData);
        SetAnbePurchase(characterData);
        SetMergeNumber(characterData);
        outOfCombatTime = 0;
        SetGold(characterData.gold);
        characterInventory.diamond = characterData.diamond;
        characterInventory.shard = characterData.shard;
        characterInventory.arenaCoin = characterData.arenaCoin;
        characterInventory.SetPlayerArena(characterData.playerArena);
        characterInventory.SetSkinExchange(characterData.skinExchange);
        characterInventory.SetRexFang(characterData.rexFang);
        characterInventory.SetBonusV3TransferTicket(characterData.bonusV3TransferTicket);
        characterInventory.SetNumberRollSKinCosmeticToday(characterData.numberRollSkinCosmeticToday);
        cosmeticSkinRollInfo.CopyFrom(characterData.cosmeticSkinRollInfo);
        characterInventory.SetAnnouncement(characterData.announcement);
        characterInventory.SetClanCoin(characterData.clanCoin);
        characterInventory.SetAutomationTile(characterData.automationTile);

        if (characterType == CharacterType.Player)
        {
            //Load data
            characterInventory.SetReviveClan(characterData.reviveClan);
            timeCheckReviveClanVillage = characterData.timeCheckReviveClanVillage;
            lastTimeAddReviveClanVillage = characterData.lastTimeAddReviveClanVillage;

            //Default
            if (string.IsNullOrEmpty(lastTimeAddReviveClanVillage))
            {
                lastTimeAddReviveClanVillage = DataUtils.TimeToString(System.DateTime.Now);
            }

            //Calculate revive regen
            CheckReviveClan(false);

            SyncSkinSet();
        }

        characterHealth.value = characterData.health;

        if (characterType == CharacterType.Building && characterHealth.value <= 0)
        {
            SetCharacterState(CharacterState.Dead);
        }

        characterEquipments.ResetEquipment();
        if (characterEquipments.collectionsIds != null)
        {
            characterEquipments.collectionsIds.Clear();
        }
        characterInventory.ResetEquipment();
        characterIngredient.ResetEquipment();

        if (characterCollection != null)
            characterCollection.ResetEquipment();
        if (characterTitleEquipment != null)
            characterTitleEquipment.ResetEquipment();

        if (characterEffects)
        {
            characterEffects.ResetEffects();
        }
        if (characterBuffs)
        {
            characterBuffs.ResetBuffs();
        }

        if (characterType == CharacterType.Player)
        {
            LogicLoadSkinSets(characterData);
            LogicLoadEquipmentSets(characterData);

            // CharacterItems is keyed by equipment id, so it does not prevent multiple
            // equipped items from sharing the same EquipmentType. Normalize corrupted
            // persisted data before loading it into characterEquipments.
            NormalizeDuplicateEquippedTypesOnLoad(characterData);
        }

        if (IsType(CharacterType.Player))
        {
            var log = userName + " remove tournament equipment in character equipment. ID: ";
            BattleManager.instance.RemoveEquipmentTournament(characterData.equipments, log);
        }

        // Load non-skin equipments từ characterData.equipments
        foreach (Equipment equipment in characterData.equipments)
        {   
            // Skip skin vì skin sẽ được load từ skinSets
            if (equipment.IsSkin())
            {
                continue;
            }
            characterEquipments.LoadEquipmentFromData(equipment);
        }

        // Load skins từ active skin set (sử dụng local fields)
        var activeSkinSet = GetActiveSkinSetData();
        foreach (Equipment skin in activeSkinSet)
        {
            if (skin != null)
            {
                characterEquipments.LoadEquipmentFromData(skin);
            }
        }

        if (IsType(CharacterType.Player))
        {
            var log = userName + " remove tournament equipment in inventory. ID: ";
            BattleManager.instance.RemoveEquipmentTournament(characterData.inventory, log);
        }

        if (characterType == CharacterType.Player)
        {
            inventoryMail.Clear();

            foreach (Equipment e in characterData.inventory)
            {
                characterInventory.LoadEquipmentFromData(e);
            }

            // Temporarily disabled overflow mail split. Keep extra inventory items in the bag so
            // they remain counted and can surface after visible items are removed.
            // for (int i = 0; i < characterData.inventory.Count; i++)
            // {
            //     Equipment e = characterData.inventory[i];
            //
            //     if (i < 16)
            //     {
            //         characterInventory.LoadEquipmentFromData(e);
            //     }
            //     else
            //     {
            //         inventoryMail.Add(characterData.inventory[i]);
            //     }
            // }
        }
        else
        {
            foreach (Equipment e in characterData.inventory)
            {
                characterInventory.LoadEquipmentFromData(e);
            }
        }


        if (IsType(CharacterType.Player))
        {
            var log = userName + " remove tournament equipment in ingredients. ID: ";
            BattleManager.instance.RemoveEquipmentTournament(characterData.ingredients, log);
        }

        if (characterType == CharacterType.Player)
        {
            ingredientMail.Clear();

            foreach (Equipment e in characterData.ingredients)
            {
                characterIngredient.LoadEquipmentFromData(e);
            }

            // Temporarily disabled overflow mail split. Keep extra ingredients in the bag so
            // they remain counted and can surface after visible ingredients are removed.
            // for (int i = 0; i < characterData.ingredients.Count; i++)
            // {
            //     Equipment e = characterData.ingredients[i];
            //
            //     if (i < 40)
            //     {
            //         characterIngredient.LoadEquipmentFromData(characterData.ingredients[i]);
            //     }
            //     else
            //     {
            //         ingredientMail.Add(characterData.ingredients[i]);
            //     }
            // }
        }
        else
        {
            foreach (Equipment e in characterData.ingredients)
            {
                characterIngredient.LoadEquipmentFromData(e);
            }
        }

        // Overflow mail is temporarily disabled while extra inventory/ingredient items stay in storage.
        // if (ingredientMail.Count > 0 || inventoryMail.Count > 0)
        // {
        //     BattleManager.instance.SendServerNotificationToTarget(connectionToClient, int.MaxValue, NotifyType.Notify,
        //     $"You have extra items {inventoryMail.Count} equipment and {ingredientMail.Count} ingredients. The items will be returned on your next login if your inventory has enough space.");
        // }


        if (characterCollection != null)
        {
            foreach (Equipment e in characterData.collections)
            {
                characterCollection.LoadEquipmentFromData(e);
            }

            //Log("load collection " + characterCollection.GetEquipmentCount());

        }

        if (characterTitleEquipment != null)
        {
            foreach (Equipment title in characterData.titleEquipment)
            {
                characterTitleEquipment.LoadEquipmentFromData(title);
            }

            //Log("load title " + characterTitleEquipment.GetEquipmentCount());

        }


        ///////////////////////////////////////////////////////////////////////////////////////////////

        if (characterEffects)
        {
            foreach (Effect effect in characterData.effects)
            {
                characterEffects.AddEffect(effect);
            }
            characterEffects.OnUpdateEffects();
        }

        if (characterBuffs)
        {
            foreach (Buff buff in characterData.buffs)
            {
                characterBuffs.AddBuff(buff);
            }
            characterBuffs.OnUpdateBuffs();
        }

        this.OnUpdateStats();

        if (isNew)
        {
            this.characterHealth.OnUpdateStats();
            this.characterHealth.value = (int)this.statData.GetStat(StatType.Health).GetValue();
        }

        //if (this.characterHealth.value > 0 && this.characterType == CharacterType.Building)
        //    this.delayHealTime = 3600;

        if (characterVisual != null)
            characterVisual.LoadEquipments();

        //Wallet
        if (characterWallet != null)
        {
            WalletData walletData = BattleManager.instance.GetWalletData(this.userName);
            if (walletData != null)
            {
                bool needSave = walletData.RemoveTournamentItem();
                characterWallet.LoadData(walletData);

                if (needSave)
                {
                    BattleManager.instance.SaveWalletData(walletData);
                }    
            }
        }

        if (GetArenaId() != -1)
        {
            if (NewArenaManager_Server.TryGetArena(GetArenaId(), out var newArenaBehavior))
            {
                //Handle reconnect to New Arena
                if (!newArenaBehavior.IsRegistered(userName, out _, out _))
                {
                    SetArenaId(-1);
                    SetTeamId(string.Empty);

                    var quitPosData = newArenaBehavior.QuitBattleTelePoint;
                    landId = quitPosData.landName;
                    lockAreaId = quitPosData.areaName;

                    characterData.posX = quitPosData.pos.x;
                    characterData.posY = quitPosData.pos.y;

                    BattleManager.Log(GameLogType.Warning,
                        $"[LoadCharacterData]: Player {userName} is not registered in Arena {newArenaBehavior.ArenaId} but has arenaId={GetArenaId()}. " +
                        $"Correct arena data and teleporting to quit position.");
                }
            }
            else
            {
                var arenaBehavior = EventManager.instance.GetArenaBehavior(GetArenaId());
                if (arenaBehavior == null || arenaBehavior.isActive == false || arenaBehavior.ServerGetSate() == ArenaState.DeActive ||
                    arenaBehavior.GetAreanaTeamData(userName) == null)
                {
                    SetArenaId(-1);
                    SetTeamId(string.Empty);
                }
            }
        }

        //Correct areaId
        if (lockAreaId.IsNullOrEmpty())
        {
            //If player is outside area and arena already start, teleport player inside area
            if (GetArenaId() != -1)
            {
                var foundArenaPossible = ArenaBehavior.FindAreaByArenaId(GetArenaId());
                if (foundArenaPossible.landId.IsNonEmpty()) //Found an arena
                {
                    //TODO-IMPORTANT: Check logic again, do we need to teleport player inside area yet ?
                }
            }
        }
        else
        {
            //This player areaId is not empty, so we find any Arena in this land has that areaId. (Only for old arena)
            //If this areaId is belong to an Arena, correct it            
            if (NewArenaManager_Server.IsInsideAnyArenaSpace(landId, lockAreaId, out var newArenaBehavior)) //Is inside New Arena's area
            {
                Debug.Log($"[LoadCharacterData]: Player {userName} is inside Arena space: Arena: {newArenaBehavior.ArenaId}, locked in {landId} - {lockAreaId}");
                if (!newArenaBehavior.IsRegistered(userName, out _, out _))
                {
                    var quitPosData = newArenaBehavior.QuitBattleTelePoint;
                    landId = quitPosData.landName;
                    lockAreaId = quitPosData.areaName;

                    characterData.posX = quitPosData.pos.x;
                    characterData.posY = quitPosData.pos.y;
                    Debug.Log($"[LoadCharacterData]: Player {userName} is inside wrong area - tele them to quit position");
                }
                else
                {
                    Debug.Log($"[LoadCharacterData]: Player {userName} is registered");
                }
            }
            else
            {
                var currentArenaId = GetArenaId();
                //Correct for old arena system
                var foundArenaIdFromArea = ArenaBehavior.FindArenaIdByAreaId(landId, lockAreaId);

                if (currentArenaId == -1) // player is NOT in any arena
                {
                    if (foundArenaIdFromArea != -1)
                    {
                        // areaId is connected to an Arena, correct it
                        Debug.Log($"[Correct areaId] Player {userName} had areaId={lockAreaId} (arena={foundArenaIdFromArea}) but not in any arena. Reset areaId.");
                        lockAreaId = string.Empty;
                    }
                    // else: areaId is not connected to any Arena (Jail/...) → giữ nguyên
                }
                else // player is in an arena
                {
                    if (foundArenaIdFromArea == currentArenaId)
                    {
                        Debug.Log($"[Correct areaId] Player {userName} areaId={lockAreaId} matches arenaId={currentArenaId}. No correction needed.");
                    }
                    else //Player is inside an area which is different from arena
                    {
                        //case areaId is empty is not happen here since first check is areaId.IsNullOrEmpty()
                        //So, should we correct areaId to match current arenaId?
                        //Maybe they are in Jail or something ? Check current areaId again ???
                        var (_, correctAreaId) = ArenaBehavior.FindAreaByArenaId(currentArenaId);
                        lockAreaId = correctAreaId;

                        Debug.Log($"[Correct areaId] Player {userName} had areaId={lockAreaId} but arenaId={currentArenaId}, correcting to {correctAreaId}." +
                                  $"Consider this reset since player can be in Jail or something ?");
                    }
                }
            }

        }

        leaveClosedEventLandOnLogin = false;
        if (characterType == CharacterType.Player && !IsEventLandOpen(landId))
        {
            leaveClosedEventLandOnLogin = true;
            SetArenaId(-1);
            SetTeamId(string.Empty);
            SetLandType(LandType.CenterLand);
            BattleManager.Log(GameLogType.Warning,
                $"[LoadCharacterData]: Player {userName} was saved in {landId} but its event is not running. Teleporting to {WorldManager.CENTER_LAND_NAME}.");
        }

        if (characterType == CharacterType.Player)
        {
            bool reset = ResetDailyCalculation();
            if (reset == false)
            {
                LogicLoadQuestData(characterData);
                //LogicLoadDailyReward(characterData);
            }

            lastTimeCheckQuestSuggestion = System.DateTime.Now;
            int vipLevel = characterData.GetVipLevel();
            RpcVipData(connectionToClient, characterData.playerDailyRewards, characterData.playerVipStats, vipLevel);

            BattleManager.instance.SaveCharacterData(characterData);

        }

        //Update Land Data cache runtime
        UpdateLandData(true);

        //Captcha
#if ENABLE_CAPTCHA
        if (characterType == CharacterType.Player)
        {
            totalCaptcha = characterData.totalCaptcha;
            totalWrongCaptcha = characterData.totalWrongCaptcha;
            currentWrongCaptcha = 0; //characterData.currentWrongCaptcha;
            totalCorrectCaptcha = characterData.totalCorrectCaptcha;
            newCaptchaTime = characterData.newCaptchaTime;
            SetTimeCaptcha();
        }
#endif

        if (BattleManager.instance.characterDataReset.ContainsKey(userName))
        {
            var cacheCharacterData = BattleManager.instance.characterDataReset[userName];

            List<Equipment> equipments = new();
            CurrencyData diamond = new() { currencyId = DIAMOND_ID };
            CurrencyData shard = new() { currencyId = SHARD_ID };

            var dataEquipment = cacheCharacterData.GetResetEquipment(cacheCharacterData.equipments);
            equipments.AddRange(dataEquipment.removes);
            diamond.value += dataEquipment.diamond;
            shard.value += dataEquipment.shard;

            dataEquipment = cacheCharacterData.GetResetEquipment(cacheCharacterData.inventory);
            equipments.AddRange(dataEquipment.removes);

            diamond.value += dataEquipment.diamond;
            shard.value += dataEquipment.shard;
            equipments.AddRange(cacheCharacterData.GetResetIngredient());

            if (BattleManager.instance.walletDataReset.ContainsKey(userName))
            {
                var wallet = BattleManager.instance.walletDataReset[userName];
                equipments.AddRange(wallet.GetIngredientResetable());
                equipments.AddRange(wallet.GetInventoryResetable());
            }
            if (characterData.characterType == CharacterType.Player)
            {
                bool haveFang = characterData.rexFang > 0 || characterData.legendFang > 0 || characterData.mythicFang > 0;
                RpcGetDataResetSeason(connectionToClient, haveFang, equipments, new List<CurrencyData>() { diamond, shard });
            }
        }

        void Log(string value, GameLogType gameLogType = GameLogType.UserTracking)
        {
            BattleManager.Log(gameLogType, userName + " " + value);
        }

#endif
    }

    /// <summary>
    /// Ensures a player cannot load more than one equipped item of the same EquipmentType.
    /// If a duplicated type is found, all items of that type are unequipped to inventory so
    /// the server does not make an arbitrary choice based on list ordering.
    /// </summary>
    private bool NormalizeDuplicateEquippedTypesOnLoad(CharacterData characterData)
    {
#if ENABLE_SERVER
        if (characterData == null || characterData.characterType != CharacterType.Player ||
            characterData.equipments == null)
        {
            return false;
        }

        characterData.inventory ??= new List<Equipment>();

        var duplicatedGroups = characterData.equipments
            .Where(equipment => equipment != null && equipment.equipmentType != EquipmentType.Emote)
            .GroupBy(equipment => equipment.equipmentType)
            .Where(group => group.Count() > 1)
            .Select(group => new
            {
                EquipmentType = group.Key,
                Equipments = group.ToList()
            })
            .ToList();

        if (duplicatedGroups.Count == 0)
        {
            return false;
        }

        var inventoryIds = new HashSet<string>(
            characterData.inventory
                .Where(equipment => equipment != null && !string.IsNullOrEmpty(equipment.id))
                .Select(equipment => equipment.id));

        foreach (var duplicatedGroup in duplicatedGroups)
        {
            string equipmentIds = string.Join(",", duplicatedGroup.Equipments.Select(equipment => equipment.id));
            string itemIds = string.Join(",", duplicatedGroup.Equipments.Select(equipment => equipment.itemId));
            string rareTypes = string.Join(",", duplicatedGroup.Equipments.Select(equipment => equipment.rareType));
            string states = string.Join(",", duplicatedGroup.Equipments.Select(equipment => equipment.state));

            string description =
                $"Action:NormalizeDuplicateEquippedType|Source:LogicLoadCharacterData|" +
                $"User:{characterData.id}|EquipmentType:{duplicatedGroup.EquipmentType}|" +
                $"DuplicateCount:{duplicatedGroup.Equipments.Count}|EquipmentIds:{equipmentIds}|" +
                $"ItemIds:{itemIds}|RareTypes:{rareTypes}|States:{states}|" +
                "Resolution:UnequipAllToInventory";

            BattleManager.Log(GameLogType.Warning, $"[DuplicateEquippedType] {description}");
            BattleManager.Log(characterData, LogAction.SuspiciousActivity, description);

            foreach (var equipment in duplicatedGroup.Equipments)
            {
                characterData.equipments.Remove(equipment);
                equipment.state = EquipmentState.Inventory;

                // A duplicate id across storages is a separate data-integrity issue. Keep
                // the existing inventory entry and avoid creating another copy of the id.
                if (!string.IsNullOrEmpty(equipment.id) && !inventoryIds.Add(equipment.id))
                {
                    BattleManager.Log(GameLogType.Warning,
                        $"[DuplicateEquipmentAcrossStorages] User:{characterData.id}|" +
                        $"EquipmentType:{equipment.equipmentType}|EquipmentId:{equipment.id}|" +
                        "SourceStorage:Character|TargetStorage:Inventory|Resolution:KeepExistingInventoryEntry");
                    continue;
                }

                characterData.inventory.Add(equipment);
            }
        }

        return true;
#else
        return false;
#endif
    }

    public void CheckReviveClan(bool save = true)
    {
#if ENABLE_SERVER
        var lastDead = DataUtils.StringToTime(lastTimeAddReviveClanVillage);
        var span = System.DateTime.Now - lastDead;
        int checkPerSecond = 180;

        if (span.TotalSeconds > checkPerSecond)
        {
            var value = Mathf.FloorToInt((float)span.TotalSeconds / checkPerSecond);

            characterInventory.AddReviveClan(value);

            if (characterInventory.GetReviveClan() > ServerGetMaxReviveClan())
            {
                characterInventory.SetReviveClan(ServerGetMaxReviveClan());
            }

            lastTimeAddReviveClanVillage = DataUtils.TimeToString(System.DateTime.Now);

            if (save)
            {
                BattleManager.instance.SavePlayerData(this);
            }
        }
#endif
    }

    public void SetTodayHitMapNumber(CharacterData characterData, bool isInit = false)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.syncTodayHitMapNumber = characterData.todayHitMapNumber;
        }
    }

    private void SetMirraPurchase(CharacterData characterData)
    {
#if ENABLE_SERVER
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.syncMirraPurchase = characterData.miraPurchaseNumber;
        }
#endif
    }

    private void SetClanPurchasePet(CharacterData characterData)
    {
#if ENABLE_SERVER
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.syncClanPurchasePet = characterData.clanPurchasePetNumber;
        }
#endif
    }

    private void SetAnbePurchase(CharacterData characterData)
    {
#if ENABLE_SERVER
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.syncAnbePurchase = characterData.anbePurchaseNumber;
        }
#endif
    }

    private void SetMergeNumber(CharacterData characterData)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.syncMergeNumber = characterData.mergeNumber;
        }
    }

    public void SetTeamBattleArenaCount(int number)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.syncTeamBattleArenaCount = number;
        }
    }

    public void AddTeamBattleArenaCount(int number)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.syncTeamBattleArenaCount += number;
        }
    }

    public int GetTeamBattleArenaCount()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.syncTeamBattleArenaCount;
        }
        return 0;
    }

    public void AddKillPlayerInTeamBattle(int number)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.syncKillPlayerInTeamBattle += number;
        }
    }

    public void SetKillPlayerInTeamBattle(int number)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.syncKillPlayerInTeamBattle = number;
        }
    }

    public int GetKillPlayerInTeamBattle()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.syncKillPlayerInTeamBattle;
        }

        return 0;
    }

    public void CalculateEquipmentScore()
    {
#if ENABLE_SERVER
        this.equipmentScore = 0;
        foreach (var e in this.characterEquipments.equipments)
        {
            if (e.Value.equipmentType == EquipmentType.Back || e.Value.equipmentType == EquipmentType.Weapons || e.Value.equipmentType == EquipmentType.Boot
                || e.Value.equipmentType == EquipmentType.Cloth || e.Value.equipmentType == EquipmentType.Helmet)
            {
                if (e.Value.rareType == RareType.Legendary)
                {
                    this.equipmentScore += 2;
                }
                else if (e.Value.rareType == RareType.Epic)
                    this.equipmentScore += 1;

                if (e.Value.madeBy != "")
                    this.equipmentScore += 5;
            }
        }
#endif
    }

    [TargetRpc]
    public void RpcLoadCharacterData(
        NetworkConnectionToClient playerConnection,
        string created,
        LandType landType,
        Vector2 initialPosition,
        string[] socialRewards)
    {
        // Use the authoritative login snapshot before creating the visual body.
        // NetworkTransform remains responsible for subsequent movement updates.
        transform.position = new Vector3(initialPosition.x, initialPosition.y, transform.position.z);

        isDataInitialized = true;
        this.createdDate = created;
        claimedSocialRewards = socialRewards != null ? socialRewards.ToList() : new List<string>();
        BattleManager.instance.isCharacterLoaded = true;
        ClientManager.instance.myLandType = landType;

        if (UIManager.instance != null)
            UIManager.instance.OnLocalPlayerLandTypeChange(landType);

        Initialize();
        ClientManager.instance.SetMyCharacter(this);
        if (isLocalPlayer)
            StartCoroutine(ApplyLocalVisualPrefsAfterLoad());
        //ClientFeatureManager.Instance.OnLoadFeatureDataRuntime(this.GetProgress());
        if (SoundManager.instance != null)
            SoundManager.instance.Initialize();

        ClientManager.instance.AddLoadingProgress("[Load Character Data Init]");

#if UNITY_ANDROID

#elif UNITY_IOS
                string clientVersion = ClientManager.instance.GetVersion();
                RequestSendIOSBuildHash(ClientManager.instance.GetApiToken(), clientVersion, BattleManager.instance.buildId, DataUtils.Md5Sum("Mega" + clientVersion + BattleManager.instance.buildId));
#endif




        MmoApiManager.GetInstance().SendEvent("StartPlay", "");
    }


    //----------------------------------------------------------------
    //Game data config
    //----------------------------------------------------------------
    [Client]
    public void RequestGetGameDataConfig(int apiToken)
    {
        CmdGetGameDataConfig(apiToken);
    }
    [Command]
    private void CmdGetGameDataConfig(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdGetGameDataConfig)))
        {
            SendGameDataConfigResponse();
            return;
        }

        SendGameDataConfigResponse();
#endif
    }

#if ENABLE_SERVER
    private void SendGameDataConfigResponse()
    {
        if (!NetSafe.CanTarget(this))
        {
            return;
        }

        var config = BattleManager.instance.gameDataConfig;
        var gameDataConfog = config == null ? "null" : config.ToClientJson();
        RpcGetGameDataConfig(connectionToClient, gameDataConfog);
    }
#endif

    [TargetRpc]
    private void RpcGetGameDataConfig(NetworkConnectionToClient networkConnectionToClient, string gameDataConfig)
    {
#if !ENABLE_ADMIN        
        var data = Newtonsoft.Json.JsonConvert.DeserializeObject<GameDataConfig>(gameDataConfig);
        BattleManager.instance.SetGameDataConfig(data);
#if ENABLE_CLIENT
        MarketFilterConfigReceived?.Invoke(data);
#endif
        ClientManager.instance.AddLoadingProgress("[Get Game data config Init]");
        MapManager.instance.InitSkinEvent(data.seasonEventType);
        UIManager.instance.OnGetGameDataConfig(data);
#endif        
    }


    //================= WORLD CONFIG ======================
    [Client]
    public void RequestWorldConfig()
    {
        CmdRequestWorldConfig();
        WorldManager.Instance.OnRequestWorldConfig();
    }
    [Command]
    private void CmdRequestWorldConfig()
    {
#if ENABLE_SERVER
        if (this.isBanned)
        {
            if (NetSafe.CanTarget(this))
                TargetReceiveWorldConfig(WorldManager.Instance.DefaultWorldConfig);
            return;
        }
        //TargetReceiveWorldConfig(JsonConvert.SerializeObject(WorldManager.Instance.DefaultWorldConfig, JsonConverters.SafeVectorSettings()));
        if (NetSafe.CanTarget(this))
            TargetReceiveWorldConfig(WorldManager.Instance.DefaultWorldConfig);
#endif
    }
    [TargetRpc]
    //private void TargetReceiveWorldConfig(string gameDataConfig)
    private void TargetReceiveWorldConfig(WorldConfig config)
    {
        //var data = JsonConvert.DeserializeObject<WorldConfig>(gameDataConfig, JsonConverters.SafeVectorSettings());
        WorldManager.Instance.ReceiveWorldConfig(config);

        ClientManager.instance.AddLoadingProgress("[World Map config Init]");
    }

    [Client]
    public void RequestTeleportToCenterLand(int apiToken)
    {
        if (!NetworkClient.isConnected) return;
        CmdTeleportToCenterLand(apiToken);
    }

    [Command]
    private void CmdTeleportToCenterLand(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdTeleportToCenterLand))) return;

        if (this.GetHealth() <= 0 || !IsStandingOn(RuntimeZoneType.Village)) return;

        var characterData = BattleManager.instance.GetCharacterData(userName);
        if (BattleManager.IsCompleteBeginnerQuest(characterData.beginnerQuestData) == false)
        {
            return;
        }

        // Teleport to CenterLand: disable automation (keepAutoMode = false, mặc định)
        TeleportToLand(WorldManager.CENTER_LAND_NAME);
        RpctTeleportToCenterLand(connectionToClient);

        //Thường sẽ lấy các thông tin này ở lần đầu login
        //Nhưng do user ở beginner bị chặn ko nhận được quest
        //Nên khi rời khỏi beginner thì cần update lại các quest này cho client
        LogicGetQuests(new QuestCategory[]
        {
            QuestCategory.DailyQuest, QuestCategory.DailyQuestPoint,
            QuestCategory.ContinuousLogin, QuestCategory.ContinuousLoginQuestPoint,
            QuestCategory.Achivement, QuestCategory.AchievementQuestPoint
        },
        characterData,
        isInit: false);
#endif
    }

    [TargetRpc]
    private void RpctTeleportToCenterLand(NetworkConnectionToClient conn)
    {
#if ENABLE_ANALYTIC_SERVICE
        AnalyticsManager.instance.TrackCenterLandReached();
#endif

        if (UIManager.instance == null) return;

        BattleManager.Log(GameLogType.Debug, "Teleport to CenterLand successfully!");
        UIManager.instance.OnLocalPlayerLandTypeChange(LandType.CenterLand);
    }

    [Client]
    public void RequestTeleportToUndeadLand(int apiToken, int posIndex)
    {
        CmdTeleportToUndeadLand(apiToken, posIndex);
    }

    [Command]
    private void CmdTeleportToUndeadLand(int apiToken, int posIndex)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdTeleportToUndeadLand)) || IsInJail()) return;

        if (this.GetHealth() <= 0 || !IsStandingOn(RuntimeZoneType.Village)) return;
        if (!IsInCenterLand()) return;

        if (!WorldManager.Instance.TryGetLandData(WorldManager.UNDEAD_LAND_NAME, out var landData))
        {
            BattleManager.Log(GameLogType.Error, userName + " try to teleport undead land but the land is not existed");
            return;
        }

        if (BattleManager.instance.GetEventRunning(GameEventId.PkIsland) == false)
        {
            var now = BattleManager.instance.ServerNow();
            var secondUntilNextEvent = BattleManager.instance.GetSecondsUntilPkIslandEvent(now);

            if (secondUntilNextEvent < 0)
            {
                RpcOnTeleportToUndeadLandFail(connectionToClient, -1);
                return;
            }

            RpcOnTeleportToUndeadLandFail(connectionToClient, secondUntilNextEvent);
            return;
        }

        var key = characterInventory.GetEquipment(EquipmentType.Key);
        if (key != null)
        {
            LogicSellItem(key);
        }

        Log(LogAction.ChangeLand, "To:UndeadLand");
        this.SetLandType(LandType.UndeadLand);

        //var mapConfig = BattleManager.instance.GetMapConfig(LandType.UndeadLand);

        //Debug.Log($"[TeleportToUndeadLand]: LandData {landData.landName} + {landData.LandCenter}");

        RpctTeleportToUndeadLand(connectionToClient);
        //SetTeamId(System.Guid.NewGuid().ToString());
        // Teleport to UndeadLand: disable automation (keepAutoMode = false, mặc định)
        TeleportToLand(WorldManager.UNDEAD_LAND_NAME);
        //ServerSetPosition(new Vector3(landData.LandCenter.x, landData.LandCenter.y));
#endif
    }

    [TargetRpc]
    private void RpctTeleportToUndeadLand(NetworkConnectionToClient networkConnectionToClient)
    {
        if (UIManager.instance == null)
            return;

        UIManager.instance.OnLocalPlayerLandTypeChange(LandType.UndeadLand);
    }

    [TargetRpc]
    private void RpcOnTeleportToUndeadLandFail(NetworkConnectionToClient conn, float nextTime)
    {
        if (UIManager.instance == null)
            return;

        if (nextTime < 0)
        {
            IngameNotifyManager.instance?.Notify(1325);
            UIManager.instance.FindView<TeleportUndeadView>().Close();
            return;
        }

        var dialog = UIManager.GetDialog(727);

        dialog += "\n" + UIManager.instance.GetTimeText(nextTime);

        // ✅ SERVER-ONLY: Add null check for IngameNotifyManager
        if (IngameNotifyManager.instance != null)
            IngameNotifyManager.instance.Notify(dialog);

        UIManager.instance.FindView<TeleportUndeadView>().Close();
    }

    [Client]
    public void RequestBackToCenterLand(int apiToken)
    {
        CmdBackToCenterLand(apiToken);
    }

    [Command]
    private void CmdBackToCenterLand(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdBackToCenterLand))) return;
        if (this.GetHealth() <= 0 || !IsStandingOn(RuntimeZoneType.Village)) return;
        if (this.IsInBeginnerLand()) return;

        var key = characterInventory.GetEquipment(EquipmentType.Key);
        if (key != null)
        {
            LogicSellItem(key);
        }

        Log(LogAction.ChangeLand, "To:CenterLand");
        this.SetLandType(LandType.CenterLand);

        //var mapConfig = BattleManager.instance.GetMapConfig(LandType.CenterLand);
        //var landData = WorldManager.Instance.GetLandData(WorldManager.CENTER_LAND_NAME);

        RpctTeleportToCenterLand(connectionToClient);
        SetTeamId(this.clanId);
        // Teleport back to CenterLand: disable automation (keepAutoMode = false, mặc định)
        TeleportToLand(WorldManager.CENTER_LAND_NAME);
        //ServerSetPosition(new Vector3(landData.LandCenter.x, landData.LandCenter.y));
#endif
    }


    //===================== TELEPORT TO WAR LAND ================
    [Client]
    public void RequestTeleportToWarLand(int apiToken, int posIndex)
    {
        CmdTeleportToWarLand(apiToken, posIndex);
    }

    [Command]
    private void CmdTeleportToWarLand(int apiToken, int posIndex)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdTeleportToWarLand)) || IsInJail()) return;

        if (this.GetHealth() <= 0 || !IsStandingOn(RuntimeZoneType.Village)) return;
        if (IsInBeginnerLand()) return;

        if (!WorldManager.Instance.TryGetLandData(WorldManager.WAR_LAND_NAME, out var landData))
        {
            BattleManager.Log(GameLogType.Error, userName + " try to teleport undead land but the land is not existed");
            return;
        }



        var key = characterInventory.GetEquipment(EquipmentType.Key);
        if (key != null)
        {
            LogicSellItem(key);
        }

        Log(LogAction.ChangeLand, "To:WarLand");
        this.SetLandType(LandType.WarLand);

        RpcTeleportToWarLand(connectionToClient);
        TeleportToLand(WorldManager.WAR_LAND_NAME);
#endif
    }

    [TargetRpc]
    private void RpcTeleportToWarLand(NetworkConnectionToClient networkConnectionToClient)
    {
        if (UIManager.instance == null) return;

        BattleManager.Log(GameLogType.Debug, "Teleport to WarLand successfully!");
        UIManager.instance.OnLocalPlayerLandTypeChange(LandType.WarLand);
    }


    [Client]
    public void RequestWarLandToCenterLand(int apiToken)
    {
        CmdWarLandToCenterLand(apiToken);
    }

    [Command]
    private void CmdWarLandToCenterLand(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdWarLandToCenterLand))) return;
        if (this.GetHealth() <= 0) return;

        // Only from the war land itself, and never as a way out of a captcha / the beginner land.
        if (!LandReturnRules.CanReturnToCenterLand(IsInWarLand(), BotDetectManager.IsCaptured(userName))) return;

        if (NewArenaManager_Server.TryGetArena(ARENA_TEAM_BATTLE, out var factionWarArena) &&
            factionWarArena != null &&
            factionWarArena.IsRegistered(userName, out _, out _))
        {
            BattleManager.instance.SendServerNotificationToTarget(
                connectionToClient, 1005, NotifyType.Notify);
            return;
        }
        var key = characterInventory.GetEquipment(EquipmentType.Key);
        if (key != null)
        {
            LogicSellItem(key);
        }

        Log(LogAction.ChangeLand, "To:CenterLand");
        this.SetLandType(LandType.CenterLand);

        SetTeamId(this.clanId);
        RpctTeleportToCenterLand(connectionToClient);
        TeleportToLand(WorldManager.CENTER_LAND_NAME);
#endif
    }
    //========================= WAR LAND END =========================

    //===================== TELEPORT TO SURVIVAL LAND ================
    [Client]
    public void RequestTeleportToSurvivalLand(int apiToken, int posIndex)
    {
        CmdTeleportToSurvivalLand(apiToken, posIndex);
    }

    [Command]
    private void CmdTeleportToSurvivalLand(int apiToken, int posIndex)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdTeleportToSurvivalLand)) || IsInJail()) return;

        if (BattleManager.instance.GetServerSeason() < 2)
        {
            if (UIManager.instance != null)
            {
                BattleManager.instance.gameLogicBehavior.SendNotification(this.connectionToClient, NotifyType.Notify, -1, UIManager.GetDialog(1189));
            }
            else
            {
                BattleManager.instance.gameLogicBehavior.SendNotification(this.connectionToClient, NotifyType.Notify, -1, "Server need to be 2 season old to unlock this mod");
            }
            return;
        }

        if (!IsInCenterLand()) return;
        if (this.GetHealth() <= 0 || !IsStandingOn(RuntimeZoneType.Village)) return;

        if (!WorldManager.Instance.TryGetLandData(WorldManager.SURVIVAL_LAND_NAME, out var landData))
        {
            BattleManager.Log(GameLogType.Error, userName + " try to teleport SurvivalLand but the land is not existed");
            return;
        }

        var key = characterInventory.GetEquipment(EquipmentType.Key);
        if (key != null)
        {
            LogicSellItem(key);
        }

        Log(LogAction.ChangeLand, "To:Survival");
        this.SetLandType(LandType.SurvivalLand);

        RpcTeleportToSurvivalLand(connectionToClient);
        TeleportToLand(WorldManager.SURVIVAL_LAND_NAME, "Waiting"); //Waiting is the areaId of SurvivalLand
#endif
    }

    [TargetRpc]
    private void RpcTeleportToSurvivalLand(NetworkConnectionToClient networkConnectionToClient)
    {
        if (UIManager.instance == null) return;

        BattleManager.Log(GameLogType.Debug, "Teleport to SurvivalLand successfully!");
        UIManager.instance.OnLocalPlayerLandTypeChange(LandType.SurvivalLand);
    }


    [Client]
    public void RequestSurvivalLandToCenterLand(int apiToken)
    {
        CmdSurvivalLandToCenterLand(apiToken);
    }

    [Command]
    private void CmdSurvivalLandToCenterLand(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdSurvivalLandToCenterLand))) return;
        if (this.GetHealth() <= 0) return;

        // Only from the survival land itself, and never as a way out of a captcha / the beginner land.
        if (!LandReturnRules.CanReturnToCenterLand(IsInSurvivalLand(), BotDetectManager.IsCaptured(userName))) return;

        var key = characterInventory.GetEquipment(EquipmentType.Key);
        if (key != null)
        {
            LogicSellItem(key);
        }

        Log(LogAction.ChangeLand, "To:CenterLand");
        this.SetLandType(LandType.CenterLand);

        RpctTeleportToCenterLand(connectionToClient);
        TeleportToLand(WorldManager.CENTER_LAND_NAME);
#endif
    }
    //========================= SURVIVAL LAND END =========================


    //===================== TELEPORT TO SHIP LAND ================

    [Client]
    public void RequestTeleportShipLand(int apiToken, int posIndex)
    {
        CmdTeleportToShipLand(apiToken, posIndex);
    }

    [Command]
    private void CmdTeleportToShipLand(int apiToken, int posIndex)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdTeleportToShipLand)) || IsInJail()) return;


        if (this.GetHealth() <= 0 || !IsStandingOn(RuntimeZoneType.Village)) return;
        if (IsInBeginnerLand()) return;

        if (!WorldManager.Instance.TryGetLandData(WorldManager.SHIP_LAND_NAME, out var landData))
        {
            BattleManager.Log(GameLogType.Error, userName + " try to teleport ship land but the land is not existed");
            return;
        }

        var key = characterInventory.GetEquipment(EquipmentType.Key);
        if (key != null)
        {
            LogicSellItem(key);
        }

        Log(LogAction.ChangeLand, "To:ShipLand");
        this.SetLandType(LandType.ShipLand);

        RpcTeleportToShipLand(connectionToClient);
        TeleportToLand(WorldManager.SHIP_LAND_NAME);
#endif
    }

    [TargetRpc]
    private void RpcTeleportToShipLand(NetworkConnectionToClient networkConnectionToClient)
    {
        if (UIManager.instance == null) return;

        BattleManager.Log(GameLogType.Debug, "Teleport to ShipLand successfully!");
        UIManager.instance.OnLocalPlayerLandTypeChange(LandType.ShipLand);
    }

    [Client]
    public void RequestShipLandToCenterLand(int apiToken)
    {
        CmdShipLandToCenterLand(apiToken);
    }

    [Command]
    private void CmdShipLandToCenterLand(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdShipLandToCenterLand))) return;
        if (this.GetHealth() <= 0) return;

        // Only from the ship land itself, and never as a way out of a captcha / the beginner land.
        if (!LandReturnRules.CanReturnToCenterLand(IsInShipLand(), BotDetectManager.IsCaptured(userName))) return;

        var key = characterInventory.GetEquipment(EquipmentType.Key);
        if (key != null)
        {
            LogicSellItem(key);
        }

        Log(LogAction.ChangeLand, "To:CenterLand");
        this.SetLandType(LandType.CenterLand);

        RpctTeleportToCenterLand(connectionToClient);
        TeleportToLand(WorldManager.CENTER_LAND_NAME);
#endif
    }
    //========================= SHIP LAND END =========================



    //----------------------------------------------------------------
    //Request hide/show supported equipment visuals
    //----------------------------------------------------------------
    [Client]
    public void RequestHideEquipment(bool value, EquipmentType equipmentType, int apiToken)
    {
        if (!NetworkClient.isConnected || characterVisual == null || characterVisual.GetEquipment(equipmentType) == null)
            return;

        CmdHideEquipment(value, equipmentType, apiToken);
    }

    [Command]
    public void CmdHideEquipment(bool value, EquipmentType equipmentType, int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdHideEquipment)))
            return;

        if (equipmentType != EquipmentType.Hair && equipmentType != EquipmentType.FaceHair && equipmentType != EquipmentType.Helmet)
            return;

        if (characterEquipments == null || characterEquipments.GetEquipment(equipmentType) == null || characterVisual == null)
            return;

        switch (equipmentType)
        {
            case EquipmentType.Hair: characterVisual.hideHair = value; break;
            case EquipmentType.FaceHair: characterVisual.hidenFaceHair = value; break;
            case EquipmentType.Helmet: characterVisual.hideHelmet = value; break;
        }
#endif
    }
    //----------------------------------------------------------------
    //Request Check Auto
    //----------------------------------------------------------------
    [Client]
    public void RequestCheckAuto()
    {
        if (!NetworkClient.isConnected)
            return;
        CmdCheckAuto();
    }

    [Command]
    public void CmdCheckAuto()
    {
#if ENABLE_SERVER
        Log(LogAction.AutoToolDetected, "Type:General");
#endif
    }

    //----------------------------------------------------------------
    //Request End Protection
    //----------------------------------------------------------------
    [Client]
    public void RequestEndProtection(int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdEndProtection(apiToken);
    }


    [Command]
    public void CmdEndProtection(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdEndProtection)))
            return;

        if (BattleManager.IsTournament)
        {
            BattleManager.Log(GameLogType.Info, $"[Tournament] Block player protection end. Player:{userName}");
            return;
        }

        this.protectionTime = 0;
        BattleManager.instance.SavePlayerData(this);
#endif
    }

    //----------------------------------------------------------------
    //Request Revive
    //----------------------------------------------------------------

    #region Revive

    [Client]
    public void RequestRevive(bool far, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdRevive(far, apiToken);
    }

    [Client]
    public void RequestReviveFarWithTH(int apiToken, string passcode)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdReviveFarWithTH(apiToken, passcode);
    }

    [Command]
    private void CmdReviveFarWithTH(int apiToken, string passcode)
    {
#if ENABLE_SERVER

        if (!ServerValidateApiToken(apiToken, nameof(CmdReviveFarWithTH)) || CheckWalletPassCode(passcode) == false)
        {
            return;
        }

        var cost = BattleManager.instance.gameDataConfig.CostTHBuyReviveClan;
        var currency = new CurrencyData() { currencyId = TH_COIN_ID, value = cost };
        if (HaveEnoughMoney(currency) == false)
        {
            return;
        }

        var characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData == null)
            return;

        PayCost(currency);
        EconomyManager.RecordThBurn(cost, "revive_fee");
        characterInventory.AddReviveClan(1);
        BattleManager.instance.SavePlayerData(this);

        LogicRevive(toClanVillage: true);

        // ✅ Send RPC with TH cost for analytics tracking
        if (cost > 0)
        {
            RpcReviveClanVillageWithTH(connectionToClient, cost);
        }
#endif
    }

    [Command]
    private void CmdRevive(bool far, int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdRevive)))
            return;
        if (GetHealth() > 0)
            return;
        LogicRevive(far);
#endif
    }
    private void LogicRevive(bool toClanVillage)
    {
#if ENABLE_SERVER
        if (GetHealth() > 0) return;

        // --- 1) Nếu đang ở trong Arena: hỏi trước xem còn lượt không ---
        bool handledByArena = false;
        NewArena arena = null;

        if (NewArenaManager_Server.TryGetArena(GetArenaId(), out arena) && arena != null)
        {
            // HẾT LƯỢT -> CHẶN HẲN revive
            if (!arena.TryConsumeRevive(userName)) return;

            handledByArena = true;
        }

        if (handledByArena)
        {
            // CÒN LƯỢT -> revive full, Arena tự lo teleport
            // Không reset effects khi revive trong NewArena
            FullyHeal(1f, true, resetEffect: true); // giống revivedHP = 1f
            arena.LogicAfterReviveArena(userName);

            TargetOnNewArenaRevive(arena.ArenaId);

            BattleManager.Log(GameLogType.Debug, $"{userName} revive in Arena {GetCharacterState()}");
        }
        else
        {
            // --- 2) Không thuộc Arena ---
            bool isTeleportedToClan = false;

            if (toClanVillage && IsInCenterLand() && !string.IsNullOrEmpty(clanId) && characterInventory.GetReviveClan() > 0)
            {
                characterInventory.AddReviveClan(-1);

                ClanData clanData = BattleManager.instance.GetClanData(clanId);
                if (clanData != null && !string.IsNullOrEmpty(clanData.villageId))
                {
                    VillageData villageData = BattleManager.instance.GetVillageData(clanData.villageId);
                    if (villageData != null)
                    {
                        Vector2 pos = new Vector2(
                            villageData.centerPosX + Random.Range(-3f, 3f),
                            villageData.centerPosY + Random.Range(-3f, 3f)
                        );

                        TeleportInCurrent(pos, true);
                        isTeleportedToClan = true;
                    }
                }
            }

            if (!isTeleportedToClan)
            {
                TeleportInCurrent(keepAutoMode: true);
            }

            // Hồi sinh theo logic cũ: clan = 25%, thường = 50%
            FullyHeal(isTeleportedToClan ? 0.25f : 0.5f, false);

            BattleManager.Log(GameLogType.Debug, $"{userName} revive {GetCharacterState()}");
        }
#endif
    }

    public void FullyHeal(float healPercent, bool forceRegen = true, bool resetEffect = true)
    {
#if ENABLE_SERVER
        if (FinalWarManager.HoldsMainBuilding(this)) return;
        //Don't need to check GetHealth() > 0 since this can be call when want to fully heal this player
        bool wasDead = (GetCharacterState() == CharacterState.Dead);
        deadTime = 0;
        SetCharacterState(CharacterState.Idle);

        if (resetEffect)
        {
            characterEffects?.ResetEffects();
        }


        if (forceRegen)
        {
            RegenHP(healPercent);
        }
        else
        {
            revivedHP = healPercent;
        }

        // Chỉ gửi RPC revive khi thực sự là revive (từ Dead state)
        if (wasDead && connectionToClient != null)
        {
            RpcRevive(connectionToClient);
        }
#endif
    }



    [Client]
    public void RequestGetTimeReviveClan(int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdGetTimeReviveClan(apiToken);
    }

    [Command]
    private void CmdGetTimeReviveClan(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdGetTimeReviveClan)))
        {
            return;
        }

        RpcGetTimeReviveClan(connectionToClient, timeCheckReviveClanVillage, lastTimeAddReviveClanVillage);
#endif
    }

    [TargetRpc]
    private void RpcGetTimeReviveClan(NetworkConnectionToClient networkConnectionToClient, float time, string lastTimeAddRevive)
    {
        if (UIManager.instance == null)
            return;

        UIManager.instance.FindView<HUDView>().DisplayTimeRegenReviveClan(time, lastTimeAddRevive);
    }



#if ENABLE_SERVER
    [Server]
    public int ServerGetMaxReviveClan()
    {
        var characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData == null)
        {
            BattleManager.Log(GameLogType.Warning, "[ServerGetMaxReviveClan] character data null. Usename: " + userName);
            return 0;
        }

        return REVIVE_CLAN_DEFAULT + (int)characterData.GetVipStatValue(VipBonusType.LimitReviveClan);
    }

    [Server]
    public int ServerGetMaxReviveClan(CharacterData characterData)
    {
        return REVIVE_CLAN_DEFAULT + (int)characterData.GetVipStatValue(VipBonusType.LimitReviveClan);
    }
#endif

    public int ClientGetMaxReviveClan()
    {
        var value = ClientManager.instance.GetVipStatValue(VipBonusType.LimitReviveClan);
        return REVIVE_CLAN_DEFAULT + (int)value;
    }


    [Client]
    public void RequestAddLimitReviveClan(int apiToken, string passcode)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdAddLimitReviveClan(apiToken, passcode);
    }

    [Command]
    private void CmdAddLimitReviveClan(int apiToken, string passcode)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdAddLimitReviveClan)))
            return;

        if (CheckWalletPassCode(passcode) == false)
            return;

        var cost = BattleManager.instance.gameDataConfig.CostTHAddLimitReviveClan;

        var currency = new CurrencyData() { currencyId = TH_COIN_ID, value = cost };
        if (HaveEnoughMoney(currency) == false)
        {
            return;
        }

        var characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData == null)
            return;

        PayCost(currency);
        EconomyManager.RecordThBurn(cost, "revive_limit_upgrade");
        BattleManager.instance.SavePlayerData(this);

        PlayerVipStat playerVipStat = new()
        {
            vipBonusType = VipBonusType.LimitReviveClan,
            vipLevel = -1,
            vipValue = 2,
        };

        characterData.playerVipStats.Add(playerVipStat);

        BattleManager.instance.SaveCharacterData(characterData);
        RpcPlayerVipStat(connectionToClient, playerVipStat, 0);

        // ✅ Send RPC with TH cost for analytics tracking
        if (cost > 0)
        {
            RpcAddLimitReviveClanWithTH(connectionToClient, cost);
        }
#endif
    }

    #endregion

    private void RegenHP(float value)
    {
        this.characterHealth.value = (int)(this.statData.GetStat(StatType.Health).GetValue() * value);
        if (this.characterHealth.value < 10)
            this.characterHealth.value = 10;
    }

    //=====================
    [Server]
    public void UnlockMovement()
    {
#if ENABLE_SERVER
        this.authorativePlayerMovement?.SetLockMovement(false);

        RpcUnlockMovement(this.connectionToClient);
#endif
    }

    [TargetRpc]
    private void RpcUnlockMovement(NetworkConnectionToClient networkConnectionToClient)
    {
        this.authorativePlayerMovement?.SetLockMovement(false);
    }

    [TargetRpc]
    public void RpcRevive(NetworkConnectionToClient networkConnectionToClient)
    {
        if (UIManager.instance != null)
            UIManager.instance.OnRevive();
        isDead = false;
        this.characterHealth.value = (int)this.statData.GetStat(StatType.Health).GetValue();
    }

    [TargetRpc]
    void RpcReviveClanVillageWithTH(NetworkConnectionToClient networkConnectionToClient, int thCost)
    {
#if ENABLE_CLIENT
        // ✅ Track TH Consumed (revive to clan village)
#if ENABLE_ANALYTIC_SERVICE
        if (thCost > 0 && AnalyticsManager.instance != null)
        {
            AnalyticsManager.instance.TrackTHConsumed(thCost, "revive_clan_village");
        }
#endif
#endif
    }

    //----------------------------------------------------------------
    //Get Other Equipments
    //----------------------------------------------------------------
    [Client]
    public void RequestGetOtherEquipments(string user)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdGetOtherEquipments(user);
    }

    [Command]
    public void CmdGetOtherEquipments(string user)
    {
#if ENABLE_SERVER
        PlayerBehavior playerBehavior = BattleManager.instance.GetPlayerBehavior(user);
        if (playerBehavior != null)
        {
            // Final War: khong cho cung clan xem trang bi/chi so cua nhau (Admin/Operator van xem duoc)
            bool sameClanCanView = !BattleManager.IsFinalWar && playerBehavior.clanId != "" && playerBehavior.clanId != GameConst.ASSASIN_CLAN_KEY && playerBehavior.clanId != GameConst.ROYALFORCE_CLAN_KEY
                && playerBehavior.clanId == this.clanId;
            if (sameClanCanView || this.playerRole != PlayerRole.Player)
            {
                RpcGetOtherEquipments(this.connectionToClient, playerBehavior.characterEquipments.GetEquipments());
            }
        }
#endif
    }

    [TargetRpc]
    public void RpcGetOtherEquipments(NetworkConnectionToClient networkConnectionToClient, List<Equipment> otherEquipments)
    {
        isDead = false;
        this.characterHealth.value = (int)this.statData.GetStat(StatType.Health).GetValue();

        if (UIManager.instance != null)
        {
            var characterInfoView = UIManager.instance.FindView<CharacterInfoView>();
            if (characterInfoView.IsOpen)
            {
                characterInfoView.RequestGetOtherEquipmentsCallback(otherEquipments);
            }
        }

    }

    //----------------------------------------------------------------
    //Logic Hit Map
    //----------------------------------------------------------------
    public void LogicHitMap(Vector2Int pos)
    {
#if ENABLE_SERVER
        if (BattleManager.instance.GetIsMaintenance()) return;
        if (this.GetHealth() <= 0) return;
        if (this.userName == "") return;
        if (this.isWatchingAd || IsInJail()) return;

        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);

        // AutoFarm with no tiles left must not break blocks, collect drops or spend tiles.
        if (!AutomationTileRules.CanAutoFarmMine(IsAutoFarm(), characterData != null ? characterData.automationTile : 0))
        {
            if (!autoFarmReturningToVillage) ServerSwitchToBackToMainVillage();
            return;
        }

        var hitResult = WorldManager.Instance.ProcessHitMap(pos, this);

        if (hitResult == null) return;

        if (hitResult.newMapHealth <= 0)
        {
            if (characterData != null)
            {
                characterData.todayHitMapNumber++;
                // Captcha hitmap: only count when not auto and in allowed zones (green/gray/white equivalents)
                if (!IsAutoFarm() && !InZoneIgnoreCaptcha())
                {
                    characterData.todayCaptchaHitmap++;
                    characterData.seasonCaptchaHitmap++;
                }

                if (lastBlockId != pos && !InZoneIgnoreCaptcha())
                {
                    lastBlockId = pos;

#if ENABLE_CAPTCHA
                    if (!IsAutoFarm())
                        newCaptchaTime += 1;
#endif
                }

                SetTodayHitMapNumber(characterData);
            }

            if (IsAutoFarm())
            {
                characterData.automationTile = AutomationTileRules.Consume(characterData.automationTile);
                characterInventory.SetAutomationTile(characterData.automationTile);
                if (AutomationTileRules.IsDepleted(characterData.automationTile))
                {
                    // Kiểm tra setting BackToMainVillage
                    // Nếu có bật → chuyển sang AutoMove về làng chính
                    // Nếu không → disable như bình thường
                    ServerSwitchToBackToMainVillage();
                }
            }

            if (hitResult.outcome != null)
            {
                HandleHitMap(hitResult.outcome);
            }
        }

        RpcHitMap(this.connectionToClient, pos, (short)Mathf.Max(0, hitResult.newMapHealth));

        void HandleHitMap(BreakMapOutcome hitResult)
        {
            CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);

            if (hitResult.landType == LandType.BeginnerLand)
            {
                if (this.isNew) this.isNew = false;
            }


            foreach (var g in hitResult.golds)
            {
                var currentGold = this.characterInventory.gold;

                if (this.connectionToClient != null)
                {
                    BattleManager.instance.gameLogicBehavior.TargetReceiveCurrency(this.connectionToClient, currentGold, g.amount, GameConst.GOLD_ID);
                }

                this.AddGold(g.amount);

                if (hitResult.landType == LandType.BeginnerLand && g.source == BreakMapOutcome.GoldDrop.GoldSource.IngredientFull)
                {
                    BattleManager.instance.SendServerNotificationToTarget(this.connectionToClient, -1,
                    NotifyType.ToastView, "Ingredient Bag Full!!! Received " + g.amount.ToString() + " gold");
                }
            }

            foreach (var ingrdient in hitResult.ingredients)
            {
                this.characterIngredient.AddEquipment(ingrdient);
                if (characterData != null) characterData.ingredientNumber++;
            }

            foreach (var entry in hitResult.inventories)
            {
                this.characterInventory.AddEquipment(entry);
            }

            foreach (var mobEntry in hitResult.mobs)
            {
                Card card = DataHolder.Instance().GetData<Card>(mobEntry.mobId);
                this.SpawnMob(mobEntry.spawnPos, card, hitResult.landType);

                if (mobEntry.mobId == GameConst.RED_DRAGON_ID)
                {
                    Log(LogAction.SpawnBoss,
                        $"Mob:{card.GetName(0)}|Pos:{Vector2Int.RoundToInt(mobEntry.spawnPos)}");
                }
            }

            if (hitResult.chestItemId != -1)
            {
                var landName = ChestKeyManager.LandTypeToLandName(hitResult.landType);

                if (ChestKeyManager.Instance.GetChest(landName) == null)
                {
                    var chestBehavior = ChestKeyManager.Instance.SpawnChest(landName, hitResult.chestType, hitResult.pos, false);
                    chestBehavior.ItemId = hitResult.chestItemId;

                    BattleManager.instance.SendServerNotificationToAll(this.characterName,
                                hitResult.chestType == ChestType.UndeadChest ? GameConst.DIALOG_SERVER_UNDEAD_CHEST : GameConst.DIALOG_SERVER_CHEST);

                    NetworkServer.Spawn(chestBehavior.gameObject);

                    if (hitResult.chestType == ChestType.UndeadChest)
                    {
                        BattleManager.instance.gameLogicBehavior.SpawnRain(pos, 600, 5);
                        Log(LogAction.FindChest, $"Type:Undead|Pos:{pos}");
                    }
                }
            }

            if (hitResult.keyItemId != -1)
            {
                var landName = ChestKeyManager.LandTypeToLandName(hitResult.landType);
                Card card = DataHolder.Instance().GetData<Card>(hitResult.keyItemId);
                if (!string.IsNullOrEmpty(landName) && card != null && ChestKeyManager.Instance.GetKey(landName) == null)
                {
                    Equipment equipment = new Equipment(hitResult.keyItemId, WorldManager.Instance.GetMapData(hitResult.pos).MapType);
                    equipment.rareType = RareType.Legendary;
                    this.characterInventory.AddEquipment(equipment);

                    var keyBehavior = ChestKeyManager.Instance.SpawnKey(landName, hitResult.chestType, Vector2.zero, false);

                    keyBehavior.ItemId = hitResult.keyItemId;
                    keyBehavior.ownerId = this.userName;
                    keyBehavior.Id = equipment.id;
                    keyBehavior.owner = this;

                    NetworkServer.Spawn(keyBehavior.gameObject);

                    BattleManager.instance.SendServerNotificationToAll(this.characterName,
                        hitResult.keyType == ChestType.DiamondChest ? GameConst.DIALOG_SERVER_DIAMOND_KEY : GameConst.DIALOG_SERVER_UNDEAD_KEY);

                    Log(LogAction.FindKey, $"Type:{hitResult.chestType}|KeyItem:{hitResult.keyItemId}");
                }
            }

            if (hitResult.diamond > 0)
            {
                var currentDiamond = this.characterInventory.diamond;
                if (this.connectionToClient != null)
                {
                    BattleManager.instance.gameLogicBehavior.TargetReceiveCurrency(this.connectionToClient, currentDiamond, hitResult.diamond, GameConst.DIAMOND_ID);
                }
                this.characterInventory.diamond += hitResult.diamond;
            }

            if (hitResult.shouldSaveCharacter)
            {
                BattleManager.instance.SavePlayerData(this);
            }
        }

#endif
    }



    [Server]
    public void SpawnMob(Vector3 pos, Card card, LandType landType, int level = 0)
    {
#if ENABLE_SERVER
        SpawnMob(pos, card, landType, level, null);
#endif
    }

    private void SpawnMob(Vector3 pos, Card card, LandType landType, int level, StatValue[] summonStatOverrides)
    {
#if ENABLE_SERVER
        var spawnLand = WorldManager.Instance.GetLandData(pos.ToVector2Int());
        var village = FinalWarManager.GetProtectedVillage(this, landId: spawnLand?.landName);
        var allowed = FinalWarManager.ResolveVillagePosition(village, spawnLand, transform.position, pos,
            grid: card.equipmentType == EquipmentType.Trap);
        if (!allowed.HasValue) return;
        if (allowed.Value != (Vector2)pos && connectionToClient != null)
            BattleManager.instance.SendServerNotificationToTarget(connectionToClient, int.MaxValue, NotifyType.MiddleNotify,
                FinalWarManager.VillageBlockedMessage);
        pos = allowed.Value;
        var gameobject = NetworkPoolManager.instance.Get(card.GetName(0), pos, Quaternion.identity);
        if (gameobject == null)
            return;

        if (gameobject.TryGetComponent(out TrapBehavior trapBehavior))
        {
            trapBehavior.SetLandType(landType);
            trapBehavior.InitializeFromSummon(this, card, summonStatOverrides);
            NetworkServer.Spawn(gameobject);
            return;
        }

        var mobBehavior = gameobject.GetComponent<MobBehavior>();
        if (mobBehavior == null)
        {
            NetworkPoolManager.instance.Return(card.GetName(0), gameobject);
            return;
        }
        mobBehavior.level = level;
        mobBehavior.SetSummonStatOverrides(summonStatOverrides);
        mobBehavior.SetLandType(landType);

        if (mobBehavior is SiegeUnitBehavior)
        {
            // Siege units snapshot Clan ownership at spawn and intentionally remain
            // independent from the Player's later lifecycle, location and Clan changes.
            mobBehavior.isSummonMob = false;
            mobBehavior.summoner = null;
            mobBehavior.summonerName = string.Empty;
            mobBehavior.UpdateClanId(clanId);
            mobBehavior.AssignTeamByType(RuntimeAreaController.AssignTeamType.Clan);
        }

        NetworkServer.Spawn(gameobject);
#endif
    }

    private void SpawnMob(Vector3 pos, int mobId, LandType landType)
    {
#if ENABLE_SERVER
        var card = DataHolder.Instance().GetData<Card>(mobId);
        SpawnMob(pos, card, landType);
#endif
    }

    [TargetRpc]
    public void RpcHitMap(NetworkConnectionToClient networkConnectionToClient, Vector2Int mapPos, short health)
    {
        // ✅ SERVER-ONLY: Add null check for MapManager
        if (MapManager.instance == null) return;

        LogicDisplayNotifyNotEnoughDamage();

        var mapId = mapPos.x + "_" + mapPos.y;
        var map = MapManager.instance.GetMapObject(mapId);
        if (map != null)
        {
            var mapData = MapManager.instance.GetMapData(mapPos.x, mapPos.y);
            if (mapData != null)
            {
                mapData.health = health;
            }

            map.LoadData();

            // ✅ SERVER-ONLY: Add null check for SoundManager
            if (SoundManager.instance != null)
                SoundManager.instance.PlaySounds(hitBlockSounds);

            //VfxManager.instance.OnMapHitEffect(map.transform.position);
            EventDispatcher.Raise(new OnSendMapPosition
            {
                position = map.transform.position
            });

            int n = Random.Range(0, 100);

            if (BattleManager.instance != null
                && BattleManager.instance.gameDataConfig != null
                && AdManager.instance != null)
            {
                if (n < BattleManager.instance.gameDataConfig.adRate)
                    AdManager.instance.AddTime();
            }

        }
    }

    private void LogicDisplayNotifyNotEnoughDamage()
    {
        // White/Undead tile hits no longer require a minimum weapon damage.
    }

    public bool ResetDailyCalculation()
    {
#if ENABLE_SERVER
        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);

        if (characterData != null && characterData.lastResetTime == "" || DataUtils.StringToTime(characterData.lastResetTime).Date != System.DateTime.UtcNow.Date)
        {
            BattleManager.Log(GameLogType.Debug, userName + " reset daily stats & quest");
            characterData.lastResetTime = DataUtils.TimeToString(System.DateTime.Now);
            characterData.todayAdNumber = 0;
            characterData.todayHitMapNumber = 0;
            characterData.todayCaptchaHitmap = 0;
            characterData.todayCraftNumber = 0;
            characterData.dailyPrisonNumber = 0;
            todayTimePlay = 0;
            SetTodayHitMapNumber(characterData);

            //Daily Quest
            LogicLoadQuestData(characterData);
            LogicLoadDailyReward(characterData);

            BattleManager.instance.SaveCharacterData(characterData);
            return true;
        }
#endif
        return false;
    }

    [Server]
    private void LogicLoadDailyReward(CharacterData characterData)
    {
#if ENABLE_SERVER
        List<PlayerDailyReward> removes = new List<PlayerDailyReward>();
        foreach (PlayerDailyReward playerDailyReward in characterData.playerDailyRewards)
        {
            if (playerDailyReward.remaining == 0 && playerDailyReward.itemType == ItemType.Vip)
            {
                removes.Add(playerDailyReward);
            }
            else
            {
                playerDailyReward.rewardState = RewardState.Ready;
            }
        }

        foreach (PlayerDailyReward remove in removes)
        {
            characterData.playerDailyRewards.Remove(remove);
        }

#endif
    }

    [TargetRpc]
    private void RpcVipData(NetworkConnectionToClient networkConnectionToClient,
        List<PlayerDailyReward> rewards, List<PlayerVipStat> playerVipStats, int vipLevel)
    {
#if ENABLE_CLIENT
        int oldVipLevel = ClientManager.instance.GetMyVipLevel();
        ClientManager.instance.ApplyVipData(rewards, playerVipStats, vipLevel);

        // ✅ Track VIP Level Up Analytics
        if (vipLevel >= 0 && vipLevel > oldVipLevel)
        {
#if ENABLE_ANALYTIC_SERVICE
            if (AnalyticsManager.instance != null)
            {
                AnalyticsManager.instance.TrackVIPLevelUp(vipLevel);
            }
#endif
        }

#endif
    }


    [TargetRpc]
    private void RpcDailyReward(NetworkConnectionToClient networkConnectionToClient,
        List<PlayerDailyReward> rewards, List<Equipment> equipments, List<CurrencyData> currencyDatas)
    {
        ClientManager.instance.SetMyDailyRewards(rewards);

        if (equipments.Count == 0 && currencyDatas.Count == 0)
            return;

        if (UIManager.instance == null)
            return;

        var rewardUI = UIManager.instance.FindView<RewardView>().GetRewardPopUpUI();

        if (equipments.Count > 0)
            rewardUI.AppendEquipments(equipments);

        if (currencyDatas.Count > 0)
            rewardUI.AppendCurrencyData(currencyDatas);

        rewardUI.Process().Load();
    }
    [TargetRpc]
    private void RpcPlayerVipStat(NetworkConnectionToClient networkConnectionToClient,
        PlayerVipStat playerVipStats, int thCost)
    {
        ClientManager.instance.AddPlayerVipStats(playerVipStats);

        // ✅ Track TH Consumed (Auto Feature purchase)
#if ENABLE_ANALYTIC_SERVICE
        if (thCost > 0 && AnalyticsManager.instance != null)
        {
            AnalyticsManager.instance.TrackTHConsumed(thCost, "buy_auto");
        }
#endif
    }

    [TargetRpc]
    void RpcAddLimitReviveClanWithTH(NetworkConnectionToClient networkConnectionToClient, int thCost)
    {
#if ENABLE_CLIENT
        // ✅ Track TH Consumed (add limit revive clan)
#if ENABLE_ANALYTIC_SERVICE
        if (thCost > 0 && AnalyticsManager.instance != null)
        {
            AnalyticsManager.instance.TrackTHConsumed(thCost, "add_limit_revive_clan");
        }
#endif
#endif
    }

    [Client]
    public void RequestClaimDailyReward(int apiToken, int itemId = -1)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdClaimRequest(apiToken, itemId);
    }

    [Command]
    private void CmdClaimRequest(int apiToken, int itemId)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdClaimRequest)))
        {
            return;
        }

        List<Equipment> equipments = new();
        List<CurrencyData> currencyDatas = new();
        bool claimAll = itemId == -1;
        bool claimedAny = false;

        var characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData == null || characterData.playerDailyRewards == null)
            return;

        foreach (PlayerDailyReward playerDailyReward in characterData.playerDailyRewards)
        {
            if (claimAll == false)
            {
                if (playerDailyReward.itemId != itemId)
                {
                    continue;
                }
            }


            if (playerDailyReward.rewardState == RewardState.Ready)
            {
                if (playerDailyReward.remaining > 0)
                    playerDailyReward.remaining -= 1;

                playerDailyReward.rewardState = RewardState.Rewarded;
                claimedAny = true;
                var box = DataHolder.Instance().GetData<Box>(playerDailyReward.boxId);
                var rewards = ServerOpenBox(box, BoxSourceType.DailyReward);
                
                // ✅ Additional safety: Check reward tuple items not null
                if (rewards.Item1 != null)
                    equipments.AddRange(rewards.Item1);
                if (rewards.Item2 != null)
                    currencyDatas.AddRange(rewards.Item2);
            }
        }
        if (!claimedAny)
            return;

        BattleManager.instance.SaveCharacterData(characterData);
        RpcDailyReward(connectionToClient, characterData.playerDailyRewards, equipments, currencyDatas);
#endif
    }

    //----------------------------------------------------------------
    //Request Use Skill
    //----------------------------------------------------------------

    [Client]
    public void RequestUseSkill(int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdUseSkill(apiToken);
    }


    [Command]
    public void CmdUseSkill(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdUseSkill)))
            return;

        if (!CanAttackPlayer())
        {
            return;
        }

        Equipment artifact = characterEquipments.GetEquipment(EquipmentType.Artifact);
        if (artifact == null)
        {
            return;
        }

        //Check cooldown
        if (string.IsNullOrEmpty(characterInventory.nextTimeUseSkill) == false)
        {
            var nextTime = DataUtils.StringToTime(characterInventory.nextTimeUseSkill);
            if (System.DateTime.Now < nextTime)
            {
                return;
            }
        }

        var card = DataHolder.Instance().GetData<Card>(artifact.itemId);
        if (card == null)
        {
            return;
        }

        var duration = artifact.GetStat(StatType.Duration);

        var conflictEffects = card.conflictEffect;

        switch (card.skillType)
        {
            case SkillType.None:
                break;
            case SkillType.Buff:
                Effect effect = new()
                {
                    stats = artifact.GetStatsEffect(),
                    endTime = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(duration)),
                    effectId = artifact.itemId
                };

                if (characterEffects != null && characterEffects.NotConflict(conflictEffects))
                {
                    characterEffects.AddEffect(effect);
                    characterEffects.OnUpdateEffects();
                }
                break;
            case SkillType.TeleportRamdom:
                break;
            case SkillType.TeleportHome:
                break;
            case SkillType.Invisible:
                break;
            case SkillType.Immortal:
                break;
            case SkillType.BuffAOE:

                effect = new()
                {
                    stats = artifact.GetStatsEffect(),
                    endTime = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(duration)),
                    effectId = artifact.itemId
                };
                //Self
                if (characterEffects != null && IsStandingOnPVP() && GetHealth() > 0)
                {
                    if (characterEffects.NotConflict(conflictEffects))
                    {
                        characterEffects.AddEffect(effect);
                        characterEffects.OnUpdateEffects();
                    }
                }

                LogicBuffAoe(artifact, conflictEffects, effect);
                break;
            case SkillType.AttackAOE:

                //TODO: check clanid + arena id

#if ENABLE_SERVER_TEST

                var dmgBonus = artifact.GetStat(StatType.Damage);
                effect = new()
                {
                    stats = new Stat[] { new Stat()
                    {   maxValue = dmgBonus,
                        minValue = dmgBonus,
                        statDataType = StatDataType.Normal,
                        statType = StatType.Damage,
                       value = dmgBonus,
                    } },
                    endTime = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(1)),
                    effectId = artifact.itemId
                };
                //Self
                if (characterEffects != null && IsStandingOnPVP() && GetHealth() > 0)
                {
                    characterEffects.AddEffect(effect);
                    characterEffects.OnUpdateEffects();
                }

#endif

                var radiusAtkAOE = artifact.GetStat(StatType.Radius);
                int atkAOECount = Physics2D.OverlapCircleNonAlloc(transform.position, radiusAtkAOE, skillColliderBuffer, BattleManager.instance.mobLayerMask);
                int atkAOEmaxNumber = (int)artifact.GetStat(StatType.NumberTarget);
                int atkAOEnumber = 0;
                for (int i = 0; i < atkAOECount; i++)
                {
                    if (skillColliderBuffer[i] != null && skillColliderBuffer[i].TryGetComponent<CharacterBehavior>(out var enemy))
                    {
                        if (!enemy.IsStandingOnPVP() || enemy.userName == userName || enemy.GetHealth() <= 0)
                        {
                            continue;
                        }

                        if (string.IsNullOrEmpty(clanId))
                        {
                            this.LogicHitTarget(enemy);
                            atkAOEnumber++;
                            if (atkAOEnumber >= atkAOEmaxNumber)
                            {
                                break;
                            }
                        }
                        else if (enemy.clanId != clanId && clanId != "")
                        {
                            BattleManager.Log(GameLogType.Debug, "Dmg AOE to " + enemy.characterName);
                            this.LogicHitTarget(enemy);
                            atkAOEnumber++;

                            if (atkAOEnumber >= atkAOEmaxNumber)
                            {
                                break;
                            }
                        }
                    }
                }


                break;
            case SkillType.DebuffAOE:
                LogicDebuffAOE(artifact, duration, conflictEffects);

                break;
            case SkillType.Heath:

                effect = new()
                {
                    stats = artifact.GetStatsEffect(),
                    endTime = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(duration)),
                    effectId = artifact.itemId
                };

                if (characterEffects != null && characterEffects.NotConflict(conflictEffects))
                {
                    int maxHealth = characterHealth.maxValue;
                    characterEffects.AddEffect(effect);
                    characterEffects.OnUpdateEffects();
                    float healthBonus = 0;

                    for (int i = 0; i < effect.stats.Length; i++)
                    {
                        if (effect.stats[i].statType == StatType.Health)
                        {
                            healthBonus += effect.stats[i].value;
                        }
                    }
                    var value = maxHealth / 100f * healthBonus;

                    characterHealth.AddValue((int)value);
                }

                break;

            case SkillType.HeathAOE:

                effect = new()
                {
                    stats = artifact.GetStatsEffect(),
                    endTime = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(duration)),
                    effectId = artifact.itemId
                };


                float healthBonusAOE = 0;

                for (int i = 0; i < effect.stats.Length; i++)
                {
                    if (effect.stats[i].statType == StatType.Health)
                    {
                        healthBonusAOE += effect.stats[i].value;
                    }
                }
                //Self
                if (characterEffects != null && IsStandingOnPVP() && GetHealth() > 0)
                {
                    if (characterEffects.NotConflict(conflictEffects))
                    {

                        int maxHealth = characterHealth.maxValue;

                        characterEffects.AddEffect(effect);
                        characterEffects.OnUpdateEffects();
                        var value = maxHealth / 100f * healthBonusAOE;

                        characterHealth.AddValue((int)value);
                    }
                }
                LogicBuffHealthAoe(artifact, conflictEffects, effect, healthBonusAOE);

                break;
            case SkillType.AttackRandom:
                break;
            case SkillType.Spawner:
            default:
                break;
        }

        var cooldown = artifact.GetStat(StatType.CoolDown);

#if ENABLE_SERVER_TEST
        cooldown *= 0.3f;
#endif

        characterInventory.nextTimeUseSkill = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(cooldown));
        BattleManager.instance.SavePlayerData(this);
        RpcUseSkill(this.transform.position, artifact);
#endif
    }

    private void LogicDebuffAOE(Equipment artifact, float duration, int[] conflictEffects)
    {
#if ENABLE_SERVER
        var debuffAOEradius = artifact.GetStat(StatType.Radius);

        Effect effect = new()
        {
            stats = artifact.GetStatsEffect(),
            endTime = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(duration)),
            effectId = artifact.itemId
        };
        int debuffAOEmaxNumber = (int)artifact.GetStat(StatType.NumberTarget);
        int debuffAOEnumber = 0;

        int debuffCount = Physics2D.OverlapCircleNonAlloc(transform.position, debuffAOEradius, skillColliderBuffer, Physics2D.AllLayers);
        for (int i = 0; i < debuffCount; i++)
        {
            if (skillColliderBuffer[i] == null || skillColliderBuffer[i].TryGetComponent<CharacterBehavior>(out var enemy) == false)
            {
                continue;
            }

            if (!CanAttack(enemy) || GetArenaId() != enemy.GetArenaId())
            {
                continue;
            }

            if (enemy.IsSameTeam(this) || enemy.userName == userName)
            {
                continue;
            }

            if (enemy.CanNotAddEffect(conflictEffects, effect))
            {
                continue;
            }

            enemy.characterEffects.AddEffect(effect);
            enemy.characterEffects.OnUpdateEffects();
            debuffAOEnumber++;

            if (debuffAOEnumber >= debuffAOEmaxNumber)
            {
                break;
            }
        }
#endif
    }

    private void LogicBuffHealthAoe(Equipment artifact, int[] conflictEffects, Effect effect, float healthBonusAOE)
    {
#if ENABLE_SERVER
        var buffAOEradius = artifact.GetStat(StatType.Radius);
        int maxTarget = (int)artifact.GetStat(StatType.NumberTarget);
        int count = 1;

        bool isUserClan = clanId.IsNonEmpty() && IsUserClan(clanId);

        int hitCount = Physics2D.OverlapCircleNonAlloc(transform.position, buffAOEradius, skillColliderBuffer, BattleManager.instance.playerLayerMask);
        for (int i = 0; i < hitCount; i++)
        {
            if (skillColliderBuffer[i] == null || skillColliderBuffer[i].TryGetComponent<CharacterBehavior>(out var otherPlayer) == false)
            {
                continue;
            }

            if (otherPlayer.CanAttackPlayer() == false || otherPlayer.userName == userName)
            {
                continue;
            }

            if (IsSameTeam(otherPlayer) == false)
            {
                continue;
            }

            if (otherPlayer.CanNotAddEffect(conflictEffects, effect))
            {
                continue;
            }

            bool canBuff = true;

            if (IsNpcClan(otherPlayer.clanId))
            {
                if (GetArenaId() != -1 && GetArenaId() == otherPlayer.GetArenaId())
                {
                    canBuff = true;
                }
                else
                {
                    canBuff = false;
                }

            }

            if (canBuff)
            {
                int maxHealth = otherPlayer.characterHealth.maxValue;

                otherPlayer.characterEffects.AddEffect(effect);
                otherPlayer.characterEffects.OnUpdateEffects();

                var value = maxHealth / 100f * healthBonusAOE;
                otherPlayer.characterHealth.AddValue((int)value);

                count++;
                if (count >= maxTarget)
                {
                    break;
                }
            }
        }
#endif
    }

    private void LogicBuffAoe(Equipment artifact, int[] conflictEffects, Effect effect)
    {
#if ENABLE_SERVER
        //if (ClanData.IsNoClanOrClanNPC(clanId))    return;

        //3 khu vực ArenaPVP, FreeForAll, UndeadLand sẽ không có đồng đội
        //if (HavePvpArenaId() || GetLandType() == LandType.UndeadLand || mapZoneType == MapZoneType.ArenaFreeForAll)

        var buffAOEradius = artifact.GetStat(StatType.Radius);
        int buffAOEmaxNumber = (int)artifact.GetStat(StatType.NumberTarget);
        int buffAOEnumber = 1;
        bool isUserClan = clanId.IsNonEmpty() && IsUserClan(clanId);

        int hitCount = Physics2D.OverlapCircleNonAlloc(transform.position, buffAOEradius, skillColliderBuffer, BattleManager.instance.playerLayerMask);
        for (int i = 0; i < hitCount; i++)
        {
            if (skillColliderBuffer[i] == null || skillColliderBuffer[i].TryGetComponent<CharacterBehavior>(out var otherPlayer) == false)
            {
                continue;
            }

            if (otherPlayer.CanAttackPlayer() == false || otherPlayer.userName == userName)
            {
                continue;
            }

            if (IsSameTeam(otherPlayer) == false)
            {
                continue;
            }

            if (otherPlayer.CanNotAddEffect(conflictEffects, effect))
            {
                continue;
            }

            bool canBuff = true;

            if (IsNpcClan(otherPlayer.clanId))
            {
                if (GetArenaId() != -1 && GetArenaId() == otherPlayer.GetArenaId())
                {
                    canBuff = true;
                }
                else
                {
                    canBuff = false;
                }
            }

            if (canBuff)
            {
                otherPlayer.characterEffects.AddEffect(effect);
                otherPlayer.characterEffects.OnUpdateEffects();
                buffAOEnumber++;
                if (buffAOEnumber >= buffAOEmaxNumber)
                {
                    break;
                }
            }
        }
#endif
    }

    public bool HavePvpArenaId() => GetArenaId() == 0 || GetArenaId() == 2;

    [ClientRpc]
    public void RpcUseSkill(Vector2 skillAppearPostion, Equipment artifact)
    {
        //VfxManager.instance.OnSkill(skillAppearPostion, artifact, isLocalPlayer, this);
        EventDispatcher.Raise(new OnSendStatSkill
        {
            skillAppearPostion = skillAppearPostion,
            artifact = artifact,
            isLocalPlayer = isLocalPlayer,
            playerBehavior = this
        });
    }

    //----------------------------------------------------------------
    //Request Use Item
    //----------------------------------------------------------------
    [Client]
    public void RequestUseItem(string equipmentId, int apiToken, string passCode = "")
    {
        if (!NetworkClient.isConnected)
            return;

#if ENABLE_CLIENT || UNITY_LOCAL_HOST
        Equipment requestedEquipment = characterInventory?.GetEquipment(equipmentId);
        if (requestedEquipment != null && requestedEquipment.equipmentType == EquipmentType.Summon &&
            GetLandType() != LandType.CenterLand)
        {
            Card requestedCard = DataHolder.Instance().GetData<Card>(requestedEquipment.itemId);
            if (HasSiegeUnitOutput(requestedCard) || HasTrapOutput(requestedCard))
            {
                IngameNotifyManager.instance?.OnMiddleNotify(UIManager.GetDialog(1539));
                return;
            }
        }

        if (TryStartTrapPlacement(equipmentId))
            return;
#endif

        CmdUseItem(equipmentId, apiToken, passCode);
    }

#if ENABLE_CLIENT || UNITY_LOCAL_HOST
    private bool TryStartTrapPlacement(string equipmentId)
    {
        Equipment equipment = characterInventory?.GetEquipment(equipmentId);
        if (equipment == null || equipment.equipmentType != EquipmentType.Summon)
            return false;

        Card summonCard = DataHolder.Instance().GetData<Card>(equipment.itemId);
        if (!TryGetTrapOutputCard(summonCard, out Card trapCard))
            return false;

        bool started = BuildingPlacementController.Instance.StartTrapPlacement(equipment.id, trapCard.id);
        if (!started)
        {
            Debug.LogWarning("[TrapPlacement] Could not start placement. Check UIManager and Trap preview prefab setup.");
            IngameNotifyManager.instance?.OnMiddleNotify("Cannot start Trap placement: player or preview setup is unavailable.");
        }

        // Trap Summons never fall through to immediate CmdUseItem, even when
        // local preview setup is incomplete.
        return true;
    }
#endif

    [Client]
    public void RequestUseTrap(string equipmentId, int posX, int posY, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdUseTrap(equipmentId, posX, posY, apiToken);
    }

    [Command]
    public void CmdUseTrap(string equipmentId, int posX, int posY, int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdUseTrap)))
        {
            TargetUseTrapResult(connectionToClient, TrapPlacementResult.InvalidRequest);
            return;
        }

        TrapPlacementResult result = LogicUseTrapPlacement(equipmentId, posX, posY);
        if (result == TrapPlacementResult.Success)
            BattleManager.instance.SavePlayerData(this);
        TargetUseTrapResult(connectionToClient, result);
#endif
    }

    [Server]
    private TrapPlacementResult LogicUseTrapPlacement(string equipmentId, int posX, int posY)
    {
        if (GetHealth() <= 0 || BattleManager.instance == null || BattleManager.instance.GetIsMaintenance() ||
            FinalWarManager.IsEliminated(this))
            return TrapPlacementResult.Unavailable;

        if (GetLandType() != LandType.CenterLand)
            return TrapPlacementResult.InvalidZone;

        Equipment equipment = characterInventory.GetEquipment(equipmentId);
        if (equipment == null)
            return TrapPlacementResult.EquipmentMissing;
        if (equipment.equipmentType != EquipmentType.Summon)
            return TrapPlacementResult.InvalidRequest;

        Card summonCard = DataHolder.Instance().GetData<Card>(equipment.itemId);
        if (!TryGetTrapOutputCard(summonCard, out Card trapCard)
            || trapCard == null
            || trapCard.equipmentType != EquipmentType.Trap
            || !trapCard.isAvailable)
        {
            return TrapPlacementResult.InvalidRequest;
        }

        if (NetworkServer.aoi is not MMOSpatialInterestManagement
            || NetworkPoolManager.instance == null
            || !NetworkPoolManager.instance.HasPoolComponent<TrapBehavior>(trapCard.GetName(0)))
        {
            return TrapPlacementResult.Unavailable;
        }

        Vector2 playerPosition = transform.position;
        Vector2 targetPosition = new Vector2(posX, posY);
        float placementRange = TrapPlacementRules.GetPlacementRange();
        if (!TrapPlacementRules.IsWithinPlacementRange(playerPosition, targetPosition, placementRange))
            return TrapPlacementResult.OutOfRange;

        var gridPosition = new Vector2Int(posX, posY);
        if (!TrapPlacementRules.IsAllowedZone(gridPosition))
            return TrapPlacementResult.InvalidZone;
        ClanData placementClan = ClanData.IsNoClanOrClanNPC(clanId) ? null : BattleManager.instance.GetClanData(clanId);
        if (TrapPlacementRules.IsBlockedByForeignVillage(gridPosition, placementClan?.villageId))
            return TrapPlacementResult.ForeignVillage;
        if (TrapPlacementRules.IsBlockedByVillageBuilding(gridPosition))
            return TrapPlacementResult.BuildingOccupied;
        if (BattleManager.instance.TrapRuntimeRegistry.IsOccupiedByOwnerOrClan(gridPosition, userName, clanId))
            return TrapPlacementResult.PositionOccupied;

        StatValue[] summonStatOverrides = equipment.GetStats(equipment.level);
        if (!SafeRemoveEquipment(equipment))
            return TrapPlacementResult.EquipmentMissing;

        SpawnMob(targetPosition, trapCard, WorldManager.Instance.GetLandType(gridPosition), 0, summonStatOverrides);
        Log(LogAction.SpawnBoss,
            $"Trap:{trapCard.GetName(0)}|TrapID:{trapCard.id}|Pos:{targetPosition}|PlacementRange:{placementRange}");
        return TrapPlacementResult.Success;
    }

    [TargetRpc]
    private void TargetUseTrapResult(NetworkConnectionToClient target, TrapPlacementResult result)
    {
#if ENABLE_CLIENT || UNITY_LOCAL_HOST
        if (result != TrapPlacementResult.Success)
            IngameNotifyManager.instance?.OnMiddleNotify(BuildingPlacementController.GetTrapPlacementFailureMessage(result));
        if (WorldPlacementController.Current is BuildingPlacementController controller)
            controller.HandleUseTrapResponse(result);
#endif
    }

    [Command]
    public void CmdUseItem(string equipmentId, int apiToken, string passCode)
    {
#if ENABLE_SERVER
        if (this.GetHealth() <= 0)
            return;

        if (!ServerValidateApiToken(apiToken, nameof(CmdUseItem)))
            return;

        LogicUseItem(equipmentId, passCode);
#endif
    }

    public void LogicUseItem(string equipmentId, string passCode, bool useSwapRateLimited = true)
    {
#if ENABLE_SERVER
        Equipment equipment = characterInventory.GetEquipment(equipmentId);
        equipment ??= characterCollection.GetEquipment(equipmentId);
        equipment ??= characterTitleEquipment.GetEquipment(equipmentId);

        if (equipment == null)
            return;

        if (equipment.equipmentType == EquipmentType.Blueprint ||
            equipment.equipmentType == EquipmentType.Ingredient ||
            equipment.equipmentType == EquipmentType.EventItem)
        {
            BattleManager.Log(GameLogType.Warning,
                $"[UseItemGuard] User:{userName}|Equipment:{equipment.id}|Item:{equipment.itemId}|RuntimeType:{equipment.equipmentType}");
            return;
        }

        // Allow-list: the final "else" below wears whatever reaches it as gear (BuildingPart, Building, Mob, Npc,
        // ArtifactShard, Chest, Trap... would be worn and add their stats). Only types with an explicit branch pass.
        if (!Equipment.IsUseItemSupportedType(equipment.equipmentType))
        {
            Log(LogAction.SuspiciousActivity,
                $"Type:UseItemInvalidType|Equipment:{equipment.id}|Item:{equipment.itemId}|EquipmentType:{equipment.equipmentType}|State:{equipment.state}");
            return;
        }

        if (equipment.IsBaseEquipment())
        {
            if(useSwapRateLimited)
            {
                if(IsBasicGearSwapRateLimited())
                {
                    Log(LogAction.SuspiciousActivity,
                        $"Type:EquipRateLimit|Action:Equip|ItemId:{equipment.itemId}|EquipmentType:{equipment.equipmentType}|Limit:{BasicGearSwapLimitPerSecond}/{BasicGearSwapWindowSeconds:F0}s");
                    return;
                }
            }
        }

        if (equipment.IsSkin())
        {
            var isCorrect = CheckWalletPassCode(passCode);
            if (isCorrect == false)
            {
                return;
            }
        }

        if (equipment.IsSkin() && equipment.state == EquipmentState.Character)
            return;

        if (equipment.equipmentType == EquipmentType.Item)
        {
            if (equipment.itemId == POTION_ID || equipment.itemId == POTION_FACTION_WAR_ID)
            {
                for (int i = 0; i < equipment.stats.Length; i++)
                {
                    if (equipment.stats[i].statType == StatType.Health)
                    {
                        int value = (int)equipment.stats[i].GetValue(equipment.level, equipment.equipmentType);
                        characterHealth.AddValue(value);
                        RpcAddHeal(value);
                    }
                }
            }
            else if (equipment.IsElixir())
            {
                if (characterBuffs != null && characterBuffs.HaveBuff(equipment.itemId) == false)
                {
                    var stats = equipment.GetStatsEffect();
                    Buff buff = new()
                    {
                        buffId = equipment.itemId,
                        stats = stats,
                        remaninngTime = equipment.GetStat(StatType.Duration)
                    };

                    characterBuffs.AddBuff(buff);
                    characterBuffs.OnUpdateBuffs();

                    for (int i = 0; i < stats.Length; i++)
                    {
                        if (stats[i].statType == StatType.Health)
                        {
                            int value = (int)stats[i].GetValue(0, equipment.equipmentType);
                            characterHealth.AddValue(value);
                            RpcAddHeal(value);
                        }
                    }

                }
                else
                {
                    BattleManager.instance.SendServerNotificationToTarget(this.connectionToClient, 536, NotifyType.ToastView);
                    return;
                }
            }

            characterInventory.RemoveEquipment(equipment.id);
        }
        else if (equipment.equipmentType == EquipmentType.Scroll)
        {
            int id = -1;
            Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);

            //Scroll bear
            if (equipment.itemId == 793)
            {
                id = card.craftOutputIds[0];
            }
            else
            {
                int n = Random.Range(0, 100);
                if (n < 99)

                    id = GetRandomValue(card.craftOutputIds);
                else
                    id = card.craftOutputIds[card.craftOutputIds.Length - 1];
            }

            if (id >= 0)
            {
                Equipment newEquipment = new Equipment(id, equipment.rareType);
                characterInventory.RemoveEquipment(equipment.id);
                characterInventory.AddEquipment(newEquipment);
            }
            BattleManager.instance.SavePlayerData(this);

        }
        else if (equipment.IsSkin())
        {
            // Khởi tạo skin sets nếu cần
            InitializeSkinSetsData();

            // Lấy skin cũ từ active set
            int activeSetIndex = activeSkinSetIndexData;
            Equipment oldSkin = GetSkinFromSetData(activeSetIndex, equipment.equipmentType);

            if (oldSkin != null && oldSkin.isLock)
            {
                BattleManager.instance.gameLogicBehavior.SendNotification(connectionToClient,
                    NotifyType.Notify, 840, "");
                return;
            }

            // Thêm skin mới vào active set (skin cũ cùng loại sẽ bị mất)
            Equipment replacedSkin = SetSkinInSetData(activeSetIndex, equipment);

            // Log nếu có skin bị replace
            if (replacedSkin != null)
            {
                Log(LogAction.UseSkin,
                    $"Type={equipment.equipmentType};OldId={replacedSkin.itemId};OldRare={replacedSkin.rareType};NewId={equipment.itemId};NewRare={equipment.rareType};Set={activeSetIndex}",
                    $"{{\"oldSkin\":{replacedSkin.ToJson()},\"newSkin\":{equipment.ToJson()}}}");
            }

            // Xóa skin khỏi inventory
            characterInventory.RemoveEquipment(equipment.id);

            // Reload skins từ active set vào characterEquipments
            ReloadSkinsFromActiveSet();

            // Sync to characterData and save
            var characterData = BattleManager.instance.GetCharacterData(userName);
            if (characterData != null)
            {
                SyncSkinSetsToCharacterData(characterData);
                SyncEquipmentSetsToCharacterData(characterData);
            }
        }
        else if (equipment.equipmentType == EquipmentType.Summon)
        {
            if (equipment.itemId == GameConst.SUMMON_4_VIKING)
            {
                LogicSummonViking(equipment);
            }
            else
            {
                LogicSummonBoss(equipment);
            }
            BattleManager.instance.SavePlayerData(this);

        }
        else if (equipment.equipmentType == EquipmentType.Egg)
        {
            if(equipment.state == EquipmentState.Character)
            {
                equipment.state = EquipmentState.Inventory;

                characterEquipments.RemoveEquipment(equipment.id);
                characterInventory.AddEquipment(equipment);
            }
            return;
        }
        else if (equipment.equipmentType == EquipmentType.Key || equipment.equipmentType == EquipmentType.EventItem)
        {
            return;
        }
        else if (equipment.IsCollection())
        {
            Equipment equiped = null;

            if (equipment.equipmentType == EquipmentType.Emote)
            {
                var equippedEmotes = characterEquipments.GetEquipments(EquipmentType.Emote);
                if (equippedEmotes != null)
                {
                    equiped = equippedEmotes.Find(e => e.itemId == equipment.itemId);
                    if (equiped == null && equippedEmotes.Count >= GameConst.MAX_COLLECTION_EMOTE)
                    {
                        BattleManager.instance.SendServerNotificationToTarget(this.connectionToClient, 784, NotifyType.Notify);
                        return;
                    }
                }
            }
            else
            {
                equiped = characterEquipments.GetEquipment(equipment.equipmentType);
            }

            equipment.state = EquipmentState.Character;

            if (equiped == null)
            {
                if (characterCollection != null)
                    characterCollection.RemoveEquipment(equipment.id);
                characterEquipments.AddEquipment(equipment);
            }
            else
            {
                equiped.state = EquipmentState.Collection;
                if (characterCollection != null)
                    characterCollection.RemoveEquipment(equipment.id);
                characterEquipments.RemoveEquipment(equiped.id);
                characterEquipments.AddEquipment(equipment);
                if (characterCollection != null)
                    characterCollection.AddEquipment(equiped);
            }

            if (characterVisual != null)
            {
                characterVisual.LoadEquipments();
            }
        }
        else if (equipment.equipmentType == EquipmentType.BuffItem)
        {

            Buff buff = new()
            {
                stats = equipment.GetStatsEffect(),
                remaninngTime = equipment.GetStat(StatType.Duration),
                buffId = equipment.itemId
            };

            if (characterBuffs != null)
            {
                characterBuffs.AddBuff(buff);
                characterBuffs.OnUpdateBuffs();
            }
            characterInventory.RemoveEquipment(equipment.id);

        }
        else if (equipment.equipmentType == EquipmentType.SkinTitle)
        {
            Equipment equiped = characterEquipments.GetEquipment(EquipmentType.SkinTitle);
            equipment.state = EquipmentState.Character;
            if (equiped == null)
            {
                characterTitleEquipment.RemoveEquipment(equipment.id);
                //31/8/2025 khi equip remove luôn cả title trong inventory nếu có tồn tại
                characterInventory.RemoveEquipment(equipment.id);
                characterEquipments.AddEquipment(equipment);
            }
            else
            {
                equiped.state = EquipmentState.Title;
                var currentOrder = equipment.sortingOrder;

                characterTitleEquipment.RemoveEquipment(equipment.id);
                characterEquipments.RemoveEquipment(equiped.id);
                //31/8/2025 khi equip remove luôn cả title trong inventory nếu có tồn tại
                characterInventory.RemoveEquipment(equipment.id);

                characterEquipments.AddEquipment(equipment);
                characterTitleEquipment.AddEquipment(equiped, currentOrder);
            }


            if (characterVisual != null)
            {
                characterVisual.LoadEquipments();
            }
        }
        else
        {
            Equipment equiped = characterEquipments.GetEquipment(equipment.equipmentType);
            equipment.state = EquipmentState.Character;

            if (equiped == null)
            {
                characterInventory.RemoveEquipment(equipment.id);
                characterEquipments.AddEquipment(equipment);
            }
            else
            {
                equiped.state = EquipmentState.Inventory;
                var currentOrder = equipment.sortingOrder;
                characterInventory.RemoveEquipment(equipment.id);
                characterEquipments.RemoveEquipment(equiped.id);
                characterEquipments.AddEquipment(equipment);
                characterInventory.AddEquipment(equiped, currentOrder);
            }


            if (characterVisual != null)
            {
                characterVisual.LoadEquipments();
            }
        }

        //BattleManager.Log(GameLogType.Debug, $"{userName} - Equipment state {equipment.state}");

        OnUpdateStats();
#endif
    }

    private void LogicSummonBoss(Equipment equipment)
    {
#if ENABLE_SERVER
        if (FinalWarManager.IsEliminated(this)) return;

        Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
        if (card == null)
            return;

        if (HasSiegeUnitOutput(card) && GetLandType() != LandType.CenterLand)
        {
            Log(LogAction.SpawnBoss, $"SiegeSummonBlocked:{card.GetName(0)}|Reason:NotCenterLand|Land:{GetLandType()}");
            BattleManager.instance.SendServerNotificationToTarget(connectionToClient,
                1539, NotifyType.MiddleNotify);
            return;
        }

        if (HasSiegeUnitOutput(card) &&
            (ClanData.IsNoClanOrClanNPC(clanId) || BattleManager.instance.GetClanData(clanId) == null))
        {
            Log(LogAction.SpawnBoss, $"SiegeSummonBlocked:{card.GetName(0)}|Reason:NoClan");
            return;
        }

        bool hasTrapOutput = HasTrapOutput(card);
        if (hasTrapOutput)
        {
            TargetUseTrapResult(connectionToClient, TrapPlacementResult.TrapPlacementRequired);
            return;
        }

        StatValue[] summonStatOverrides = card.overrideSummonedMobStats || hasTrapOutput
            ? equipment.GetStats(equipment.level)
            : null;


        if (card.craftOutputIds.Length > 0)
        {
            Card boss = DataHolder.Instance().GetData<Card>(card.craftOutputIds[0]);

            if (boss.isBoss && boss.seasonEventType != SeasonEventType.None)
            {
                if (!IsStandingOn(RuntimeZoneType.Undead) &&
                    !IsStandingOn(RuntimeZoneType.White))
                {
                    BattleManager.instance.SendServerNotificationToTarget(connectionToClient, int.MaxValue, NotifyType.Notify, "Can not summon in this zone");
                    return;
                }
            }
            else if (GetArenaId() == ARENA_TEAM_BATTLE)
            {
                if (IsInWarLand())
                {
                    BattleManager.instance.SendServerNotificationToTarget(connectionToClient, int.MaxValue, NotifyType.Notify,
                        "Can not summon in this zone");
                    return;
                }
            }
        }


        bool success = SafeRemoveEquipment(equipment);
        if (success)
        {
            for (int i = 0; i < card.craftOutputIds.Length; i++)
            {
                Card boss = DataHolder.Instance().GetData<Card>(card.craftOutputIds[i]);
                if (boss.isAvailable == false)
                {
                    return;
                }

                bool isSiegeOutput = boss.id == GameConst.CATAPULT_SIEGE_UNIT_ID || boss.id == GameConst.BALLOON_SIEGE_UNIT_ID;
                Vector2 pos = this.transform.position;
                if (!isSiegeOutput)
                {
                    pos += new Vector2(Random.Range(-3, 3), Random.Range(-3, 3));
                    pos = BattleManager.instance.ClampPosition(pos, this);
                }
                SpawnMob(pos, boss, GetLandType(), 0, summonStatOverrides);
                Log(LogAction.SpawnBoss, $"Boss:{card.GetName(0)}|BossID:{card.craftOutputIds[i]}|Pos:{pos}");
            }
        }
#endif
    }

    private static bool HasSiegeUnitOutput(Card summonCard)
    {
        if (summonCard?.craftOutputIds == null)
            return false;

        for (int i = 0; i < summonCard.craftOutputIds.Length; i++)
        {
            int outputId = summonCard.craftOutputIds[i];
            if (outputId == GameConst.CATAPULT_SIEGE_UNIT_ID ||
                outputId == GameConst.BALLOON_SIEGE_UNIT_ID)
            {
                return true;
            }
        }

        return false;
    }

    private static bool HasTrapOutput(Card summonCard)
    {
        return TryGetTrapOutputCard(summonCard, out _);
    }

    private static bool TryGetTrapOutputCard(Card summonCard, out Card trapCard)
    {
        trapCard = null;
        if (summonCard?.craftOutputIds == null)
            return false;

        for (int i = 0; i < summonCard.craftOutputIds.Length; i++)
        {
            Card outputCard = DataHolder.Instance().GetData<Card>(summonCard.craftOutputIds[i]);
            if (outputCard != null && outputCard.equipmentType == EquipmentType.Trap)
            {
                trapCard = outputCard;
                return true;
            }
        }

        return false;
    }

    private void LogicSummonViking(Equipment equipment)
    {
#if ENABLE_SERVER
        if (FinalWarManager.IsEliminated(this)) return;

        if (VikingRushManager.IsSpawnSlotActive(BattleManager.instance.ServerNow()))
        {
            BattleManager.instance.SendServerNotificationToTarget(
                connectionToClient,
                -1,
                NotifyType.Notify,
                "Viking summon is disabled during Viking Rush.");
            return;
        }

        bool stayOnViking = IsStandingOn(RuntimeAreaController.RuntimeAreaType.WhiteVillage);
        if (stayOnViking == false)
            return;

        var runtimeArea = WorldManager.Instance.GetAreaController(this.transform.position);

        if (runtimeArea == null || runtimeArea.Type != RuntimeAreaController.RuntimeAreaType.WhiteVillage)
            return;

        var vikingVillagePosition = runtimeArea.Position;

        var vikingVillageId = (int)runtimeArea.Position.x + "_" + (int)runtimeArea.Position.y;

        bool dontHaveVikingInWhiteVillage = BattleManager.instance.villageVikingBehavior.Contains(vikingVillageId) == false;

        if (dontHaveVikingInWhiteVillage == false)
        {
            // Self-heal: ID is in the list but no active VikingVillageBehavior is tracking it
            // (can happen when pool resets mobs before OnUpdate detects death, or InitCO exception)
            bool hasActiveBehavior = VikingVillageManager.instance.vikingVillageBehaviors
                .Any(v => v.villageData != null && v.villageData.id == vikingVillageId && !v.IsDefeated);

            if (!hasActiveBehavior)
            {
                BattleManager.instance.villageVikingBehavior.Remove(vikingVillageId);
                dontHaveVikingInWhiteVillage = true;
                BattleManager.Log(GameLogType.Info, userName + " Cleaned stale viking ID: " + vikingVillageId);
            }
            else
            {
                BattleManager.Log(GameLogType.Error, userName + "Try spawn viking in " + vikingVillageId + " but this pos already have viking");
            }
        }

        if (stayOnViking && dontHaveVikingInWhiteVillage)
        {
            var data = WorldManager.Instance.GetWhiteVillageData(vikingVillagePosition.ToVector2Int());
            if (data == null)
            {
                BattleManager.Log(GameLogType.Error, userName + "Try spawn viking in " + vikingVillageId + " but village data is null");
                return;
            }

            bool started = VikingVillageManager.instance.TrySpawnVikingVillage(data, clanId, equipment.rareType);
            if (!started)
            {
                BattleManager.Log(GameLogType.Error, userName + "Try spawn viking in " + vikingVillageId + " but state is blocked or invalid");
                return;
            }

            BattleManager.instance.SendServerNotificationToTarget(connectionToClient, 494, NotifyType.VikingComming);

            Log(LogAction.SpawnBoss, "Viking", "|Pos:" + vikingVillagePosition.ToVector2Int());

            SafeRemoveEquipment(equipment);
        }
#endif

    }

    //----------------------------------------------------------------
    //Request UnEquip Item
    //----------------------------------------------------------------
    [Client]
    public void RequestUnEquipItem(string equipmentId, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdUnEquipItem(equipmentId, apiToken);
    }

    [Command]
    public void CmdUnEquipItem(string equipmentId, int apiToken)
    {
#if ENABLE_SERVER
        if (this.GetHealth() <= 0)
            return;

        if (this.userName == "" || equipmentId == "")
        {
            return;
        }


        if (!ServerValidateApiToken(apiToken, nameof(CmdUnEquipItem)))
            return;

        Equipment equipment = characterEquipments.GetEquipment(equipmentId);
        if (equipment != null && equipment.IsSkin())
        {
            return;
        }

        if (equipment != null && equipment.IsBaseEquipment() && IsBasicGearSwapRateLimited())
        {
            Log(LogAction.SuspiciousActivity,
                $"Type:EquipRateLimit|Action:UnEquip|ItemId:{equipment.itemId}|EquipmentType:{equipment.equipmentType}|Limit:{BasicGearSwapLimitPerSecond}/{BasicGearSwapWindowSeconds:F0}s");
            return;
        }

        if (equipment != null)
        {
            if (equipment.IsCollection())
            {
                equipment.state = EquipmentState.Collection;
                if (characterCollection != null)
                    characterCollection.AddEquipment(equipment);
            }
            else if (equipment.equipmentType == EquipmentType.SkinTitle)
            {
                equipment.state = EquipmentState.Title;
                if (characterTitleEquipment != null)
                {
                    characterTitleEquipment.AddEquipment(equipment);
                }
            }
            else
            {
                if (CanUnEquipEquipment(equipment, out var inventorySlotIsFull, out var ingredientSlotIsFull) == false)
                {
                    int dialogId = ingredientSlotIsFull ? 27 : 26;
                    BattleManager.instance.SendServerNotificationToTarget(connectionToClient, dialogId, NotifyType.Notify);
                    return;
                }

                equipment.state = EquipmentState.Inventory;
                characterInventory.AddEquipment(equipment);
            }

            characterEquipments.RemoveEquipment(equipment.id);

            if (characterVisual != null)
            {
                characterVisual.LoadEquipments();
            }

            OnUpdateStats();
        }
        else
        {
            equipment = characterInventory.GetEquipment(equipmentId);
            if (equipment != null)
            {
                equipment.state = EquipmentState.Inventory;
            }
            else
            {
                equipment = characterTitleEquipment.GetEquipment(equipmentId);
                if (equipment != null)
                {
                    equipment.state = EquipmentState.Title;
                    characterTitleEquipment.ResetEquipment(equipment);
                }
                else
                {
                    equipment = characterCollection.GetEquipment(equipmentId);
                    if (equipment != null)
                    {
                        equipment.state = EquipmentState.Collection;
                        characterCollection.ResetEquipment(equipment);
                    }
                }
            }
        }
#endif
    }
    //----------------------------------------------------------------
    //Request Sell Item
    //----------------------------------------------------------------
    [Client]
    public void RequestSellItem(string equipmentId, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdSellItem(equipmentId, apiToken);
    }

    [Command]
    public void CmdSellItem(string equipmentId, int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdSellItem)) || GetHealth() <= 0 || string.IsNullOrEmpty(equipmentId))
            return;

        if ((System.DateTime.Now - lastSellTime).TotalSeconds < SellCommandCooldownSeconds)
            return;

        lastSellTime = System.DateTime.Now;

        Equipment equipment = GetEquipment(equipmentId);
        if (equipment != null)
        {
            LogicSellItem(equipment);
            OnUpdateStats();

            if ((equipment.state == EquipmentState.Character || equipment.state == EquipmentState.Collection ||
                equipment.state == EquipmentState.Title) && characterVisual != null)
            {
                characterVisual.LoadEquipments();
            }


        }
#endif
    }


    public void LogicSellItem(Equipment equipment)
    {
#if ENABLE_SERVER
        if (equipment.isLock)
            return;

        var card = DataHolder.Instance().GetData<Card>(equipment.itemId);
        if (card == null || !card.canSell)
            return;

        if (equipment.IsSkin() && equipment.state == EquipmentState.Character)
            return;
        bool success = SafeRemoveEquipment(equipment);
        if (!success)
        {
            return;
        }

        CurrencyData cost = equipment.GetSellCost();
        AddCost(cost);


        if (equipment.state == EquipmentState.Inventory || equipment.state == EquipmentState.New)
        {
            if (equipment.equipmentType == EquipmentType.Key)
            {
                LogicSellKey(equipment);
            }
        }

        if (cost.currencyId == TH_COIN_ID)
        {
            SellItemTHCallback(this.connectionToClient);
        }

        //if (card.isTradable && card.equipmentType != EquipmentType.Ingredient)
        //    BattleManager.Log(GameLogType.UserTracking, this.userName + " - " + this.characterName + " have sell " + equipment.id + " " + equipment.equipmentType + " " + equipment.rareType + " for " + cost.value + " ID: " + cost.currencyId);

        if (equipment.madeBy != "" && (card.isTradable || equipment.rareType == RareType.Legendary))
        {
            // ========== 🆕 LOGGING: Sell Crafted Item ==========
            Log(LogAction.SellCraftedItem,
                $"Type:{equipment.equipmentType}|Item:{card.GetName(0)}|Rare:{equipment.rareType}|Lv:{equipment.level}|Price:{cost.value}",
                equipment.ToJson(),
                cost.value.ToString());
            // ========== END Sell Crafted Item Logging ==========
        }
#endif
    }

    private void LogicSellKey(Equipment equipment)
    {
#if ENABLE_SERVER
        var landID = equipment.itemId == DIAMOND_KEY_ID ? WorldManager.CENTER_LAND_NAME : WorldManager.UNDEAD_LAND_NAME;
        var key = ChestKeyManager.Instance.GetKey(landID);
        if (key == null) return;

        NetworkServer.Destroy(key.gameObject);


        //if (equipment.itemId == DIAMOND_KEY_ID && BattleManager.instance.keyBehavior != null)
        //{
        //    NetworkServer.Destroy(BattleManager.instance.keyBehavior.gameObject);
        //}
        //else if (equipment.itemId == UNDEAD_KEY_ID &&
        //    BattleManager.instance.GetUndeadKeyBehavior().Count > 0)
        //{
        //    var keyBehavior = BattleManager.instance.GetUndeadKeyBehavior()[0];
        //    if (keyBehavior != null)
        //    {
        //        BattleManager.instance.RemoveUndeadKeyBehavior(keyBehavior);
        //        NetworkServer.Destroy(keyBehavior.gameObject);
        //    }
        //}
#endif
    }

    [TargetRpc]
    private void SellItemTHCallback(NetworkConnectionToClient networkConnectionToClient)
    {
        //RequestGetWalletData();
    }

    //----------------------------------------------------------------
    //Request Lock Item
    //----------------------------------------------------------------
    [Client]
    public void RequestLockItem(string equipmentId, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdLockItem(equipmentId, apiToken);
    }

    [Command]
    public void CmdLockItem(string equipmentId, int apiToken)
    {
#if ENABLE_SERVER
        if (this.GetHealth() <= 0)
            return;

        if (this.userName == "" || equipmentId == "")
        {
            return;
        }

        if (!ServerValidateApiToken(apiToken, nameof(CmdLockItem)))
            return;

        Equipment equipment = GetEquipment(equipmentId);

        if (equipment == null)
            return;

        if (equipment.itemId == BODY_DEFAULT_ID)
        {
            return;
        }

        // Client only offers the lock button for CanLock() items; collection/title/ingredient/etc. are not lockable.
        if (!equipment.CanLock())
        {
            Log(LogAction.SuspiciousActivity,
                $"Type:LockItemInvalidType|ItemId:{equipment.itemId}|EquipmentType:{equipment.equipmentType}|State:{equipment.state}");
            return;
        }

        equipment.isLock = true;

        ResetEquipment(equipment);

        BattleManager.instance.SavePlayerData(this);
#endif
    }


    //----------------------------------------------------------------
    //Request UnLock Item
    //----------------------------------------------------------------
    [Client]
    public void RequestUnLockItem(string equipmentId, int apiToken, string passCode)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdUnLockItem(equipmentId, apiToken, passCode);
    }

    [Command]
    public void CmdUnLockItem(string equipmentId, int apiToken, string passCode)
    {
#if ENABLE_SERVER
        if (this.GetHealth() <= 0)
            return;

        if (!ServerValidateApiToken(apiToken, nameof(CmdUnLockItem)))
            return;

        var isCorrect = CheckWalletPassCode(passCode);
        if (isCorrect == false)
        {
            return;
        }

        if (this.userName == "" || equipmentId == "")
        {
            return;
        }

        Equipment equipment = GetEquipment(equipmentId);
        if (equipment == null)
            return;

        bool soldByAutoSell = false;
        equipment.isLock = false;

        // Re-evaluate auto-sell when item transitions from locked to unlocked.
        soldByAutoSell = TryAutoSellExistingEquipment(equipment);

        if (!soldByAutoSell)
        {
            ResetEquipment(equipment);
        }

        BattleManager.instance.SavePlayerData(this);
#endif
    }

    private bool CheckWalletPassCode(string passCode)
    {
        if (string.IsNullOrEmpty(characterInventory.walletPassCode))
        {
            return true;
        }

        return VerifyWalletPinHash(passCode);
    }

    /// <summary>
    /// Compares an already hashed PIN with the stored one. Wrong guesses are counted per account and lock PIN checks
    /// for WalletPinLockout.LockSeconds after WalletPinLockout.MaxFailedAttempts misses. An empty value is not a guess and is not counted.
    /// </summary>
    private bool VerifyWalletPinHash(string passCodeHash)
    {
        if (string.IsNullOrEmpty(characterInventory.walletPassCode))
        {
            RpcWrongPassCode(connectionToClient);
            return false;
        }

        if (WalletPinLockout.IsLocked(userName, System.DateTime.UtcNow))
        {
            RpcWrongPassCode(connectionToClient);
            return false;
        }

        if (string.IsNullOrEmpty(passCodeHash))
        {
            RpcWrongPassCode(connectionToClient);
            return false;
        }

        if (characterInventory.walletPassCode != passCodeHash)
        {
            if (WalletPinLockout.RegisterFailure(userName, System.DateTime.UtcNow))
                Log(LogAction.SuspiciousActivity, "Reason:WalletPinLocked|Time:" + DataUtils.TimeToString(System.DateTime.Now));
            RpcWrongPassCode(connectionToClient);
            return false;
        }

        WalletPinLockout.Reset(userName);
        return true;
    }

    //----------------------------------------------------------------
    //Request Sell shared Item
    //----------------------------------------------------------------
    [Client]
    public void RequestSellShardItem(string equipmentId, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdSellShardItem(equipmentId, apiToken);
    }

    [Command]
    public void CmdSellShardItem(string equipmentId, int apiToken)
    {
#if ENABLE_SERVER
        if (this.GetHealth() <= 0)
            return;

        if (equipmentId == "")
        {
            return;
        }

        if (!ServerValidateApiToken(apiToken, nameof(CmdSellShardItem)))
            return;

        if ((System.DateTime.Now - lastSellTime).TotalSeconds < SellCommandCooldownSeconds)
            return;

        lastSellTime = System.DateTime.Now;

        Equipment equipment = GetEquipment(equipmentId);
        if (equipment == null || equipment.state == EquipmentState.Lock || equipment.state == EquipmentState.Trading)
            return;

        if (equipment.isLock || equipment.IsCrafted() == false || equipment.equipmentType == EquipmentType.Summon
            || equipment.equipmentType == EquipmentType.Scroll || equipment.equipmentType == EquipmentType.Ingredient
            || equipment.equipmentType == EquipmentType.EventItem)
            return;

        Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
        if (card == null || !card.canSell)
            return;

        if (equipment.IsSkinEquiped())
            return;

        bool result = SafeRemoveEquipment(equipment);

        if (result)
        {
            CurrencyData cost = equipment.GetShardCost();
            AddCost(cost);

            // Log sell shard with equipment type for easy identification
            Log(LogAction.SellShard,
                "Type:" + equipment.equipmentType + "|Item:" + card.GetName(0) + "|Rare:" + equipment.rareType + "|Lv:" + equipment.level + "|Shard:" + cost.value,
                equipment.ToJson(),
                value: cost.value.ToString());


            BattleManager.instance.SavePlayerData(this);
        }

#endif
    }

    //----------------------------------------------------------------
    //Request Upgrade Item
    //----------------------------------------------------------------
    [Client]
    public void RequestUpgradeItem(string equipmentId, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        //HelpManager.IsUpgradeEquipment = true;
        CmdUpgradeItem(equipmentId, apiToken);
    }

    [Command]
    public void CmdUpgradeItem(string equipmentId, int apiToken)
    {
#if ENABLE_SERVER
        if (this.GetHealth() <= 0)
            return;

        if (equipmentId == "")
        {
            return;
        }

        if (!ServerValidateApiToken(apiToken, nameof(CmdUpgradeItem)))
            return;

        bool canUpgrade = true;
        Equipment equipment = GetEquipment(equipmentId);

        if (equipment != null)
        {
            if (equipment.state == EquipmentState.New)
                equipment.state = EquipmentState.Inventory;

            if (equipment.IsCollection())
                return;

            Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);

            if (card == null || !card.canUpgrade)
                return;

            if (equipment.level >= BattleManager.instance.gameDataConfig.maxLevel)
            {
                canUpgrade = false;
            }
            else
            {
                CurrencyData cost = equipment.GetUpgradeCost();

                CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);
                if (characterData != null)
                {
                    cost.value = (int)(cost.value * (1f - characterData.GetVipStatValue(VipBonusType.UpgradeCost)));
                }

                if (HaveEnoughMoney(cost))
                {
                    PayCost(cost);
                    equipment.level++;
                    ResetEquipment(equipment);
                }
            }

            if (canUpgrade)
            {
                BattleManager.Log(GameLogType.Debug, $"Player upgrade item {equipmentId} - Find And Replace this item in EquipmentSet");

                OnUpdateStats();
                if (card.isTradable)
                    BattleManager.instance.SavePlayerData(this);
            }
            else
            {
                BattleManager.instance.SendServerNotificationToTarget(this.connectionToClient, 142, NotifyType.ToastView);
            }
        }


#endif
    }

    //----------------------------------------------------------------
    //Request Upgrade Item To Level
    //----------------------------------------------------------------
    [Client]
    public void RequestUpgradeItemToLevel(string equipmentId, int targetLevel, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdUpgradeItemToLevel(equipmentId, targetLevel, apiToken);
    }

    [Command]
    public void CmdUpgradeItemToLevel(string equipmentId, int targetLevel, int apiToken)
    {
#if ENABLE_SERVER
        if (this.GetHealth() <= 0)
            return;

        if (equipmentId == "")
        {
            return;
        }

        if (!ServerValidateApiToken(apiToken, nameof(CmdUpgradeItemToLevel)))
            return;

        Equipment equipment = GetEquipment(equipmentId);
        if (equipment == null)
            return;

        if (equipment.state == EquipmentState.New)
            equipment.state = EquipmentState.Inventory;

        if (equipment.IsCollection())
            return;

        Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
        if (card == null || !card.canUpgrade)
            return;

        if (equipment.level < 0)
        {
            equipment.level = 0;
        }

        int maxLevel = BattleManager.instance.gameDataConfig.maxLevel;
        targetLevel = Mathf.Clamp(targetLevel, equipment.level, maxLevel);
        if (equipment.level >= targetLevel)
            return;

        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);
        bool upgraded = false;

        while (equipment.level < targetLevel)
        {
            CurrencyData cost = equipment.GetUpgradeCost();
            if (characterData != null)
            {
                cost.value = (int)(cost.value * (1f - characterData.GetVipStatValue(VipBonusType.UpgradeCost)));
            }

            if (HaveEnoughMoney(cost) == false)
            {
                break;
            }

            PayCost(cost);
            equipment.level++;
            upgraded = true;
        }

        if (upgraded)
        {
            ResetEquipment(equipment);
            OnUpdateStats();
            if (card.isTradable)
                BattleManager.instance.SavePlayerData(this);
        }
        else if (equipment.level >= maxLevel)
        {
            BattleManager.instance.SendServerNotificationToTarget(this.connectionToClient, 142, NotifyType.ToastView);
        }
#endif
    }

    //----------------------------------------------------------------
    //Request Upgrade Max Item
    //----------------------------------------------------------------
    [Client]
    public void RequestUpgradeMaxItem(string equipmentId, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdUpgradeMaxItem(equipmentId, apiToken);
    }

    [Command]
    public void CmdUpgradeMaxItem(string equipmentId, int apiToken)
    {
#if ENABLE_SERVER
        if (this.GetHealth() <= 0)
            return;

        if (equipmentId == "")
        {
            return;
        }

        if (!ServerValidateApiToken(apiToken, nameof(CmdUpgradeMaxItem)))
            return;

        bool canUpgrade = true;
        Equipment equipment = GetEquipment(equipmentId);

        if (equipment != null)
        {
            if (equipment.state == EquipmentState.New)
                equipment.state = EquipmentState.Inventory;

            Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);

            if (card == null || !card.canUpgrade)
                return;

            if (equipment.level >= BattleManager.instance.gameDataConfig.maxLevel)
            {
                canUpgrade = false;
            }
            else
            {
                CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);
                for (int i = equipment.level; i < BattleManager.instance.gameDataConfig.maxLevel; i++)
                {
                    CurrencyData cost = equipment.GetUpgradeCost();

                    if (characterData != null)
                    {
                        cost.value = (int)(cost.value * (1f - characterData.GetVipStatValue(VipBonusType.UpgradeCost)));
                    }

                    if (HaveEnoughMoney(cost))
                    {
                        PayCost(cost);
                        equipment.level++;
                    }
                    else
                    {
                        break;
                    }
                }
                ResetEquipment(equipment);
            }

            if (canUpgrade)
            {
                OnUpdateStats();
                if (card.isTradable)
                    BattleManager.instance.SavePlayerData(this);
            }
        }


#endif
    }


    //----------------------------------------------------------------
    //Request Send Item To Wallet
    //----------------------------------------------------------------
    [Client]
    public void RequestSendItemToWallet(string equipmentId, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdMoveToWallet(equipmentId, apiToken);
    }

    [Command]
    public void CmdMoveToWallet(string equipmentId, int apiToken)
    {
#if ENABLE_SERVER
        if (this.userName == "" || equipmentId == "")
        {
            return;
        }

        if (!ServerValidateApiToken(apiToken, nameof(CmdMoveToWallet)) || GetLandType() == LandType.BeginnerLand)
            return;

        Equipment equipment = characterInventory.GetEquipment(equipmentId);
        if (equipment == null)
        {
            equipment = characterIngredient.GetEquipment(equipmentId);
            if (equipment == null)
            {
                equipment = characterCollection.GetEquipment(equipmentId);
                if (equipment == null)
                {
                    return;
                }
            }
        }

        Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
        if (card == null)
            return;

        var errorCode = equipment.CanSendToWallet(card);
        if (errorCode != ErrorCode.Success)
        {
            return;
        }

        WalletData walletData = BattleManager.instance.GetWalletData(userName);
        if (walletData == null)
            return;

        if (equipment.equipmentType == EquipmentType.Ingredient)
        {
            if (walletData.IsHaveIngredientSlot())
            {
                equipment.state = EquipmentState.Ingredient;
                SafeRemoveEquipment(equipment);
                BattleManager.instance.AddWalletItem(walletData, equipment);
            }
            else
            {
                return;
            }
        }
        else
        {
            if (walletData.IsHaveInventorySlot())
            {
                equipment.state = EquipmentState.Inventory;
                SafeRemoveEquipment(equipment);
                BattleManager.instance.AddWalletItem(walletData, equipment);
            }
            else
            {
                return;
            }
        }

        // Log move to wallet with equipment type (reuse 'card' variable from above)
        Log(LogAction.MoveToWallet,
            "Type:" + equipment.equipmentType + "|Item:" + (card != null ? card.GetName(0) : equipment.itemId.ToString()) + "|Rare:" + equipment.rareType + "|Lv:" + equipment.level,
            equipment.ToJson());
        BattleManager.instance.SavePlayerData(this);
#endif
    }

    //----------------------------------------------------------------
    //Request Move Item From Wallet
    //----------------------------------------------------------------
    [Client]
    public void RequestMoveItemFromWallet(string equipmentId, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdTakeFromWallet(equipmentId, apiToken);
    }

    [Command]
    public void CmdTakeFromWallet(string equipmentId, int apiToken)
    {
#if ENABLE_SERVER
        if (equipmentId == "" || GetLandType() == LandType.BeginnerLand)
            return;

        WalletData walletData = BattleManager.instance.GetWalletData(userName);
        if (walletData == null)
            return;

        if (!ServerValidateApiToken(apiToken, nameof(CmdTakeFromWallet)))
            return;

        Equipment equipment = walletData.GetEquipment(equipmentId);
        if (equipment == null || equipment.state == EquipmentState.Trading)
        {
            RpcTakeFromWallet(connectionToClient, false);
            return;
        }

        BattleManager.instance.RemoveWalletItem(walletData, equipment);


        if (equipment.equipmentType == EquipmentType.Ingredient)
        {
            characterIngredient.AddEquipment(equipment);
        }
        else if (equipment.IsCollection())
        {
            characterCollection.AddEquipment(equipment);
        }
        else
        {
            characterInventory.AddEquipment(equipment);
        }

        // Log take from wallet with equipment type
        Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
        Log(LogAction.TakeFromWallet,
            "Type:" + equipment.equipmentType + "|Item:" + (card != null ? card.GetName(0) : equipment.itemId.ToString()) + "|Rare:" + equipment.rareType + "|Lv:" + equipment.level,
            equipment.ToJson());
        BattleManager.instance.SavePlayerData(this);
#endif
    }

    [TargetRpc]
    void RpcTakeFromWallet(NetworkConnectionToClient networkConnectionToClient, bool isSucces)
    {
        if (!isSucces)
            return;

#if ENABLE_CLIENT && !ENABLE_ADMIN
        // ✅ SERVER-ONLY: Add null check for UIManager
        if (UIManager.instance == null) return;
#endif
    }


    //----------------------------------------------------------------
    //Request Unlock Wallet InventorySlot
    //----------------------------------------------------------------
    [Client]
    public void RequestUnLockWalletInventorySlot(int apiToken, string walletPassCode)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdUnlockWalletInventorySlot(apiToken, walletPassCode);
    }


    [Command]
    private void CmdUnlockWalletInventorySlot(int apiToken, string walletPassCode)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdUnlockWalletInventorySlot)) || GetLandType() == LandType.BeginnerLand)
            return;

        var isCorrect = CheckWalletPassCode(walletPassCode);
        if (isCorrect == false)
        {
            return;
        }

        WalletData walletData = BattleManager.instance.GetWalletData(userName);
        if (walletData == null)
            return;

        int cost = walletData.GetCostUnlockSlotInventory();
        if (walletData.token < cost)
            return;

        BattleManager.instance.AddToken(walletData, -cost);
        EconomyManager.RecordThBurn(cost, "th_tool_inventory_slot");
        walletData.SlotInventory++;
        characterWallet.slotInventory = walletData.SlotInventory;
        BattleManager.instance.SaveWalletData(walletData);

        Log(LogAction.BuyShopTH,
            $"Unlock Inventory Slot|Cost:{cost}",
            value: cost.ToString());

        // ✅ Send RPC with cost for analytics tracking
        RpcUnlockWalletInventorySlot(this.connectionToClient, cost);
#endif
    }

    //----------------------------------------------------------------
    //Request Unlock Wallet IngredientSlot
    //----------------------------------------------------------------
    [Client]
    public void RequestUnLockWalletIngredientSlot(int apiToken, string walletPassCode)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdUnlockWalletIngredientSlot(apiToken, walletPassCode);
    }

    [Command]
    private void CmdUnlockWalletIngredientSlot(int apiToken, string walletPassCode)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdUnlockWalletIngredientSlot)) || GetLandType() == LandType.BeginnerLand)
            return;

        var isCorrect = CheckWalletPassCode(walletPassCode);
        if (isCorrect == false)
        {
            return;
        }

        WalletData walletData = BattleManager.instance.GetWalletData(userName);
        if (walletData == null)
            return;

        int cost = walletData.GetCostUnlockSlotIngredient();
        if (walletData.token < cost)
            return;

        BattleManager.instance.AddToken(walletData, -cost);
        EconomyManager.RecordThBurn(cost, "th_tool_inventory_slot");
        walletData.slotIngredient++;
        characterWallet.slotIngredient = walletData.slotIngredient;
        BattleManager.instance.SaveWalletData(walletData);

        Log(LogAction.BuyShopTH,
            $"Unlock Ingredient Slot|Cost:{cost}",
            value: cost.ToString());

        // ✅ Send RPC with cost for analytics tracking
        RpcUnlockWalletIngredientSlot(this.connectionToClient, cost);
#endif
    }

    [TargetRpc]
    void RpcUnlockWalletInventorySlot(NetworkConnectionToClient networkConnectionToClient, int cost)
    {
#if ENABLE_CLIENT
        // ✅ Track TH Consumed (wallet inventory slot unlock)
#if ENABLE_ANALYTIC_SERVICE
        if (cost > 0 && AnalyticsManager.instance != null)
        {
            AnalyticsManager.instance.TrackTHConsumed(cost, "wallet_slot_inventory");
        }
#endif
#endif
    }

    [TargetRpc]
    void RpcUnlockWalletIngredientSlot(NetworkConnectionToClient networkConnectionToClient, int cost)
    {
#if ENABLE_CLIENT
        // ✅ Track TH Consumed (wallet ingredient slot unlock)
#if ENABLE_ANALYTIC_SERVICE
        if (cost > 0 && AnalyticsManager.instance != null)
        {
            AnalyticsManager.instance.TrackTHConsumed(cost, "wallet_slot_ingredient");
        }
#endif
#endif
    }

    //----------------------------------------------------------------
    //Request Create Order
    //----------------------------------------------------------------
    private bool TryBlockMarketVietnam()
    {
        if (UIManager.instance == null || !UIManager.instance.IsMarketVietnamBlocked())
        {
            return false;
        }

        if (IngameNotifyManager.instance != null)
        {
            IngameNotifyManager.instance.OnToastView(UIManager.GetDialog(1387));
        }

        return true;
    }

    [Client]
    public void RequestCreateOrder(string equipmentId, int price, int apiToken, string walletPassCode)
    {
        if (!NetworkClient.isConnected)
            return;

        if (TryBlockMarketVietnam())
            return;

        if (!BattleManager.TryGetGameDataConfig(out var config, logWarning: false))
        {
            // Config chưa load, vẫn cho phép request để server xử lý
            CmdCreateOrder(equipmentId, price, apiToken, walletPassCode);
            return;
        }

        if (!config.canCreateOrder)
        {
            // TODO:dialog -> Tính năng tạo đơn hàng trên chợ đang tạm thời bị vô hiệu hóa
            if (IngameNotifyManager.instance != null)
            {
                IngameNotifyManager.instance.OnToastView(UIManager.GetDialog(1211));
            }
            return;
        }

        CmdCreateOrder(equipmentId, price, apiToken, walletPassCode);
    }


    [Command]
    public void CmdCreateOrder(string equipmentId, int price, int apiToken, string walletPassCode)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdCreateOrder)) || GetLandType() == LandType.BeginnerLand)
            return;

        if (!BattleManager.instance.gameDataConfig.canCreateOrder)
        {
            BattleManager.Log(GameLogType.Debug, $"[CmdCreateOrder] canCreateOrder is disabled. User: {userName}, EquipmentId: {equipmentId}, Price: {price}");
            return;
        }

        AccountInfo accountInfo = BattleManager.instance.GetAccountInfo(this.userName);

        if (accountInfo == null)
            return;

#if !ENABLE_SERVER_BETA && !ENABLE_SERVER_TEST
        if (string.IsNullOrEmpty(accountInfo.email) || !DataUtils.IsValidEmail(accountInfo.email))
        {
            BattleManager.instance.gameLogicBehavior.SendServerMessage(
                connectionToClient,
                "Account need to link with email in order to create order",
                -1);
            return;
        }
#endif


        if (string.IsNullOrEmpty(equipmentId) || string.IsNullOrEmpty(userName) || !MarketOrderValidation.HasPositivePrice(price))
            return;

        var isCorrect = CheckWalletPassCode(walletPassCode);
        if (isCorrect == false)
        {
            return;
        }

        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);



        WalletData walletData = BattleManager.instance.GetWalletData(userName);
        if (walletData == null)
            return;

        Equipment equipment = walletData.GetEquipment(equipmentId);
        Card card = equipment != null ? DataHolder.Instance().GetData<Card>(equipment.itemId) : null;
        if (equipment == null || card == null || equipment.CanCreateMarketOrder(card) != ErrorCode.Success)
            return;

        int listingCost = BattleManager.instance.GetListingPrice(price, equipment);
        if (characterData != null)
            listingCost = listingCost - (int)characterData.GetVipStatValue(VipBonusType.ListingCost);

        if (listingCost < 1)
            listingCost = 1;

        if (walletData.token < listingCost)
            return;

        int maxPrice = equipment.GetMarketCost();
        int minPrice = equipment.equipmentType == EquipmentType.Blueprint
            ? Equipment.BlueprintMarketMinPrice : maxPrice / 160;
        //if (minPrice > 50)
        //    minPrice = 50;

        if (!MarketOrderValidation.IsWithinInclusiveRange(price, minPrice, maxPrice))
        {
            RpcCreateOrderMaxValue(this.connectionToClient, equipmentId, maxPrice, minPrice, null);
            return;
        }

        equipment.state = EquipmentState.Trading;
        characterWallet.AddOrUpdateEquipment(equipment);

        OrderData orderData = new()
        {
            id = System.Guid.NewGuid().ToString() + BattleManager.instance.serverConfig.serverIndex.ToLower(),
            equipment = new Equipment(equipment),
            price = price,
            seller = userName,
            sellerCharacterName = characterName,
            seasonId = BattleManager.instance.serverConfig.seasonId,
            orderState = OrderState.Ready,
#if ENABLE_SERVER_BETA || ENABLE_SERVER_TEST
            activeTIme = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(Random.Range(170, 180))),
#else
            activeTIme = DataUtils.TimeToString(System.DateTime.Now.AddMinutes(Random.Range(2, 30))),
#endif

            created = DataUtils.TimeToString(System.DateTime.Now),
            lastUpdate = DataUtils.TimeToString(System.DateTime.Now)
        };

        //BattleManager.Log(GameLogType.UserTracking, walletData.userName + " have create order " + orderData.id + " price: " + orderData.price + " equipment " + equipment.equipmentType);

        // ========== 🆕 LOGGING: Create Order ==========
        Log(LogAction.CreateOrder,
            $"Type:{equipment.equipmentType}|Item:{(card != null ? card.GetName(0) : equipment.itemId.ToString())}|Rare:{equipment.rareType}|Lv:{equipment.level}|Price:{price}",
            equipment.ToJson(),
            value: price.ToString());
        // ========== END Create Order Logging ==========

        BattleManager.instance.AddToken(walletData, -listingCost, "System", orderData.id);
        EconomyManager.RecordListingCost(listingCost);
        EconomyManager.RecordThBurn(listingCost, "marketplace_listing_fee");
        BattleManager.instance.SaveWalletData(walletData);
        BattleManager.instance.readyOrders.Add(orderData);
        BattleManager.instance.CreateOrEditOrderData(orderData.id, orderData);
        RpcCreateOrder(this.connectionToClient, equipmentId, orderData, listingCost);  // ✅ Pass listing cost for analytics
#endif
    }

    [TargetRpc]
    void RpcCreateOrder(NetworkConnectionToClient networkConnectionToClient, string equipmentId, OrderData orderData, int listingCost)
    {
#if ENABLE_CLIENT && !ENABLE_ADMIN
        /*
        var walletView = UIManager.instance.FindView<WalletView>();
        if (walletView.IsOpen)
        {
            walletView.CreateOrderCallback(equipmentId);
        }*/
#endif
#if ENABLE_MMO_WEB_API && ENABLE_CLIENT && !ENABLE_ADMIN
        if (orderData != null)
        {
            MmoApiManager.GetInstance().SendEvent(MCP.Mmo.DataModels.Common.MmoEventType.MarketplaceOrderCreated, orderData.ToJson());
        }
#endif

        // ✅ Track Market CreateOrder Analytics
#if ENABLE_ANALYTIC_SERVICE
        if (orderData != null && AnalyticsManager.instance != null)
        {
            AnalyticsManager.instance.TrackMarketCreateOrder(
                orderData.id,
                orderData.equipment.itemId,
                orderData.price,
                orderData.equipment.equipmentType
            );
            
            // ✅ Track TH Consumed (listing cost)
            if (listingCost > 0)
            {
                AnalyticsManager.instance.TrackTHConsumed(listingCost, "marketplace_listing");
            }
        }
#endif
    }



    [TargetRpc]
    void RpcCreateOrderMaxValue(NetworkConnectionToClient networkConnectionToClient, string equipmentId, int maxPrice, int minPrice, OrderData orderData)
    {
#if ENABLE_CLIENT && !ENABLE_ADMIN
        // ✅ SERVER-ONLY: Add null check for UIManager
        if (UIManager.instance == null) return;

        var walletView = UIManager.instance.FindView<WalletView>();
        walletView.CreateOderFailCallback(maxPrice, minPrice, equipmentId);
#endif
    }

    //----------------------------------------------------------------
    //Request Get Order
    //----------------------------------------------------------------
    [Client]
    public void RequestGetOrder(string id)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdGetOrder(id, ClientManager.instance.GetApiToken());
    }

    [Command]
    public void CmdGetOrder(string id, int apiToken)
    {
#if ENABLE_SERVER
        if (this.userName == "" || string.IsNullOrEmpty(id) || GetLandType() == LandType.BeginnerLand)
        {
            return;
        }

        if (!ServerValidateApiToken(apiToken, nameof(CmdGetOrder)))
        {
            return;
        }

        if (BattleManager.instance.orderDatas.ContainsKey(id))
            RpcGetOrder(this.connectionToClient, BattleManager.instance.orderDatas[id]);
#endif
    }

    [TargetRpc]
    void RpcGetOrder(NetworkConnectionToClient networkConnectionToClient, OrderData orderData)
    {
#if ENABLE_ADMIN
        if (AdminManager.instance != null)
            AdminManager.instance.orderData = orderData;
#endif

    }

    //----------------------------------------------------------------
    //Request Update Order (Cancel, Update Price)
    //----------------------------------------------------------------
    [Client]
    public void RequestUpdateOrder(string id, bool isCancel, int price, int apiToken, string walletPassCode)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdUpdateOrderData(id, isCancel, price, apiToken, walletPassCode);
    }



    [Command]
    public void CmdUpdateOrderData(string id, bool isCancel, int price, int apiToken, string walletPassCode)
    {
#if ENABLE_SERVER
        if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(userName))
        {
            BattleManager.Log(GameLogType.Warning, $"[CmdUpdateOrderData] {userName} update order fail. ID: {id}");
            return;
        }

        if (!ServerValidateApiToken(apiToken, nameof(CmdUpdateOrderData)))
        {
            BattleManager.Log(GameLogType.Warning, $"[CmdUpdateOrderData] {userName} update order fail. Token invalid");
            return;
        }

        AccountInfo accountInfo = BattleManager.instance.GetAccountInfo(this.userName);

        if (accountInfo == null)
            return;

#if !ENABLE_SERVER_BETA && !ENABLE_SERVER_TEST
        if (string.IsNullOrEmpty(accountInfo.email) || !DataUtils.IsValidEmail(accountInfo.email))
        {
            BattleManager.instance.gameLogicBehavior.SendServerMessage(
                connectionToClient,
                "Account need to link with email in order to create order",
                -1);
            return;
        }
#endif

        if (!MarketOrderValidation.HasPositivePrice(price))
        {
            BattleManager.Log(GameLogType.Warning, $"[CmdUpdateOrderData] {userName} update order fail. Price invalid " + price);
            return;
        }

        if (GetLandType() == LandType.BeginnerLand)
        {
            BattleManager.Log(GameLogType.Warning, $"[CmdUpdateOrderData] {userName} update order in beginner land");
            return;
        }

        var isCorrect = CheckWalletPassCode(walletPassCode);
        if (isCorrect == false)
        {
            RpcUpdateOrder_1(this.connectionToClient, null, 0, 0, 0);
            return;
        }

        OrderData orderData = BattleManager.instance.GetOrderData(id);
        if (orderData == null)
        {
            BattleManager.Log(GameLogType.Warning, $"[CmdUpdateOrderData] {userName} update order fail. OrderData not found. ID: {id}");
            return;
        }

        if (orderData.equipment == null || !string.Equals(orderData.seller, userName, System.StringComparison.Ordinal))
        {
            BattleManager.Log(GameLogType.Warning,
                $"[CmdUpdateOrderData] {userName} attempted to update order owned by {orderData.seller}. ID: {id}");
            return;
        }

        if (!MarketOrderValidation.CanSellerUpdate(
                orderData.orderState == OrderState.Active,
                orderData.orderState == OrderState.Ready))
        {
            BattleManager.Log(GameLogType.Warning, $"[CmdUpdateOrderData] {userName} update order fail. OrderData state invalid: {orderData.orderState}");
            return;
        }

        WalletData walletData = BattleManager.instance.GetWalletData(userName);
        if (walletData == null)
        {
            BattleManager.Log(GameLogType.Warning, $"[CmdUpdateOrderData] {userName} update order fail. walletData not found");
            return;
        }

        Equipment equipment = walletData.GetEquipment(orderData.equipment.id);
        if (equipment == null)
        {
            BattleManager.Log(GameLogType.Warning, $"[CmdUpdateOrderData] {userName} update order fail. Equipment not found. ID: {orderData.equipment.id}");
            return;
        }

        if (orderData.equipment == null || orderData.equipment.id != equipment.id ||
            orderData.equipment.itemId != equipment.itemId ||
            orderData.equipment.equipmentType != equipment.equipmentType)
        {
            BattleManager.Log(GameLogType.Warning,
                $"[MarketOrderGuard] User:{userName}|Order:{id}|Equipment:{equipment.id}|Item:{equipment.itemId}|RuntimeType:{equipment.equipmentType}");
            return;
        }

        if (equipment.state != EquipmentState.Trading)
        {
            BattleManager.Log(GameLogType.Warning, $"[CmdUpdateOrderData] {userName} update order fail. Equipment state invalid. ID: {equipment.state}");
            return;
        }

        // Capture old price and calculate range
        int oldPrice = orderData.price;
        int maxPrice = equipment.GetMarketCost();
        int minPrice = equipment.equipmentType == EquipmentType.Blueprint
            ? Equipment.BlueprintMarketMinPrice : maxPrice / 160;

        if (!isCancel && !MarketOrderValidation.IsWithinInclusiveRange(price, minPrice, maxPrice))
        {
            RpcUpdateOrder_1(this.connectionToClient, null, maxPrice, minPrice, 0);
            return;
        }

        orderData.lastUpdate = DataUtils.TimeToString(System.DateTime.Now);

        if (isCancel)
        {
            orderData.orderState = OrderState.Cancel;

            Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
            if (card != null)
            {
                if (card.equipmentType == EquipmentType.Ingredient)
                {
                    equipment.state = EquipmentState.Ingredient;
                }
                else
                {
                    equipment.state = EquipmentState.Inventory;
                }
            }
            else
            {
                equipment.state = EquipmentState.Inventory;
            }

            Log(LogAction.UpdateOrder,
                "OrderID:" + orderData.id + "|Action:Cancel|Type:" + equipment.equipmentType + "|Item:" + (card != null ? card.GetName(0) : equipment.itemId.ToString()) + "|Rare:" + equipment.rareType + "|Lv:" + equipment.level + "|Price:" + oldPrice,
                equipment.ToJson(),
                value: oldPrice.ToString());
        }
        else
        {
            int listingPrice = BattleManager.instance.GetListingPrice(price, equipment);

            CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);

            if (characterData != null)
                listingPrice = listingPrice - (int)characterData.GetVipStatValue(VipBonusType.ListingCost);

            if (listingPrice < 1)
                listingPrice = 1;

            if (walletData.token < listingPrice)
            {
                return;
            }
            BattleManager.instance.AddToken(walletData, -listingPrice, "System", orderData.id);
            EconomyManager.RecordListingCost(listingPrice);
            EconomyManager.RecordThBurn(listingPrice, "marketplace_listing_fee");
            orderData.price = price;
            orderData.orderState = OrderState.Ready;
#if ENABLE_SERVER_BETA || ENABLE_SERVER_TEST
            orderData.activeTIme = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(Random.Range(30, 60)));
#else
            orderData.activeTIme = DataUtils.TimeToString(System.DateTime.Now.AddMinutes(Random.Range(2, 30)));
#endif

            Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
            Log(LogAction.UpdateOrder,
                "OrderID:" + orderData.id + "|Action:UpdatePrice|Type:" + equipment.equipmentType + "|Item:" + (card != null ? card.GetName(0) : equipment.itemId.ToString()) + "|Rare:" + equipment.rareType + "|Lv:" + equipment.level + "|OldPrice:" + oldPrice + "|NewPrice:" + price + "|Min:" + minPrice + "|Max:" + maxPrice,
                equipment.ToJson(),
                value: price.ToString());
        }

        characterWallet.AddOrUpdateEquipment(equipment);
        BattleManager.instance.SaveWalletData(walletData);
        BattleManager.instance.CreateOrEditOrderData(orderData.id, orderData);

        // ✅ Get listing cost for analytics (0 if cancel, actual cost if update price)
        int listingCost = 0;
        if (!isCancel)
        {
            int listingPrice = BattleManager.instance.GetListingPrice(price, equipment);
            CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);
            if (characterData != null)
                listingPrice = listingPrice - (int)characterData.GetVipStatValue(VipBonusType.ListingCost);
            if (listingPrice < 1)
                listingPrice = 1;
            listingCost = listingPrice;
        }

        ServerRefreshMarketOrders(true);
        RpcUpdateOrder_1(this.connectionToClient, orderData, orderData.price, 1, listingCost);
#endif
    }

    [TargetRpc]
    void RpcMissingWalletIdentity(NetworkConnectionToClient networkConnectionToClient)
    {
        if (UIManager.instance == null)
            return;

        UIManager.instance.FindView<MarketPlaceView>().Close();
#if ENABLE_CLIENT
        UIManager.instance.FindView<WalletView>().Close();
        UIManager.instance.PromptMissingMarketplaceEmail();
#endif
    }

    [TargetRpc]
    void RpcUpdateOrder_1(NetworkConnectionToClient networkConnectionToClient, OrderData orderData, int maxPrice, int minPrice, int listingCost)
    {
        if (UIManager.instance == null)
            return;

        UIManager.instance.FindView<MarketPlaceView>().UpdateOrderCallback(orderData, maxPrice, minPrice);
#if ENABLE_MMO_WEB_API && ENABLE_CLIENT && !ENABLE_ADMIN
        if (orderData != null)
        {
            if (orderData.orderState == OrderState.Cancel)
            {
                MmoApiManager.GetInstance().SendEvent(MCP.Mmo.DataModels.Common.MmoEventType.MarketplaceOrderCancelled, orderData.ToJson());
            }
            else
            {
                MmoApiManager.GetInstance().SendEvent(MCP.Mmo.DataModels.Common.MmoEventType.MarketplaceOrderPriceUpdated, orderData.ToJson());
            }
        }
#endif

        // ✅ Track Market UpdateOrder Analytics
#if ENABLE_ANALYTIC_SERVICE
        if (orderData != null && AnalyticsManager.instance != null)
        {
            // Get old price from orderData (có thể lưu trong orderData hoặc tính từ maxPrice/minPrice)
            int oldPrice = orderData.price; // Tạm thời dùng price hiện tại, có thể cần lưu oldPrice riêng
            int newPrice = orderData.price;
            bool isCancel = (orderData.orderState == OrderState.Cancel);
            
            AnalyticsManager.instance.TrackMarketUpdateOrder(
                orderData.id,
                oldPrice,
                newPrice,
                isCancel
            );
            
            // ✅ Track TH Consumed (listing cost when updating price)
            if (listingCost > 0)
            {
                AnalyticsManager.instance.TrackTHConsumed(listingCost, "marketplace_listing");
            }
        }
#endif
    }

    //----------------------------------------------------------------
    //Request Complete Order
    //----------------------------------------------------------------
    [Client]
    public void RequestCompleteOrder(string id, int price, int apiToken, string walletPassCode)
    {
        if (!NetworkClient.isConnected)
            return;

        if (TryBlockMarketVietnam())
            return;

        if (!BattleManager.TryGetGameDataConfig(out var config, logWarning: false))
        {
            // Config chưa load, vẫn cho phép request để server xử lý
            CmdCompleteOrder(id, price, apiToken, walletPassCode);
            return;
        }

        if (!config.canCompleteOrder)
        {
            // TODO:dialog -> Tính năng mua hàng trên chợ đang tạm thời bị vô hiệu hóa
            if (IngameNotifyManager.instance != null)
            {
                IngameNotifyManager.instance.OnToastView(UIManager.GetDialog(1212));
            }
            return;
        }

        CmdCompleteOrder(id, price, apiToken, walletPassCode);
    }

    [Command]
    public void CmdCompleteOrder(string id, int price, int apiToken, string walletPassCode)
    {
#if ENABLE_SERVER
        if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(userName) || GetLandType() == LandType.BeginnerLand)
            return;

        if (!ServerValidateApiToken(apiToken, nameof(CmdCompleteOrder)))
            return;

        if (!BattleManager.instance.gameDataConfig.canCompleteOrder)
        {
            BattleManager.Log(GameLogType.Debug, $"[CmdCompleteOrder] canCompleteOrder is disabled. User: {userName}, OrderId: {id}, Price: {price}");
            RpcCompleteOrder(this.connectionToClient, 1, null, 0);
            return;
        }

        AccountInfo accountInfo = BattleManager.instance.GetAccountInfo(this.userName);

        if (accountInfo == null)
            return;

#if !ENABLE_SERVER_BETA && !ENABLE_SERVER_TEST
        if (string.IsNullOrEmpty(accountInfo.email) || !DataUtils.IsValidEmail(accountInfo.email))
        {
            BattleManager.instance.gameLogicBehavior.SendServerMessage(
                connectionToClient,
                "Account need to link with email in order to create order",
                -1);
            return;
        }
#endif

        var isCorrect = CheckWalletPassCode(walletPassCode);
        if (isCorrect == false)
        {
            RpcCompleteOrder(this.connectionToClient, 6, null, 0);
            return;
        }

        //Check suspect
        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);
#if !ENABLE_SERVER_TEST
        if (characterData.refundedNumber > 0)
        {
        Log(LogAction.SuspiciousActivity,
            $"Action:CompleteOrder|SuspectCount:{characterData.suspectdNumber}|RefundCount:{characterData.refundedNumber}");
            RpcCompleteOrder(this.connectionToClient, 1, null, 0);
            return;
        }
#endif

        OrderData orderData = BattleManager.instance.GetOrderData(id);
        if (orderData == null)
        {
            RpcCompleteOrder(this.connectionToClient, 1, null, 0);
            return;
        }

        if (orderData.equipment == null)
        {
            BattleManager.Log(GameLogType.Warning, $"[CmdCompleteOrder] Order equipment snapshot missing. OrderId:{id}");
            RpcCompleteOrder(this.connectionToClient, 1, null, 0);
            return;
        }

        if (orderData.orderState != OrderState.Active)
        {
            if (orderData.orderState == OrderState.Cancel)
            {
                RpcCompleteOrder(this.connectionToClient, 1, null, 0);
            }
            else if (orderData.orderState == OrderState.Completed)
            {
                RpcCompleteOrder(this.connectionToClient, 2, null, 0);
            }
            else
            {
                Log(LogAction.CompleteOrder,
                    $"Status:InvalidState|OrderId:{orderData.id}|State:{orderData.orderState}");
            }
            RpcCompleteOrder(this.connectionToClient, 1, null, 0);
            return;
        }

        if (orderData.price != price)
        {
            RpcCompleteOrder(this.connectionToClient, 3, null, 0);
            return;
        }

        if (string.Equals(orderData.seller, userName, System.StringComparison.Ordinal))
        {
            BattleManager.Log(GameLogType.Warning, $"[CmdCompleteOrder] Self-purchase rejected. User: {userName}, OrderId: {id}");
            RpcCompleteOrder(this.connectionToClient, 1, null, 0);
            return;
        }

        var buyerWalletData = BattleManager.instance.GetWalletData(userName);
        if (buyerWalletData == null)
        {
            RpcCompleteOrder(this.connectionToClient, 1, null, 0);
            return;
        }
        if (buyerWalletData.token < orderData.price)
        {
            RpcCompleteOrder(this.connectionToClient, 1, null, 0);
            return;
        }

        if (orderData.equipment.equipmentType == EquipmentType.Ingredient && buyerWalletData.IsHaveIngredientSlot() == false)
        {
            RpcCompleteOrder(this.connectionToClient, 4, null, 0);
            return;
        }

        if ((orderData.equipment.equipmentType == EquipmentType.Pet ||
            orderData.equipment.equipmentType == EquipmentType.Horse ||
            orderData.equipment.equipmentType == EquipmentType.Artifact ||
            orderData.equipment.equipmentType == EquipmentType.Hair ||
            orderData.equipment.equipmentType == EquipmentType.Eye ||
            orderData.equipment.equipmentType == EquipmentType.Body ||
            orderData.equipment.equipmentType == EquipmentType.FaceHair ||
            orderData.equipment.IsCollectionPet())
            && buyerWalletData.IsHaveInventorySlot() == false)
        {
            RpcCompleteOrder(this.connectionToClient, 5, null, 0);
            return;
        }

        AccountInfo sellerAccountInfo = BattleManager.instance.GetAccountInfo(orderData.seller);
        if (!MarketOrderValidation.IsMarketplaceAccountEligible(
                sellerAccountInfo != null,
                sellerAccountInfo != null && sellerAccountInfo.accountState == AccountInfo.AccountState.Active,
                sellerAccountInfo != null && sellerAccountInfo.deleted,
                sellerAccountInfo != null && sellerAccountInfo.banned))
        {
            RpcCompleteOrder(this.connectionToClient, 1, null, 0);
            return;
        }

        var sellerWalletData = BattleManager.instance.GetWalletData(orderData.seller);
        if (sellerWalletData == null)
        {
            RpcCompleteOrder(this.connectionToClient, 1, null, 0);
            return;
        }

        Equipment equipment = sellerWalletData.GetEquipment(orderData.equipment.id);

        if (equipment == null)
        {
            orderData.orderState = OrderState.Cancel;
            orderData.lastUpdate = DataUtils.TimeToString(System.DateTime.Now);
            BattleManager.instance.CreateOrEditOrderData(orderData.id, orderData);
            RpcCompleteOrder(this.connectionToClient, 1, orderData, 0);
            return;
        }

        var card = DataHolder.Instance().GetData<Card>(equipment.itemId);
        if (orderData.equipment.itemId != equipment.itemId ||
            orderData.equipment.equipmentType != equipment.equipmentType)
        {
            orderData.orderState = OrderState.Cancel;
            orderData.lastUpdate = DataUtils.TimeToString(System.DateTime.Now);
            BattleManager.instance.CreateOrEditOrderData(orderData.id, orderData);
            BattleManager.Log(GameLogType.Warning,
                $"[MarketCompleteGuard] Buyer:{userName}|Seller:{orderData.seller}|Order:{id}|Equipment:{equipment.id}|Item:{equipment.itemId}|RuntimeType:{equipment.equipmentType}");
            RpcCompleteOrder(this.connectionToClient, 1, orderData, 0);
            return;
        }

        if (card != null)
        {
            if (card.equipmentType == EquipmentType.Ingredient)
            {
                equipment.state = EquipmentState.Ingredient;
            }
            else
            {
                equipment.state = EquipmentState.Inventory;
            }
        }
        else
        {
            equipment.state = EquipmentState.Inventory;
        }

        int earn = orderData.price;

        if (orderData.equipment.equipmentType != EquipmentType.Ingredient || orderData.price >= 15)
        {
            float marketCut = BattleManager.instance.marketCut;
            CharacterData sellerCharacterData = BattleManager.instance.GetCharacterData(orderData.seller);
            if (sellerCharacterData != null)
            {
                marketCut = marketCut + (1f - marketCut) * sellerCharacterData.GetVipStatValue(VipBonusType.MarketTax);
            }

            earn = Mathf.CeilToInt(orderData.price * marketCut);
        }


        BattleManager.instance.AddToken(sellerWalletData, earn, buyerWalletData.userName, id);
        BattleManager.instance.RemoveWalletItem(sellerWalletData, equipment, buyerWalletData.userName, id);

        BattleManager.instance.AddToken(buyerWalletData, -orderData.price, sellerWalletData.userName, id);
        BattleManager.instance.AddWalletItem(buyerWalletData, equipment, sellerWalletData.userName, id);

        orderData.lastUpdate = DataUtils.TimeToString(System.DateTime.Now);
        orderData.orderState = OrderState.Completed;
        orderData.buyer = buyerWalletData.userName;
        orderData.buyerCharacterName = characterName;
        BattleManager.instance.CreateOrEditOrderData(orderData.id, orderData);

        // ✅ Calculate market cut for analytics (amount buyer pays but seller doesn't receive)
        int marketCutAmount = orderData.price - earn;
        EconomyManager.RecordMarketOrderCompleted(orderData.price, marketCutAmount);
        EconomyManager.ExcludeMarketplaceTransfer(earn, orderData.price);
        EconomyManager.RecordThSupplyBurn(marketCutAmount);
        EconomyManager.RecordThBurn(marketCutAmount, "marketplace_transaction_fee");

        RpcCompleteOrder(this.connectionToClient, 0, orderData, marketCutAmount);
        //BattleManager.Log(GameLogType.UserTracking, this.userName + " Complete Order " + orderData.id + " seller: " + sellerWalletData.userName + " buyer " + buyerWalletData.userName + " price " + orderData.price + " Equipment " + equipment.equipmentType.ToString());

        // ========== 🆕 LOGGING: Complete Order (Seller & Buyer, reuse 'card' from line 6575) ==========
        // Seller side
        var sellerData = BattleManager.instance.GetCharacterData(sellerWalletData.userName);
        if (sellerData != null)
        {
            BattleManager.Log(sellerData, LogAction.CompleteOrder,
                $"Type:{equipment.equipmentType}|Item:{(card != null ? card.GetName(0) : equipment.itemId.ToString())}|Rare:{equipment.rareType}|Lv:{equipment.level}|Buyer:{buyerWalletData.userName}|Price:{orderData.price}",
                equipment.ToJson());
        }

        // Buyer side
        Log(LogAction.CompleteOrder,
            $"Type:{equipment.equipmentType}|Item:{(card != null ? card.GetName(0) : equipment.itemId.ToString())}|Rare:{equipment.rareType}|Lv:{equipment.level}|Seller:{sellerWalletData.userName}|Price:{orderData.price}",
            equipment.ToJson(),
            value: orderData.price.ToString());
        // ========== END Complete Order Logging ==========

        BattleManager.instance.SaveWalletData(sellerWalletData);
        BattleManager.instance.SaveWalletData(buyerWalletData);

        ServerRefreshMarketOrders();

        var sellerPlayerBehavior = BattleManager.instance.GetPlayerBehavior(orderData.seller);
        if (sellerPlayerBehavior != null)
        {
            sellerPlayerBehavior.ServerRefreshMarketOrders();
            BattleManager.instance.gameLogicBehavior.RpcNotifyToSeller(sellerPlayerBehavior.connectionToClient, orderData);
        }
#endif
    }

    /// <summary>
    ///                 Callback trả về khi mua hàng
    /// <para>          Error Code:                      </para>
    /// <para>          0: Thành công                    </para>
    /// <para>          1: Order đã cancel               </para>
    /// <para>          2: Order đã complete             </para>
    /// <para>          3: Order đã update giá           </para>
    /// <para>          4: Order ingredient nhưng không đủ slot đá </para>
    /// <para>          5: Order inventory nhưng không đủ slot inventory </para>
    /// <para>          6: Sai PIN    </para>
    /// </summary>
    [TargetRpc]
    void RpcCompleteOrder(NetworkConnectionToClient networkConnectionToClient, int errorCode, OrderData orderData, int marketCutAmount)
    {
        if (UIManager.instance == null)
            return;

        var marketPlaceView = UIManager.instance.FindView<MarketPlaceView>();
        switch (errorCode)
        {
            case 0:
                marketPlaceView.CompleteOrderCallback();
                marketPlaceView.CreateOrderCompleteHistory(orderData);
#if ENABLE_MMO_WEB_API && ENABLE_CLIENT && !ENABLE_ADMIN
                if (orderData != null)
                {
                    MmoApiManager.GetInstance().SendEvent(MCP.Mmo.DataModels.Common.MmoEventType.MarketplaceOrderCompleted, orderData.ToJson());
                }
#endif

                // ✅ Track Market CompleteOrder Analytics (Buyer)
#if ENABLE_ANALYTIC_SERVICE
                if (orderData != null && AnalyticsManager.instance != null)
                {
                    AnalyticsManager.instance.TrackMarketCompleteOrder(
                        orderData.id,
                        orderData.equipment.itemId,
                        orderData.price,
                        isBuyer: true
                    );
                    
                    // ✅ Track TH Consumed (market cut - fee paid to system)
                    // Note: Full price (orderData.price) is for purchasing the item, not a fee
                    // Only market cut is the fee that should be tracked
                    if (marketCutAmount > 0)
                    {
                        AnalyticsManager.instance.TrackTHConsumed(marketCutAmount, "marketplace_cut");
                    }
                }
#endif
                break;
            case 1:
                if (IngameNotifyManager.instance != null)
                    IngameNotifyManager.instance.Notify(264);
                marketPlaceView.OnCompleteOrderError();
                break;
            case 2:
                if (IngameNotifyManager.instance != null)
                    IngameNotifyManager.instance.Notify(265);
                marketPlaceView.OnCompleteOrderError();
                break;
            case 3:
                if (IngameNotifyManager.instance != null)
                    IngameNotifyManager.instance.Notify(266);
                marketPlaceView.OnCompleteOrderError();
                break;
            case 4:
                if (IngameNotifyManager.instance != null)
                    IngameNotifyManager.instance.Notify(386);
                marketPlaceView.OnCompleteOrderError();
                break;
            case 5:
                if (IngameNotifyManager.instance != null)
                    IngameNotifyManager.instance.Notify(445);
                marketPlaceView.OnCompleteOrderError();
                break;
            case 6:
                marketPlaceView.OnCompleteOrderError();
                break;
            default: break;
        }
    }

    [TargetRpc]
    void RpcNotifyToSeller(NetworkConnectionToClient networkConnectionToClient, OrderData orderData)
    {
        if (UIManager.instance == null)
            return;

        //if (ClientManager.instance.myCharacter != null)
        //    ClientManager.instance.myCharacter.RequestGetWalletData();

        var marketPlaceView = UIManager.instance.FindView<MarketPlaceView>();
        if (marketPlaceView.IsOpen)
        {
            marketPlaceView.OnSellSuccess();
        }

        // ✅ SERVER-ONLY: Add null check for IngameNotifyManager
        if (IngameNotifyManager.instance != null)
            IngameNotifyManager.instance.Notify(263);

        // ✅ Track Market CompleteOrder Analytics (Seller)
#if ENABLE_ANALYTIC_SERVICE
        if (orderData != null && AnalyticsManager.instance != null)
        {
            AnalyticsManager.instance.TrackMarketCompleteOrder(
                orderData.id,
                orderData.equipment.itemId,
                orderData.price,
                isBuyer: false
            );
        }
#endif
    }

    //----------------------------------------------------------------
    //Request Get Orders
    //----------------------------------------------------------------
    [Client]
    public void RequestGetOrders(int page, bool isItem, bool isMyOrder)
    {
        if (!NetworkClient.isConnected)
            return;

        if (TryBlockMarketVietnam())
            return;

        if (!BattleManager.TryGetGameDataConfig(out var config, logWarning: false))
        {
            // Config chưa load, vẫn cho phép request để server xử lý
            CmdGetOrders(page, isItem, isMyOrder, ClientManager.instance.GetApiToken());
            return;
        }

        if (!config.canCheckMarket)
        {
            // TODO:dialog -> Tính năng xem chợ đang tạm thời bị vô hiệu hóa
            if (IngameNotifyManager.instance != null)
            {
                IngameNotifyManager.instance.OnToastView(UIManager.GetDialog(1213));
            }
            return;
        }

        CmdGetOrders(page, isItem, isMyOrder, ClientManager.instance.GetApiToken());
    }

    [Command]
    public void CmdGetOrders(int page, bool isItem, bool isMyOrder, int apiToken)
    {
#if ENABLE_SERVER
        if (string.IsNullOrEmpty(userName) || !ServerValidateApiToken(apiToken,nameof(CmdGetOrders)) || !NetSafe.CanTarget(this)) return;
        var result = ServerQueryMarketOrders(0,page,isItem,isMyOrder,null,null,true);
        RpcGetOrders(connectionToClient,result.status == MarketQueryStatus.Success ? result.orders : null,result.totalPages,isItem);
#endif
    }

    [TargetRpc]
    void RpcGetOrders(NetworkConnectionToClient networkConnectionToClient, List<OrderData> orderDatas, int totalPage, bool isItem)
    {
        if (UIManager.instance == null)
            return;

        UIManager.instance.FindView<MarketPlaceView>().GetOrdersCallback(orderDatas, totalPage, isItem);
    }



    //----------------------------------------------------------------
    //Request Unlock Vip
    //----------------------------------------------------------------
    [Client]
    public void RequestUnlockVip(int apiToken, string passCode)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdUnlockVip(apiToken, passCode);
    }

    [Command]
    private void CmdUnlockVip(int apiToken, string walletPassCode)
    {
#if ENABLE_SERVER

        if (GetHealth() <= 0)
            return;

        if (!ServerValidateApiToken(apiToken, nameof(CmdUnlockVip)) || isHaveLoginSeasonPass)
            return;

        var isCorrect = CheckWalletPassCode(walletPassCode);
        if (isCorrect == false)
        {
            return;
        }

        CurrencyData cost = new() { currencyId = TH_COIN_ID, value = BattleManager.instance.gameDataConfig.UnlockVipCost };
        if (HaveEnoughMoney(cost) == false)
        {
            return;
        }

        PayCost(cost);
        EconomyManager.RecordThBurn(cost.value, "season_pass");
        isHaveLoginSeasonPass = true;
        BattleManager.instance.SavePlayerData(this);
        
        Log(LogAction.BuyShopTH,
            $"Unlock Login Season Pass|Cost:{cost}",
            value: cost.ToString());
        RpcUnlockVip(connectionToClient, isHaveLoginSeasonPass);
#endif
    }

    [TargetRpc]
    private void RpcUnlockVip(NetworkConnectionToClient networkConnectionToClient, bool isVip)
    {
        ClientManager.instance.SetMyLoginBattlePass(isVip);

        if (UIManager.instance == null)
            return;


        var view = UIManager.instance.FindView<DailyQuestsView>();
        if (view.IsOpen)
        {
            view.MarkQuestDataDirty(QuestCategory.ContinuousLogin);
            view.MoveToTab((int)DailyQuestsView.DailyQuestTab.Login);
        }
    }

    //----------------------------------------------------------------
    //Request Craft Items
    //----------------------------------------------------------------
    [Client]
    public void RequestCraftItem(string equipmentId, List<string> ingredients, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdCraftItem(equipmentId, ingredients, apiToken);
    }


    [Command]
    public void CmdCraftItem(string equipmentId, List<string> ingredients, int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdCraftItem)))
            return;

        if (this.GetHealth() <= 0)
            return;

        if (BattleManager.instance.GetIsMaintenance())
            return;

        // The craft button is only shown on the fire craft area; enforce it on the server too so a modified client
        // cannot craft anywhere.
        if (!IsStandingOn(RuntimeAreaController.RuntimeAreaType.FireCraft))
        {
            BattleManager.Log(GameLogType.Warning,
                $"[Craft] {userName} tried to craft outside the fire craft area|Area:{GetRuntimeAreaType()}");
            return;
        }

        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);


        Equipment equipment = GetEquipment(equipmentId);

        if (equipment == null || equipment.equipmentType == EquipmentType.SkinTitle ||
            equipment.equipmentType == EquipmentType.Egg ||
            equipment.equipmentType == EquipmentType.Blueprint ||
            equipment.IsCollection())
            return;

        if (equipment.isLock && equipment.IsSkin() == false)
            return;

        if (equipment.madeBy != "")
        {
            return;
        }

        var card = DataHolder.Instance().GetData<Card>(equipment.itemId);
        if (card == null)
            return;

        // Server-authoritative craft target validation. The client already filters
        // craft targets by useForCraft, but a direct command could previously use
        // an ingredient as the base equipment and copy other ingredient stats to it.
        // BuildingPart cards are excluded by data (useForCraft=false in Card.txt v504), not by a hard-coded list.
        if (!card.useForCraft ||
            equipment.equipmentType == EquipmentType.Ingredient ||
            equipment.equipmentType == EquipmentType.EventItem)
        {
            Log(LogAction.SuspiciousActivity,
                $"Invalid craft target|Equipment:{equipment.id}|ItemId:{equipment.itemId}|" +
                $"EquipmentType:{equipment.equipmentType}|UseForCraft:{card.useForCraft}");
            return;
        }

        if (ingredients == null)
            return;

        if (ingredients.Count == 0 || ingredients.Count > GetCraftSlot(card.isTradable))
        {
            return;
        }


        if (characterData == null)
            return;

        List<string> checkIds = new List<string>();
        int craftPoints = 0;

        foreach (string id in ingredients)
        {
            if (checkIds.Contains(id))
                return;
            checkIds.Add(id);
        }

        if (equipment.state == EquipmentState.New)
            equipment.state = EquipmentState.Inventory;

        //Check if have all ingredient
        foreach (string id in ingredients)
        {
            Equipment ingredient = characterIngredient.GetEquipment(id);
            if (ingredient == null)
                return;

            // The ingredient bag also holds EventItem (merge-only): only Ingredient stones may be craft stones.
            if (!ForgeCraftRules.IsValidCraftIngredient(
                    ingredient, DataHolder.Instance().GetData<Card>(ingredient.itemId)))
            {
                Log(LogAction.SuspiciousActivity,
                    $"Invalid craft ingredient|Equipment:{ingredient.id}|ItemId:{ingredient.itemId}|" +
                    $"EquipmentType:{ingredient.equipmentType}");
                return;
            }

            if (ingredient.rareType == RareType.Legendary)
                craftPoints += 2;
            else if (ingredient.rareType == RareType.Epic)
                craftPoints += 1;
        }

        CurrencyData cost = equipment.GetCraftCost();

        if (characterData != null)
        {
            cost.value = (int)(cost.value * (1f - characterData.GetVipStatValue(VipBonusType.CraftCost)));
        }

        if (!HaveEnoughMoney(cost))
            return;

        EconomyManager.RecordCraftAttempt();

        float craftChance = GetCraftChance(ingredients, equipment);

        if (equipment.rareType == RareType.Common)
            craftChance += 15;
        else if (equipment.rareType == RareType.Rare)
            craftChance += 10;

        int n = Random.Range(0, 1000);

        //Beginner help
        if (GetLandType() == LandType.BeginnerLand && GetCraftNumber() < 2)
        {
            if (card.cost != null && card.cost.Length > 0)
            {
                var currencyId = card.cost[0].currencyId;
                if (currencyId == GameConst.GOLD_ID)
                {
                    n = Mathf.FloorToInt(craftChance * 10) - 1;
                }
            }
        }

        if (n > craftChance * 10)
        {
            EconomyManager.RecordCraftResult(false);
            //Fail only lost equipment not lost of ingredient and cost
            
            // Xử lý đặc biệt cho skin trong SkinSet
            if (equipment.IsSkin())
            {
                // Tìm skin nằm trong set nào TRƯỚC khi xóa
                var (skinSetIndex, _) = FindSkinInSkinSetsData(equipment.id);
                
                // Xóa skin (SafeRemoveEquipment sẽ xóa cả trong skinSetsData)
                SafeRemoveEquipment(equipment);
                
                if (skinSetIndex >= 0)
                {
                    // Thay bằng default skin để đảm bảo player có skin cơ bản
                    Equipment defaultSkin = CreateDefaultSkinForType(equipment.equipmentType);
                    if (defaultSkin != null)
                    {
                        SetSkinInSetData(skinSetIndex, defaultSkin);
                    }
                    
                    // Reload visual nếu đang active set này
                    if (activeSkinSetIndexData == skinSetIndex)
                    {
                        ReloadSkinsFromActiveSet();
                    }
                    
                    // Sync skinSetsData to characterData
                    SyncSkinSetsToCharacterData(characterData);
                }
            }
            {
                // Logic cũ cho non-skin equipment
                if (equipment.state == EquipmentState.Character)
                    characterEquipments.RemoveEquipment(equipment.id);
                else if (equipment.state == EquipmentState.Inventory || equipment.state == EquipmentState.New)
                    characterInventory.RemoveEquipment(equipment.id);
            }

            // ========== Craft Fail Logging (with legendary filter) ==========
            if (card.isTradable)
            {
                Log(LogAction.CraftFail,
                    $"ItemId={equipment.itemId};Rare={equipment.rareType};Cost={cost.Log()};Chance={craftChance}%",
                    equipment.ToJson(),
                    value: cost.value.ToString());
            }
            // ========== END Craft Fail Logging ==========

            bool isLostCurrentBody = equipment.state == EquipmentState.Character && equipment.equipmentType == EquipmentType.Body;
            if (isLostCurrentBody)
            {
                Log(LogAction.CraftFail,
                    $"Item:{equipment.id}|Type:{equipment.equipmentType}|Reason:BodyLost");
                characterEquipments.AddEquipment(new Equipment(BODY_DEFAULT_ID, RareType.Common));
            }

            TargetCraftFail(this.connectionToClient);
        }
        else
        {
            //Craft
            List<string> ingredientCraftSuccess = new List<string>();
            List<string> ingredientCraftFail = new List<string>();

            // ✅ PHASE 2: Switch between Craft() (old) and CraftNew() (new) for testing
            // TODO: Remove flag and use CraftNew() only after Phase 4 testing
            bool useNewCraftSystem = true; // Set to false to use old Craft() method
            Equipment newEquipment = useNewCraftSystem
                ? CraftNew(equipment, ingredients, ref ingredientCraftSuccess, ref ingredientCraftFail, GetCraftLevel(true))
                : Craft(equipment, ingredients, ref ingredientCraftSuccess, ref ingredientCraftFail);
            if (newEquipment != null)
            {
                EconomyManager.RecordCraftResult(true);
                newEquipment.state = EquipmentState.Inventory;
                newEquipment.madeBy = this.characterName;

                //Deduct cost
                PayCost(cost);

                //Remove ingredient
                foreach (string id in ingredients)
                {
                    characterIngredient.RemoveEquipment(id);
                }

                // Xử lý đặc biệt cho skin trong SkinSet
                if (equipment.IsSkin())
                {
                    // Tìm skin nằm trong set nào TRƯỚC khi xóa
                    var (skinSetIndex, _) = FindSkinInSkinSetsData(equipment.id);
                    
                    // Xóa skin cũ (SafeRemoveEquipment sẽ xóa cả trong skinSetsData)
                    SafeRemoveEquipment(equipment);
                    
                    // Add skin mới vào inventory (player tự requestUseItem sau)
                    characterInventory.AddEquipment(newEquipment);
                    
                    if (skinSetIndex >= 0)
                    {
                        // Thay bằng default skin để đảm bảo player có skin cơ bản
                        Equipment defaultSkin = CreateDefaultSkinForType(equipment.equipmentType);
                        if (defaultSkin != null)
                        {
                            SetSkinInSetData(skinSetIndex, defaultSkin);
                        }
                        
                        // Reload visual nếu đang active set này
                        if (activeSkinSetIndexData == skinSetIndex)
                        {
                            ReloadSkinsFromActiveSet();
                        }
                        
                        // Sync skinSetsData to characterData
                        SyncSkinSetsToCharacterData(characterData);
                    }
                }
                else
                {
                    // Logic cũ cho non-skin equipment
                    characterInventory.AddEquipment(newEquipment);

                    //Remove original equipment
                    characterEquipments.RemoveEquipment(equipment.id);
                    characterInventory.RemoveEquipment(equipment.id);
                }

                if (craftPoints > 0)
                    AddCraftNumber(craftPoints);

                if (GetCraftLevel(true) + 1 < 5)
                    AddCraftNumber(1);

                characterData.todayCraftNumber += 1;

                // ========== Craft Success Logging (with legendary filter) ==========
                if (card.isTradable)
                {
                    int legendaryCount = craftPoints / 2; // Legendary = 2 points each

                    Log(LogAction.CraftSuccess,
                        $"Type:{newEquipment.equipmentType}|Item:{card.GetName(0)}|Rare:{newEquipment.rareType}|Legendary:{legendaryCount}",
                        newEquipment.ToJson());
                }
                // ========== END Craft Success Logging ==========

                var current = characterEquipments.GetEquipment(EquipmentType.Body);
                if (newEquipment.equipmentType == EquipmentType.Body && current == null)
                {
                    characterEquipments.AddEquipment(new Equipment(BODY_DEFAULT_ID, RareType.Common));
                }


                //Send Success Message
                TargetCraftSuccess(this.connectionToClient, newEquipment.id, ingredientCraftSuccess, ingredientCraftFail);
            }
        }
        //Save
        OnUpdateStats();

        if ((equipment.state == EquipmentState.Character || equipment.state == EquipmentState.Collection || equipment.state == EquipmentState.Title) && characterVisual != null)
        {
            characterVisual.LoadEquipments();
        }

        BattleManager.instance.SavePlayerData(this);
#endif
    }

    //----------------------------------------------------------------
    // Request Blueprint Craft at a clan Forge
    //----------------------------------------------------------------
    [Client]
    public void RequestCraftBlueprint(string buildingId, string equipmentId, List<string> ingredients, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdCraftBlueprint(buildingId, equipmentId, ingredients, apiToken);
    }

    [Command]
    public void CmdCraftBlueprint(string buildingId, string equipmentId, List<string> ingredients, int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdCraftBlueprint)))
            return;

        if (BattleManager.instance.GetIsMaintenance())
            return;

        if (!this.IsAlive())
            return;

        // Forge crafting happens at the clan Forge inside the Orc Village; enforce it on the server.
        if (!IsStandingOn(RuntimeAreaController.RuntimeAreaType.OrcVillage))
        {
            BattleManager.Log(GameLogType.Warning,
                $"[Craft] {userName} tried to craft at a Forge outside the Orc Village|Area:{GetRuntimeAreaType()}");
            return;
        }

        if (string.IsNullOrEmpty(buildingId) || buildingId.Length > 128 ||
            string.IsNullOrEmpty(equipmentId) || equipmentId.Length > 128 ||
            ingredients == null)
        {
            return;
        }

        if (ClanData.IsNoClanOrClanNPC(clanId))
            return;

        ClanData clanData = BattleManager.instance.GetClanData(clanId);
        if (clanData == null || clanData.clanBuildings == null || clanData.clanBuildings.Contains(buildingId) == false)
            return;

        PlayerBehavior building = BattleManager.instance.GetPlayerBehavior(buildingId);
        if (building == null ||
            building.characterType != CharacterType.Building ||
            building.mobId != GameConst.FORGE_BUILDING_ID ||
            building.clanId != clanId ||
            !building.IsAlive() ||
            building.statData == null)
        {
            return;
        }

        int craftMastery = Mathf.Max(0, Mathf.FloorToInt(
            building.statData.GetStat(StatType.CraftMastery).value));

        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);
        Equipment equipment = GetEquipment(equipmentId);
        if (characterData == null ||
            equipment == null ||
            equipment.equipmentType != EquipmentType.Blueprint ||
            equipment.IsCollection() ||
            equipment.isLock ||
            equipment.madeBy != "" ||
            (equipment.state != EquipmentState.Inventory && equipment.state != EquipmentState.New))
        {
            return;
        }

        Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
        if (card == null || !card.useForCraft || GetValidBlueprintCraftOutputIds(card, CraftTier.Tier1).Length == 0)
            return;

        if (ingredients.Count == 0 || ingredients.Count > GameConst.CRAFT_SLOT_MAX)
            return;

        List<string> checkIds = new List<string>();
        foreach (string id in ingredients)
        {
            if (string.IsNullOrEmpty(id) || id.Length > 128 || checkIds.Contains(id))
                return;

            checkIds.Add(id);
            Equipment ingredient = characterIngredient.GetEquipment(id);
            if (ingredient == null || ForgeCraftRules.IsValidIngredient(equipment, card, ingredient) == false)
                return;
        }

        if (!BattleManager.TryGetGameDataConfig(
                out var config,
                $"{nameof(PlayerBehavior)}.{nameof(CmdCraftBlueprint)}",
                logWarning: false))
        {
            return;
        }

        CurrencyData cost = ForgeCraftRules.GetCraftCost(
            equipment,
            config,
            characterData.GetVipStatValue(VipBonusType.CraftCost));
        if (cost == null || !HaveEnoughMoney(cost))
            return;

        EconomyManager.RecordCraftAttempt();
        float craftChance = GetCraftChance(ingredients, equipment);
        if (equipment.rareType == RareType.Common)
            craftChance += 15;
        else if (equipment.rareType == RareType.Rare)
            craftChance += 10;

        int n = Random.Range(0, 1000);
        if (n > craftChance * 10)
        {
            EconomyManager.RecordCraftResult(false);
            characterInventory.RemoveEquipment(equipment.id);
            if (card.isTradable)
            {
                Log(LogAction.CraftFail,
                    $"BlueprintForge|ItemId={equipment.itemId};Rare={equipment.rareType};Cost={cost.Log()};Chance={craftChance}%",
                    equipment.ToJson(),
                    value: cost.value.ToString());
            }

            TargetCraftBlueprintFail(this.connectionToClient);
        }
        else
        {
            List<string> ingredientCraftSuccess = new List<string>();
            List<string> ingredientCraftFail = new List<string>();
            Equipment newEquipment = CraftNew(
                equipment,
                ingredients,
                ref ingredientCraftSuccess,
                ref ingredientCraftFail,
                craftMastery);
            if (newEquipment == null || newEquipment.equipmentType == EquipmentType.Blueprint)
                return;

            EconomyManager.RecordCraftResult(true);
            newEquipment.state = EquipmentState.Inventory;
            newEquipment.madeBy = this.characterName;

            PayCost(cost);
            foreach (string id in ingredients)
                characterIngredient.RemoveEquipment(id);

            characterInventory.AddEquipment(newEquipment);
            characterInventory.RemoveEquipment(equipment.id);

            characterData.todayCraftNumber += 1;
            if (card.isTradable)
            {
                Log(LogAction.CraftSuccess,
                    $"BlueprintForge|Type:{newEquipment.equipmentType}|Item:{card.GetName(0)}|Rare:{newEquipment.rareType}|Mastery:{craftMastery}",
                    newEquipment.ToJson());
            }

            TargetCraftBlueprintSuccess(
                this.connectionToClient,
                newEquipment.id,
                ingredientCraftSuccess,
                ingredientCraftFail);
        }

        OnUpdateStats();
        BattleManager.instance.SavePlayerData(this);
#endif
    }

    [TargetRpc]
    private void TargetCraftBlueprintSuccess(
        NetworkConnectionToClient networkConnectionToClient,
        string equipmentId,
        List<string> ingredientCraftSuccess,
        List<string> ingredientCraftFail)
    {
        if (UIManager.instance == null)
            return;

        BuildingView buildingView = UIManager.instance.FindView<BuildingView>();
        if (buildingView != null && buildingView.IsOpen)
        {
            buildingView.OnForgeCraftSuccess(
                equipmentId,
                ingredientCraftSuccess,
                ingredientCraftFail);
        }
    }

    [TargetRpc]
    private void TargetCraftBlueprintFail(NetworkConnectionToClient networkConnectionToClient)
    {
        if (UIManager.instance == null)
            return;

        BuildingView buildingView = UIManager.instance.FindView<BuildingView>();
        if (buildingView != null && buildingView.IsOpen)
            buildingView.OnForgeCraftFail();
    }

    public float GetCraftChance(List<string> ingredients, Equipment equipment)
    {
        float craftChance = equipment.GetCraftChance();
        foreach (string id in ingredients)
        {
            var e = characterIngredient.GetEquipment(id);
            if (e == null)
            {
                return 0f;
            }
            craftChance += characterIngredient.GetEquipment(id).GetStat(StatType.CraftChance);
        }

        return craftChance;
    }

    [TargetRpc]
    void TargetCraftSuccess(NetworkConnectionToClient networkConnectionToClient, string equipmentId,
        List<string> ingredientCraftSuccess, List<string> ingredientCraftFail)
    {
        if (UIManager.instance == null)
            return;
        UIManager.instance.FindView<CraftView>().CraftSuccess(equipmentId, ingredientCraftSuccess, ingredientCraftFail);
    }

    [TargetRpc]
    void TargetCraftFail(NetworkConnectionToClient networkConnectionToClient)
    {
        if (UIManager.instance == null)
            return;
        UIManager.instance.FindView<CraftView>().CraftFail();
    }

    // ✅ PHASE 1: Helper methods for CraftOutputTiers system
    // Note: Tier0 = No evolution (keep original itemId), Tier1+ = Evolution tiers

    /// <summary>
    /// Check if card has a specific tier available in craftOutputTiers
    /// Note: Only checks craftOutputTiers (new system), does not use craftOutputIds (old system)
    /// </summary>
    private bool HasTier(Card card, CraftTier tier)
    {
        if (card == null) return false;

        if (!card.HasCraftOutputTiers())
            return false;

        foreach (var tierData in card.craftOutputTiers)
        {
            if (tierData != null && tierData.tier == tier && tierData.cardIds != null && tierData.cardIds.Length > 0)
                return true;
        }

        return false;
    }

    private bool HasValidCraftOutputTier(Card card, CraftTier tier)
    {
        return GetValidCraftOutputIds(card, tier).Length > 0;
    }

    private int[] GetValidCraftOutputIds(Card card, CraftTier tier)
    {
        List<int> validIds = new List<int>();
        if (card == null || !card.HasCraftOutputTiers())
            return validIds.ToArray();

        int[] candidateIds = card.GetCardIdsByTier(tier);
        if (candidateIds == null)
            return validIds.ToArray();

        DataHolder dataHolder = DataHolder.Instance();
        if (dataHolder == null)
            return validIds.ToArray();

        foreach (int candidateId in candidateIds)
        {
            Card outputCard = dataHolder.GetData<Card>(candidateId);
            if (outputCard != null && outputCard.id == candidateId && outputCard.equipmentType == card.equipmentType)
                validIds.Add(candidateId);
        }

        return validIds.ToArray();
    }

    private int[] GetValidBlueprintCraftOutputIds(Card card, CraftTier tier)
    {
        List<int> validIds = new List<int>();
        if (card == null || card.equipmentType != EquipmentType.Blueprint || card.HasCraftOutputTiers() == false)
            return validIds.ToArray();

        int[] candidateIds = card.GetCardIdsByTier(tier);
        if (candidateIds == null)
            return validIds.ToArray();

        DataHolder dataHolder = DataHolder.Instance();
        if (dataHolder == null)
            return validIds.ToArray();

        foreach (int candidateId in candidateIds)
        {
            Card outputCard = dataHolder.GetData<Card>(candidateId);
            if (outputCard != null &&
                outputCard.id == candidateId &&
                outputCard.isAvailable &&
                outputCard.equipmentType != EquipmentType.Blueprint)
            {
                validIds.Add(candidateId);
            }
        }

        return validIds.ToArray();
    }

    private CraftTier GetHighestValidBlueprintCraftOutputTier(Card card, CraftTier maximumTier)
    {
        for (int tierValue = (int)maximumTier; tierValue >= (int)CraftTier.Tier1; tierValue--)
        {
            CraftTier tier = (CraftTier)tierValue;
            if (GetValidBlueprintCraftOutputIds(card, tier).Length > 0)
                return tier;
        }

        return CraftTier.Tier0;
    }

    private CraftTier GetHighestValidCraftOutputTier(Card card, CraftTier maximumTier)
    {
        for (int tierValue = (int)maximumTier; tierValue >= (int)CraftTier.Tier1; tierValue--)
        {
            CraftTier tier = (CraftTier)tierValue;
            if (HasValidCraftOutputTier(card, tier))
                return tier;
        }

        return CraftTier.Tier0;
    }

    /// <summary>
    /// Determine tier based on RNG roll, evolution chance, rarity, and equipment type
    /// Returns: Tier0 = No evolution, Tier1+ = Evolution tiers
    /// IMPORTANT: Only returns tier if it exists in craftOutputTiers
    /// </summary>
    private CraftTier DetermineTier(int n, int evolChance, RareType rareType, EquipmentType equipmentType, Card card, int n1 = -1)
    {
#if ENABLE_SERVER_TEST
        List<CraftTier> availableTiers = new List<CraftTier>();
        for (int tierValue = (int)CraftTier.Tier1; tierValue <= (int)CraftTier.Tier6; tierValue++)
        {
            CraftTier tier = (CraftTier)tierValue;
            if (equipmentType == EquipmentType.Blueprint
                ? GetValidBlueprintCraftOutputIds(card, tier).Length > 0
                : HasValidCraftOutputTier(card, tier))
            {
                availableTiers.Add(tier);
            }
        }

        if (availableTiers.Count == 0)
            return CraftTier.Tier0;

        // Equal tier intervals preserve the existing VIP-biased craft roll.
        int tierIndex = Mathf.Clamp(n, 0, 999) * availableTiers.Count / 1000;
        return availableTiers[tierIndex];
#else
        if (equipmentType == EquipmentType.Pet)
        {
            if (n > 996 - evolChance / 3 && rareType == RareType.Legendary)
            {
                if (n1 == -1) n1 = Random.Range(0, 1000);

                // Check Tier5 first (highest tier)
                if (n1 > 990 && HasTier(card, CraftTier.Tier5))
                    return CraftTier.Tier5;

                // Check Tier4
                if (n1 > 900 && HasTier(card, CraftTier.Tier4))
                    return CraftTier.Tier4;

                // Check Tier3, Tier2, Tier1, or fallback to Tier1
                if (HasTier(card, CraftTier.Tier3))
                    return CraftTier.Tier3;
                if (HasTier(card, CraftTier.Tier2))
                    return CraftTier.Tier2;
                if (HasTier(card, CraftTier.Tier1))
                    return CraftTier.Tier1;

                // If no tiers available, return Tier0 (no evolution)
                return CraftTier.Tier0;
            }
            else if (n > 950 - evolChance / 2 && rareType == RareType.Legendary)
            {
                // Can be Tier2 or Tier1 depending on available tiers
                if (HasTier(card, CraftTier.Tier2))
                    return CraftTier.Tier2;
                if (HasTier(card, CraftTier.Tier1))
                    return CraftTier.Tier1;
                return CraftTier.Tier0;
            }
            else if (n > 700 - evolChance && (rareType == RareType.Epic || rareType == RareType.Legendary))
            {
                // Epic/Legendary: Returns Tier1 (first evolution tier)
                if (HasTier(card, CraftTier.Tier1))
                    return CraftTier.Tier1;
                return CraftTier.Tier0;
            }
        }
        else if (equipmentType == EquipmentType.Horse)
        {
            // Normal builds resolve Tier0-Tier4 first, then give an existing valid Tier5 a 5% promotion roll.
            if (n > 998 - evolChance / 4 && HasTier(card, CraftTier.Tier4))
            {
#if !ENABLE_SERVER_TEST
                if (HasValidCraftOutputTier(card, CraftTier.Tier5))
                {
                    if (n1 == -1) n1 = Random.Range(0, 1000);
                    if (n1 >= 950 && n1 < 1000)
                        return CraftTier.Tier5;
                }
#endif

                return CraftTier.Tier4;
            }
            if (n > 992 - evolChance / 3 - (int)rareType && HasTier(card, CraftTier.Tier3))
                return CraftTier.Tier3;
            if (n > 940 - evolChance / 2 - 5 * (int)rareType && HasTier(card, CraftTier.Tier2))
                return CraftTier.Tier2;
            if (n > 810 - evolChance - 10 * (int)rareType && HasTier(card, CraftTier.Tier1))
                return CraftTier.Tier1;
            // Tier0 = No evolution (fall through)
        }
        else if (card != null && card.IsSkin())
        {
            if (rareType == RareType.Legendary && n > 800 - evolChance && HasTier(card, CraftTier.Tier1))
                return CraftTier.Tier1; // Skin evolution = Tier1
        }
        else if (equipmentType == EquipmentType.Item)
        {
            // Potion: Tier0 = No evolution, Tier1-Tier6 = Evolution tiers
            if (n < 500 - evolChance * 2 && HasTier(card, CraftTier.Tier1)) return CraftTier.Tier1;
            if (n < 800 - evolChance && HasTier(card, CraftTier.Tier2)) return CraftTier.Tier2;
            if (n < 950 - evolChance / 2 && HasTier(card, CraftTier.Tier3)) return CraftTier.Tier3;
            if (n < 980 - evolChance / 3 && HasTier(card, CraftTier.Tier4)) return CraftTier.Tier4;
            if (n < 995 - evolChance / 4 && HasTier(card, CraftTier.Tier5)) return CraftTier.Tier5;
            if (HasTier(card, CraftTier.Tier6)) return CraftTier.Tier6;
            // Fallback to highest available tier (Tier6 down to Tier1)
            for (int i = 6; i >= 1; i--)
            {
                if (HasTier(card, (CraftTier)i))
                    return (CraftTier)i;
            }
            // Tier0 = No evolution (fall through)
        }
        else if (equipmentType == EquipmentType.Artifact)
        {
            if (rareType == RareType.Legendary && n > 950 - evolChance && HasTier(card, CraftTier.Tier1))
                return CraftTier.Tier1;
        }
        else if (equipmentType == EquipmentType.Blueprint)
        {
            if (rareType == RareType.Legendary || rareType == RareType.Epic)
            {
                if (n > 900 - evolChance / 2 && HasTier(card, CraftTier.Tier3))
                    return CraftTier.Tier3;
                if (n > 800 - evolChance / 3 && HasTier(card, CraftTier.Tier2))
                    return CraftTier.Tier2;
            }

            if (HasTier(card, CraftTier.Tier1))
                return CraftTier.Tier1;
        }
        else if (rareType == RareType.Legendary || rareType == RareType.Epic)
        {
            if (n > 900 - evolChance / 2 && HasTier(card, CraftTier.Tier3))
                return CraftTier.Tier3;
            if (n > 800 - evolChance / 3 && HasTier(card, CraftTier.Tier2))
                return CraftTier.Tier2;
            if (n > 600 - evolChance && HasTier(card, CraftTier.Tier1))
                return CraftTier.Tier1; // General equipment Tier1 is first evolution tier
        }

        return CraftTier.Tier0; // No evolution - keep original itemId
#endif
    }

    /// <summary>
    /// Get scale and statScale values for a given tier, rarity, and equipment type
    /// Returns: (scale, statScale)
    /// Note: Tier0 = No evolution (scale = 1f), Tier1+ = Evolution tiers
    /// </summary>
    private (float scale, float statScale) GetScaleForTier(CraftTier tier, RareType rareType, EquipmentType equipmentType, Card card = null)
    {
        float scale = 1f;
        float statScale = 1f;

        // Tier0 = No evolution, no scale change
        if (tier == CraftTier.Tier0)
        {
            return (scale, statScale);
        }

        // Tier1+ = Evolution tiers
        if (equipmentType == EquipmentType.Pet)
        {
            switch (tier)
            {
                case CraftTier.Tier5:
                    scale = 2f;
                    statScale = 2f;
                    break;
                case CraftTier.Tier4:
                    scale = 1.5f;
                    statScale = 1.5f;
                    break;
                case CraftTier.Tier3:
                    scale = 1.5f;
                    statScale = 1.2f;
                    break;
                case CraftTier.Tier2:
                    scale = 1.5f;
                    statScale = 1f;
                    break;
                case CraftTier.Tier1:
                    scale = 1.25f; // Epic/Legendary first evolution tier
                    statScale = 1f;
                    break;
                default:
                    scale = 1f;
                    statScale = 1f;
                    break;
            }
        }
        else if (equipmentType == EquipmentType.Horse)
        {
            switch (tier)
            {
                case CraftTier.Tier5:
                    scale = 1 + (1 + (int)rareType) / 5f;
                    statScale = 1 + (1 + (int)rareType) / 18f;
                    break;
                case CraftTier.Tier4:
                    // RareType.Common: scale = 1.17, statScale = 1.05
                    // RareType.Rare: scale = 1.33, statScale = 1.10
                    // RareType.Epic: scale = 1.50, statScale = 1.15
                    // RareType.Legendary: scale = 1.67, statScale = 1.20
                    scale = 1 + (1 + (int)rareType) / 6f;
                    statScale = 1 + (1 + (int)rareType) / 20f;
                    break;
                case CraftTier.Tier3:
                    // Same scale as Tier4, but no statScale bonus
                    scale = 1 + (1 + (int)rareType) / 6f;
                    statScale = 1f;
                    break;
                case CraftTier.Tier2:
                    // RareType.Common: scale = 1.08
                    // RareType.Rare: scale = 1.17
                    // RareType.Epic: scale = 1.25
                    // RareType.Legendary: scale = 1.33
                    scale = 1 + (1 + (int)rareType) / 12f;
                    statScale = 1f;
                    break;
                case CraftTier.Tier1:
                    // RareType.Common: scale = 1.05
                    // RareType.Rare: scale = 1.10
                    // RareType.Epic: scale = 1.15
                    // RareType.Legendary: scale = 1.20
                    scale = 1 + (1 + (int)rareType) / 20f;
                    statScale = 1f;
                    break;
                default:
                    scale = 1f;
                    statScale = 1f;
                    break;
            }
        }
        else if (card != null && card.IsSkin())
        {
            switch (tier)
            {
                case CraftTier.Tier1:
                    scale = 1f;
                    statScale = 2f;
                    break;
                default:
                    scale = 1f;
                    statScale = 1f;
                    break;
            }
        }
        else if (equipmentType == EquipmentType.Item)
        {
            switch (tier)
            {
                case CraftTier.Tier1:
                    scale = 1f;
                    statScale = 0.15f; // Was Tier0 in old system
                    break;
                case CraftTier.Tier2:
                    scale = 1f;
                    statScale = 0.2f; // Was Tier1 in old system
                    break;
                case CraftTier.Tier3:
                    scale = 1f;
                    statScale = 0.25f; // Was Tier2 in old system
                    break;
                case CraftTier.Tier4:
                    scale = 1f;
                    statScale = 0.3f; // Was Tier3 in old system
                    break;
                case CraftTier.Tier5:
                    scale = 1f;
                    statScale = 0.4f; // Was Tier4 in old system
                    break;
                case CraftTier.Tier6:
                    scale = 1f;
                    statScale = 0.5f; // Was Tier5 in old system
                    break;
                default:
                    scale = 1f;
                    statScale = 0.15f;
                    break;
            }
        }
        else if (equipmentType == EquipmentType.Artifact)
        {
            scale = 1f;
            statScale = 1f;
        }
        else if (rareType == RareType.Legendary || rareType == RareType.Epic)
        {
            switch (tier)
            {
                case CraftTier.Tier3:
                    // RareType.Epic: scale = 1.17
                    // RareType.Legendary: scale = 1.33
                    scale = 1 + (1 + (int)rareType) / 6f;
                    statScale = 1f;
                    break;
                case CraftTier.Tier2:
                    // RareType.Epic: scale = 1.08
                    // RareType.Legendary: scale = 1.17
                    scale = 1 + (1 + (int)rareType) / 12f;
                    statScale = 1f;
                    break;
                case CraftTier.Tier1:
                    // RareType.Epic: scale = 1.05
                    // RareType.Legendary: scale = 1.10
                    scale = 1 + (1 + (int)rareType) / 20f;
                    statScale = 1f;
                    break;
                default:
                    scale = 1f;
                    statScale = 1f;
                    break;
            }
        }
        else
        {
            // Default for any other case
            scale = 1f;
            statScale = 1f;
        }

        return (scale, statScale);
    }

    Equipment Craft(Equipment equipment, List<string> ids, ref List<string> success, ref List<string> fail)
    {
        Equipment newEquipment = new Equipment();
#if ENABLE_SERVER
        newEquipment.rareType = equipment.rareType;
        newEquipment.itemId = equipment.itemId;
        newEquipment.equipmentType = equipment.equipmentType;
        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);

        int n = Random.Range(0, 1000);
        int evolChance = equipment.level * equipment.level / 5 + (int)equipment.rareType * (int)equipment.rareType;

        //if (characterData.todayCraftNumber < 50)
        evolChance += GetCraftLevel(true) * 3;
        evolChance += (int)(characterData.GetVipStatValue(VipBonusType.EvoRate) * 1000);

        if (BattleManager.instance.GetServerSeason() < 2)
        {
            evolChance += 30 - BattleManager.instance.GetServerSeason() * 15;
        }

        Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
        int itemId = -1;
        float scale = 1f;
        float statScale = 1f;
        int evolTier = 0;

#if ENABLE_SERVER_TEST
        n = Random.Range(990, 1000);
#endif

        if (card.equipmentType == EquipmentType.Pet)
        {
            // Nếu không craft ra pet event, sử dụng logic craft như bình thường
            if (itemId == -1)
            {
                int tier1 = 1;
                int tier2 = 1;
                int tier3 = 100;
                int tier4 = 100;

                if (card.Id() == 38 || card.Id() == 41 || card.Id() == 42)
                {
                    tier1 = 1;
                    tier2 = 5;
                    tier3 = 9;
                    tier4 = 11;
                }
                else if (card.Id() == 246)
                {
                    tier1 = 4;
                    tier2 = 9;
                    tier3 = 14;
                    tier4 = 19;
                }
                else if (card.Id() == 747)
                {
                    tier1 = 1;
                    tier2 = 3;
                    tier3 = 5;
                    tier4 = 7;
                }
                else if (card.Id() == GameConst.GIFT_PET_0)
                {
                    tier1 = 1;
                    tier2 = 2;
                    tier3 = 3;
                    tier4 = 6;
                }


                if (n > 996 - evolChance / 3 && equipment.rareType == RareType.Legendary)
                {
                    int n1 = Random.Range(0, 1000);

#if ENABLE_SERVER_TEST
                    n1 = Random.Range(600, 1000);
#endif
                    if (n1 > 990 && card.craftOutputIds.Length > tier4)
                    {
                        itemId = card.craftOutputIds[Random.Range(tier4, card.craftOutputIds.Length)];
                        scale = 2f;
                        statScale = 2f;
                    }
                    else if (n1 > 900 && card.craftOutputIds.Length > tier3)
                    {
                        itemId = card.craftOutputIds[Random.Range(tier3, card.craftOutputIds.Length)];
                        scale = 1.5f;
                        statScale = 1.5f;
                    }
                    else
                    {
                        if (card.craftOutputIds.Length > tier2)
                        {
                            itemId = card.craftOutputIds[Random.Range(tier2, card.craftOutputIds.Length)];
                        }
                        else if (card.craftOutputIds.Length > tier1)
                        {
                            itemId = card.craftOutputIds[Random.Range(tier1, Mathf.Min(tier2, card.craftOutputIds.Length))];
                        }
                        else if (card.craftOutputIds.Length > 0)
                        {
                            itemId = card.craftOutputIds[0];
                        }
                        scale = 1.5f;
                        statScale = 1.2f;
                    }
                }
                else if (n > 950 - evolChance / 2 && equipment.rareType == RareType.Legendary)
                {
                    if (card.craftOutputIds.Length > tier1)
                    {
                        itemId = card.craftOutputIds[Random.Range(tier1, Mathf.Min(tier2, card.craftOutputIds.Length))];
                    }
                    else if (card.craftOutputIds.Length > 0)
                    {
                        itemId = card.craftOutputIds[Random.Range(0, tier1)];
                    }
                    scale = 1.5f;
                }
                else if (n > 700 - evolChance && (equipment.rareType == RareType.Epic || equipment.rareType == RareType.Legendary))
                {
                    if (card.craftOutputIds.Length > 0)
                    {
                        itemId = card.craftOutputIds[Random.Range(0, tier1)];
                    }
                    scale = 1.25f;
                }
            }
        }
        else if (card.equipmentType == EquipmentType.Horse)
        {
            if (n > 998 - evolChance / 4)
            {
                if (card.craftOutputIds.Length > 4)
                {
                    itemId = card.craftOutputIds[4];
                }
                else if (card.craftOutputIds.Length > 3)
                {
                    itemId = card.craftOutputIds[3];
                }
                else if (card.craftOutputIds.Length > 1)
                {
                    int id = card.craftOutputIds[Random.Range(1, Mathf.Min(3, card.craftOutputIds.Length))];
                    //itemId = card.craftOutputIds[id];
                    itemId = id;
                }
                else if (card.craftOutputIds.Length > 0)
                {
                    itemId = card.craftOutputIds[0];
                }
                scale = 1 + (1 + (int)equipment.rareType) / 6f;
                statScale = 1 + (1 + (int)equipment.rareType) / 20f;
            }
            else if (n > 992 - evolChance / 3 - (int)equipment.rareType)
            {
                if (card.craftOutputIds.Length > 3)
                {
                    itemId = card.craftOutputIds[3];
                }
                else if (card.craftOutputIds.Length > 1)
                {
                    int id = card.craftOutputIds[Random.Range(1, Mathf.Min(3, card.craftOutputIds.Length))];
                    // itemId = card.craftOutputIds[id];
                    itemId = id;
                }
                else if (card.craftOutputIds.Length > 0)
                {
                    itemId = card.craftOutputIds[0];
                }
                scale = 1 + (1 + (int)equipment.rareType) / 6f;
            }
            else if (n > 940 - evolChance / 2 - 5 * (int)equipment.rareType)
            {
                if (card.craftOutputIds.Length > 1)
                {
                    int id = card.craftOutputIds[Random.Range(1, Mathf.Min(3, card.craftOutputIds.Length))];
                    //itemId = card.craftOutputIds[id];
                    itemId = id;
                }
                else if (card.craftOutputIds.Length > 0)
                {
                    itemId = card.craftOutputIds[0];
                }
                scale = 1 + (1 + (int)equipment.rareType) / 12f;
            }
            else if (n > 810 - evolChance - 10 * (int)equipment.rareType)
            {
                if (card.craftOutputIds.Length > 0)
                {
                    itemId = card.craftOutputIds[0];
                }
                scale = 1 + (1 + (int)equipment.rareType) / 20f;
            }
        }
        else if (equipment.IsSkin())
        {   //TODO: refactor
            if (equipment.rareType == RareType.Legendary)
            {
                if (n > 800 - evolChance)
                {
                    if (equipment.equipmentType == EquipmentType.Hair)
                    {
                        if (card.craftOutputIds.Length > 0)
                        {
                            int id = Random.Range(0, card.craftOutputIds.Length);
                            itemId = card.craftOutputIds[id];
                        }
                        statScale = 2;
                    }
                    else if (equipment.equipmentType == EquipmentType.FaceHair)
                    {
                        /*
                        if (IsEventItem(equipment.itemId) && card.craftOutputIds.Length > 0)
                        {
                            itemId = Random.Range(card.craftOutputIds[0], card.craftOutputIds[^1]);
                        }
                        else if (IsVipFaceHair(equipment.itemId) && card.craftOutputIds.Length > 0)
                        {
                            itemId = Random.Range(card.craftOutputIds[0], card.craftOutputIds[^1]);
                        }
                        else
                        {
                            itemId = BattleManager.instance.craftedFaceHairs[Random.Range(0, BattleManager.instance.craftedFaceHairs.Count)];
                        }
                        */
                        itemId = BattleManager.instance.craftedFaceHairs[Random.Range(0, BattleManager.instance.craftedFaceHairs.Count)];


                        statScale = 2;
                    }
                    else if (equipment.equipmentType == EquipmentType.Body)
                    {
                        /*
                        if (IsEventItem(equipment.itemId) && card.craftOutputIds.Length > 0)
                        {
                            itemId = Random.Range(card.craftOutputIds[0], card.craftOutputIds[^1]);
                        }
                        else if (IsVipBody(equipment.itemId) && card.craftOutputIds.Length > 0)
                        {
                            itemId = Random.Range(card.craftOutputIds[0], card.craftOutputIds[^1]);
                        }
                        else
                        {
                            itemId = BattleManager.instance.craftedBodies[Random.Range(0, BattleManager.instance.craftedBodies.Count)];
                        }
                        */
                        itemId = BattleManager.instance.craftedBodies[Random.Range(0, BattleManager.instance.craftedBodies.Count)];

                        statScale = 2;
                    }
                    else if (equipment.equipmentType == EquipmentType.Eye)
                    {
                        if (card.craftOutputIds.Length > 0)
                        {
                            int id = Random.Range(0, card.craftOutputIds.Length);
                            itemId = card.craftOutputIds[id];
                        }
                        statScale = 2;
                    }
                }
            }

        }
        else if (equipment.itemId == POTION_ID)
        {
            int ingredientNumber = ids.Count;
            if (ingredientNumber < 8)
            {
                n = Mathf.Clamp(n, 0, 990);
            }

            if (n < 500 - evolChance * 2)
            {
                statScale = 0.15f;
                itemId = card.craftOutputIds[0];
            }
            else if (n < 800 - evolChance)
            {
                statScale = 0.2f;
                itemId = card.craftOutputIds[1];
            }
            else if (n < 950 - evolChance / 2)
            {
                statScale = 0.25f;
                itemId = card.craftOutputIds[2];
            }
            else if (n < 980 - evolChance / 3)
            {
                statScale = 0.3f;
                itemId = card.craftOutputIds[3];
            }
            else if (n < 995 - evolChance / 4)
            {
                statScale = 0.4f;
                itemId = card.craftOutputIds[4];
            }
            else
            {
                statScale = 0.5f;
                itemId = card.craftOutputIds[5];
            }
        }
        else if (equipment.equipmentType == EquipmentType.Artifact)
        {
            if (equipment.rareType == RareType.Legendary)
            {
                if (n > 950 - evolChance && card.craftOutputIds.Length > 0)
                {
                    itemId = card.craftOutputIds[0];
                    evolTier = 1;
                }
            }
        }
        else if (equipment.rareType == RareType.Legendary || equipment.rareType == RareType.Epic)
        {
            if (itemId == -1)
            {
                if (n > 900 - evolChance / 2)
                {
                    if (card.craftOutputIds.Length > 2)
                    {
                        itemId = card.craftOutputIds[2];
                    }
                    else if (card.craftOutputIds.Length > 1)
                    {
                        itemId = card.craftOutputIds[1];
                    }
                    else if (card.craftOutputIds.Length > 0)
                    {
                        itemId = card.craftOutputIds[0];
                    }
                    scale = 1 + (1 + (int)equipment.rareType) / 6f;
                }
                else if (n > 800 - evolChance / 3)
                {
                    if (card.craftOutputIds.Length > 1)
                    {
                        itemId = card.craftOutputIds[1];
                    }
                    else if (card.craftOutputIds.Length > 0)
                    {
                        itemId = card.craftOutputIds[0];
                    }
                    scale = 1 + (1 + (int)equipment.rareType) / 12f;
                }
                else if (n > 600 - evolChance)
                {
                    if (card.craftOutputIds.Length > 0)
                    {
                        itemId = card.craftOutputIds[0];
                    }
                    scale = 1 + (1 + (int)equipment.rareType) / 20f;
                }
            }
        }

        if (itemId > -1)
            newEquipment.itemId = itemId;

        foreach (var stat in equipment.stats)
        {
            StatValue statValue = new StatValue(stat);
            if (itemId >= 0)
            {
                statValue.value = Random.Range(1 + (scale - 1) / 5, scale) * statValue.value;
            }

            newEquipment.stats = DataUtils.Add(statValue, newEquipment.stats);
        }


        //For potion x10 base stat
        float elixirDuration = 120;
        if (newEquipment.IsElixir())
        {
            foreach (var stat in newEquipment.stats)
            {
                stat.value = 10 * stat.value;
            }

            foreach (string id in ids)
            {
                Equipment ingredient = characterIngredient.GetEquipment(id);

                if (ingredient != null)
                {
                    elixirDuration += (int)ingredient.rareType * 60 * (1 + 0.1f * ingredient.level);
                }
            }
        }

        int count = 0;
        foreach (string id in ids)
        {
            var result = newEquipment.Craft(characterIngredient.GetEquipment(id), count);

            if (result)
            {
                success.Add(id);
            }
            else
            {
                fail.Add(id);
            }

            count++;
        }

        //Remove buff max stat
        if (newEquipment.equipmentType == EquipmentType.Artifact)
        {
            foreach (var stat in newEquipment.stats)
            {
                if (stat.statValueType == StatValueType.Max && evolTier == 0)
                {
                    stat.value = 0;
                }
            }
        }

        if (newEquipment.IsElixir())
        {
            Card cardEvo = DataHolder.Instance().GetData<Card>(newEquipment.itemId);

            if (cardEvo != null)
            {
                var duration = cardEvo.GetStatData(StatType.Duration);
                duration.value = Random.Range(duration.minValue, duration.maxValue);
                StatValue statValue = new StatValue(duration);
                newEquipment.stats = DataUtils.Add(statValue, newEquipment.stats);
            }
        }

        //Potion craft
        if (newEquipment.IsElixir())
        {
            foreach (var stat in newEquipment.stats)
            {
                if (stat.statType == StatType.Duration)
                {
                    stat.value = elixirDuration;
                }
                else
                {
                    stat.value = statScale * stat.value;
                }
            }
        }
        else
        {
            //Increase all stat 1 more time
            if (statScale > 1)
            {
                foreach (var stat in newEquipment.stats)
                {
                    stat.value = Random.Range(1 + (statScale - 1) / 5, statScale) * stat.value;
                }
            }
        }
        //Artifact
        if (newEquipment.equipmentType == EquipmentType.Artifact && evolTier == 1)
        {
            //Increase Stat
            foreach (var stat in newEquipment.stats)
            {
                int n1 = Random.Range(0, 100);

                if (stat.statType == StatType.Duration && n1 < 10)
                    stat.value = Random.Range(1.1f, 1.3f) * stat.value;

                n1 = Random.Range(0, 100);
                if (stat.statType == StatType.CoolDown && n1 < 10)
                    stat.value = Random.Range(0.7f, 0.95f) * stat.value;

                if (stat.statType == StatType.Health || stat.statType == StatType.Damage ||
                    stat.statType == StatType.Speed)
                {
                    float n2 = Random.Range(1.02f, 1.1f);
                    stat.value *= n2;
                }

                if (stat.statValueType == StatValueType.Max)
                {
                    if (newEquipment.GetStat(StatType.NumberTarget) < 2)
                        stat.value = Random.Range(5, 25);
                    else
                        stat.value = Random.Range(2, 12);

                    if (card.skillType == SkillType.DebuffAOE)
                    {
                        stat.value *= -1;
                    }
                }
            }
        }
#endif
        return newEquipment;

    }

    /// <summary>
    /// ✅ PHASE 2: New Craft method using craftOutputTiers system ONLY
    /// Uses DetermineTier() and GetScaleForTier() helper methods
    /// Only works with craftOutputTiers data. Invalid Tier5 output cards fall back to the highest valid tier.
    /// If no craftOutputTiers or valid tier is found, keeps original itemId (no evolution).
    /// </summary>
    Equipment CraftNew(Equipment equipment, List<string> ids, ref List<string> success, ref List<string> fail, int craftLevel)
    {
        Equipment newEquipment = new Equipment();
#if ENABLE_SERVER
        newEquipment.rareType = equipment.rareType;
        newEquipment.itemId = equipment.itemId;
        newEquipment.equipmentType = equipment.equipmentType;
        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);

        int n = Random.Range(0, 1000);
        int evolChance = equipment.level * equipment.level / 5 + (int)equipment.rareType * (int)equipment.rareType;

        evolChance += craftLevel * 3;
        evolChance += (int)(characterData.GetVipStatValue(VipBonusType.EvoRate) * 1000);

        if (BattleManager.instance.GetServerSeason() < 3)
        {
            evolChance += 60 - BattleManager.instance.GetServerSeason() * 15;
        }

        Card card = DataHolder.Instance().GetData<Card>(equipment.itemId);
        int itemId = -1;
        float scale = 1f;
        float statScale = 1f;
        CraftTier selectedTier = CraftTier.Tier0; // Track selected tier instead of evolTier int

#if ENABLE_SERVER_TEST
        n = GetServerTestCraftChange();
#endif

        if (card != null && card.HasCraftOutputTiers())
        {
            int ingredientNumber = ids.Count;
            if (equipment.itemId == GameConst.POTION_ID && ingredientNumber < 8)
            {
                n = Mathf.Clamp(n, 0, 990);
            }

            // Determine tier using helper method (n1 will be auto-generated inside DetermineTier if needed)
            selectedTier = DetermineTier(n, evolChance, equipment.rareType, equipment.equipmentType, card);

            // Tier5 is valid only when its configured output Card exists and keeps the source equipment type.
            int[] candidateIds;
            if (equipment.equipmentType == EquipmentType.Blueprint)
            {
                candidateIds = GetValidBlueprintCraftOutputIds(card, selectedTier);
                if (candidateIds.Length == 0)
                {
                    selectedTier = GetHighestValidBlueprintCraftOutputTier(card, selectedTier);
                    candidateIds = selectedTier == CraftTier.Tier0
                        ? new int[0]
                        : GetValidBlueprintCraftOutputIds(card, selectedTier);
                }
            }
            else
            {
#if ENABLE_SERVER_TEST
                candidateIds = GetValidCraftOutputIds(card, selectedTier);
#else
                candidateIds = selectedTier == CraftTier.Tier5
                    ? GetValidCraftOutputIds(card, selectedTier)
                    : card.GetCardIdsByTier(selectedTier);
#endif
            }

            if (selectedTier == CraftTier.Tier5 && candidateIds.Length == 0)
            {
                selectedTier = GetHighestValidCraftOutputTier(card, CraftTier.Tier4);
                candidateIds = selectedTier == CraftTier.Tier0
                    ? new int[0]
                    : GetValidCraftOutputIds(card, selectedTier);
            }

            if (candidateIds != null && candidateIds.Length > 0)
            {
                // Random select from tier's card IDs
                itemId = candidateIds[Random.Range(0, candidateIds.Length)];

                // Get scale/statScale for tier
                (scale, statScale) = GetScaleForTier(selectedTier, equipment.rareType, equipment.equipmentType, card);
            }
            // If tier selected but no card IDs found, itemId stays -1 (no evolution, keep original)
        }
        else if (card != null && !card.HasCraftOutputTiers())
        {
            // Special handling for FaceHair and Body - use BattleManager lists
            if (equipment.IsSkin() && equipment.rareType == RareType.Legendary)
            {
                if (n > 800 - evolChance)
                {
                    if (equipment.equipmentType == EquipmentType.FaceHair)
                    {
                        // Use BattleManager's craftedFaceHairs list
                        if (BattleManager.instance.craftedFaceHairs != null && BattleManager.instance.craftedFaceHairs.Count > 0)
                        {
                            itemId = BattleManager.instance.craftedFaceHairs[Random.Range(0, BattleManager.instance.craftedFaceHairs.Count)];
                        }

                        // Default statScale for FaceHair evolution (same as Craft())
                        statScale = 2;
                    }
                    else if (equipment.equipmentType == EquipmentType.Body)
                    {
                        // Use BattleManager's craftedBodies list
                        if (BattleManager.instance.craftedBodies != null && BattleManager.instance.craftedBodies.Count > 0)
                        {
                            itemId = BattleManager.instance.craftedBodies[Random.Range(0, BattleManager.instance.craftedBodies.Count)];
                        }

                        // Default statScale for Body evolution (same as Craft())
                        statScale = 2;
                    }
                }
            }
        }
        // If no craftOutputTiers and no fallback logic applies, itemId stays -1 (no evolution, keep original itemId)

        // Set itemId if evolution occurred
        if (itemId > -1)
        {
            newEquipment.itemId = itemId;
            if (equipment.equipmentType == EquipmentType.Blueprint)
            {
                Card outputCard = DataHolder.Instance().GetData<Card>(itemId);
                if (outputCard == null || outputCard.equipmentType == EquipmentType.Blueprint)
                    return null;

                newEquipment.equipmentType = outputCard.equipmentType;
            }
        }

        scale = ForgeCraftRules.GetBaseStatScale(equipment.equipmentType, newEquipment.equipmentType, scale);

        // Apply stat scaling (same logic as Craft())
        foreach (var stat in equipment.stats)
        {
            StatValue statValue = new StatValue(stat);
            if (itemId >= 0)
            {
                statValue.value = Random.Range(1 + (scale - 1) / 5, scale) * statValue.value;
            }

            newEquipment.stats = DataUtils.Add(statValue, newEquipment.stats);
        }

        // For potion x10 base stat
        float elixirDuration = 120;
        if (newEquipment.IsElixir())
        {
            foreach (var stat in newEquipment.stats)
            {
                if (stat.statType == StatType.Health && stat.value > 300)
                {
                    stat.value = 5 * stat.value;
                }
                else
                    stat.value = 10 * stat.value;
            }

            foreach (string id in ids)
            {
                Equipment ingredient = characterIngredient.GetEquipment(id);

                if (ingredient != null)
                {
                    elixirDuration += (int)ingredient.rareType * 60 * (1 + 0.1f * ingredient.level);
                }
            }
        }

        // Process ingredient crafting (success/fail)
        int count = 0;
        foreach (string id in ids)
        {
            var result = newEquipment.Craft(characterIngredient.GetEquipment(id), count);

            if (result)
            {
                success.Add(id);
            }
            else
            {
                fail.Add(id);
            }

            count++;
        }

        // Remove buff max stat (Artifact) - only if no evolution (Tier0)
        if (newEquipment.equipmentType == EquipmentType.Artifact)
        {
            foreach (var stat in newEquipment.stats)
            {
                if (stat.statValueType == StatValueType.Max && selectedTier == CraftTier.Tier0)
                {
                    stat.value = 0;
                }
            }
        }

        // Elixir duration handling
        if (newEquipment.IsElixir())
        {
            Card cardEvo = DataHolder.Instance().GetData<Card>(newEquipment.itemId);

            if (cardEvo != null)
            {
                var duration = cardEvo.GetStatData(StatType.Duration);
                duration.value = Random.Range(duration.minValue, duration.maxValue);
                StatValue statValue = new StatValue(duration);
                newEquipment.stats = DataUtils.Add(statValue, newEquipment.stats);
            }
        }

        // Potion craft stat scaling
        if (newEquipment.IsElixir())
        {
            foreach (var stat in newEquipment.stats)
            {
                if (stat.statType == StatType.Duration)
                {
                    stat.value = elixirDuration;
                }
                else
                {
                    stat.value = statScale * stat.value;
                }
            }
        }
        else
        {
            // Increase all stat 1 more time
            if (statScale > 1)
            {
                foreach (var stat in newEquipment.stats)
                {
                    stat.value = Random.Range(1 + (statScale - 1) / 5, statScale) * stat.value;
                }
            }
        }

        // Artifact evolution bonus stats (Tier1 = evolution)
        if (newEquipment.equipmentType == EquipmentType.Artifact && selectedTier != CraftTier.Tier0)
        {
            // Increase Stat
            foreach (var stat in newEquipment.stats)
            {
                int n1 = Random.Range(0, 100);

                if (stat.statType == StatType.Duration && n1 < 10)
                    stat.value = Random.Range(1.1f, 1.3f) * stat.value;

                n1 = Random.Range(0, 100);
                if (stat.statType == StatType.CoolDown && n1 < 10)
                    stat.value = Random.Range(0.7f, 0.95f) * stat.value;

                if (stat.statType == StatType.Health || stat.statType == StatType.Damage ||
                    stat.statType == StatType.Speed)
                {
                    float n2 = Random.Range(1.02f, 1.1f);
                    stat.value *= n2;
                }

                if (stat.statValueType == StatValueType.Max)
                {
                    if (newEquipment.GetStat(StatType.NumberTarget) < 2)
                        stat.value = Random.Range(5, 25);
                    else
                        stat.value = Random.Range(2, 12);

                    if (card.skillType == SkillType.DebuffAOE)
                    {
                        stat.value *= -1;
                    }
                }
            }
        }
#endif
        return newEquipment;
    }

#if ENABLE_SERVER_TEST

    private int GetServerTestCraftChange()
    {
        var character = BattleManager.instance.GetCharacterData(userName);
        if (character == null) return 0;

        var vipLevel = character.GetVipLevel();
        if (vipLevel <= 1)
        {
            return Random.Range(0, 1000);
        }
        else if (vipLevel <= 5)
        {
            return Random.Range(500, 1000);
        }
        else if (vipLevel <= 10)
        {
            return Random.Range(800, 1000);
        }
        else if (vipLevel <= 15)
        {
            return Random.Range(900, 1000);
        }
        else
        {
            return Random.Range(950, 1000);
        }
    }

#endif

    //----------------------------------------------------------------
    [TargetRpc]
    void RpcMergeIngredient(NetworkConnectionToClient networkConnectionToClient, bool isSuccess, string equipmentId)
    {
        if (isSuccess == false)
        {
            return;
        }
        if (UIManager.instance == null)
            return;

        var mergeIngredientView = UIManager.instance.FindView<MergeIngredientView>();

        if (mergeIngredientView.IsOpen)
        {
            mergeIngredientView.RequestMergeIngredientCallback(equipmentId);
        }
        else
        {
            StartCoroutine(UIManager.instance.CallbackAutoMergeIngredientCO(equipmentId));
        }

    }

    public CurrencyData GetCostEventMerge(int currencyId)
    {
        CurrencyData result = new()
        {
            currencyId = currencyId
        };

        var config = BattleManager.instance.gameDataConfig;

        if (result.currencyId == GOLD_ID)
        {
            result.value = config.MergeEventCostGold;
        }
        else if (result.currencyId == DIAMOND_ID)
        {
            result.value = config.MergeEventCostDiamond;
        }
        else if (result.currencyId == TH_COIN_ID)
        {
            result.value = config.MergeEventCostTH;
        }

        return result;
    }

    public CurrencyData GetRollCost(int numberRoll, int currencyId = 1)
    {
        int rollCost = 99 * numberRoll;
        return new() { currencyId = currencyId, value = rollCost };
    }


    [TargetRpc]
    void RpcSeasonEvent(NetworkConnectionToClient networkConnectionToClient, SeasonEventResponse response, int thCost)
    {
        if (UIManager.instance == null)
            return;

        UIManager.instance.HandleResponse(response);

        // ✅ Track TH Consumed (event roll)
#if ENABLE_ANALYTIC_SERVICE
        if (thCost > 0 && AnalyticsManager.instance != null)
        {
            AnalyticsManager.instance.TrackTHConsumed(thCost, "event_roll");
        }
#endif
    }

    [TargetRpc]
    public void RpcLoot(NetworkConnectionToClient networkConnectionToClient,
        CurrencyData[] currencyDatas, List<Equipment> equipment)
    {
        HandleLootReceived(currencyDatas, equipment, null);
    }

    [TargetRpc]
    public void RpcCombatLoot(NetworkConnectionToClient networkConnectionToClient,
        CurrencyData[] currencyDatas, List<Equipment> equipment, CharacterHistoryContext characterContext,
        HistoryLogActionType actionType)
    {
        if (actionType == HistoryLogActionType.Add)
            HandleLootReceived(currencyDatas, equipment, characterContext);
        else if (actionType == HistoryLogActionType.Lost)
            HandleLootLost(currencyDatas, equipment, characterContext);
    }

    private void HandleLootReceived(CurrencyData[] currencyDatas, List<Equipment> equipment, CharacterHistoryContext characterContext)
    {
#if ENABLE_CLIENT
        // ✅ SERVER-ONLY: Add null check for IngameNotifyManager
        if (IngameNotifyManager.instance == null) return;

        for (int i = 0; i < currencyDatas.Length; i++)
        {
            var c = currencyDatas[i];
            if (c == null || c.value == 0)
            {
                continue;
            }

            IngameNotifyManager.instance.OnToastView(new NotifyData()
            {
                CurrencyID = c.GetCurrencyType(),
                IntParam = c.value,
                Source = BoxSourceType.PK,
                RareType = RareType.Epic,
                NotifyType = NotifyType.AddCurrency,
                ActionType = HistoryLogActionType.Add,
            });

            if (ClientManager.instance != null && UIManager.instance != null)
                ClientManager.instance.AddHistoryReward(HistoryRewardView.CreateNotifyData(c, BoxSourceType.PK, NotifyType.AddCurrency, HistoryLogActionType.Add), characterContext);
        }

        foreach (var item in equipment)
        {
            IngameNotifyManager.instance.OnToastView(new NotifyData()
            {
                NotifyType = NotifyType.AddItem,
                Source = BoxSourceType.PK,
                RareType = item.rareType,
                IntParam = item.itemId,
                ActionType = HistoryLogActionType.Add,
            });

            if (ClientManager.instance != null && UIManager.instance != null)
                ClientManager.instance.AddHistoryReward(HistoryRewardView.CreateNotifyData(item, BoxSourceType.PK, NotifyType.AddItem, HistoryLogActionType.Add), characterContext);
        }
#endif
    }

    [TargetRpc]
    public void RpcLooted(NetworkConnectionToClient networkConnectionToClient,
    CurrencyData[] currencyDatas, List<Equipment> equipment)
    {
        HandleLootLost(currencyDatas, equipment, null);
    }

    private void HandleLootLost(CurrencyData[] currencyDatas, List<Equipment> equipment, CharacterHistoryContext characterContext)
    {

#if ENABLE_CLIENT
        // ✅ SERVER-ONLY: Add null check for IngameNotifyManager
        if (IngameNotifyManager.instance == null) return;

        for (int i = 0; i < currencyDatas.Length; i++)
        {
            var c = currencyDatas[i];
            if (c == null || c.value == 0)
            {
                continue;
            }
            IngameNotifyManager.instance.OnToastView(new NotifyData()
            {
                CurrencyID = c.GetCurrencyType(),
                IntParam = c.value,
                Source = BoxSourceType.PK,
                RareType = RareType.Epic,
                NotifyType = NotifyType.AddCurrency,
                ActionType = HistoryLogActionType.Lost,
            });

            if (ClientManager.instance != null && UIManager.instance != null)
                ClientManager.instance.AddHistoryReward(HistoryRewardView.CreateNotifyData(c, BoxSourceType.PK, NotifyType.AddCurrency, HistoryLogActionType.Lost), characterContext);
        }

        foreach (var item in equipment)
        {
            IngameNotifyManager.instance.OnToastView(new NotifyData()
            {
                NotifyType = NotifyType.AddItem,
                Source = BoxSourceType.PK,
                RareType = item.rareType,
                IntParam = item.itemId,
                ActionType = HistoryLogActionType.Lost,
            });

            if (ClientManager.instance != null && UIManager.instance != null)
                ClientManager.instance.AddHistoryReward(HistoryRewardView.CreateNotifyData(item, BoxSourceType.PK, NotifyType.AddItem, HistoryLogActionType.Lost), characterContext);
        }
#endif
    }

    //----------------------------------------------------------------
    //Request Buy Box Artifact
    //----------------------------------------------------------------
    [Client, System.Obsolete]
    public void RequestBuyBoxArtifact(int boxId, int apiToken)
    {
        CmdBuyBoxArtifact(boxId, apiToken);
    }

    [Command]
    public void CmdBuyBoxArtifact(int boxId, int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdBuyBoxArtifact)))
            return;

        //if (this.GetHealth() <= 0 || this.mapZoneType != MapZoneType.Village)
        if (this.GetHealth() <= 0 || !IsStandingOn(RuntimeZoneType.Village))
            return;

        if (BattleManager.instance.GetIsMaintenance())
            return;

        if (HasNoInventorySlot())
            return;

        var item = DataHolder.Instance().GetData<Item>(boxId);
        if (item == null || !item.isAvailable || item.itemType != ItemType.Anbe ||
            item.cost == null || item.cost.Length == 0 || item.cost.Any(x => x == null || x.value < 0))
        {
            return;
        }

        var box = DataHolder.Instance().GetData<Box>(item.boxId);
        if (box == null || HaveEnoughMoneys(item.cost) == false)
        {
            return;
        }
        PayCosts(item.cost);

        Log(LogAction.BuyAnbe,
            $"BoxID:{boxId}|Cost:{string.Join(",", item.cost.Select(x => x.Log()))}",
            value: item.cost[0].value.ToString());
        ServerOpenBox(box, BoxSourceType.ShardShop);
        BattleManager.instance.SavePlayerData(this);
#endif
    }

    //----------------------------------------------------------------
    //Request Input code
    //----------------------------------------------------------------

    [Client]
    public void RequestClaimSocialReward(string rewardKey, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdClaimSocialReward(rewardKey, apiToken);
    }

    [Command]
    private void CmdClaimSocialReward(string rewardKey, int apiToken)
    {
#if ENABLE_SERVER
        if (BattleManager.instance.GetIsMaintenance())
            return;

        if (!ServerValidateApiToken(apiToken, nameof(CmdClaimSocialReward)))
        {
            return;
        }

        LogicClaimSocialReward(rewardKey);
#endif
    }

    [Server]
    private void LogicClaimSocialReward(string rewardKey)
    {
#if ENABLE_SERVER
        CharacterData characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData == null)
        {
            return;
        }

        if (!SocialRewardKeys.IsClaimable(rewardKey))
        {
            RpcClaimSocialReward(connectionToClient, false, rewardKey, claimedSocialRewards.ToArray());
            return;
        }

        if (characterData.claimedSocialRewards == null)
        {
            characterData.claimedSocialRewards = new List<string>();
        }

        if (characterData.claimedSocialRewards.Contains(rewardKey))
        {
            claimedSocialRewards = new List<string>(characterData.claimedSocialRewards);
            RpcClaimSocialReward(connectionToClient, false, rewardKey, claimedSocialRewards.ToArray());
            return;
        }

        characterData.claimedSocialRewards.Add(rewardKey);
        claimedSocialRewards = new List<string>(characterData.claimedSocialRewards);

        var currencyData = new CurrencyData()
        {
            currencyId = GameConst.DIAMOND_ID,
            value = SocialRewardKeys.RewardDiamond,
        };
        int currentDiamond = characterInventory.diamond;

        ReceiveCurrencies(new List<CurrencyData>() { currencyData }, BoxSourceType.System);

        if (connectionToClient != null)
        {
            BattleManager.instance.gameLogicBehavior.TargetReceiveCurrency(connectionToClient, currentDiamond, currencyData);
        }

        BattleManager.instance.SavePlayerData(this);
        BattleManager.Log(GameLogType.UserTracking,
            $"{userName} claimed social reward {rewardKey}: +{SocialRewardKeys.RewardDiamond} diamond");

        RpcClaimSocialReward(connectionToClient, true, rewardKey, claimedSocialRewards.ToArray());
#endif
    }

    [TargetRpc]
    private void RpcClaimSocialReward(NetworkConnectionToClient networkConnectionToClient, bool isSuccess, string rewardKey, string[] socialRewards)
    {
#if ENABLE_CLIENT
        claimedSocialRewards = socialRewards != null ? socialRewards.ToList() : new List<string>();

        MCP.Manager.Client.NotifyDotManager.Instance.RefreshSocialNotifications();

        if (UIManager.instance == null)
        {
            return;
        }

        var socialView = UIManager.instance.FindView<SocialView>();
        if (socialView != null)
        {
            socialView.RefreshRewardState();
        }
#endif
    }

    [Client]
    public void RequestInputCode(string code, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdInputCode(code, apiToken);
    }


    [Command]
    public void CmdInputCode(string code, int apiToken)
    {
#if ENABLE_SERVER
        if (BattleManager.instance.GetIsMaintenance())
            return;

        if (!ServerValidateApiToken(apiToken, nameof(CmdInputCode)))
        {
            return;
        }
        LogicUseInputCode(code);
#endif
    }

    [Server]
    private void LogicUseInputCode(string code)
    {
#if ENABLE_SERVER

        var codeBeginner = BattleManager.instance.codeBeginner.Contains(code);
        if (codeBeginner == false)
        {
            if (GetLandType() == LandType.BeginnerLand)
            {
                return;
            }
        }

        code = code.Replace("-", "");

        Log(LogAction.InputCode, $"Code:{code}|Status:Sent");
        if (ValidateFromFormattedCode(code) && !this.activationCodes.Contains(code))
        {
            StartCoroutine(CmdInputCodeCouroutine(code));
        }
        else
        {
            RpcInputCode(this.connectionToClient, isSuccess: false, -1, 0);
            return;
        }
#endif
    }


    IEnumerator CmdInputCodeCouroutine(string code)
    {
#if ENABLE_SERVER
        //Log(LogAction.InputCode, "Code:" + code, "Status:Validated");
        if (MmoAdminApiManager.GetInstance() != null && MmoAdminApiManager.GetInstance().IsInitialized())
        {
            while (BattleManager.instance.processingActivationCodes.Contains(code))
            {
                yield return new WaitForEndOfFrame();
            }


            BattleManager.instance.processingActivationCodes.Add(code);

            //Log(LogAction.InputCode, "Code:" + code, "Status:SendingToAPI");
            List<AccountActivateCodeRequest> codes = new List<AccountActivateCodeRequest>
                        {
                            new AccountActivateCodeRequest() { activationCode = code, username = this.userName}
                        };

            bool isDone = false;
            bool isError = false;
            int productId = -1;

            Thread saveThread = new Thread(() =>
            {
                MmoAdminApiManager.GetInstance().ActivateCodes(
                codes,
                (response) =>
                {
                    foreach (AccountActivateCodeResult accountActivateCodeResult in response.activationResult)
                    {
                        if (accountActivateCodeResult.activatedStatus == CodeActivationResult.Success)
                        {
                            this.activationCodes.Add(code);

                            //Add Reward here                           
                            productId = accountActivateCodeResult.productId;

                        }
                    }

                    isDone = true;
                    Log(LogAction.InputCode,
                        $"Code:{code}|Status:Success|ProductId:{productId}",
                        value: productId.ToString());
                },
                (errorCode, error) =>
                {
                    isDone = true;
                    isError = true;
                    this.wrongCode++;
                    Log(LogAction.InputCode,
                        $"Code:{code}|Status:Error|Message:{errorCode}:{error}");
                }
                );

            });
            saveThread.Start();

            while (!isDone)
            {
                yield return new WaitForEndOfFrame();
            }

            if (BattleManager.instance.processingActivationCodes.Contains(code))
                BattleManager.instance.processingActivationCodes.Remove(code);

            if (isError)
            {
                RpcInputCode(connectionToClient, isSuccess: false, productId, 0);
                yield break;
            }

            if (productId < 0)
            {
                RpcInputCode(connectionToClient, isSuccess: false, productId, 0);
                yield break;
            }

            Bundle bundle = DataHolder.Instance().GetData<Bundle>(productId);
            List<ItemPack> itemPacks = BattleManager.GetItemPackFromBundle(bundle);
            if (bundle == null)
            {
                isError = true;
                BattleManager.Log(GameLogType.Error, userName + " code error no bundle found " + productId);
                yield break;
            }

            // ✅ Calculate TH amount from itemPacks
            int thAmount = 0;
            foreach (ItemPack itemPack in itemPacks)
            {
                if (itemPack.itemClass == ItemClass.Currency &&
                    itemPack.itemId == (int)CurrencyID.THCoin)
                {
                    thAmount += itemPack.number;
                }
            }

            Log(LogAction.InputCode, $"Code:{code}|Action:Use");

            ReceiveItemPacks(itemPacks, BoxSourceType.ActivationCode);
            Log(LogAction.InputCode, $"Code:{code}|Status:Complete|ProductID:{productId}|TH:{thAmount}");

            if (thAmount >= 1000)
            {
                var count = thAmount / 1000;

                for (int i = 0; i < count; i++)
                {
                    IAPGiftService.SendGiftToFriendsAndClan(userName, characterName, 618);
                    BattleManager.Log(GameLogType.UserTracking, userName + " send gift to friend & clan");
                }
            }

            // ✅ Send RPC with TH amount
            RpcInputCode(this.connectionToClient, isSuccess: true, productId, thAmount);
        }
#else
        yield return null;
#endif
    }

    private void OnVipLevelUp(CharacterData characterData)
    {
        numberRollSeasonEventFree = characterData.numberRollSeasonEventFree;
        characterInventory.SetAnnouncement(characterData.announcement);
        characterInventory.SetAutomationTile(characterData.automationTile);
        int vipLevel = characterData.GetVipLevel();
        RpcVipData(connectionToClient, characterData.playerDailyRewards, characterData.playerVipStats, vipLevel);
    }


    //Check code
    private bool ValidateFromFormattedCode(string code)
    {
        // Replace hyphens (-) with spaces
        if (code.Length != 12)
            return false;

        return true;
    }

    [TargetRpc]
    void RpcInputCode(NetworkConnectionToClient networkConnectionToClient, bool isSuccess, int bundleId, int thAmount)
    {
#if ENABLE_CLIENT
        if (isSuccess)
        {
            if (UIManager.instance == null)
                return;

            UIManager.instance.FindView<GiftcodeView>().OnSuccess();

            // ✅ Track Activation Code TH Analytics (chỉ khi có TH)
            if (thAmount > 0)
            {
#if ENABLE_ANALYTIC_SERVICE
                if (AnalyticsManager.instance != null)
                {
                    string code = ""; // Code không có trong RPC, có thể lưu tạm hoặc bỏ qua
                    AnalyticsManager.instance.TrackActivationCodeTH(code, thAmount, bundleId);
                }
#endif
            }
        }
        else
        {
            if (UIManager.instance != null)
            {
                var giftCodeView = UIManager.instance.FindView<GiftcodeView>();
                if (giftCodeView.IsOpen)
                {
                    giftCodeView.OnFail();
                }
            }
        }
#endif
    }
    //----------------------------------------------------------------
    //Request Buy Box Arena
    // TODO: chuyển qua shop data
    //----------------------------------------------------------------
    [Client]
    public void RequestBuyBoxArena(int itemId, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdBuyBoxArena(itemId, apiToken);
    }

    [Command]
    public void CmdBuyBoxArena(int itemId, int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdBuyBoxArena)))
            return;
        LogicBuyBoxArena(itemId);
#endif
    }

    //----------------------------------------------------------------
    //Request Payment
    //----------------------------------------------------------------

    [Client]
    public void RequestPayment(int thValue, int apiToken)
    {
        CmdPayment(thValue, apiToken);
    }

    [Command]
    private void CmdPayment(int thValue, int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdPayment)) || thValue <= 0)
            return;

        int bundleID = 24;
        if (thValue == 50)
        {
            bundleID = 30;
        }
        else if (thValue == 100)
        {
            bundleID = 31;
        }
        else if (thValue == 250)
        {
            bundleID = 32;
        }
        else if (thValue == 500)
        {
            bundleID = 33;
        }
        else if (thValue == 1000)
        {
            bundleID = 34;
        }
        else if (thValue == 2500)
        {
            bundleID = 35;
        }

        AccountInfo accountInfo = BattleManager.instance.GetAccountInfo(this.userName);

        var email = accountInfo.email;
        if (string.IsNullOrEmpty(email) || DataUtils.IsValidEmail(email) == false)
            return;

        Log(LogAction.BuyIAPByEmail,
            $"Amount:{thValue}TH|Email:{email}|BundleID:{bundleID}|Platform:{accountInfo.platform}|Device:{accountInfo.deviceId}",
            value: thValue.ToString());

        if (string.IsNullOrEmpty(lastTimeOTP) == false)
        {
            var time = DataUtils.StringToTime(lastTimeOTP);
            var timeSpan = System.DateTime.Now - time;
            if (timeSpan.TotalSeconds < 10)
            {
                RpcPayment(connectionToClient, false, "Hãy thử lại");
                return;
            }
        }

        lastTimeOTP = DataUtils.TimeToString(System.DateTime.Now);

        MCP.Mmo.DataModels.Admin.Request.InitTopupTransactionRequest request = new MCP.Mmo.DataModels.Admin.Request.InitTopupTransactionRequest(
            this.userName, this.ipAddress, bundleID.ToString(), email, accountInfo.deviceId, accountInfo.platform);

        MmoAdminApiManager.GetInstance().InitTopupTransaction(
            request,
            (response) =>
            {
                Debug.Log("Response: " + response.ToJson());
                RpcPayment(connectionToClient, true, "Một thanh toán đã được gửi tới email của bạn");

            },
            (error, message) =>
            {
                Debug.Log("Error: " + error + " message: " + message);
                RpcPayment(connectionToClient, false, message);
            }
        );

#endif
    }

    [TargetRpc]
    private void RpcPayment(NetworkConnectionToClient networkConnectionToClient, bool result, string message)
    {
        if (UIManager.instance == null)
            return;

        if (result)
        {
            UIManager.instance.FindView<PaymentView>().Close();
            UIManager.instance.FindView<ShopView>(UIManager.SHOP_IAP_VIEW).Close();
        }

        IngameNotifyManager.instance.Notify(message);
    }


    //----------------------------------------------------------------
    //Request Buy Box IAP
    //----------------------------------------------------------------
    [Client]
    public void RequestBuyBoxIAP(IAPData iAPData, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdBuyBoxIAP(iAPData, apiToken);
    }


    [Command]
    private async void CmdBuyBoxIAP(IAPData iAPData, int apiToken)
    {
        LogicCheckBuyBoxIAP(iAPData, apiToken);
    }

    [Server]
    private async void LogicCheckBuyBoxIAP(IAPData iAPData, int apiToken)
    {
#if ENABLE_SERVER

        if (!ServerValidateApiToken(apiToken, nameof(LogicCheckBuyBoxIAP)))
            return;

        if (iAPData == null || string.IsNullOrEmpty(iAPData.productId) ||
            string.IsNullOrEmpty(iAPData.receipt) || iAPData.username != userName)
        {
            Log(LogAction.IAPFraud, "Reason:InvalidClientIAPData");
            return;
        }

        string requestedBoxId = GetBoxId(iAPData.productId);
        if (!BattleManager.instance.iapProductToItemId.ContainsKey(requestedBoxId) &&
            !BattleManager.instance.iapSuggestion.ContainsKey(requestedBoxId))
        {
            Log(LogAction.IAPFraud, $"Reason:UnknownProduct|Product:{iAPData.productId}");
            return;
        }

        Log(LogAction.BuyIap, "Validating Product:" + iAPData.productId + "|Transaction:" + iAPData.transactionId + "|IP:" + iAPData.ip + "|Device:" + iAPData.deviceId + "|OS:" + iAPData.deviceOS, iAPData.ToJson());


#if ENABBLE_CHECK_IAP

        if (iAPData.deviceOS == "Android")
        {
            try
            {
                JObject jsonObject = JObject.Parse(iAPData.receipt);

                if (jsonObject == null)
                {
                    Log(LogAction.IAPFraud, "Reason:WrongReceiptFormat|Step:ParseJSON");
                    return;
                }

                string payloadString = jsonObject["Payload"].ToString();

                if (string.IsNullOrEmpty(payloadString))
                {
                    Log(LogAction.IAPFraud, "Reason:WrongReceiptFormat|Step:ParseJSON");
                    return;
                }

                // Parse the Payload JSON object
                JObject payloadObject = JObject.Parse(payloadString);

                if (payloadObject == null)
                {
                    Log(LogAction.IAPFraud, "Reason:WrongReceiptFormat|Step:ParseJSON");
                    return;
                }

                string nestedJsonString = payloadObject["json"].ToString();

                if (string.IsNullOrEmpty(nestedJsonString))
                {
                    Log(LogAction.IAPFraud, "Reason:WrongReceiptFormat|Step:ParseJSON");
                    return;
                }

                // Parse the nested JSON object
                JObject nestedJsonObject = JObject.Parse(nestedJsonString);

                if (nestedJsonObject == null)
                {
                    Log(LogAction.IAPFraud, "Reason:WrongReceiptFormat|Step:ParseJSON");
                    return;
                }


                //string orderId = nestedJsonObject["orderId"].ToString();
                string purchaseToken = nestedJsonObject["purchaseToken"].ToString();
                string productId = nestedJsonObject["productId"].ToString();
                string orderId = nestedJsonObject["orderId"].ToString();
                if (!string.Equals(productId, iAPData.productId, System.StringComparison.Ordinal))
                {
                    Log(LogAction.IAPFraud,
                        $"Reason:ProductMismatch|ReceiptProduct:{productId}|ClientProduct:{iAPData.productId}|OrderID:{orderId}");
                    return;
                }

                string bundle = productId.Substring(0, productId.LastIndexOf('.'));

                if (BattleManager.instance.transactionIds.Contains(orderId))
                    return;

                if (currenOrderIds.Contains(orderId))
                    return;

                currenOrderIds.Add(orderId);

                

                MmoAdminApiManager.GetInstance().VerifyPurchase(
                bundle,
                productId,
                iAPData.receipt,
                orderId,
                iAPData.deviceOS,
                userName,
                (response) =>
                {
                    if(currenOrderIds.Contains(orderId))
                        currenOrderIds.Remove(orderId);

                    if (response.isValidTransaction)
                    {
                        BattleManager.instance.transactionIds.Add(orderId);
                        //BattleManager.Log(GameLogType.Info,"Good transaction: " + response.ToJson());
                        Log(LogAction.BuyIap, "Validated Product:" + iAPData.productId);
                        LogicBuyBoxIAP(iAPData);
                    }
                    else
                    {
                        Log(LogAction.IAPFraud, $"Reason:ValidationFailed|Product:{iAPData.productId}|Status:{response.isValidTransaction}");
                        
                        // ✅ FIX #2: Send error response to clear client history
                        if (NetSafe.CanTarget(this))
                        {
                            RpcBuyBoxIAPFailed(connectionToClient, orderId, "Receipt validation failed");
                        }
                    }
                },
                (error, message) =>
                {
                    if (currenOrderIds.Contains(orderId))
                        currenOrderIds.Remove(orderId);

                    Log(LogAction.BuyIap, "Error:" + message);
                    //BattleManager.Log(GameLogType.Info,"Error: " + error + " message: " + message);
                    
                    // ✅ FIX #3: Send error response to clear client history
                    if (NetSafe.CanTarget(this))
                    {
                        RpcBuyBoxIAPFailed(connectionToClient, orderId, $"Admin API Error: {error} - {message}");
                    }
                    return;
                },
                () =>
                {
                    BattleManager.instance.transactionIds.Add(orderId);
                    if (currenOrderIds.Contains(orderId))
                        currenOrderIds.Remove(orderId);

                    Log(LogAction.BuyIap, "Timeout");
                    //BattleManager.Log(GameLogType.Info,userName + " iap timeout");
                    LogicBuyBoxIAP(iAPData);
                });
            }
            catch (System.Exception e)
            {
        Log(LogAction.IAPFraud, "Reason:InvalidReceipt|Exception:ParseError");
                return;
            }
        }
        else
        {

            try
            {
                JObject jsonObject = JObject.Parse(iAPData.receipt);

                if (jsonObject == null)
                {
                    Log(LogAction.IAPFraud, "Reason:WrongReceiptFormat|Step:ParseJSON");
                    return;
                }

                string orderId = jsonObject["TransactionID"].ToString();



                if (BattleManager.instance.transactionIds.Contains(orderId))
                    return;

                if (currenOrderIds.Contains(orderId))
                    return;

                currenOrderIds.Add(orderId);

                MmoAdminApiManager.GetInstance().VerifyPurchase(
                "com.megacombat.treasurehunter",
                iAPData.productId,
                iAPData.receipt,
                orderId,
                iAPData.deviceOS,
                userName,
                (response) =>
                {
                    if (response.isValidTransaction)
                    {
                        BattleManager.instance.transactionIds.Add(orderId);
                        if (currenOrderIds.Contains(orderId))
                            currenOrderIds.Remove(orderId);
                        //BattleManager.Log(GameLogType.Info,"Good transaction: " + response.ToJson());
                        Log(LogAction.BuyIap, "Validated Product:" + iAPData.productId);
                        LogicBuyBoxIAP(iAPData);
                    }
                    else
                    {
                        if (currenOrderIds.Contains(orderId))
                            currenOrderIds.Remove(orderId);
                        Log(LogAction.IAPFraud, $"Reason:ValidationFailed|Product:{iAPData.productId}|OrderID:{orderId}|Status:{response.isValidTransaction}");
                        
                        // ✅ FIX #2: Send error response to clear client history (iOS)
                        if (NetSafe.CanTarget(this))
                        {
                            RpcBuyBoxIAPFailed(connectionToClient, orderId, "Receipt validation failed");
                        }
                    }
                },
                (error, message) =>
                {
                    if (currenOrderIds.Contains(orderId))
                        currenOrderIds.Remove(orderId);
                    //BattleManager.Log(GameLogType.Info,"Error: " + error + " message: " + message);
                    Log(LogAction.BuyIap, "Error:" + message);
                    // ✅ FIX #3: Send error response to clear client history (iOS)
                    if (NetSafe.CanTarget(this))
                    {
                        RpcBuyBoxIAPFailed(connectionToClient, orderId, $"Admin API Error: {error} - {message}");
                    }
                    return;
                },
                () =>
                {
                    BattleManager.instance.transactionIds.Add(orderId);
                    if (currenOrderIds.Contains(orderId))
                        currenOrderIds.Remove(orderId);
                    //BattleManager.Log(GameLogType.Info,userName + " iap timeout");
                    Log(LogAction.BuyIap, "Timeout");
                    LogicBuyBoxIAP(iAPData);
                });
            }
            catch (System.Exception e)
            {
                Log(LogAction.IAPFraud, "Reason:InvalidReceipt|Platform:iOS|Exception:ParseError");
                return;
            }
        }
#else
        LogicBuyBoxIAP(iAPData);
#endif
#endif
    }

    [Server]
    void LogicBuyBoxIAP(IAPData iAPData)
    {
#if ENABLE_SERVER

        //BattleManager.Log(GameLogType.UserTracking, this.userName + " buy IAP box successfull " + iAPData.productId + " transaction " + iAPData.transactionId);

        bool reloadWallet = false;

        string boxId = GetBoxId(iAPData.productId);

        if (BattleManager.instance.iapProductToItemId.TryGetValue(boxId, out int itemId))
        {
            var item = DataHolder.Instance().GetData<Item>(itemId);
            if (item == null)
                return;

            var box = DataHolder.Instance().GetData<Box>(item.boxId);
            if (box == null)
            {
                return;
            }

            Log(LogAction.BuyIap,
                "Box Added - Transaction ID" + iAPData.productId + "|Cost " + item.cost[0].Log(),
                value: item.cost[0].value.ToString());
            ServerOpenBox(box, BoxSourceType.IAP);
            BattleManager.instance.SavePlayerData(this);
            BattleManager.instance.AddIAPTransaction(iAPData);

            long thReward = 0;
            string productType = "other";
            switch (iAPData.productId)
            {
                case "com.megacombat.treasurehunter.thbox1": thReward = 10; productType = "th"; break;
                case "com.megacombat.treasurehunter.thbox2": thReward = 52; productType = "th"; break;
                case "com.megacombat.treasurehunter.thbox3": thReward = 220; productType = "th"; break;
                case "com.megacombat.treasurehunter.thbox4": thReward = 1200; productType = "th"; break;
                case "com.megacombat.treasurehunter.skinbox1":
                case "com.megacombat.treasurehunter.skinbox2":
                case "com.megacombat.treasurehunter.skinbox3": productType = "skin_box"; break;
                case "com.megacombat.treasurehunter.skipad1":
                case "com.megacombat.treasurehunter.skipad2":
                case "com.megacombat.treasurehunter.skipad3": productType = "skip_ad"; break;
            }
            EconomyManager.RecordIapPurchase(iAPData.productId, productType, thReward);
            if (thReward > 0)
                EconomyManager.RecordThEarn(thReward, "iap_" + iAPData.productId);

            RpcBuyBoxIAP(connectionToClient, iAPData.transactionId, reloadWallet);

            
            if (boxId == "thbox4")
            {
                IAPGiftService.SendGiftToFriendsAndClan(userName, characterName, 618);
                BattleManager.Log(GameLogType.UserTracking, userName + " send gift to friend & clan");
            }
            
        }
        else if (BattleManager.instance.iapSuggestion.TryGetValue(boxId, out int itemIdSuggestion))
        {
            BuyBoxSuggestionIAP(itemIdSuggestion);
        }
#endif
    }



    public string GetBoxId(string productId)
    {
        return BattleManager.GetBoxId(productId);
    }

    public static int GetVipLevel(int vipPoint)
    {
#if ENABLE_SERVER
        return (int)Mathf.Sqrt(vipPoint / 50);
#else
        return -1;
#endif

    }

    public float GetVipProgress(int vipPoint)
    {
        int currentLevel = GetVipLevel(vipPoint);
        int nextLevel = currentLevel + 1;

        float currentLevelCraftCount = currentLevel * currentLevel * 50;
        float nextLevelCraftCount = nextLevel * nextLevel * 50;

        if (vipPoint >= nextLevelCraftCount)
            return 1.0f;

        float progress = (vipPoint - currentLevelCraftCount)
            / (nextLevelCraftCount - currentLevelCraftCount);

        return Mathf.Clamp01(progress);
    }

    public (float, float) GetVipExpData(int vipPoint)
    {
        int currentLevel = GetVipLevel(vipPoint);
        int nextLevel = currentLevel + 1;

        float currentLevelCraftCount = currentLevel * currentLevel * 50;
        float nextLevelCraftCount = nextLevel * nextLevel * 50;

        float current = (vipPoint - currentLevelCraftCount);
        float next = (nextLevelCraftCount - currentLevelCraftCount);

        return (current, next);
    }

    [TargetRpc]
    void RpcBuyBoxIAP(NetworkConnectionToClient networkConnectionToClient, string transactionId, bool reloadWallet)
    {
        foreach (IAPData iAPData1 in ClientManager.instance.iapHistory)
        {
            if (iAPData1.transactionId == transactionId)
            {
                ClientManager.instance.iapHistory.Remove(iAPData1);
                break;
            }
        }


#if ENABLE_CLIENT
        ES3Helper.SaveEncrypted("IAPHistory", ClientManager.instance.iapHistory);
#endif
        if (UIManager.instance == null)
            return;
        IngameNotifyManager.instance.OnToastView(UIManager.GetDialog(151));

        if (reloadWallet)
        {
        }
    }

    // ✅ FIX #2-3: Add error response for IAP validation/API failures
    [TargetRpc]
    void RpcBuyBoxIAPFailed(NetworkConnectionToClient networkConnectionToClient, string transactionId, string errorMessage)
    {
        BattleManager.Log(GameLogType.Warning, $"[IAP] Purchase failed: {errorMessage} (Transaction: {transactionId})");

        // ✅ Clear from history to prevent infinite retry
        for (int i = ClientManager.instance.iapHistory.Count - 1; i >= 0; i--)
        {
            if (ClientManager.instance.iapHistory[i].transactionId == transactionId)
            {
                ClientManager.instance.iapHistory.RemoveAt(i);
                BattleManager.Log(GameLogType.Info, $"[IAP] Removed failed transaction from history: {transactionId}");
                break;
            }
        }

#if ENABLE_CLIENT
        ES3Helper.SaveEncrypted("IAPHistory", ClientManager.instance.iapHistory);
#endif

        // ✅ Show error to user
        if (UIManager.instance != null && IngameNotifyManager.instance != null)
        {
            IngameNotifyManager.instance.Notify($"Purchase validation failed. Contact support with ID: {transactionId}");
        }
    }

    //----------------------------------------------------------------
    //Request Buy THC Box
    //----------------------------------------------------------------
    [Client]
    public void RequestBuyBoxTHC(int itemId, int apiToken, string walletPassCode)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdBuyBoxTHC(itemId, apiToken, walletPassCode);
    }


    [Command]
    private void CmdBuyBoxTHC(int itemId, int apiToken, string walletPassCode)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdBuyBoxTHC)))
            return;

        var isCorrect = CheckWalletPassCode(walletPassCode);
        if (isCorrect == false)
        {
            return;
        }

        LogicBuyBoxTHC(itemId);
#endif
    }

    private bool LogicBuyBoxTHC(int itemId)
    {
#if ENABLE_SERVER
        Item item = DataHolder.Instance().GetData<Item>(itemId);
        if (item == null || !item.isAvailable || item.itemType != ItemType.THShop ||
            item.cost == null || item.cost.Length == 0 || item.cost.Any(x => x == null || x.value < 0))
            return false;

        if (HaveEnoughMoneys(item.cost) == false)
            return false;

        Box box = DataHolder.Instance().GetData<Box>(item.boxId);
        if (box == null)
            return false;

        PayCosts(item.cost);

        if (item.itemType == ItemType.THShop && item.cost.Length > 0 && item.cost[0].GetCurrencyType() == CurrencyID.THCoin)
            EconomyManager.RecordThBurn(item.cost[0].value, $"th_shop:item_{item.Id()}:box_{item.boxId}");

#if ENABLE_SERVER_BETA
        //Add Vip To player
        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);
        if (characterData != null)
        {
            if (item.cost.Length > 0)
            {
                bool isVipLevelUp = characterData.AddVipPoint(item.cost[0].value);
                if (isVipLevelUp)
                {
                    OnVipLevelUp(characterData);
                }
            }

        }
#endif

        if (item.cost.Length > 0 &&
            item.cost[0].GetCurrencyType() == CurrencyID.THCoin &&
            item.itemType == ItemType.THShop)
        {
            seasonTHShop += item.cost[0].value;
        }

        Log(LogAction.BuyShopTH,
            $"BoxID:{itemId}|Cost:{item.cost[0].Log()}",
            value: item.cost[0].value.ToString());
        ServerOpenBox(box, BoxSourceType.THShop);

        BattleManager.instance.SavePlayerData(this);

        // ✅ Get TH cost for analytics
        int thCost = 0;
        if (item.cost.Length > 0 && item.cost[0].GetCurrencyType() == CurrencyID.THCoin)
        {
            thCost = item.cost[0].value;
        }
        RpcBuyBoxTHC(this.connectionToClient, itemId, seasonTHShop, thCost);
        return true;
#endif
        return true;
    }

    [TargetRpc]
    void RpcBuyBoxTHC(NetworkConnectionToClient networkConnectionToClient, int itemId, int seasonTH, int thCost)
    {
#if ENABLE_CLIENT
        ClientManager.instance.mySeasonTHShop = seasonTH;
        var questView = UIManager.instance?.FindView<DailyQuestsView>();
        if (questView != null)
        {
            questView.MarkQuestDataDirty(QuestCategory.ContinuousLogin);
            questView.MarkQuestDataDirty(QuestCategory.ContinuousLoginQuestPoint);
            questView.ReloadCurrentTab();
        }

        MCP.Manager.Client.NotifyDotManager.Instance.RefreshQuestNotifications();

        // ✅ Track TH Consumed (TH Shop purchase)
#if ENABLE_ANALYTIC_SERVICE
        if (thCost > 0 && AnalyticsManager.instance != null)
        {
            AnalyticsManager.instance.TrackTHConsumed(thCost, "th_shop");
        }
#endif
#endif
    }

    //----------------------------------------------------------------
    // Start Open Chest
    //----------------------------------------------------------------

    private void ServerLogicStartOpenChest(ChestBehavior chestBehavior, string keyEquipmentId)
    {
#if ENABLE_SERVER
        if (this.GetHealth() <= 0 || chestBehavior == null || string.IsNullOrEmpty(keyEquipmentId))
            return;

        var landType = GetLandType();
        KeyBehavior key = ChestKeyManager.Instance.GetKey(chestBehavior.LandId);

        if (key == null) return;
        if (key.Id != keyEquipmentId) return; //Check ??


        //if (landType == LandType.CenterLand)
        //{
        //    chestBehavior = BattleManager.instance.chestBehavior;
        //    key = BattleManager.instance.keyBehavior;
        //}
        //else if (landType == LandType.UndeadLand)
        //{
        //    if (BattleManager.instance.GetUndeadChestBehavior().Contains(chestBehavior) == false)
        //        return;

        //    foreach (var undeadKey in BattleManager.instance.GetUndeadKeyBehavior())
        //    {
        //        if (undeadKey.id == keyEquipmentId)
        //        {
        //            key = undeadKey;
        //            break;
        //        }
        //    }
        //    if (key == null)
        //        return;
        //}

        if (chestBehavior != null && key != null && key.owner != null && key.ownerId == this.userName
            && Vector2.Distance(chestBehavior.transform.position, key.transform.position) <= GameConst.OPEN_CHEST_DISTANCE)
        {
            chestBehavior.OpenChest(key);
        }
#endif
    }

    //----------------------------------------------------------------
    // Open Chest
    //----------------------------------------------------------------

    [Server]
    public void SellKey()
    {
#if ENABLE_SERVER
        var key = characterInventory.GetEquipment(EquipmentType.Key);
        if (key != null)
        {
            LogicSellItem(key);
        }
#endif
    }

    [Server]
    public void LogicOpenChest(ChestBehavior chestBehavior, KeyBehavior keyBehavior)
    {
#if ENABLE_SERVER

        if (chestBehavior == null || keyBehavior == null)
        {
            return;
        }

        Card item = DataHolder.Instance().GetData<Card>(chestBehavior.ItemId);

        BattleManager.Log(GameLogType.Debug, userName + " Server try open chest ID " + chestBehavior.ItemId);


        if (item.keyId == keyBehavior.ItemId && keyBehavior.owner != null && Vector2.Distance(keyBehavior.transform.position, chestBehavior.transform.position) < 2)
        {
            Equipment key = keyBehavior.owner.GetInventoryEquipment(EquipmentType.Key);
            if (key != null)
            {
                keyBehavior.owner.SafeRemoveEquipment(key);
                LogicOpenChest(keyBehavior.owner, item.box);


                if (item.keyId == DIAMOND_KEY_ID)
                {
                    BattleManager.instance.SendServerNotificationToAll(keyBehavior.owner.characterName, DIALOG_SERVER_OPEN_CHEST);
                }
                else if (item.keyId == UNDEAD_KEY_ID)
                {
                    BattleManager.instance.SendServerNotificationToAll(keyBehavior.owner.characterName, DIALOG_SERVER_OPEN_UNDEAD_CHEST);
                }

                keyBehavior.owner.AddChestNumber(1);
                keyBehavior.owner.Log(LogAction.OpenChest, $"ChestType:{keyBehavior.ChestType}");
                BattleManager.instance.SavePlayerData(keyBehavior.owner);
                keyBehavior.MapItemState = MapItemState.Opened;
                chestBehavior.MapItemState = MapItemState.Opened;
                return;
            }
        }
#endif
    }


    private void LogicOpenChest(PlayerBehavior owner, Box box)
    {
#if ENABLE_SERVER
        if (owner != null)
            owner.ServerOpenBox(box);
#endif
    }
    //----------------------------------------------------------------
    // Open Box
    //----------------------------------------------------------------

    /// <summary>
    /// Hàm mở box
    /// </summary>
    /// <param name="box"></param>
    /// <param name="boxSourceType"></param>
    /// <param name="boxSourceId"> index trên BoxEditor </param>
    /// <param name="allStat"> card được mở ra có full chỉ số hay không </param>
    /// <returns></returns>
    [Server]
    public (List<Equipment>, List<CurrencyData>) ServerOpenBox(Box box, BoxSourceType boxSourceType = BoxSourceType.None, int boxSourceId = -1, bool allStat = false, bool ignoreTrophyCurrencies = false)
    {
#if ENABLE_SERVER
        if (box == null || box.randomPacks == null)
        {
            return (null, null);
        }

        RewardCurrencyInspectionResult thInspection =
            BattleManager.InspectBoxForCurrency(box, CurrencyID.THCoin);
        if (thInspection.ContainsCurrency && !BattleManager.IsTHRewardSourceAllowed(boxSourceType))
        {
            Log(LogAction.SuspiciousActivity,
                $"Reason:THSourceNotAllowed|Context:ServerOpenBox|Source:{boxSourceType}|BoxId:{box.id}|BoxSourceId:{boxSourceId}|RewardPath:{thInspection.Path}");
            return (null, null);
        }

        List<ItemPack> itemPacks = BattleManager.GetItemPacksFromBox(box);
        if (itemPacks == null || itemPacks.Count == 0)
        {
            return (null, null);
        }

        return ReceiveItemPacks(itemPacks, boxSourceType, boxSourceId, allStat, ignoreTrophyCurrencies);
#endif
        return (null, null);
    }

    public (List<Equipment>, List<CurrencyData>) ReceiveItemPacks(List<ItemPack> itemPacks,
        BoxSourceType boxSourceType = BoxSourceType.None, int boxSourceId = -1, bool allStat = false,
        bool ignoreTrophyCurrencies = false)
    {
#if ENABLE_SERVER
        RewardCurrencyInspectionResult thInspection = BattleManager.InspectItemPacksForCurrency(
            itemPacks,
            CurrencyID.THCoin,
            $"ItemPacks:{boxSourceType}:{boxSourceId}");
        if (thInspection.ContainsCurrency && !BattleManager.IsTHRewardSourceAllowed(boxSourceType))
        {
            Log(LogAction.SuspiciousActivity,
                $"Reason:THSourceNotAllowed|Context:ReceiveItemPacks|Source:{boxSourceType}|BoxSourceId:{boxSourceId}|RewardPath:{thInspection.Path}");
            return (null, null);
        }

        var equipments = BattleManager.GetEquipmentsFromItemPacks(itemPacks, allStat);
        ReceiveEquipments(equipments, boxSourceType, boxSourceId);

        var currencyDatas = BattleManager.GetCurrencyFromItemPacks(itemPacks);
        if (ignoreTrophyCurrencies)
        {
            currencyDatas.RemoveAll(currencyData =>
                currencyData.GetCurrencyType() == CurrencyID.PlayerTrophy ||
                currencyData.GetCurrencyType() == CurrencyID.ClanTrophy);
        }
        ReceiveCurrencies(currencyDatas, boxSourceType, boxSourceId);


        // Handle VipBonusStat from item packs
        var vipStats = BattleManager.GetVipBonusTypeFromItemPacks(itemPacks);
        if (vipStats != null && vipStats.Count > 0)
        {
            var characterData = BattleManager.instance.GetCharacterData(userName);
            if (characterData != null)
            {
                foreach (var playerVipStat in vipStats)
                {
                    // Add to CharacterData.playerVipStats
                    if (!characterData.playerVipStats.Contains(playerVipStat))
                    {
                        characterData.playerVipStats.Add(playerVipStat);

                        // Process VipStat (add to announcement, numberRollSeasonEventFree, automationTile, etc.)
                        BattleManager.ProcessPlayerVipStat(characterData, playerVipStat);

                        // Sync AutomationTile
                        if (this.characterInventory != null)
                        {
                            this.characterInventory.SetAutomationTile(characterData.automationTile);
                        }

                        // Sync FreeEventRoll (numberRollSeasonEventFree)
                        if (playerVipStat.vipBonusType == VipBonusType.FreeEventRoll)
                        {
                            this.numberRollSeasonEventFree = characterData.numberRollSeasonEventFree;
                        }

                        // Log khi nhận VipStat từ box
                        Log(LogAction.ReciveVipStat,
                            $"Type:{playerVipStat.vipBonusType}|Value:{playerVipStat.vipValue}|Source:{boxSourceType}|BoxId:{boxSourceId}",
                            playerVipStat.ToJson(),
                            playerVipStat.vipValue.ToString());

                        // Rpc to client-side
                        if (NetSafe.CanTarget(this))
                        {
                            RpcPlayerVipStat(connectionToClient, playerVipStat, 0);
                        }
                    }
                }
                BattleManager.instance.SaveCharacterData(characterData);
            }
        }

        /*
        var mobIds = BattleManager.GetMobIdsFromItemPack(itemPacks);
        */

        return (equipments, currencyDatas);
#endif
        return (null, null);
    }

    [Server]
    public void ReceiveEquipments(List<Equipment> equipments, BoxSourceType boxSourceType = BoxSourceType.None, int boxSourceId = -1)
    {
#if ENABLE_SERVER
        if (equipments.Count <= 0)
            return;

        int goldFactor = 1;
        if (BattleManager.instance.GetEventRunning(GameEventId.x2Gold))
            goldFactor = 2;

        for (int i = 0; i < equipments.Count; i++)
        {
            bool useRpc = true;
            bool checkSlot = false;

            if (boxSourceType == BoxSourceType.Mob ||
                boxSourceType == BoxSourceType.Quest ||
                boxSourceType == BoxSourceType.DailyReward ||
                boxSourceType == BoxSourceType.HitMap ||
                boxSourceType == BoxSourceType.Leaderboard)
            {
                useRpc = false;
            }

            if (boxSourceType == BoxSourceType.Mob || boxSourceType == BoxSourceType.Boss
                || boxSourceType == BoxSourceType.HitMap)
            {
                checkSlot = true;
            }

            var e = equipments[i];
            if (e.equipmentType == EquipmentType.Ingredient || e.equipmentType == EquipmentType.EventItem)
            {
                if (checkSlot)
                {
                    if (characterIngredient.GetEquipmentCount() >= GetFinalIngredientSlot())
                    {
                        int increaseGold = Random.Range(5, 8) * goldFactor;
                        var currentGold = GetGold();
                        if (this.connectionToClient != null)
                            BattleManager.instance.gameLogicBehavior.TargetReceiveCurrency(this.connectionToClient, currentGold, increaseGold, GameConst.GOLD_ID);
                        AddGold(increaseGold);
                        continue;
                    }
                }

                e.state = EquipmentState.Ingredient;
                characterIngredient.AddEquipment(e);
            }
            else if (e.IsCollection())
            {
                e.state = EquipmentState.Collection;
                characterCollection.AddEquipment(e);
                if (boxSourceType != BoxSourceType.Quest)
                {
                    useRpc = true;
                }
            }
            else if (e.equipmentType == EquipmentType.SkinTitle)
            {
                e.state = EquipmentState.Title;
                characterTitleEquipment.AddEquipment(e);
                useRpc = false;
            }
            else
            {
                if (checkSlot)
                {
                    if (characterInventory.GetEquipmentCount() >= GetFinalInventorySlot())
                    {
                        int increaseGold = Random.Range(5, 8) * goldFactor;
                        var currentGold = GetGold();
                        if (this.connectionToClient != null)
                            BattleManager.instance.gameLogicBehavior.TargetReceiveCurrency(this.connectionToClient, currentGold, increaseGold, GameConst.GOLD_ID);
                        AddGold(increaseGold);
                        continue;
                    }
                }
                e.state = EquipmentState.Inventory;
                characterInventory.AddEquipment(e);
            }

            if (boxSourceType == BoxSourceType.ActivationCode)
            {
                var itemCard = DataHolder.Instance().GetData<Card>(e.itemId);
                Log(LogAction.InputCode,
                "Type:" + e.equipmentType + "|Item:" + (itemCard != null ? itemCard.GetName(0) : e.itemId.ToString()) + "|Rare:" + e.rareType,
                e.ToJson());
            }

            if (useRpc)
            {
                var notify = new NotifyData()
                {
                    NotifyType = NotifyType.AddItem,
                    IntParam = e.itemId,
                    RareType = equipments[i].rareType,
                    Sender = UIManager.Sender.System,
                    Source = boxSourceType,
                    BoxSourceId = boxSourceId,
                    ActionType = HistoryLogActionType.Add,
                };

                RpcEndWatchAd(this.connectionToClient, notify);
            }
        }
#endif
    }

    [Server]
    public void ReceiveCurrencies(List<CurrencyData> currencyDatas, BoxSourceType boxSourceType = BoxSourceType.None, int boxSourceId = -1)
    {
#if ENABLE_SERVER
        if (currencyDatas.Count <= 0)
            return;

        bool containsTH = currencyDatas.Any(currencyData =>
            currencyData != null && currencyData.GetCurrencyType() == CurrencyID.THCoin);
        if (containsTH && !BattleManager.IsTHRewardSourceAllowed(boxSourceType))
        {
            Log(LogAction.SuspiciousActivity,
                $"Reason:THSourceNotAllowed|Context:ReceiveCurrencies|Source:{boxSourceType}|BoxSourceId:{boxSourceId}");
            return;
        }

        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);
        if (characterData == null)
            return;

        foreach (CurrencyData currencyData in currencyDatas)
        {
            bool isRpc = true;
            bool rpcTargetCurrency = false;
            int currentValue = 0;

            if (currencyData.GetCurrencyType() == CurrencyID.Announcement)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.AutomationTile)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.THCoin)
            {
                WalletData walletData = BattleManager.instance.GetWalletData(this.userName);
                if (walletData != null)
                {
                    BattleManager.instance.AddCurrencyData(this.userName, currencyData);

                    if (boxSourceType == BoxSourceType.ActivationCode)
                    {
                        if (currencyData.value > 0)
                            EconomyManager.RecordThEarn(currencyData.value, "activation_code");
                        int iapValue = currencyData.value / 10;
                        bool isVipLevelUp = characterData.AddVipPoint(iapValue);
                        seasonIAPValue += iapValue;
                        BattleManager.instance.codeValue += currencyData.value;

                        BattleManager.instance.UpdateLeaderboardsByCurrency(
                            CurrencyID.IAPValue,
                            userName,
                            iapValue);

                        if (isVipLevelUp)
                        {
                            OnVipLevelUp(characterData);
                        }
                    }

                }
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.ClanCoin)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.ClanTrophy)
            {
                if (boxSourceType != BoxSourceType.Leaderboard)
                {
                    BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                    ClanData clanData = BattleManager.instance.GetClanData(this.clanId);
                    if (clanData != null && IsUserClan(this.clanId))
                    {

                        BattleManager.LogClan(
                            clanData,
                            LogAction.ClanTrophy,
                            $"Source:{boxSourceType}|BoxId:{boxSourceId}|Player:{userName}|Character:{this.characterName}|Delta:{currencyData.value}|Final:{clanData.trophy}",
                            value: currencyData.value.ToString(),
                            characterName: this.characterName);
                    }
                }
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.ClanDailyQuestPoint)
            {
                isRpc = false;
                ClanData clanData = BattleManager.instance.GetClanData(this.clanId);
                if (clanData != null && IsUserClan(this.clanId))
                {
                    BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                    OnClanQuestPointChange(clanData);
                }
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.CenterLandChestNumber)
            {
                isRpc = false;
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.UndeadLandChestNumber)
            {
                isRpc = false;
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.PlayerTrophy)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.Diamond)
            {
                currentValue = characterInventory.diamond;
                if (boxSourceType == BoxSourceType.Mob || boxSourceType == BoxSourceType.HitMap)
                {
                    isRpc = false;
                    rpcTargetCurrency = true;
                }

                if (boxSourceType == BoxSourceType.Mob || boxSourceType == BoxSourceType.Boss)
                {
                    currencyData.value = currencyData.value * GetDiamondRate();
                }
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);

            }
            else if (currencyData.GetCurrencyType() == CurrencyID.Gold)
            {
                currentValue = GetGold();
                if (boxSourceType == BoxSourceType.Mob || boxSourceType == BoxSourceType.HitMap)
                {
                    isRpc = false;
                    rpcTargetCurrency = true;
                }

                if (boxSourceType == BoxSourceType.Mob || boxSourceType == BoxSourceType.Boss
                    || boxSourceType == BoxSourceType.HitMap)
                {
                    int goldFactor = 1;
                    if (BattleManager.instance.GetEventRunning(GameEventId.x2Gold))
                        goldFactor = 2;

                    currencyData.value = (int)(currencyData.value * goldFactor * goldRate);
                }
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.Shard)
            {
                currentValue = characterInventory.shard;
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                if (boxSourceType == BoxSourceType.Mob)
                {
                    isRpc = false;
                    rpcTargetCurrency = true;
                }
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.ArenaCoin)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.SkinExchange)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.RexFang)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.LegendFang)
            {
                isRpc = false;
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                BattleManager.Log(GameLogType.UserTracking, $"{userName} Received Legend Fang: {currencyData.value}, total: {characterData.legendFang}");

            }
            else if (currencyData.GetCurrencyType() == CurrencyID.MythicFang)
            {
                isRpc = false;
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                BattleManager.Log(GameLogType.UserTracking, $"{userName} Received Mythic Fang: {currencyData.value}, total: {characterData.mythicFang}");
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.BonusV3TransferTicket)
            {
                isRpc = false;
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.WerewolfPoint)
            {
                BattleManager.Log(GameLogType.Debug, $"Player {userName} update leaderboard Werewolf");
                BattleManager.instance.UpdateLeaderboardsByCurrency(
                    CurrencyID.WerewolfPoint,
                    userName,
                    currencyData.value);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.BearHuntPoint)
            {
                BattleManager.instance.UpdateLeaderboardsByCurrency(
                    CurrencyID.BearHuntPoint,
                    userName,
                    currencyData.value);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.BossEventPoint)
            {
                BattleManager.instance.UpdateLeaderboardsByCurrency(
                    CurrencyID.BossEventPoint,
                    userName,
                    currencyData.value);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.VikingPoint)
            {
                isRpc = false;
                if (VikingRushManager.IsSpawnSlotActive(BattleManager.instance.ServerNow())
                    && IsUserClan(clanId)
                    && BattleManager.instance.GetClanData(clanId) != null)
                {
                    BattleManager.instance.UpdateLeaderboardsByCurrency(
                        CurrencyID.VikingPoint,
                        clanId,
                        currencyData.value);
                }
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.CyclicQuestPoint)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.DailyQuestPoint)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.AchievementQuestPoint)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.LoginPoint)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.QuestScore)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.MobFirecraftPoint)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);

                isRpc = false;
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.QuestNumber)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                isRpc = false;
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.Progress)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                isRpc = false;
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.TrexPoint)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.ClanTrexPoint)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.TeamBattlePoint)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                isRpc = false;
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.PlayerClanScore)
            {
                if (IsUserClan(clanId))
                {
                    BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                    if (GetClanScore() >= BattleManager.instance.gameDataConfig.MinClanScoreUnlockQuest)
                    {
                        BattleManager.instance.SavePlayerData(this);
                        OnPlayerClanScoreChange(characterData);
                    }
                }
                else
                {
                    isRpc = false;
                }
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.ClanScore)
            {
                if (clanId.IsNonEmpty() && IsUserClan(clanId))
                {
                    var clanData = BattleManager.instance.GetClanData(clanId);
                    if (clanData != null)
                    {
                        BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                        BattleManager.LogClan(
                            clanData,
                            LogAction.ClanScore,
                            $"Source:{boxSourceType}|BoxId:{boxSourceId}|Player:{userName}|Character:{this.characterName}|Delta:{currencyData.value}|Final:{clanData.score}",
                            value: currencyData.value.ToString(),
                            characterName: this.characterName);
                    }
                }
                isRpc = false;

            }
            else if (currencyData.GetCurrencyType() == CurrencyID.ClanDiamond)
            {
                isRpc = false;

                if (clanId.IsNonEmpty() && IsUserClan(clanId))
                {
                    var clanData = BattleManager.instance.GetClanData(clanId);
                    if (clanData != null)
                    {
                        BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                        BattleManager.LogClan(
                            clanData,
                            LogAction.ClanDiamond,
                            $"Source:{boxSourceType}|BoxId:{boxSourceId}|Player:{userName}|Character:{this.characterName}|Delta:{currencyData.value}|Final:{clanData.diamond}",
                            value: currencyData.value.ToString(),
                            characterName: this.characterName);
                    }
                }
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.VipScore)
            {
                bool isVipLevelUp = characterData.AddVipPoint(currencyData.value);
                if (isVipLevelUp)
                {
                    OnVipLevelUp(characterData);
                }
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.IAPValue)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                isRpc = false;
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.CraftScore)
            {
                currentValue = GetCraftNumber();
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
                rpcTargetCurrency = true;
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.SkipAd)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }
            else if (currencyData.GetCurrencyType() == CurrencyID.NumberRollSkinCosmeticToday)
            {
                BattleManager.instance.AddCurrencyData(this.userName, currencyData);
            }

            if (currencyData.value == 0 || boxSourceType == BoxSourceType.Quest ||
                boxSourceType == BoxSourceType.DailyReward ||
                boxSourceType == BoxSourceType.ClanDailyQuest ||
                boxSourceType == BoxSourceType.Leaderboard)
            {
                isRpc = false;
            }

            if (isRpc)
            {
                RpcEndWatchAd(this.connectionToClient, new NotifyData()
                {
                    NotifyType = NotifyType.AddCurrency,
                    IntParam = currencyData.value,
                    Sender = UIManager.Sender.System,
                    CurrencyID = currencyData.GetCurrencyType(),
                    Source = boxSourceType,
                    BoxSourceId = boxSourceId,
                    ActionType = HistoryLogActionType.Add,
                });
            }
            else if (rpcTargetCurrency)
            {
                BattleManager.instance.gameLogicBehavior.TargetReceiveCurrency
                (
                    connectionToClient,
                    currentValue,
                    currencyData
                );
            }
        }
#endif
    }

    //----------------------------------------------------------------
    //Quit Game
    //----------------------------------------------------------------
    [Client]
    public void RequestStartQuit(int apiToken)
    {
        BuildingPlacementController.CleanupActivePlacement();
        CmdStartQuit(apiToken);
    }

    [Command]
    public void CmdStartQuit(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdStartQuit)))
            return;

        PlayerSessionService.StartSafeQuitOrLogoutImmediately(this);
#endif
    }

    [Server]
    public void LogicStartQuit()
    {
#if ENABLE_SERVER
        PlayerSessionService.StartSafeQuitOrLogoutImmediately(this);
#endif
    }

    [Server]
    public void EndQuitServer()
    {
#if ENABLE_SERVER
        Log(LogAction.PlayerLogout, "Time:" + DataUtils.TimeToString(System.DateTime.Now));
        PlayerSessionService.FinalizeLogout(this, DisconnectReason.SafeQuit, saveData: true, disconnectConnection: true);
#endif
    }

    [Server]
    public void ForceQuit()
    {
        PlayerSessionService.ForceDisconnect(this, DisconnectReason.ForceDisconnect);
    }

    [Client]
    public static void EndQuitClient()
    {
        ClientConnectionService.DisconnectIfConnected(ClientDisconnectReason.SafeQuit);
        ClientManager.instance.isAutoLogin = false;

        if (UIManager.instance == null)
            return;

        UIManager.instance.Reload();
    }

    [Client]
    public void RequestCancelQuit(int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdCancelQuit(apiToken);
    }

    [Command]
    void CmdCancelQuit(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdCancelQuit)))
            return;

        PlayerSessionService.CancelSafeQuit(this);
#endif
    }

    [TargetRpc]
    public void TargetApplyServerSafeQuitState(NetworkConnectionToClient networkConnectionToClient, bool quit, float quitTime)
    {
        isQuiting = quit;
        timeQuit = quitTime;
    }

    [TargetRpc]
    public void RpcDisconnect(NetworkConnectionToClient networkConnectionToClient)
    {
        ClientConnectionService.Disconnect(ClientDisconnectReason.ForceDisconnect);
    }

    //----------------------------------------------------------------
    // Send IP Address
    //----------------------------------------------------------------
    public void RequestSendIpAddress(string ip)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdSendIpAddress(ip);
    }

    [Command]
    public void CmdSendIpAddress(string ip)
    {
#if ENABLE_SERVER
        if (string.IsNullOrEmpty(ip))
            return;
        this.ipAddress = ip;

        BattleManager.instance.OnServerUpdateIp(this);
        //BattleManager.Log(GameLogType.UserTracking, this.userName + " - " + this.characterName + " send ip " + ip);
#endif
    }

    //----------------------------------------------------------------
    // Start Watch Ad
    //----------------------------------------------------------------
    [Client]
    public void RequestStartWatchAd(int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdStartWatchAd(apiToken);
    }

    [Command]
    public void CmdStartWatchAd(int apiToken)
    {
#if ENABLE_SERVER

        if (!ServerValidateApiToken(apiToken, nameof(CmdStartWatchAd)))
            return;

        //Log(LogAction.WatchAd, "SkipRemaining:" + characterInventory.adSkipNumber, "");

        if (characterInventory.adSkipNumber > 0)
        {
            int rewardBoxId = BattleManager.instance.GetAdRewardBoxId();
            if (BattleManager.instance.GrantAdRewardBox(
                userName,
                rewardBoxId,
                "SkipAd",
                out var errorMessage))
            {
                characterInventory.adSkipNumber--;
                BattleManager.instance.SavePlayerData(this);
            }
            else
            {
                BattleManager.Log(GameLogType.Warning, $"[AdMob] SkipAd reward failed for {userName}: {errorMessage}");
            }
        }
        else
        {
            if (!CanWatchRealAd(out var errorMessage))
            {
                BattleManager.Log(GameLogType.Info, $"[AdMob] Watch ad rejected for {userName}: {errorMessage}");
                return;
            }

            // The ad (and its server-issued, SSV-verified reward ticket) always proceeds. The protection window is only a
            // server-granted, bounded privilege: no restart/extension while active and a minimum gap between windows. The
            // server cannot see an ad being displayed, so without this a client could re-arm it forever without any ad.
            double now = NetworkTime.time;
            if (WatchAdSessionPolicy.CanGrantProtection(isWatchingAd, now, lastWatchAdProtectionStartTime))
            {
                lastWatchAdProtectionStartTime = now;
                isWatchingAd = true;
                if (characterVisual != null)
                    characterVisual.isWatchingAd = true;
                timeWatchAd = 0f;
            }
            else
            {
                BattleManager.Log(GameLogType.Info,
                    $"[AdMob] Watch ad protection not granted for {userName}: AlreadyProtected:{isWatchingAd}|SinceLast:{now - lastWatchAdProtectionStartTime:F1}s");
            }

            var customData = BattleManager.instance.CreateAdmobRewardCustomData(this.userName);
            RpcStartWatchAd(this.connectionToClient, JsonConvert.SerializeObject(customData));
        }
#endif
    }

    [TargetRpc]
    void RpcStartWatchAd(NetworkConnectionToClient networkConnectionToClient, string customData)
    {
#if ENABLE_ADMOB || ENABLE_APPLOVIN
        //BattleManager.instance.SetIsAdWatched = true;
        //UIManager.instance.StartSleepMode();
        StartCoroutine(ShowAd(customData));
#endif
    }

    IEnumerator ShowAd(string customData)
    {
        yield return new WaitForSeconds(0.1f);
#if ENABLE_ADMOB || ENABLE_APPLOVIN
        //BattleManager.instance.StartWatchAd();
        AdManager.instance.ShowAd(customData);

        /*
        yield return new WaitForSeconds(10f);

        if(AdManager.instance.AdIsDisplayed == false)
        {
            BattleManager.instance.SetIsAdWatched = false;
            UIManager.instance.EndSleepMode();
        }*/

#endif
        //yield return new WaitForSeconds(0.1f);
        //NetworkClient.Disconnect();
    }

    [TargetRpc]
    public void RpcHistoryCost(NetworkConnectionToClient connection, CurrencyData cost, BoxSourceType source)
    {
#if ENABLE_CLIENT
        if (cost == null || cost.value <= 0 || ClientManager.instance == null || UIManager.instance == null)
            return;

        ClientManager.instance.AddHistoryReward(HistoryRewardView.CreateNotifyData(cost, source,
            NotifyType.AddCurrency, HistoryLogActionType.Lost));
#endif
    }

    [TargetRpc]
    public void RpcHistoryReward(NetworkConnectionToClient connection, NotifyData notifyData,
        CharacterHistoryContext characterContext)
    {
#if ENABLE_CLIENT
        if (UIManager.instance == null || ClientManager.instance == null)
            return;

        UIManager.instance.FindView<GiftcodeView>().Close();
        UIManager.instance.FindView<ToastView>(UIManager.TOAST_VIEW_LEFT).Load(notifyData);
        ClientManager.instance.AddHistoryReward(notifyData, characterContext);
#endif
    }

    [TargetRpc]
    public void RpcEndWatchAd(NetworkConnectionToClient networkConnectionToClient, NotifyData notifyData)
    {
#if ENABLE_CLIENT
        if (UIManager.instance == null)
            return;

        UIManager.instance.FindView<GiftcodeView>().Close();
        //StartCoroutine(DisplayRewardCO(notifyData));
        UIManager.instance.FindView<ToastView>(UIManager.TOAST_VIEW_LEFT).Load(notifyData);
        ClientManager.instance.AddHistoryReward(notifyData);
#endif
    }


    private IEnumerator DisplayRewardCO(NotifyData notifyData)
    {
        float timeOut = 5f;
        while (UIManager.instance.loading.activeInHierarchy == true)
        {
            yield return null;
            timeOut += Time.deltaTime;
            if (timeOut > 5)
            {
                yield break;
            }
        }

        UIManager.instance.FindView<ToastView>(UIManager.TOAST_VIEW_LEFT).Load(notifyData);
    }

    //----------------------------------------------------------------
    // Request Get player info
    //----------------------------------------------------------------


    /// <summary>
    /// Lấy tất cả các thông tin public của 1 player
    /// </summary>
    [Client]
    public void RequestGetPlayerInfo(string targetUsername)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdGetPlayerInfo(targetUsername, ClientManager.instance.GetApiToken());
    }

    [Command]
    public void CmdGetPlayerInfo(string targetUsername, int apiToken)
    {
#if ENABLE_SERVER

        if (!ServerValidateApiToken(apiToken, nameof(CmdGetPlayerInfo)))
            return;

        if (string.IsNullOrEmpty(targetUsername))
        {
            BattleManager.Log(GameLogType.UserTracking, "[CmdGetPlayerInfo] Username is null or empty");
            return;
        }

        if (targetUsername == userName)
        {
            var characterData = BattleManager.instance.GetCharacterData(targetUsername);

            var response = HandleBoxSuggestionsAndCreateGamePlayerInfo(characterData);
            Vector3 vipInfo = CreateVipInfo(characterData);

            RpcGetMyPlayerInfo(connectionToClient, response.ToJson(),
                GetVipLevel(characterData.GetVipPoint()),
                vipInfo);
        }
        else
        {
            var characterData = BattleManager.instance.GetCharacterData(targetUsername);
            if (characterData != null)
            {
                var response = new GamePlayerInfo()
                {
                    chestNumber = characterData.chestNumber,
                    pvpCount = characterData.arenaCount,
                    clanWarCount = characterData.clanArenaCount,
                    craftNumber = characterData.craftNumber,
                    killBossNumber = characterData.killBossNumber,
                    killMobNumber = characterData.killMobNumber,
                    killPlayerNumber = characterData.killPlayerNumber,
                    questScore = characterData.questScore,
                    trophy = characterData.trophy,
                    leaveClanTime = characterData.leaveClanTime,
                };

                var playerTarget = BattleManager.instance.GetPlayerBehavior(targetUsername);
                if (playerTarget != null)
                {
                    response.jailTime = playerTarget.jailTime;
                }


                RpcGetPlayerInfo(connectionToClient, targetUsername, response.ToJson());
            }
            else
            {
                RpcGetPlayerInfo(connectionToClient, targetUsername, "");
            }
        }
#endif
    }

    [TargetRpc]
    private void RpcGetPlayerInfo(NetworkConnectionToClient networkConnectionToClient, string usernameTarget, string response)
    {
        if (string.IsNullOrEmpty(response))
        {
            return;
        }

        GamePlayerInfo gamePlayerInfo = DataUtils.CreateFromJSON<GamePlayerInfo>(response);

        if (UIManager.instance == null)
            return;

        var myCharacterInfoView = UIManager.instance.FindView<MyCharacterInfoView>();
        if (myCharacterInfoView != null && myCharacterInfoView.IsOpen)
        {
            myCharacterInfoView.OnGetArenaCountAndQuestScoreCallBack(gamePlayerInfo);
        }
        else
        {
            var characterInfoView = UIManager.instance.FindView<CharacterInfoView>();
            if (characterInfoView != null && characterInfoView.IsOpen)
            {
                characterInfoView.OnGetArenaCountAndQuestScoreCallBack(gamePlayerInfo);
            }
        }
    }

    [TargetRpc]
    private void RpcGetMyPlayerInfo(NetworkConnectionToClient networkConnectionToClient,
        string response, int vipLevel, Vector3 vipInfo)
    {
        if (string.IsNullOrEmpty(response))
        {
            return;
        }
        GamePlayerInfo gamePlayerInfo = DataUtils.CreateFromJSON<GamePlayerInfo>(response);

        LoadMyPlayerInfo(vipLevel, vipInfo, gamePlayerInfo);

        LoadDataToInfoView(gamePlayerInfo);
    }

    /// <summary>
    /// Lấy tất cả các thông tin public của 1 player
    /// </summary>
    [Client]
    public void RequestGetMyPlayerInfoInit(string targetUsername)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdGetMyPlayerInfoInit(targetUsername, ClientManager.instance.GetApiToken());
    }

    [Command]
    public void CmdGetMyPlayerInfoInit(string targetUsername, int apiToken)
    {
#if ENABLE_SERVER

        if (!ServerValidateApiToken(apiToken, nameof(CmdGetMyPlayerInfoInit)))
            return;

        if (string.IsNullOrEmpty(targetUsername))
        {
            BattleManager.Log(GameLogType.UserTracking, "[CmdGetMyPlayerInfoInit] Username is null or empty");
            return;
        }

        var characterData = BattleManager.instance.GetCharacterData(targetUsername);
        if (characterData != null)
        {
            GamePlayerInfo response = HandleBoxSuggestionsAndCreateGamePlayerInfo(characterData);
            Vector3 vipInfo = CreateVipInfo(characterData);

            RpcGetMyPlayerInfoInit(connectionToClient, response.ToJson(),
                GetVipLevel(characterData.GetVipPoint()),
                vipInfo);
        }
        else
        {
            BattleManager.Log(GameLogType.UserTracking, $"[CmdGetMyPlayerInfoInit] Username {targetUsername} - characterData is null");

            RpcGetMyPlayerInfoInit(
                connectionToClient, 
                "", 
                0,
                Vector3.zero
            );
        }
#endif
    }

    [TargetRpc]
    private void RpcGetMyPlayerInfoInit(NetworkConnectionToClient networkConnectionToClient,
    string response, int vipLevel, Vector3 vipInfo)
    {
        if (string.IsNullOrEmpty(response))
        {
            return;
        }
        GamePlayerInfo gamePlayerInfo = DataUtils.CreateFromJSON<GamePlayerInfo>(response);

        LoadMyPlayerInfo(vipLevel, vipInfo, gamePlayerInfo);
        LoadMyPlayerInfoInit();

        LoadDataToInfoView(gamePlayerInfo);
    }

    private void LoadMyPlayerInfo(int vipLevel, Vector3 vipInfo, GamePlayerInfo gamePlayerInfo)
    {
        isPlayerInfoLoaded = true;

        ClientManager.instance.SetBoxSuggestions(gamePlayerInfo.boxSuggestions);
        ClientManager.instance.SetPlayerVipStats(gamePlayerInfo.playerVipStat);
        ClientManager.instance.SetMyPvPCount(gamePlayerInfo.pvpCount);
        ClientManager.instance.SetMyClanWarCount(gamePlayerInfo.clanWarCount);
        ClientQuestManager.Instance.SetQuestScore_Statistic(gamePlayerInfo.questScore);
        ClientManager.instance.SetMyVipLevel(vipLevel);
        ClientManager.instance.SetMyVipProgress(vipInfo.x);
        ClientManager.instance.SetMyVipExp(vipInfo.y, vipInfo.z);
        ClientManager.instance.SetMyLastServer(gamePlayerInfo.lastServer);
        ClientManager.instance.SetCanUseVipAutomation();
        ClientManager.instance.LoadIsFirstOnAnyZone();
        ClientManager.instance.LoadMyClanRecruitmentData();
    }

    private void LoadMyPlayerInfoInit()
    {
        ClientManager.instance.LoadVipAutoSell();
#if ENABLE_CLIENT
        ClientManager.instance.LoadHistoryRewards();
#endif
    }

    private void LoadDataToInfoView(GamePlayerInfo gamePlayerInfo)
    {
        if (UIManager.instance == null)
            return;

        var unlockJailView = UIManager.instance.FindView<UnlockJailView>();
        if (unlockJailView != null)
            unlockJailView.OnGetJailTime(this, gamePlayerInfo.jailTime);

        // RpcGetMyPlayerInfo is specifically for my player, so only update MyCharacterInfoView
        var myCharacterInfoView = UIManager.instance.FindView<MyCharacterInfoView>();
        if (myCharacterInfoView != null && myCharacterInfoView.IsOpen)
        {
            myCharacterInfoView.OnGetArenaCountAndQuestScoreCallBack(gamePlayerInfo);
        }
    }

#if ENABLE_SERVER
    private Vector3 CreateVipInfo(CharacterData characterData)
    {
        return new Vector3
                    (GetVipProgress(characterData.GetVipPoint()),
                    GetVipExpData(characterData.GetVipPoint()).Item1,
                    GetVipExpData(characterData.GetVipPoint()).Item2);
    }

    private GamePlayerInfo HandleBoxSuggestionsAndCreateGamePlayerInfo(CharacterData characterData)
    {
        #region Check Box suggestion
        List<BoxSuggestion> boxOutDate = new();

        var serverNow = BattleManager.instance.ServerNow();

        foreach (var item in boxSuggestions)
        {
            if (item.IsExpired(serverNow))
            {
                boxOutDate.Add(item);
            }
        }

        foreach (var item in boxOutDate)
        {
            boxSuggestions.Remove(item);
        }
        #endregion

        var response = new GamePlayerInfo()
        {
            pvpCount = arenaCount,
            clanWarCount = clanArenaCount,
            questScore = characterData.questScore,
            playerVipStat = characterData.playerVipStats,
            jailTime = jailTime,
            boxSuggestions = boxSuggestions,
            lastServer = characterData.lastServer
        };
        return response;
    }
#endif

    [TargetRpc]
    private void RpcGetDataResetSeason(NetworkConnectionToClient connectionToClient, bool haveFang,
        List<Equipment> equipments, List<CurrencyData> currencyDatas)
    {
#if !ENABLE_ADMIN
        // ✅ SERVER-ONLY: Add null check for UIManager
        if (UIManager.instance == null) return;

        var view = UIManager.instance.FindView<EndSeasonView>();
        view.haveFang = haveFang;
        view.equipments = equipments;
        view.currencyDatas = currencyDatas;
        view.Load();
#endif
    }

    [Client]
    public void RequestRemoveDataResetSeason(int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdRemoveDataResetSeason(apiToken);
    }

    [Command]
    private void CmdRemoveDataResetSeason(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdRemoveDataResetSeason)))
            return;

        if (BattleManager.instance.characterDataReset.ContainsKey(userName))
        {
            BattleManager.instance.characterDataReset.Remove(userName);
        }

        if (BattleManager.instance.walletDataReset.ContainsKey(userName))
        {
            BattleManager.instance.walletDataReset.Remove(userName);
        }
#endif
    }

#endregion

    //----------------------------------------------------------------
    // Get TOP Clan
    //----------------------------------------------------------------

    /// <summary>
    /// [DEPRECATED] Use RequestLeaderboard(LeaderboardType.ClanWarTrophy) instead
    /// </summary>
    [Client]
    public void RequestGetTopClan()
    {
        if (!NetworkClient.isConnected)
            return;
        CmdGetTopClan();
    }

    [Command]
    public void CmdGetTopClan()
    {
#if ENABLE_SERVER

        var topClan = BattleManager.instance.GetTopClan();

        if (topClan != null)
        {
            RpcGetTopClan(this.connectionToClient, topClan, true);
        }
        else
        {
            RpcGetTopClan(this.connectionToClient, null, false);
        }
#endif
    }

    [TargetRpc]
    void RpcGetTopClan(NetworkConnectionToClient networkConnectionToClient, List<ClanDataBrief> clanData, bool success)
    {

#if ENABLE_CLIENT
        var eventData = new LeaderboardEventData
        {
            GameEventConfigId = -1,
            PlayerData = null,
            ClanData = clanData,
            Success = success,
            ErrorCode = ErrorCode.Success,
            MyRank = -1,
            MyPlayerData = null,
            MyClanData = null
        };

        EventDispatcher.Raise(eventData);
#endif
#if ENABLE_ADMIN
        if (AdminManager.instance != null)
            AdminManager.instance.topClanBriefs = clanData;
#endif
    }

    //----------------------------------------------------------------
    // Get TOP player
    //----------------------------------------------------------------
    /// <summary>
    /// [DEPRECATED] Use RequestLeaderboard(LeaderboardType.PvPTrophy) instead
    /// </summary>
    [Client]
    public void RequestGetTopPlayer()
    {
        if (!NetworkClient.isConnected)
            return;
        CmdGetTopPlayer();
    }

    [Command]
    public void CmdGetTopPlayer()
    {
#if ENABLE_SERVER

        var topPlayer = BattleManager.instance.GetTopPlayer();
        if (topPlayer != null)
        {
            RpcGetTopPlayer(this.connectionToClient, topPlayer, true);
        }
        else
        {
            RpcGetTopPlayer(this.connectionToClient, null, false);
        }
#endif
    }

    [TargetRpc]
    void RpcGetTopPlayer(NetworkConnectionToClient networkConnectionToClient, List<CharacterBrief> topPlayers, bool success)
    {
        if (topPlayers != null)
        {
#if ENABLE_ADMIN
            if (AdminManager.instance != null)
                AdminManager.instance.topPlayers = topPlayers;
#endif
        }

#if ENABLE_CLIENT
        var eventData = new LeaderboardEventData
        {
            GameEventConfigId = -1,
            PlayerData = topPlayers,
            ClanData = null,
            Success = success,
            ErrorCode = ErrorCode.Success,
            MyRank = -1,
            MyPlayerData = null,
            MyClanData = null
        };
        EventDispatcher.Raise(eventData);
#endif
    }


    //----------------------------------------------------------------
    // Unified Leaderboard Request
    //----------------------------------------------------------------

    [Client]
    public void RequestLeaderboard(int gameEventConfigId)
    {
        if (!NetworkClient.isConnected)
        {
            return;
        }
        CmdGetLeaderboard(gameEventConfigId);
    }

    [Command]
    private void CmdGetLeaderboard(int gameEventConfigId)
    {
#if ENABLE_SERVER
        if (this.isBanned)
        {
            return;
        }
        var gameEvent = DataHolder.Instance().GetData<GameEvent>(gameEventConfigId);
        if(gameEvent == null)
        {
            return;
        }
        var leaderboardConfig = DataHolder.Instance().GetData<LeaderboardConfig>(gameEvent.leaderboardConfigId);
        if (leaderboardConfig == null || leaderboardConfig.leaderboardType == LeaderboardType.None)
        {
            return;
        }
        // Xác định loại data trả về (player hoặc clan)
        bool isClanLeaderboard = leaderboardConfig.leaderboardType == LeaderboardType.Clan;
        var leaderboardType = leaderboardConfig.leaderboardType;
        
        int myRank = -1;
        CharacterBrief myPlayerData = null;
        ClanDataBrief myClanData = null;

        if (isClanLeaderboard)
        {
            var clanData = ServerLeaderBoardManager.Instance.GetClanLeaderboard(gameEvent);
            bool success = clanData != null;

            if (success == false)
            {
                BattleManager.Log(GameLogType.Warning, $"[Leaderboard] CmdGetLeaderboard: No clan data found for {gameEvent.GetName(0)}");
            }
            
            var characterData = BattleManager.instance.GetCharacterData(this.userName);
            string clanId = characterData != null ? characterData.clanId : null;
            var table = BattleManager.instance.GetLeaderBoard(gameEvent.id);
            if (table != null && table.clans != null && !string.IsNullOrEmpty(clanId))
            {
                for (int i = 0; i < table.clans.Count; i++)
                {
                    if (table.clans[i] != null && table.clans[i].clanName == clanId)
                    {
                        myRank = i;
                        myClanData = table.clans[i];
                        break;
                    }
                }
            }

            if (success && clanData != null && leaderboardConfig.topCount > 0 && clanData.Count > leaderboardConfig.topCount)
            {
                clanData = clanData.Take(leaderboardConfig.topCount).ToList();
            }

            RpcGetLeaderboard(this.connectionToClient, gameEventConfigId, leaderboardType, null, clanData, success, success ? ErrorCode.Success : ErrorCode.DataNotExist, myRank, myPlayerData, myClanData);
        }
        else
        {
            var playerData = ServerLeaderBoardManager.Instance.GetLeaderboard(gameEvent);
            bool success = playerData != null;

            if (success == false)
            {
                BattleManager.Log(GameLogType.Warning, $"[Leaderboard] CmdGetLeaderboard: No player data found for {leaderboardType}");
            }
            
            var characterData = BattleManager.instance.GetCharacterData(this.userName);
            string charName = characterData != null ? characterData.characterName : this.userName;
            var table = BattleManager.instance.GetLeaderBoard(gameEvent.id);
            if (table != null && table.players != null)
            {
                for (int i = 0; i < table.players.Count; i++)
                {
                    var p = table.players[i];
                    if (p != null && (p.id == this.userName || p.characterName == charName || p.characterName == this.userName))
                    {
                        myRank = i;
                        myPlayerData = p;
                        break;
                    }
                }
            }

            if (success && playerData != null && leaderboardConfig.topCount > 0 && playerData.Count > leaderboardConfig.topCount)
            {
                playerData = playerData.Take(leaderboardConfig.topCount).ToList();
            }

            RpcGetLeaderboard(this.connectionToClient, gameEventConfigId, leaderboardType, playerData, null, success, success ? ErrorCode.Success : ErrorCode.DataNotExist, myRank, myPlayerData, myClanData);
        }
#endif
    }

    /// <summary>
    /// Client nhận leaderboard data từ server.
    /// Forward data đến ClientLeaderboardManager để xử lý và raise event cho UI.
    /// </summary>
    [TargetRpc]
    private void RpcGetLeaderboard(
        NetworkConnectionToClient conn,
        int gameEventConfigId,
        LeaderboardType leaderboardType,
        List<CharacterBrief> playerData,
        List<ClanDataBrief> clanData,
        bool success,
        ErrorCode errorCode,
        int myRank,
        CharacterBrief myPlayerData,
        ClanDataBrief myClanData)
    {
#if ENABLE_CLIENT
        if (success)
        {
            int count = playerData != null ? playerData.Count : (clanData != null ? clanData.Count : 0);
        }
        else
        {
            BattleManager.Log(GameLogType.Warning, $"[Leaderboard] RpcGetLeaderboard: Failed to get {leaderboardType}, error: {errorCode}");
        }

        var eventData = new LeaderboardEventData
        {
            GameEventConfigId = gameEventConfigId,
            PlayerData = playerData,
            ClanData = clanData,
            Success = success,
            ErrorCode = success ? ErrorCode.Success : errorCode,
            MyRank = myRank,
            MyPlayerData = myPlayerData,
            MyClanData = myClanData
        };

        EventDispatcher.Raise(eventData);
#endif

#if ENABLE_ADMIN
        // Admin tool support (backward compatibility)
        if (AdminManager.instance != null)
        {
            if (clanData != null)
            {
                AdminManager.instance.topClanBriefs = clanData;
            }
            if (playerData != null)
            {
                AdminManager.instance.topPlayers = playerData;
            }
        }
#endif
    }

    //----------------------------------------------------------------
    // Request Delete Player
    //----------------------------------------------------------------
    public void RequestDeletePlayerData(int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdDeletePlayerData(apiToken);
    }

    [Command]
    void CmdDeletePlayerData(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdDeletePlayerData)))
            return;

        Log(LogAction.DeleteAccount, $"Username:{this.userName}");
        BattleManager.instance.DeleteAccount(this.userName, true);
        RpcDeletePlayerData(this.connectionToClient);
#endif
    }

    [Client]
    public void RequestDeletePlayerData(int apiToken, string passCode)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdDeletePlayerData(apiToken, passCode);
    }

    [Command]
    void CmdDeletePlayerData(int apiToken, string passCode)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdDeletePlayerData)))
            return;

        var isCorrect = CheckWalletPassCode(passCode);
        if (isCorrect == false)
        {
            return;
        }

        Log(LogAction.DeleteAccount, $"Username:{this.userName}");
        BattleManager.instance.DeleteAccount(this.userName, true);
        RpcDeletePlayerData(this.connectionToClient);
#endif
    }

    [TargetRpc]
    void RpcDeletePlayerData(NetworkConnectionToClient networkConnectionToClient)
    {
        ClientConnectionService.Disconnect(ClientDisconnectReason.Manual);
    }

    //----------------------------------------------------------------
    // Request Ban My Account
    //----------------------------------------------------------------
    public void RequestBanMyPlayerData(int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdBanMyPlayerData(apiToken);
    }

    [Command]
    void CmdBanMyPlayerData(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdBanMyPlayerData)))
            return;
        Log(LogAction.IAPFraud, "Reason:RefundDetected|Source:WebRequest");
        BattleManager.instance.BlockAccount(this.userName, true);
        RpcBanMyPlayerData(this.connectionToClient);
#endif
    }

    [TargetRpc]
    void RpcBanMyPlayerData(NetworkConnectionToClient networkConnectionToClient)
    {
        ClientConnectionService.Disconnect(ClientDisconnectReason.ForceDisconnect);
        // update status to banned
#if ENABLE_MMO_WEB_API
        MmoApiManager.GetInstance().UpdateAccountBannedStatus(
            MCP.DataModels.BaseModels.AccountBannedStatus.Banned,
            (response) =>
            {
            },
            (error, message) =>
            {
            }
        );
#endif
    }

    //----------------------------------------------------------------
    // Leaderboard Reward System (Dedicated)
    //----------------------------------------------------------------

    [Client]
    public void RequestClaimLeaderboardReward(int apiToken, string entryId)
    {
        if (!NetworkClient.isConnected)
        {
            return;
        }
        CmdClaimLeaderboardReward(apiToken, entryId);
    }

    [Command]
    public void CmdClaimLeaderboardReward(int apiToken, string entryId)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdClaimLeaderboardReward)))
        {
            return;
        }

        var result = LeaderboardRewardService.Instance.ClaimReward(userName, entryId);
        var entry = result.Item1;
        ErrorCode errorCode = result.Item2;

        if (entry is null || errorCode != ErrorCode.Success)
        {
            BattleManager.Log(GameLogType.Warning, $"[LeaderboardReward] CmdClaimLeaderboardReward: Claim failed for {userName} entry {entryId}, error: {errorCode}");
            return;
        }

        var box = DataHolder.Instance().GetData<Box>(entry.boxId);
        if (box == null)
        {
            return;
        }

        var characterData = BattleManager.instance.GetCharacterData(userName);
        if(characterData == null)
        {
            BattleManager.Log(GameLogType.Warning, $"[LeaderboardReward] CmdClaimLeaderboardReward: {userName} - CharacterData is null!");
            return;
        }

        BattleManager.Log(GameLogType.Info, $"[LeaderboardReward] Before receive Fang, Player {userName} have RexFang: {characterData.rexFang} | LegendFang: {characterData.legendFang} | MythicFang: {characterData.mythicFang}");

        var rewards = ServerOpenBox(box, BoxSourceType.Leaderboard, entry.boxId, true);
        BattleManager.instance.SaveCharacterData(characterData);

        BattleManager.Log(GameLogType.Info, $"[LeaderboardReward] After receive Fang, Player {userName} have RexFang: {characterData.rexFang} | LegendFang: {characterData.legendFang} | MythicFang: {characterData.mythicFang}");
        BattleManager.Log(GameLogType.Info, $"[LeaderboardReward] CmdClaimLeaderboardReward: Successfully claimed and opened box {entry.boxId} for {userName}");
        // Audit of what the box gave (anh Tuan 2026-10-31): entry, event, edition, rank, box, equipment (itemId:rare:level) and currency (id:value).
        string rewardEquipment = rewards.Item1 == null ? "" : string.Join(",", rewards.Item1.Select(e => e == null ? "null" : $"{e.itemId}:{e.rareType}:L{e.level}"));
        string rewardCurrency = rewards.Item2 == null ? "" : string.Join(",", rewards.Item2.Select(c => c == null ? "null" : $"{(CurrencyID)c.currencyId}:{c.value}"));
        BattleManager.Log(GameLogType.Info, $"[LeaderboardReward] Reward received: Player {userName}|Entry {entry.id}|Event {entry.gameEvent}|Edition {entry.edition}|{entry.leaderboardType} Rank {entry.rank}|Box {entry.boxId}|Equipment[{rewardEquipment}]|Currency[{rewardCurrency}]");

        ClaimLeaderboardRewardResponse response = new()
        {
            equipment = rewards.Item1,
            currencyDatas = rewards.Item2,
        };

        RpcClaimLeaderboardRewardResponse(connectionToClient, response);
#endif
    }

    [TargetRpc]
    public void RpcClaimLeaderboardRewardResponse(NetworkConnectionToClient conn,
        ClaimLeaderboardRewardResponse response)
    {
        EventDispatcher.Raise(response);
    }

#if ENABLE_SERVER
    /// <summary>
    /// Server sync reward entry xuống client.
    /// Được gọi từ LeaderboardRewardService khi có reward mới được generate hoặc khi claim reward.
    /// Đảm bảo client luôn có data mới nhất về rewards của user.
    /// </summary>
    [Server]
    public void ServerSyncLeaderboardReward(LeaderboardRewardEntry entry)
    {
        if (entry == null)
        {
            BattleManager.Log(GameLogType.Error, "[LeaderboardReward] ServerSyncLeaderboardReward: entry is null");
            return;
        }

        TargetRpcUpdateLeaderboardReward(this.connectionToClient, entry);
    }
#endif

    /// <summary>
    /// Client nhận reward update từ server.
    /// Update local cache trong ClientLeaderboardManager để UI có thể hiển thị.
    /// Được gọi khi:
    /// - Generate rewards mới sau khi tổng kết mùa giải
    /// - Claim reward (update status từ Pending -> Claimed)
    /// - Load character data lần đầu (sync toàn bộ rewards)
    /// </summary>
    [TargetRpc]
    public void TargetRpcUpdateLeaderboardReward(NetworkConnectionToClient conn, LeaderboardRewardEntry entry)
    {
        LeaderboardEventRewardEntry eventEntry = new()
        {
            rewardEntry = entry,
        };
        EventDispatcher.Raise(eventEntry);
    }

    /// <summary>
    /// Sync leaderboard rewards của season hiện tại xuống client khi load character data.
    /// Được gọi sau khi LogicLoadCharacterData hoàn thành để đảm bảo client có đầy đủ rewards.
    /// </summary>
    private void SyncAllLeaderboardRewardsToClient()
    {
#if ENABLE_SERVER
        var characterData = BattleManager.instance.GetCharacterData(this.userName);
        if (characterData == null || characterData.leaderboardRewards == null || characterData.leaderboardRewards.Count == 0)
        {
            return;
        }

        int currentSeasonId = BattleManager.instance.serverConfig.seasonId;
        int syncedCount = 0;

        for (int i = characterData.leaderboardRewards.Count - 1;  i >= 0; i--)
        {
            var current = characterData.leaderboardRewards[i];

            if (current.seasonId == currentSeasonId)
            {
                TargetRpcUpdateLeaderboardReward(this.connectionToClient, current);
                syncedCount++;
            }

        }

        if (syncedCount > 0)
        {
            BattleManager.Log(GameLogType.Info, $"[LeaderboardReward] SyncAllLeaderboardRewardsToClient: Synced {syncedCount} rewards (season {currentSeasonId}) to {this.userName}");
        }
#endif
    }

    //----------------------------------------------------------------
    // Request Lock Account
    //----------------------------------------------------------------
    [Client]

    public void RequestLockPlayer(int apiToken, string user, int hours)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdLockPlayer(apiToken, user, hours);
    }

    [Command]
    void CmdLockPlayer(int apiToken, string user, int hours)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdLockPlayer)))
            return;

        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);

        if (characterData == null || characterData.characterRole == CharacterRole.Player || characterData.characterRole == CharacterRole.Reporter)
            return;

        CharacterData lockPlayer = BattleManager.instance.GetCharacterData(user);
        if (lockPlayer == null)
            return;

        lockPlayer.lockTime = DataUtils.TimeToString(System.DateTime.Now.AddHours(hours));
        BattleManager.instance.SaveCharacterData(lockPlayer);

        PlayerBehavior lockPlayerBehavior = BattleManager.instance.GetPlayerBehavior(user);
        if (lockPlayerBehavior != null)
            lockPlayerBehavior.ForceQuit();

        BattleManager.Log(GameLogType.Admin, this.userName + " lock other player " + user + " for " + hours + " hours");
        //RpcLockPlayer(this.connectionToClient,true);
#endif
    }

    [TargetRpc]
    void RpcLockPlayer(NetworkConnectionToClient networkConnectionToClient, bool success)
    {
        if (UIManager.instance == null)
            return;

        if (success)
        {
            IngameNotifyManager.instance.Notify(766);
            UIManager.instance.FindView<CharacterInfoView>().RequestLockJailCallBack();
        }
    }

    //----------------------------------------------------------------
    // Request Lock Jail
    //----------------------------------------------------------------

    [Client]
    public void RequestLockJail(int apiToken, string user, int hours)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdLockJail(apiToken, user, hours);
    }

    [Command]
    void CmdLockJail(int apiToken, string user, int hours)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdLockJail)))
            return;

        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);

        if (characterData == null || characterData.characterRole == CharacterRole.Player
            || characterData.characterRole == CharacterRole.Reporter)
            return;
        var success = LogicLockJail(user, hours, BannedReason.Auto);
        if (success)
        {
            RpcLockPlayer(this.connectionToClient, true);
        }
#endif
    }

    public bool LogicLockJail(string user, int hours, BannedReason bannedReason, int jailId = 0)
    {

#if ENABLE_SERVER
        PlayerBehavior lockPlayerBehavior = BattleManager.instance.GetPlayerBehavior(user);

        if (lockPlayerBehavior != null)
        {
            if (lockPlayerBehavior.IsInBeginnerLand()) return false;

            if (lockPlayerBehavior.characterRole == CharacterRole.Mod || lockPlayerBehavior.characterRole == CharacterRole.Admin)
                return false;


            lockPlayerBehavior.jailTime += hours * 3600;
            lockPlayerBehavior.LockToJail();

            CharacterData lockPlayerData = BattleManager.instance.GetCharacterData(user);
            lockPlayerData.AddPrisonNumber(1);
            BattleManager.instance.SaveCharacterData(lockPlayerData);

            lockPlayerBehavior.RpcOnLockJail(lockPlayerBehavior.connectionToClient, bannedReason.ToString(), hours);

            // Log jail action
            BattleManager.Log(user, LogAction.JailPlayer, "Hours:" + hours, "Reason:" + bannedReason + "|Jailer:" + userName);
        }
        else
        {
            CharacterData lockPlayer = BattleManager.instance.GetCharacterData(user);
            if (lockPlayer == null) return false;

            if (lockPlayer.characterRole == CharacterRole.Mod || lockPlayer.characterRole == CharacterRole.Admin)
                return false;
            if (lockPlayer.landId == WorldManager.BEGINNER_LAND_NAME) return false;


            var land = WorldManager.Instance.GetLandData(WorldManager.CENTER_LAND_NAME);
            var jailArea = land.GetAreaController("Jail_Center");

            if (land != null && jailArea != null)
            {
                lockPlayer.jailTime += hours * 3600;
                lockPlayer.jailId = 0;

                lockPlayer.landId = WorldManager.CENTER_LAND_NAME;
                lockPlayer.lockAreaId = jailArea.Id;

                lockPlayer.posX = jailArea.Position.x;
                lockPlayer.posY = jailArea.Position.y;
                lockPlayer.AddPrisonNumber(1);
                BattleManager.instance.SaveCharacterData(lockPlayer);
                BattleManager.Log(GameLogType.Admin, userName + " lock jail player " + user + " for " + hours + " hours");
            }
        }
#endif
        return true;
    }

    [TargetRpc]
    public void RpcOnLockJail(NetworkConnectionToClient networkConnectionToClient, string reason, int hour)
    {
        if (UIManager.instance == null || IngameNotifyManager.instance == null)
            return;

        // Admin text is content, never notification rich-text markup.
        string displayReason = string.IsNullOrWhiteSpace(reason) ? BannedReason.Admin.ToString() : reason.Replace('<', '＜').Replace('>', '＞');
        var sb = UIManager.instance.StringBuilder.Clear();

        sb.Append(UIManager.GetDialog(767))
            .Append($"<color=#{UIRes.GetHighlightTextColor()}>{displayReason}</color>")
            .Append("\n")
            .Append(UIManager.GetDialog(768))
            .Append($"<color=#{UIRes.GetHighlightTextColor()}>{hour}h</color>");

        IngameNotifyManager.instance.Notify(sb.ToString());
    }

    //----------------------------------------------------------------
    // Request UnLock Jail
    //----------------------------------------------------------------

    [Client]
    public void RequestUnLockJail(int apiToken, string passcode, int hours, int expectedCost)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdUnlockJail(apiToken, passcode, hours, expectedCost);
    }

    [Command]
    private void CmdUnlockJail(int apiToken, string passcode, int hours, int expectedCost)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdUnlockJail)))
        {
            RejectJailUnlock(JailUnlockRules.Rejection.InvalidRequest);
            return;
        }

        if (CheckWalletPassCode(passcode) == false)
        {
            RejectJailUnlock(JailUnlockRules.Rejection.InvalidRequest);
            return;
        }

        if (!IsInJail() || jailTime <= 0)
        {
            RejectJailUnlock(JailUnlockRules.Rejection.NoSentence);
            return;
        }

        // hours comes from the client: it must be a real, positive amount no longer than the remaining sentence,
        // and the price must be positive before anything is charged (a negative price would credit the wallet).
        var gameDataConfig = BattleManager.instance.gameDataConfig;
        if (gameDataConfig == null || !JailUnlockRules.TryGetCost(hours, jailTime, gameDataConfig.JailUnlockCostPerHourTH, out int cost))
        {
            BattleManager.Log(GameLogType.Warning, $"[UnlockJail] Rejected user:{userName}|Hours:{hours}|JailTime:{jailTime}");
            RejectJailUnlock(JailUnlockRules.Rejection.InvalidRequest);
            return;
        }

        var walletData = BattleManager.instance.GetWalletData(userName);
        if (walletData == null)
        {
            RejectJailUnlock(JailUnlockRules.Rejection.InvalidRequest);
            return;
        }

        if (!JailUnlockRules.IsPriceAccepted(cost, expectedCost))
        {
            RejectJailUnlock(expectedCost > 0 ? JailUnlockRules.Rejection.PriceIncreased : JailUnlockRules.Rejection.InvalidRequest);
            return;
        }

        if (walletData.token < cost)
        {
            RejectJailUnlock(JailUnlockRules.Rejection.InsufficientMoney);
            return;
        }

        BattleManager.instance.AddToken(walletData, -cost);
        EconomyManager.RecordThBurn(cost, "jail_unlock_fee");

        if (hours == JailUnlockRules.UnlockAllHours)
        {
            jailTime = 0f;
        }
        else
        {
            jailTime = Mathf.Max(0f, jailTime - JailUnlockRules.SecondsToRemove(hours, jailTime));
        }

        CharacterData characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData != null)
            characterData.suspectdNumber = 0;

        // Log pay to escape jail
        Log(LogAction.PayToEscapeJail,
            $"Hours:{hours}",
            value: cost.ToString());
        BattleManager.Log(GameLogType.Admin, userName + " unlock jail for " + cost + " TH");

        BattleManager.instance.SavePlayerData(this);
        RpcUnlockJail(connectionToClient, cost);
#endif
    }

#if ENABLE_SERVER
    private void RejectJailUnlock(JailUnlockRules.Rejection reason)
    {
        if (!NetSafe.CanTarget(this))
            return;

        var config = BattleManager.instance.gameDataConfig;
        RpcUnlockJailRejected(connectionToClient, reason, jailTime, config == null ? 0 : config.JailUnlockCostPerHourTH);
    }
#endif

    [TargetRpc]
    private void RpcUnlockJailRejected(NetworkConnectionToClient connection, JailUnlockRules.Rejection reason, float remainingSeconds, int costPerHour)
    {
        if (UIManager.instance == null)
            return;

        var view = UIManager.instance.FindView<UnlockJailView>();
        if (view != null)
            view.OnUnlockJailRejected(this, reason, remainingSeconds, costPerHour);
    }

    [TargetRpc]
    private void RpcUnlockJail(NetworkConnectionToClient networkConnectionToClient, int thCost)
    {
        if (UIManager.instance == null)
            return;

        var view = UIManager.instance.FindView<UnlockJailView>();
        if (view != null)
            view.OnUnlockJailSucceeded(this);

        // ✅ Track TH Consumed (unlock jail)
#if ENABLE_ANALYTIC_SERVICE
        if (thCost > 0 && AnalyticsManager.instance != null)
        {
            AnalyticsManager.instance.TrackTHConsumed(thCost, "unlock_jail");
        }
#endif
    }

    //----------------------------------------------------------------
    // Request Get Role
    //----------------------------------------------------------------
    [Client]
    public void RequestGetPlayerRole(int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdGetPlayerRole(apiToken);
    }

    [Command]
    void CmdGetPlayerRole(int apiToken)
    {
#if ENABLE_SERVER
        if (!ServerValidateApiToken(apiToken, nameof(CmdGetPlayerRole)))
            return;

        CharacterData characterData = BattleManager.instance.GetCharacterData(this.userName);

        if (characterData == null)
            return;

        RpcGetPlayerRole(this.connectionToClient, characterData.characterRole);
#endif
    }

    [TargetRpc]
    void RpcGetPlayerRole(NetworkConnectionToClient networkConnectionToClient, CharacterRole characterRole)
    {

    }

    //----------------------------------------------------------------
    // Request Set Role
    //----------------------------------------------------------------
    [Client]
    public void RequestSetPlayerRole(int apiToken, string targetUsername, CharacterRole characterRole)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdSetPlayerRole(apiToken, targetUsername, characterRole);
    }

    [Command]
    void CmdSetPlayerRole(int apiToken, string targetUsername, CharacterRole characterRole)
    {
#if ENABLE_SERVER

        if (!ServerValidateApiToken(apiToken, nameof(CmdSetPlayerRole)))
            return;

        //TODO: check set role permission
        if (playerRole != PlayerRole.Admin)
        {
            BattleManager.Log(GameLogType.Warning, $"{userName} try set role but no permission");
            return;
        }

        var playerBehavior = BattleManager.instance.GetPlayerBehavior(targetUsername);
        if (playerBehavior != null)
        {
            playerBehavior.characterRole = characterRole;
            playerBehavior.OnUpdateStats();
            BattleManager.instance.SavePlayerData(playerBehavior);

            BattleManager.Log(GameLogType.Admin, $"{userName} Set role success. {targetUsername} is {characterRole}");
            RpcSetPlayerRole(this.connectionToClient, targetUsername, characterRole);
        }
        else
        {
            var characterData = BattleManager.instance.GetCharacterData(targetUsername);
            if (characterData == null)
            {
                return;
            }

            characterData.characterRole = characterRole;
            BattleManager.instance.SaveCharacterData(characterData);
            BattleManager.Log(GameLogType.Admin, $"{userName} Set role success. {targetUsername} is {characterRole}");

            RpcSetPlayerRole(this.connectionToClient, targetUsername, characterRole);
        }
#endif
    }

    [TargetRpc]
    void RpcSetPlayerRole(NetworkConnectionToClient networkConnectionToClient, string targetUsername, CharacterRole characterRole)
    {
        BattleManager.Log(GameLogType.Debug, $"Set role success. {targetUsername} is {characterRole}");
    }

    // RequestInitGetMailDatas - Request dạng init, luôn trả về rpc 
    [Client]
    public void RequestInitGetMailDatas(string username, int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;
        CmdInitGetMailDatas(username, apiToken);
    }

    [TargetRpc]
    void RpcDeleteAllMail(NetworkConnectionToClient networkConnectionToClient, DeleteAllMailDatasResponse response)
    {
        //TODO: nhớ thêm dialog mới cho errorCode -> response.ErrorCode
        if (response.ErrorCode != ErrorCode.Success)
        {
            IngameNotifyManager.instance.Notify(response.ErrorCode);
            return;
        }

        EventDispatcher.Raise(response);
    }

    [Client]
    public void RequestGetGlobalChatCharacterBrief(int apiToken, int startIndex, int count)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdGetGlobalChatCharacterBrief(apiToken, startIndex, count);
    }

    [Command]
    void CmdGetGlobalChatCharacterBrief(int apiToken, int startIndex, int count)
    {
#if ENABLE_SERVER

        if (!ServerValidateApiToken(apiToken, nameof(CmdGetGlobalChatCharacterBrief)))
            return;

        RpcGetGlobalChatCharacterBrief(this.connectionToClient, BattleManager.instance.GetGlobalChatCharacterBriefs(startIndex, count));
#endif
    }

    [TargetRpc]
    void RpcGetGlobalChatCharacterBrief(NetworkConnectionToClient networkConnectionToClient, List<CharacterBrief> characterBriefs)
    {
#if ENABLE_CLIENT
        var chatView = UIManager.instance.FindView<ChatView>();
        if(chatView != null)
        {
            chatView.RequestGetGlobalChatCharacterBriefCallback(characterBriefs);
        }
#endif
    }

    [Client]
    public void RequestUseExpandCamera(int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdUseExpandCamera(apiToken);
    }

    [Command]
    void CmdUseExpandCamera(int apiToken)
    {
#if ENABLE_SERVER

        if (!ServerValidateApiToken(apiToken, nameof(CmdUseExpandCamera)))
            return;

        if(IsInBeginnerLand())
        {
            RpcUseExpandCamera(this.connectionToClient, false);
            return;
        }

        var characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData == null) return;

        if(characterData.GetVipStatValue(VipBonusType.ExpandCamera) == 0)
        {
            RpcUseExpandCamera(this.connectionToClient, false);
            return;
        }

        RpcUseExpandCamera(this.connectionToClient, true);
#endif
    }

    [TargetRpc]
    void RpcUseExpandCamera(NetworkConnectionToClient networkConnectionToClient, bool canUse)
    {
#if ENABLE_CLIENT
        var hudView = UIManager.instance.FindView<HUDView>();
        if(hudView != null)
        {
            hudView.OnRequestUseExpandCameraCallback(canUse);
        }
#endif
    }

    [Client]
    public void RequestGetProtectedItems(int apiToken)
    {
        if (!NetworkClient.isConnected)
            return;

        CmdGetProtectedItems(apiToken);
    }

    [Command]
    void CmdGetProtectedItems(int apiToken)
    {
#if ENABLE_SERVER

        if (!ServerValidateApiToken(apiToken, nameof(CmdGetProtectedItems)))
            return;

        var walletData = BattleManager.instance.GetWalletData(userName);
        if(walletData != null)
        {
            var protectedWalletItems = walletData.protectedWalletItems;
            var protectedCharacterItems = walletData.protectedCharacterItems;

            RpcGetProtectedItems(connectionToClient, protectedWalletItems, protectedCharacterItems);
        }

#endif
    }

    [TargetRpc]
    void RpcGetProtectedItems(NetworkConnectionToClient networkConnectionToClient, List<Equipment> protectedWalletItems, List<Equipment> protectedCharacterItems)
    {
#if ENABLE_CLIENT
        var walletData = ClientManager.instance.myWalletData;
        if (walletData != null)
        {
            walletData.protectedWalletItems.Clear();
            walletData.protectedCharacterItems.Clear();
        
            if(protectedWalletItems != null)
            {
                foreach (var equipment in protectedWalletItems)
                {
                    walletData.protectedWalletItems.Add(equipment);
                }
            }

            if (protectedCharacterItems != null)
            {
                foreach (var equipment in protectedCharacterItems)
                {
                    walletData.protectedCharacterItems.Add(equipment);
                }
            }

            var walletView = UIManager.instance.FindView<WalletView>();
            if(walletView != null)
            {
                walletView.IsFirstLoadProtectedItems = false;
            }
        }
#endif
    }


    //============= SHOULD BE REFACTOR  =====================

    //TODO-REFACTOR: README: Those IsInsideArea should change their name since IsInLand is using runtime caching to compare
    //but these is using landId and areaId string to compare
    public bool IsInsideArea(string landId, string areaId)
    {
        //Read README above
        return this.landId == landId && this.lockAreaId == areaId;
    }
    public bool IsInsideArea(string areaId)
    {
        //Read README above

        return this.lockAreaId == areaId;
    }

    public bool IsInsideJailArea()
    {
        //Read README above

        return IsInsideArea(WorldManager.CENTER_LAND_NAME, "Jail_Center");
    }

    public bool IsInJail()
    {
        return jailId != -1; //Should also check jailTime > 0
    }

    public void LockToJail()
    {
        jailId = 0;
        // Jail teleport: disable automation (keepAutoMode = false, mặc định)
        TeleportToLand(WorldManager.CENTER_LAND_NAME, "Jail_Center");
    }

    public void ReleaseFromJail()
    {
        jailId = -1;
        TeleportExitCurrentArea();
    }

    public bool SafeRemoveEquipment(Equipment equipment)
    {
        if (equipment == null) return false;

        var state = equipment.state;
        if (state == EquipmentState.Trading || state == EquipmentState.Lock)
        {
            BattleManager.Log(GameLogType.Warning, userName + " try remove equipment " + state.ToString());
            return false;
        }

        bool isSuccess = false;
        switch (state)
        {
            case EquipmentState.New:
            case EquipmentState.Inventory:
                if (characterInventory != null)
                    isSuccess = characterInventory.RemoveEquipment(equipment.id);
                break;
            case EquipmentState.Character:
                if (characterEquipments != null)
                {
                    isSuccess = characterEquipments.RemoveEquipment(equipment.id);
                }
                
                // Nếu là skin, cũng xóa khỏi skinSetsData
                if (equipment.IsSkin())
                {
                    var (setIndex, removed) = RemoveSkinFromSkinSetsDataById(equipment.id);
                    if (removed != null)
                    {
                        isSuccess = true;
                    }
                }
                break;
            case EquipmentState.Ingredient:
                if (characterIngredient != null)
                    isSuccess = characterIngredient.RemoveEquipment(equipment.id);
                break;
            case EquipmentState.Collection:
                if (characterCollection != null)
                    isSuccess = characterCollection.RemoveEquipment(equipment.id);
                break;
            case EquipmentState.Title:
                if (characterTitleEquipment != null)
                    isSuccess = characterTitleEquipment.RemoveEquipment(equipment.id);
                break;
            default:
                break;
        }

        if (isSuccess == false)
        {
            if (characterInventory != null)
            {
                bool result = characterInventory.RemoveEquipment(equipment.id);
                if (result)
                {
                    BattleManager.Log(GameLogType.Error, $"{userName} request remove item state={state} but found in Inventory");
                    return true;
                }
            }

            if (characterEquipments != null)
            {
                bool result = characterEquipments.RemoveEquipment(equipment.id);
                if (result)
                {
                    BattleManager.Log(GameLogType.Error, $"{userName} request remove item state={state} but found in Equipments");
                    return true;
                }
            }

            if (characterIngredient != null)
            {
                bool result = characterIngredient.RemoveEquipment(equipment.id);
                if (result)
                {
                    BattleManager.Log(GameLogType.Error, $"{userName} request remove item state={state} but found in Ingredient");
                    return true;
                }
            }

            if (characterCollection != null)
            {
                bool result = characterCollection.RemoveEquipment(equipment.id);
                if (result)
                {
                    BattleManager.Log(GameLogType.Error, $"{userName} request remove item state={state} but found in Collection");
                    return true;
                }
            }

            if (characterTitleEquipment != null)
            {
                bool result = characterTitleEquipment.RemoveEquipment(equipment.id);
                if (result)
                {
                    BattleManager.Log(GameLogType.Error, $"{userName} request remove item state={state} but found in Title");
                    return true;
                }
            }

            // Fallback cho skinSetsData
            if (equipment.IsSkin())
            {
                var (setIndex, removed) = RemoveSkinFromSkinSetsDataById(equipment.id);
                if (removed != null)
                {
                    BattleManager.Log(GameLogType.Error, $"{userName} request remove skin state={state} but found in SkinSet[{setIndex}]");
                    return true;
                }
            }

            BattleManager.Log(GameLogType.Warning, $"{userName} try remove item {equipment.id} state={state} but not found anywhere");
            return false;
        }

        return true;
    }
}
