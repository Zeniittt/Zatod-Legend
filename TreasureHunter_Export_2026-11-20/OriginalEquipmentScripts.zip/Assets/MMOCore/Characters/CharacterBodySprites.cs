using System.Collections;
using System.Collections.Generic;
using MCP.DataModels.BaseModels;
using UnityEngine;
using static GameConst;

public class CharacterBodySprites : MonoBehaviour
{
    public List<SpriteList> spriteLists = new List<SpriteList>();
    CharacterCopySprite[] copySprites = new CharacterCopySprite[0];
    //List<EquipmentVisual> equipmentVisuals = new List<EquipmentVisual>();
    bool lastHideHelmet = false;
    bool lastHideFaceHair = false;

    private void Awake()
    {
        copySprites = this.GetComponentsInChildren<CharacterCopySprite>(true);
    }

    private void Start()
    {
        CopySprite();
    }
    public void LoadSkinHorse(EquipmentVisual equipment, RareType rareType)
    {
        Card card = UIManager.instance.GetCard(equipment.itemId);
        if (card == null)
        {
            return;
        }

        if (!card.canEquip)
        {
            return;
        }
        //bắt buộc là equipmenType = ngựa vì skin ngựa nằm chung path và chung 1 cách load với ngựa.
        string path = GetSpritePath(card, EquipmentType.Horse, rareType);
        LoadSpriteFromPath(card, EquipmentType.Horse, rareType, path);

        CopySprite();
    }
    public void LoadEquipment(EquipmentVisual equipment, bool hideHelmet, bool hideFaceHair = false, bool hideHair = false)
    {
        /*
        foreach (EquipmentVisual equipmentVisual in equipmentVisuals)
        {
            if (equipment.equipmentType == equipmentVisual.equipmentType)
            {
                if (equipment.itemId == equipmentVisual.itemId && equipment.rareType == equipmentVisual.rareType)
                {
                    if (lastHideFaceHair == hideFaceHair && hideHelmet == lastHideHelmet)
                    {
                        return;
                    }
                }                    
                else
                {
                    equipmentVisuals.Remove(equipmentVisual);
                    break;
                }
            }
        }*/


        //if(!equipmentVisuals.Contains(equipment))
        //    equipmentVisuals.Add(equipment);

        lastHideFaceHair = hideFaceHair;
        lastHideHelmet = hideHelmet;

        Card card = UIManager.instance.GetCard(equipment.itemId);
        if(card == null)
        {
            return;
        }

        if (!card.canEquip)
        {
            return;
        }

        //if(equipment.equipmentType != EquipmentType.Horse)
        //ResetEquipmentSprite(equipment);            

        if (card.equipmentType == EquipmentType.Helmet && hideHelmet)
        {
            ResetEquipmentSprite(equipment);
            return;
        }

        if (card.equipmentType == EquipmentType.FaceHair && hideFaceHair)
        {
            ResetEquipmentSprite(equipment);
            return;
        }

        if (card.equipmentType == EquipmentType.Hair && hideHair)
        {
            ResetEquipmentSprite(equipment);
            return;
        }

        string path = GetSpritePath(card, card.equipmentType, equipment.rareType);
        LoadSpriteFromPath(card, card.equipmentType, equipment.rareType, path);

        CopySprite();
    }

    private static string GetSpritePath(Card card, EquipmentType equipmentType, RareType rareType)
    {
        string path = "Icons/Items/" + equipmentType.ToString() + "/" + card.GetName(0);
        if (equipmentType == EquipmentType.Horse)
        {
            path += "_" + rareType.ToString();
        }

        return path;
    }

    private void LoadSpriteFromPath(Card card, EquipmentType equipmentType, RareType rareType, string path)
    {
        if (AssetManager.instance == null) return;
        Sprite[] tObj = AssetManager.instance.GetCharacterSprites(path);
        if (equipmentType == EquipmentType.Horse && (tObj == null || tObj.Length == 0))
        {
            path = "Icons/Items/" + equipmentType.ToString() + "/" + card.GetName(0);
            tObj = AssetManager.instance.GetCharacterSprites(path);
        }
        if (tObj != null)
        {

            if ((int)equipmentType < spriteLists.Count)
            {
                SetSpriteList(spriteLists[(int)equipmentType].itemList, tObj);
            }

            if (equipmentType == EquipmentType.Eye)
            {
                if (card.craftable)
                {
                    LoadColor(equipmentType, Color.white);
                }
                else
                {
                    LoadEyeColor(equipmentType, UIRes.DB.rarityBackEyeColors[(int)rareType], UIRes.DB.rarityEyeColors[(int)rareType]);
                }
            }
            else if (equipmentType == EquipmentType.Hair || equipmentType == EquipmentType.FaceHair)
            {
                if (card.craftable)
                {
                    LoadColor(equipmentType, Color.white);
                }
                else if (card.useRareColor)
                {
                    LoadColor(equipmentType, UIRes.DB.rarityHairColors[(int)rareType]);
                }
                else
                {
                    LoadColor(equipmentType, Color.white);
                }
            }
            else if (equipmentType == EquipmentType.Weapons ||
                    equipmentType == EquipmentType.Helmet ||
                    equipmentType == EquipmentType.Cloth ||
                    equipmentType == EquipmentType.Back ||
                    equipmentType == EquipmentType.Boot)
            {
                if (card.useRareColor)
                {
                    LoadColor(equipmentType, UIRes.GetColor(rareType));
                }
                else
                {
                    LoadColor(equipmentType, Color.white);
                }
            }
            else if (equipmentType == EquipmentType.Body)
            {
                LoadColor(equipmentType, Color.white);
            }
            else if (equipmentType != EquipmentType.Horse && equipmentType != EquipmentType.SkinHorse)
            {
                if (card.craftable == false && card.useRareColor == false)
                {
                    LoadColor(equipmentType, Color.white);
                }
                else
                {
                    LoadColor(equipmentType, UIRes.GetColor(rareType));
                }
            }
        }
    }

    public void LoadDefaultEye()
    {
        string path = "Icons/Items/Eye/Eye_0";

        //Debug.Log("Item Path " + path);

        // ✅ SERVER-ONLY: Add null check for AssetManager
        if (AssetManager.instance == null) return;

        Sprite[] tObj = AssetManager.instance.GetCharacterSprites(path);
        if (tObj != null)
        {
            SetSpriteList(spriteLists[(int)EquipmentType.Eye].itemList, tObj);
            LoadEyeColor(EquipmentType.Eye, UIRes.DB.rarityBackEyeColors[(int)RareType.Common], UIRes.DB.rarityEyeColors[(int)RareType.Common]);
        }

        CopySprite();
    }

    public void LoadDefaultBody()
    {
        string path = "Icons/Items/Body/Body_0";

        if (AssetManager.instance == null) return;

        Sprite[] tObj = AssetManager.instance.GetCharacterSprites(path);
        if (tObj != null)
        {
            SetSpriteList(spriteLists[(int)EquipmentType.Body].itemList, tObj);
            LoadColor(EquipmentType.Body, Color.white);
        }

        CopySprite();
    }
    void CopySprite()
    {
        for(int i = 0; i < copySprites.Length; i++)
        {
            copySprites[i].Load();
        }
    }

    //Load Color to equipment
    public void LoadColor(EquipmentType itemType, Color color)
    {
        SetSpriteColorList(spriteLists[(int)itemType].itemList, color);
    }

    public void LoadEyeColor(EquipmentType itemType, Color color1,Color color2)
    {
        SpriteList spriteList = spriteLists[(int)itemType];

        if (spriteList.itemList.Count > 1)
        {
            spriteList.itemList[0].color = color1;
            spriteList.itemList[1].color = color2;
        }
    }

    //Reset All Color
    public void ResetAllEquipmentSprite()
    {
        //this.equipmentVisuals.Clear();
        lastHideFaceHair = false;
        lastHideHelmet = false;
        LoadDefaultEye();
        LoadDefaultBody();
        for (int i = 0; i < spriteLists.Count; i++)
        {
            for (int j = 0; j < spriteLists[i].itemList.Count; j++)
            {
                if (spriteLists[i] != null && spriteLists[i].itemList[j] != null &&
                    spriteLists[i].equipmentType != EquipmentType.Eye && spriteLists[i].equipmentType != EquipmentType.Item)
                {
                    if (spriteLists[i].equipmentType != EquipmentType.Body)
                    {
                        spriteLists[i].itemList[j].sprite = null;
                    }

                    spriteLists[i].itemList[j].color = Color.white;
                }
            }
        }
    }

    //Reset All Color
    public void ResetEquipmentSprite(EquipmentVisual e)
    {
        Card card = UIManager.instance.GetCard(e.itemId);
        if (card == null)
            return;

        for (int i = 0; i < spriteLists.Count; i++)
        {
            if (spriteLists[i] != null && spriteLists[i].equipmentType == card.equipmentType && card.equipmentType == EquipmentType.Body)
            {
                LoadDefaultBody();
                continue;
            }

            
            if (spriteLists[i] != null && spriteLists[i].equipmentType == card.equipmentType && card.equipmentType == EquipmentType.Eye)
            {
                LoadDefaultEye();
                continue;
            }

            if (spriteLists[i] != null && spriteLists[i].equipmentType == card.equipmentType && card.equipmentType != EquipmentType.Body
                && card.equipmentType != EquipmentType.Eye && card.equipmentType != EquipmentType.Item && card.equipmentType != EquipmentType.Pet
                && card.equipmentType != EquipmentType.Artifact)
            {
                for (int j = 0; j < spriteLists[i].itemList.Count; j++)
                {
                    if (spriteLists[i].itemList[j] != null)
                    {
                        spriteLists[i].itemList[j].sprite = null;
                        spriteLists[i].itemList[j].color = Color.white;
                    }
                }
            }
        }
    }

    //Set List SpriteRenderer with List Sprite
    public void SetSpriteList(List<SpriteRenderer> data, Sprite[] sprites)
    {
        for (int i = 0; i < data.Count; i++)
        {
            if (data[i] != null)
            {
                if(i < sprites.Length && sprites[i] != null)
                    data[i].sprite = sprites[i];
                else
                    data[i].sprite = null;
            }
                
        }
    }

    //Set List SpriteRenderer with List Sprite
    public void SetSpriteColorList(List<SpriteRenderer> data, Color color)
    {
        for (int i = 0; i < data.Count; i++)
        {
            if (data[i] != null)
                data[i].color = color;
        }
    }

}

[System.Serializable]
public class SpriteList
{
    public EquipmentType equipmentType = EquipmentType.Item;
    public List<SpriteRenderer> itemList = new List<SpriteRenderer>();
}
