using System.Collections;
using System.Collections.Generic;
using System.Security.Claims;
using MCP.DataModel.Utils;
using MCP.DataModels.BaseModels;
using Mirror;
using PathologicalGames;
using TMPro;
using UnityEngine;
using UnityEngine.Rendering;
using static CharacterBodyStatus;
using static MCP.Unity.UnityUtils;

public class CharacterBody : MonoBehaviour
{
    //[HideInInspector]
    public CharacterBehavior characterBehavior;
    //[HideInInspector]
    public CharacterHealth characterHealth;
    public CharacterBodyStatus characterBodyStatus;

    public Transform nameAnchor;

    public Transform chatAnchor;
    public bool isInView = true;
    public bool isShowBody = true;
    public bool isShowName = true;
    Camera mainCamera;

    public Color playerNameColor;
    public Transform body;
    //public Animator defaultAnimator;
    public Animator animator;
    public HealthBar healthBar;
    public EffectStatusUI effectStatusUI;
    public TextMeshPro playerNameText;
    public TextMeshPro clanNameText;
    public Transform protectionIcon;
    public Transform wantedIcon;
    public Transform autoIcon;
    public Transform autoWithShieldIcon;
    public GameObject arenaWinner;
    public Transform arenaIcon;
    public Transform watchAdIcon;
    public Transform tiredIcon;

    public SortingGroup sortingGroup;
    public OutlineAble OutlineAble;

    float correctTime = 0;

    [Header("Area")]
    public Transform sizeTransform;
    public SpriteRenderer areaGlow;
    public GameObject getColorGameobject;
    float areaGlowVisibleAlpha = -1f;
    float areaGlowTargetAlpha;
    float areaGlowFadeDuration;
    bool isAreaGlowTargetVisible;
    Coroutine areaGlowFadeCoroutine;

    [Header("Royalty")]
    [SerializeField] SpriteRenderer royaltyBar;
    private BuildingSyncRoyalty syncRoyalty;
    private float maxScale = 1;

    [Header("Visibility")]
    [SerializeField] private float visibilityRefreshInterval = 0.1f;
    private float visibilityTimer;
    private bool hasVisibilityState;

    [Header("Runtime Refresh")]
    [SerializeField] private float bodyStatusRefreshInterval = 0.1f;
    [SerializeField] private float buildingProtectionRefreshInterval = 0.25f;
    private float bodyStatusRefreshTimer;
    private float buildingProtectionRefreshTimer;
    private int lastProtectionSecond = int.MinValue;
    private string lastProtectionText = null;
    private bool lastProtectionVisible;
    private bool lastProtectionIsPreparation;
    private bool lastProtectionIsEvent;
    private bool lastArenaWinner;
    private bool hasLastArenaWinner;
    private float lastRoyaltyRatio = -1f;
    private bool hasLastSyncedPosition;

    [Header("Protection")]
    [SerializeField] Transform preparationIcon;
    [SerializeField] Transform protectIcon;
    [SerializeField] Transform eventProtectionIcon;

    [SerializeField] TMP_Text protectionTime;
    [SerializeField] Transform protectionTimeLabel;

    public event System.Action<PlayerBehavior> OnInitializeEvent;
    public event System.Action<PlayerBehavior> OnUpdateStatEvent;
    public int bodyId = -2;

    string lastCharacterName = "";
    public string lastClanName = "";

    void Awake()
    {
        if (royaltyBar != null)
        {
            maxScale = royaltyBar.transform.localScale.x;
        }
        mainCamera = Camera.main;
        InitializeAreaGlowAlpha();
    }

    public virtual void LoadBody(int cardId)
    {
        lastCharacterName = "";
        lastClanName = "";

        if (cardId == bodyId)
            return;

        bodyId = cardId;

        if (animator != null && animator.transform != null)
        {
            if (characterBodyStatus == null)
            {
                characterBodyStatus = animator.gameObject.GetComponent<CharacterBodyStatus>();
            }

            PoolManager.Pools["Mounts"].Despawn(animator.transform, PoolManager.Pools["Mounts"].transform);
        }

        //Debug.Log("Load Body Spite " + cardId);

        if (cardId == -1)
        {
            Transform t = PoolManager.Pools["Mounts"].Spawn("Unit");
            t.SetParent(this.body);
            t.localPosition = Vector3.zero;
            t.localRotation = Quaternion.identity;
            t.localScale = new Vector3(Mathf.Abs(t.localScale.x), Mathf.Abs(t.localScale.y), 1);
            animator = t.GetComponent<Animator>();
            animator.enabled = true;
            animator.keepAnimatorStateOnDisable = true;
        }
        else
        {
            Card card = DataHolder.Instance().GetData<Card>(cardId);
            string name = UIManager.GetDialog(1193);
            if (card != null)
            {
                name = card.GetName(0);
            }
            Transform t = PoolManager.Pools["Mounts"].Spawn(name);
            t.SetParent(this.body);
            t.localPosition = Vector3.zero;
            t.localRotation = Quaternion.identity;
            t.localScale = new Vector3(Mathf.Abs(t.localScale.x), Mathf.Abs(t.localScale.y), 1);
            animator = t.GetComponent<Animator>();
            animator.enabled = true;
            animator.keepAnimatorStateOnDisable = true;
        }
    }

    public virtual void LoadData(CharacterBehavior character)
    {
        // A pooled Body can be rebound to a different actor after visibility/login changes.
        lastCharacterName = "";
        lastClanName = "";
        characterHealth = character.GetComponentInParent<CharacterHealth>();
        this.characterBehavior = character;
        syncRoyalty = character.characterType == CharacterType.Building ? character.GetComponent<BuildingSyncRoyalty>() : null;

        if (character is PlayerBehavior playerBehavior)
        {
            OnInitializeEvent?.Invoke(playerBehavior);
        }

        if (character.characterType == CharacterType.Building)
        {
            SetAreaGlowVisible(false, 0f);
            GetComponentInChildren<BuildingPlacementGridOwner>(true)?.Register(this);
        }

        if (animator != null && animator.transform != null)
        {
            if (characterBodyStatus == null)
            {
                characterBodyStatus = animator.gameObject.GetComponent<CharacterBodyStatus>();
            }
        }

        if (healthBar != null && characterHealth != null)
        {
            healthBar.ClearEffect();
            healthBar.ResetDisplayCache();
            healthBar.health = characterHealth;
            healthBar.characterBehavior = character;
            healthBar.RefreshDisplayNow();

            if (character.characterEffects != null)
            {
                var effects = character.characterEffects.GetEffects();
                healthBar.OnAddEffect(effects);
            }

            if (character is MobBehavior mob)
            {
                healthBar.SetUpLifeTimeCounter(mob.liveTime);
                healthBar.SetUpLevel(mob.level);
            }
        }
    }

    public virtual void OnUpdateStat(CharacterBehavior playerBehavior)
    {
        var player = playerBehavior as PlayerBehavior;

        if (player != null)
        {
            OnUpdateStatEvent?.Invoke(player);
        }

        if (sizeTransform && playerBehavior != null && playerBehavior.characterType != CharacterType.Building)
        {
            // Siege Range comes from the Server projection. Local Card stats
            // do not contain the consumed Summon instance's effective values.
            var range = (playerBehavior is SiegeUnitBehavior siegeUnit
                ? siegeUnit.attackRange
                : playerBehavior.statData.GetStat(StatType.Range).value) * 2f;
            sizeTransform.localScale = new Vector2(range, range);
        }

        if (areaGlow)
        {
            InitializeAreaGlowAlpha();

            var color = areaGlow.color;
            float currentAlpha = color.a;
            if (getColorGameobject != null && getColorGameobject.TryGetComponent<IGetColor>(out var getColor))
            {
                color = getColor.Color(playerBehavior);
                areaGlowVisibleAlpha = color.a;

                var nameColor = color;
                nameColor.a = 1f;
                if (characterBehavior != null && characterBehavior.GetTeamId().IsNullOrEmpty() == false)
                    playerNameText.color = nameColor;
            }

            areaGlowTargetAlpha = isAreaGlowTargetVisible ? areaGlowVisibleAlpha : 0f;
            color.a = currentAlpha;
            areaGlow.color = color;
        }
    }

    public void UpdateArea(float range)
    {
        if (sizeTransform == null)
            return;

        range = range * 2f;

        sizeTransform.localScale = new Vector2(range, range);
    }

    public void SetAreaGlowVisible(bool visible, float fadeDuration = 0f)
    {
        if (areaGlow == null || !isActiveAndEnabled)
            return;

        InitializeAreaGlowAlpha();
        isAreaGlowTargetVisible = visible;
        areaGlowTargetAlpha = visible ? areaGlowVisibleAlpha : 0f;
        areaGlowFadeDuration = fadeDuration;
        areaGlow.enabled = visible || areaGlow.color.a > 0f;

        if (fadeDuration <= 0f)
        {
            StopAreaGlowFade();
            SetAreaGlowAlpha(areaGlowTargetAlpha);
            areaGlow.enabled = visible;
            return;
        }

        StopAreaGlowFade();
        areaGlowFadeCoroutine = StartCoroutine(FadeAreaGlowAlpha());
    }

    private IEnumerator FadeAreaGlowAlpha()
    {
        while (areaGlow != null && !Mathf.Approximately(areaGlow.color.a, areaGlowTargetAlpha))
        {
            float currentAlpha = areaGlow.color.a;
            float nextAlpha = Mathf.MoveTowards(
                currentAlpha,
                areaGlowTargetAlpha,
                Time.deltaTime * areaGlowVisibleAlpha / areaGlowFadeDuration);

            SetAreaGlowAlpha(nextAlpha);
            yield return null;
        }

        if (areaGlow != null)
        {
            SetAreaGlowAlpha(areaGlowTargetAlpha);
            areaGlow.enabled = isAreaGlowTargetVisible;
        }

        areaGlowFadeCoroutine = null;
    }

    private void InitializeAreaGlowAlpha()
    {
        if (areaGlow == null)
            return;

        if (areaGlowVisibleAlpha < 0f)
        {
            areaGlowVisibleAlpha = Mathf.Max(areaGlow.color.a, 0f);
        }
        areaGlowTargetAlpha = areaGlow.enabled ? areaGlowVisibleAlpha : 0f;
        isAreaGlowTargetVisible = areaGlow.enabled;
    }

    private void StopAreaGlowFade()
    {
        if (areaGlowFadeCoroutine != null)
        {
            StopCoroutine(areaGlowFadeCoroutine);
            areaGlowFadeCoroutine = null;
        }
    }

    private void SetAreaGlowAlpha(float alpha)
    {
        var color = areaGlow.color;
        color.a = alpha;
        areaGlow.color = color;
    }

    private void UpdateBodyStatus()
    {
        if (playerNameText != null && FinalWarManager.IsEliminated(characterBehavior)) playerNameText.color = Color.gray;
        if (characterBodyStatus != null)
        {
            //Update body status
            bool isWind = false;

            if (characterBehavior.characterEffects != null)
            {
                isWind = characterBehavior.characterEffects.HaveEffect(1732);
            }
            bool isPoison = characterBehavior.statData.GetStat(StatType.PoisonDoT).value > 0;
            bool isBurn = characterBehavior.fireDot > 0;
            bool isFreeze = characterBehavior.freezeDoT > 0;
            BodyStatus bodyStatus;

            if (isWind)
            {
                bodyStatus = BodyStatus.Wind;
            }
            else if (isFreeze)
            {
                bodyStatus = BodyStatus.Freeze;
            }
            else if (isBurn)
            {
                bodyStatus = BodyStatus.Fire;
            }
            else if (isPoison)
            {
                bodyStatus = BodyStatus.Poison;
            }
            else
            {
                bodyStatus = BodyStatus.Normal;
            }

            characterBodyStatus.UpdateStatus(bodyStatus, animator);
        }
    }


    void DeactiveBody()
    {
        SetActive(this.body, false);
        SetActive(this.healthBar, false);
        if (!isShowName)
        {
            SetActive(this.chatAnchor, false);
            SetActive(this.nameAnchor, false);
        }
        SetActive(this.protectionIcon, false);

        if (characterBehavior.isLocalPlayer == false)
        {
            characterBehavior.EnableCollider(false);
        }
    }

    void ActiveBody()
    {
        SetActive(this.body, true);
        SetActive(this.healthBar, true);
        SetActive(this.chatAnchor, true);
        SetActive(this.nameAnchor, true);

        //if (this.characterBehavior.GetProtectionTime() > 0)
        //    SetActive(this.protectionIcon, true);


        //if (this.characterBehavior.GetProtectionTime() == 0
        //    && this.characterBehavior.GetMapZoneType() != MapZoneType.SafeZone 
        //    && this.characterBehavior.GetMapZoneType() != MapZoneType.Village
        //    && this.characterBehavior.GetMapZoneType() != MapZoneType.RegisterZone 
        //    && this.characterBehavior.GetMapZoneType() != MapZoneType.Jail)
        //{
        //    this.characterBehavior.EnableCollider(true);
        //}


        var isInPvpZone = this.characterBehavior.IsStandingOnPVP();

        if (this.characterBehavior.GetProtectionTime() > 0 && this.characterBehavior.IsStandingOn(CombatZoneType.PVPWithProtection))
        {
            SetActive(this.protectionIcon, true);
        }

        //TODO-RECHECK:  characterBehavior.characterType == CharacterType.Npc recheck for all npcs
        if (isInPvpZone ||
            characterBehavior.characterType == CharacterType.Npc ||
            characterBehavior.characterType == CharacterType.Mob ||
            characterBehavior.characterType == CharacterType.Building ||
            characterBehavior.isLocalPlayer)
        {
            this.characterBehavior.EnableCollider(true);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (this.characterBehavior != null && this.characterBehavior.gameObject.activeSelf)
        {
            visibilityTimer += Time.deltaTime;
            if (!hasVisibilityState || visibilityTimer >= visibilityRefreshInterval)
            {
                visibilityTimer = 0;
                RefreshVisibilityState();
            }

            CharacterType characterType = this.characterBehavior.characterType;

            if (characterType == CharacterType.Mob ||
                characterType == CharacterType.Npc ||
                characterType == CharacterType.Building)
            {
                var characterPosition = this.characterBehavior.transform.position;
                if (!hasLastSyncedPosition || (this.transform.position - characterPosition).sqrMagnitude > 0.000001f)
                {
                    this.transform.position = characterPosition;
                    hasLastSyncedPosition = true;
                }

                if (this.characterBehavior.mobId == GameConst.MAIN_BUILDING_ID)
                {
                    if (syncRoyalty != null)
                    {
                        var royalty = syncRoyalty.royalty;
                        int maxRoyalty = BattleManager.instance != null ? BattleManager.instance.GetMaxRoyalty() : GameConst.MAX_ROYALTY;
                        var ratio = Mathf.Clamp(1f * royalty / maxRoyalty, 0, 1);
                        if (Mathf.Abs(ratio - lastRoyaltyRatio) > 0.0001f)
                        {
                            lastRoyaltyRatio = ratio;
                            Vector3 scale = royaltyBar.transform.localScale;
                            scale.x = ratio * maxScale;
                            royaltyBar.transform.localScale = scale;
                        }
                    }

                }

                if (characterType == CharacterType.Building)
                {
                    buildingProtectionRefreshTimer += Time.deltaTime;
                    if (buildingProtectionRefreshTimer >= buildingProtectionRefreshInterval)
                    {
                        buildingProtectionRefreshTimer = 0f;
                        UpdateBuildingProtectionDisplay();
                    }
                }
                else if (characterType == CharacterType.Mob)
                {
                    if (characterBehavior is MobBehavior mobBehavior)
                    {
                        if (mobBehavior.isSummonMob == false)
                        {   
                            SetActive(protectionIcon, false);
                        }
                    }
                }
            }
            else if (characterType == CharacterType.Player)
            {
                var isArenaWinner = characterBehavior.IsArenaWinner();
                if (arenaWinner != null && (!hasLastArenaWinner || lastArenaWinner != isArenaWinner))
                {
                    lastArenaWinner = isArenaWinner;
                    hasLastArenaWinner = true;
                    arenaWinner.SetActive(isArenaWinner);
                }

                PlayerBehavior playerBehavior = (PlayerBehavior)this.characterBehavior;
                UpdateClanNameColor(playerBehavior);

                if (playerBehavior.isLocalPlayer)
                {
                }
                else
                {
                    if ((this.transform.position - characterBehavior.transform.position).sqrMagnitude > 0.001f)
                        this.transform.position = characterBehavior.transform.position;
                }
            }

            bodyStatusRefreshTimer += Time.deltaTime;
            if (bodyStatusRefreshTimer >= bodyStatusRefreshInterval)
            {
                bodyStatusRefreshTimer = 0f;
                UpdateBodyStatus();
            }
        }
        else
        {
            SetActive(this.gameObject, false);
        }
    }

    private void UpdateBuildingProtectionDisplay()
    {
        float preparationTime = characterBehavior.GetPreparationTime();
#if ENABLE_CLIENT
        bool isAreaClashPreparation = TryGetAreaClashPreparationTime(
            out float areaClashPreparationTime, out bool isAreaClashActive);
        if (isAreaClashActive)
        {
            DeActiveProtectionIcon();
            lastProtectionVisible = false;
            lastProtectionIsPreparation = false;
            lastProtectionIsEvent = false;
            lastProtectionSecond = int.MinValue;
            lastProtectionText = string.Empty;
            return;
        }

        if (isAreaClashPreparation)
        {
            preparationTime = areaClashPreparationTime;
        }
#else
        bool isAreaClashPreparation = false;
#endif
        float protectionTimeValue = characterBehavior.GetProtectionTime();
        float eventProtectionTime = characterBehavior.GetVillageProtectionEventTime();
        bool isEventProtection = !isAreaClashPreparation && eventProtectionTime > 0;
        bool isPreparation = isAreaClashPreparation || (!isEventProtection && preparationTime > 0);
        float remainingTime = isEventProtection
            ? Mathf.Max(protectionTimeValue, eventProtectionTime)
            : isPreparation ? preparationTime : protectionTimeValue;
        bool isVisible = remainingTime > 0;
        int remainingSecond = Mathf.FloorToInt(remainingTime);

        SetActive(preparationIcon, false);
        SetActive(protectIcon, false);
        SetActive(eventProtectionIcon, false);

        if (isEventProtection && isVisible)
            SetActive(eventProtectionIcon, true);
        else if (isPreparation && isVisible)
            SetActive(preparationIcon, true);
        else if (isVisible)
            SetActive(protectIcon, true);

        if (isVisible == lastProtectionVisible &&
            isPreparation == lastProtectionIsPreparation &&
            isEventProtection == lastProtectionIsEvent &&
            remainingSecond == lastProtectionSecond)
        {
            return;
        }

        lastProtectionVisible = isVisible;
        lastProtectionIsPreparation = isPreparation;
        lastProtectionIsEvent = isEventProtection;
        lastProtectionSecond = remainingSecond;

        SetActive(protectionTimeLabel, isVisible);

        string text = isVisible && UIManager.instance != null
            ? UIManager.instance.GetTimeText(remainingTime)
            : string.Empty;

        if (protectionTime != null && text != lastProtectionText)
        {
            lastProtectionText = text;
            protectionTime.text = text;
        }
    }

#if ENABLE_CLIENT
    private bool TryGetAreaClashPreparationTime(out float remainingTime, out bool isEventActive)
    {
        remainingTime = 0f;
        isEventActive = false;

        if (characterBehavior == null || characterBehavior.characterType != CharacterType.Building ||
            string.IsNullOrEmpty(characterBehavior.userName) ||
            !characterBehavior.userName.StartsWith(AreaClashManager.PoolIdPrefix, System.StringComparison.Ordinal) ||
            EventManager.instance == null || BattleManager.instance == null)
        {
            return false;
        }

        var now = BattleManager.instance.ServerNow();
        var localEvents = EventManager.instance.GetLocalGameEvent();
        if (localEvents == null)
        {
            return false;
        }

        System.DateTime nextStart = System.DateTime.MaxValue;
        foreach (var gameEvent in localEvents)
        {
            if (gameEvent == null || gameEvent.eventId != GameEventId.AreaClash ||
                gameEvent.state == GameEventState.Completed || !gameEvent.haveTime ||
                !gameEvent.IsInActiveDay(now) || gameEvent.gameEventTimes == null)
            {
                continue;
            }

            foreach (var eventTime in gameEvent.gameEventTimes)
            {
                if (eventTime == null || eventTime.timeType != GameEventTimeType.Custom)
                {
                    continue;
                }

                if (eventTime.IsDayOfWeek(now) && eventTime.IsInActiveTime(now))
                {
                    isEventActive = true;
                    return false;
                }

                var candidate = eventTime.ServerStartTime(now);
                for (int dayOffset = 0; dayOffset <= 7 && candidate <= now; dayOffset++)
                {
                    candidate = candidate.AddDays(1);
                }

                for (int dayOffset = 0; dayOffset < 7 && !eventTime.IsDayOfWeek(candidate); dayOffset++)
                {
                    candidate = candidate.AddDays(1);
                }

                if (candidate > now && candidate < gameEvent.ServerEffectiveEndDay() && candidate < nextStart)
                {
                    nextStart = candidate;
                }
            }
        }

        if (nextStart == System.DateTime.MaxValue)
        {
            return false;
        }

        remainingTime = Mathf.Max(0f, (float)(nextStart - now).TotalSeconds);
        return remainingTime > 0f;
    }
#endif

    private void RefreshVisibilityState()
    {
        hasVisibilityState = true;

        // ✅ SERVER-ONLY: Add null check for MapManager
        if (MapManager.instance == null) return;

        isInView = MapManager.instance.IsInView(this.transform.position);

        if (isInView)
        {
            //if (UIManager.IsHidenBody && characterBehavior.GetMapZoneType() == MapZoneType.RegisterZone && !characterBehavior.isLocalPlayer
            //    && ClientManager.instance.myCharacter != null &&
            //    (ClientManager.instance.myCharacter.GetMapZoneType() == MapZoneType.RegisterZone ||
            //    ClientManager.instance.myCharacter.mapZoneType == MapZoneType.Arena))
            var myCharacter = ClientManager.instance.myCharacter;
            if (UIManager.IsHidenBody && characterBehavior.IsStandingOn(RuntimeAreaController.RuntimeAreaType.RegisterZone) &&
                !characterBehavior.isLocalPlayer && characterBehavior.IsType(CharacterType.Player) &&
                myCharacter != null && myCharacter.IsStandingOn(RuntimeAreaController.RuntimeAreaType.RegisterZone, RuntimeAreaController.RuntimeAreaType.Arena))
            {
                isShowBody = false;
                isShowName = true;
            }
            else
            {
                isShowBody = true;
                isShowName = true;
            }
        }
        else
        {
            isShowBody = false;
            isShowName = false;
        }

        if (isShowBody)
            ActiveBody();
        else
            DeactiveBody();
    }

    private void DeActiveProtectionIcon()
    {
        SetActive(preparationIcon, false);
        SetActive(protectIcon, false);
        SetActive(eventProtectionIcon, false);
        SetActive(protectionTimeLabel, false);
        SetText(protectionTime, string.Empty);
    }

    public virtual void SetName(bool dontFixName = false)
    {
        if (playerNameText == null)
        {
            return;
        }

        // Chỗ này check lastCharacterName nếu có rồi thì không set nữa
        // Ở case làng Viking nếu đã set name một lần rồi -> đổi ngôn ngữ -> sẽ không set lại
        bool useDescription = characterBehavior is SiegeUnitBehavior || characterBehavior is TrapBehavior;
        if (lastCharacterName == "" || useDescription)
        {
            if (dontFixName)
            {
                playerNameText.text = characterBehavior.characterName;
            }

            if (useDescription)
            {
                Card card = UIManager.instance != null ? UIManager.instance.GetCard(characterBehavior.mobId) : null;
                int languageId = UIManager.instance != null ? UIManager.instance.GetLanguageID() : 0;
                playerNameText.text = GetSiegeTrapDisplayName(card, languageId, characterBehavior.characterName);
            }
            else if (characterBehavior.characterType == CharacterType.Building || characterBehavior.characterType == CharacterType.Mob)
            {
                var card = UIManager.instance.GetCard(characterBehavior.mobId);
                if (card != null)
                {
                    OverrideNameByCard(card);
                }
                else
                {
                    playerNameText.text = UIManager.GetDialog(1193);
                }
            }
            else
            {
                playerNameText.text = characterBehavior.characterName;
            }

            lastCharacterName = playerNameText.text;
        }

        if (lastClanName == "")
        {
            ReloadClanName();
        }
    }

    internal static string GetSiegeTrapDisplayName(Card card, int languageId, string fallback)
    {
        if (card == null)
            return fallback;

        string description = card.GetDescription(languageId);
        return string.IsNullOrWhiteSpace(description) ? card.GetName(languageId) : description;
    }

    private void OverrideNameByCard(Card card)
    {
        switch (card.Id())
        {
            case GameConst.VIKING_ARCHER_TOWER:
            case GameConst.VIKING_MAIN_BUILDING:
            case GameConst.VIKING_MAIN_FURY:
            case GameConst.VIKING_MAIN_TITAN:
            case GameConst.VIKING_STORAGE_BUILDING:
                playerNameText.text = card.GetName(UIManager.instance.GetLanguageID());
                break;
            case 908:
                playerNameText.text = "B-Tiny";
                break;
            case GameConst.TEAM_BATTLE_MAIN_1:
                if (characterBehavior != null)
                {
                    if (characterBehavior.GetTeamId() == 1.ToString())
                    {
                        playerNameText.text = "Reven Blue";
                    }
                    else if (characterBehavior.GetTeamId() == 0.ToString())
                    {
                        playerNameText.text = "Reven Red";
                    }
                    else
                    {
                        playerNameText.text = "Reven";
                    }
                }
                else
                {
                    playerNameText.text = "Reven";
                }
                break;
            default:
                playerNameText.text = card.GetName(UIManager.instance.GetLanguageID());
                break;
        }
    }

    public void ReloadCharacterName()
    {
        if (characterBehavior is SiegeUnitBehavior || characterBehavior is TrapBehavior)
        {
            lastCharacterName = string.Empty;
            SetName();
            return;
        }
        playerNameText.text = characterBehavior.characterName;
        lastCharacterName = playerNameText.text;
    }

    public void ReloadClanName()
    {
        if (clanNameText != null)
        {
            if (characterBehavior == null)
            {
                clanNameText.text = string.Empty;
                lastClanName = string.Empty;
                return;
            }

            if (characterBehavior.clanId.IsNullOrEmpty() == false)
            {
                clanNameText.text = UIManager.instance.RemoveRegionId(characterBehavior.clanId);
                lastClanName = clanNameText.text;
            }
            else
            {
                clanNameText.text = string.Empty;
                lastClanName = string.Empty;
            }
        }
    }

    private void UpdateClanNameColor(PlayerBehavior playerBehavior)
    {
        if (playerBehavior.IsStandingOn(RuntimeZoneType.White))
        {
            clanNameText.color = new Color32(93, 82, 20, 255);
        }
        else
        {
            clanNameText.color = new Color32(255, 196, 33, 255);
        }
    }
}
