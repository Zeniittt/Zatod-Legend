﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterCopySprite : MonoBehaviour
{
    public SpriteRenderer target;
    SpriteRenderer mySprite;

    private void Awake()
    {
        mySprite = this.GetComponent<SpriteRenderer>();
    }

    public void Load()
    {
        if (mySprite == null || target == null)
        {
            //Debug.LogWarning("Character Copy Sprite Target Null");
            return;
        }

        mySprite.color = target.color;
        mySprite.sprite = target.sprite;
    }
}
