﻿using MCP.DataModels.BaseModels;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class PlayerBody : CharacterBody
{
    protected CharacterEquipments characterEquipments;
    protected PlayerBehavior playerBehavior;
    protected CharacterInventory characterInventory;
    protected CharacterIngredient characterIngredient;
    protected CharacterVisual characterVisual;

    //public CharacterBodySprites humanSprites;
    //public CharacterBodySprites horseSprites;
    public PetBehavior petBehavior;

    public TextMeshPro titleText;
    [Header("UI position")]
    public RectTransform playerNamePosDefault;
    public Transform healthPosDefault;

    public Transform middle;
    public Transform top;

    [HideInInspector]
    public CharacterBodySprites bodySprites;


    public float heightOfNormalMount;
    [SerializeField] private Vector3 chatWithHorse;
    [SerializeField] private Vector3 chatWithoutHorse;
    [SerializeField] private Vector3 offsetClanName;
    [SerializeField] private Vector3 offsetTitle;
    

    private void Start()
    {
        chatAnchor.localPosition = chatWithoutHorse;
    }

    public override void LoadData(CharacterBehavior character)
    {
        base.LoadData(character);
        characterEquipments = character.GetComponentInParent<CharacterEquipments>();
        characterInventory = character.GetComponentInParent<CharacterInventory>();
        playerBehavior = character.GetComponentInParent<PlayerBehavior>();
        characterIngredient = character.GetComponentInParent<CharacterIngredient>();
        characterVisual = character.GetComponent<CharacterVisual>();
    }

    public override void LoadBody(int cardId)
    {
        base.LoadBody(cardId);
        this.bodySprites = animator.gameObject.GetComponent<CharacterBodySprites>();
        this.OutlineAble = animator.gameObject.GetComponent<OutlineAble>();
        characterBodyStatus = animator.gameObject.GetComponent<CharacterBodyStatus>();
        this.bodySprites.ResetAllEquipmentSprite();
    }

    public void ReloadAnchorChatWithTitle()
    {
        EquipmentVisual title = characterVisual.GetEquipment(EquipmentType.SkinTitle);
        EquipmentVisual horse = characterVisual.GetEquipment(EquipmentType.Horse);
        bool haveClan = string.IsNullOrEmpty(playerBehavior.clanId) == false;

        if (horse != null)
        {
            chatAnchor.localPosition = Vector3.zero;
            var cardHorse = UIManager.instance.GetCard(horse.itemId);
            if (cardHorse != null)
            {
                if(cardHorse.heightOfMount > 0)
                {
                    chatAnchor.localPosition += new Vector3(0, cardHorse.heightOfMount - heightOfNormalMount, 0);
                }
            }

            if(haveClan)
            {
                if (title != null)
                {
                    titleText.text = BattleManager.GetCurrentTitle(title.itemId);
                    chatAnchor.localPosition += chatWithHorse + offsetClanName + offsetTitle;
                    titleText.rectTransform.position = top.position;
                }
                else
                {
                    titleText.text = string.Empty;
                    chatAnchor.localPosition += chatWithHorse + offsetClanName;
                }
            }
            else
            {
                if (title != null)
                {
                    titleText.text = BattleManager.GetCurrentTitle(title.itemId);
                    chatAnchor.localPosition += chatWithHorse + offsetTitle;
                    titleText.rectTransform.position = middle.position;
                }
                else
                {
                    titleText.text = string.Empty;
                    chatAnchor.localPosition += chatWithHorse;
                }
            }
        }
        else
        {
            if (haveClan)
            {
                if(title != null)
                {
                    titleText.text = BattleManager.GetCurrentTitle(title.itemId);
                    chatAnchor.localPosition = chatWithoutHorse + offsetClanName + offsetTitle;
                    titleText.rectTransform.position = top.position;
                }
                else
                {
                    titleText.text = string.Empty;
                    chatAnchor.localPosition = chatWithoutHorse + offsetClanName;
                }
            }
            else
            {
                if (title != null)
                {
                    titleText.text = BattleManager.GetCurrentTitle(title.itemId);
                    chatAnchor.localPosition = chatWithoutHorse + offsetTitle;
                    titleText.rectTransform.position = middle.position;
                }
                else
                {
                    titleText.text = string.Empty;
                    chatAnchor.localPosition = chatWithoutHorse;
                }
            }
        }
    }
}
