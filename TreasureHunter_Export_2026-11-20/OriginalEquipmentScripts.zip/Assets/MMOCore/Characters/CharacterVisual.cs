using System;
using System.Collections;
using System.Collections.Generic;
using MCP.DataModels.BaseModels;
using Mirror;
using PathologicalGames;
using UnityEngine;

public class CharacterVisual : NetworkBehaviour
{
    private enum VisualDeltaOp
    {
        AddOrSet,
        Remove,
    }

    private struct VisualDelta
    {
        public VisualDeltaOp Op;
        public EquipmentVisual Data;
    }

    PlayerBehavior playerBehavior;
    public SyncList<EquipmentVisual> equipmentVisuals = new SyncList<EquipmentVisual>();
    PlayerBody playerBody;
    [SyncVar(hook = nameof(OnHelmetValueChange))]
    [HideInInspector]
    public bool hideHelmet = false;
    [HideInInspector]
    public bool hideHelmetCache;
    [SyncVar(hook = nameof(OnFaceHairValueChange))]
    [HideInInspector]
    public bool hidenFaceHair = false;
    [HideInInspector]
    public bool hidenFaceHairCache;
    [SyncVar(hook = nameof(OnHairValueChange))]
    [HideInInspector]
    public bool hideHair = false;
    [HideInInspector]
    public bool hideHairCache;
    public List<EquipmentVisual> localEquipmentVisual = new();
    private readonly Dictionary<EquipmentType, VisualDelta> pendingVisualDeltas = new();
    private bool pendingClearVisuals = false;
    private Coroutine flushVisualCoroutine;

    [SyncVar]
    [HideInInspector]
    public bool isWatchingAd = false;
    [SyncVar]
    [HideInInspector]
    public bool isTired = false;


    public bool isInitialize = false;

    private void Awake()
    {
        playerBehavior = this.GetComponent<PlayerBehavior>();
#if ENABLE_CLIENT 
        equipmentVisuals.Callback += OnEquipmentChange;
#endif
    }

    private void Start()
    {

    }

    public override void OnStartClient()
    {
        isInitialize = false;
        if (isLocalPlayer)
            Initialize();
    }

    public void Initialize()
    {
        StartCoroutine(InitializeCoroutine());
    }

    IEnumerator InitializeCoroutine()
    {
#if ENABLE_CLIENT || UNITY_LOCAL_HOST
        while (!BattleManager.instance.isMapInitialized)
        {
            yield return null;
        }

        while (playerBehavior.characterBody == null || !playerBehavior.characterBody.gameObject.activeSelf)
        {
            yield return null;
        }

        if (playerBehavior.characterBody is PlayerBody castPlayerBody)
        {
            playerBody = castPlayerBody;
            playerBody.bodyId = -2;
        }

        localEquipmentVisual.Clear();
        if (playerBody != null)
        {
            playerBody.ReloadAnchorChatWithTitle();
        }

        if (playerBody != null)
        {
            if (GetMountCard() == -1)
            {
                playerBody.LoadBody(-1);
                isInitialize = true;
                playerBody.nameAnchor.localPosition = Vector3.zero;
            }
        }

        // Process initial SyncList payload
        for (int index = 0; index < equipmentVisuals.Count; index++)
            OnEquipmentChange(SyncList<EquipmentVisual>.Operation.OP_ADD, index, new EquipmentVisual(), equipmentVisuals[index]);
#endif
        yield return null;
    }

    void OnEquipmentChange(SyncList<EquipmentVisual>.Operation op, int index, EquipmentVisual oldItem, EquipmentVisual newItem)
    {
        switch (op)
        {
            case SyncList<EquipmentVisual>.Operation.OP_ADD:
                QueueVisualDelta(VisualDeltaOp.AddOrSet, newItem);
                break;
            case SyncList<EquipmentVisual>.Operation.OP_INSERT:
                QueueVisualDelta(VisualDeltaOp.AddOrSet, newItem);
                break;
            case SyncList<EquipmentVisual>.Operation.OP_REMOVEAT:
                QueueVisualDelta(VisualDeltaOp.Remove, oldItem);
                break;
            case SyncList<EquipmentVisual>.Operation.OP_SET:
                QueueVisualDelta(VisualDeltaOp.AddOrSet, newItem);
                break;
            case SyncList<EquipmentVisual>.Operation.OP_CLEAR:
                pendingClearVisuals = true;
                pendingVisualDeltas.Clear();
                EnsureFlushVisualDeltaRoutine();
                break;
        }
    }

    private void QueueVisualDelta(VisualDeltaOp op, EquipmentVisual data)
    {
        pendingVisualDeltas[data.equipmentType] = new VisualDelta
        {
            Op = op,
            Data = data,
        };

        EnsureFlushVisualDeltaRoutine();
    }

    private void EnsureFlushVisualDeltaRoutine()
    {
        if (flushVisualCoroutine == null)
        {
            flushVisualCoroutine = StartCoroutine(CoFlushVisualDelta());
        }
    }

    private IEnumerator CoFlushVisualDelta()
    {
        yield return new WaitForEndOfFrame();

        if (pendingClearVisuals)
        {
            localEquipmentVisual.Clear();
            pendingClearVisuals = false;
        }

        if (pendingVisualDeltas.Count > 0)
        {
            var deltas = new List<VisualDelta>(pendingVisualDeltas.Values);
            pendingVisualDeltas.Clear();

            for (int i = 0; i < deltas.Count; i++)
            {
                var delta = deltas[i];
                if (delta.Op == VisualDeltaOp.Remove)
                {
                    OnRemoveItemList(delta.Data);
                }
                else
                {
                    ApplyAddOrSetVisual(delta.Data);
                }
            }
        }

        flushVisualCoroutine = null;
    }
private void ApplyAddOrSetVisual(EquipmentVisual e)
    {
        if (TryGetLocalEquipmentByType(e.equipmentType, out var existing) && IsSameVisual(existing, e))
        {
            return;
        }

        if (existing != null)
        {
            OnSetItemList(e);
        }
        else
        {
            OnAddItemList(e);
        }

        RefreshPetCollectionAnimationIfNeeded(e.equipmentType);
    }

    private void RefreshPetCollectionAnimationIfNeeded(EquipmentType equipmentType)
    {
        if (equipmentType != EquipmentType.SkinRunPet && equipmentType != EquipmentType.SkinIdlePet)
        {
            return;
        }

        playerBody?.petBehavior?.RefreshPetCollectionAnimation();
    }

    private bool TryGetLocalEquipmentByType(EquipmentType type, out EquipmentVisual result)
    {
        for (int i = 0; i < localEquipmentVisual.Count; i++)
        {
            if (localEquipmentVisual[i].equipmentType == type)
            {
                result = localEquipmentVisual[i];
                return true;
            }
        }

        result = null;
        return false;
    }

    private static bool IsSameVisual(EquipmentVisual a, EquipmentVisual b)
    {
        if (a == null || b == null)
        {
            return false;
        }

        return a.equipmentType == b.equipmentType
            && a.itemId == b.itemId
            && a.rareType == b.rareType
            && a.level == b.level;
    }

    public void LoadEquipments()
    {
#if ENABLE_SERVER
        foreach (var e in playerBehavior.characterEquipments.equipments)
        {
            bool isAdd = true;
            for (int i = 0; i < equipmentVisuals.Count; i++)
            {
                if (e.Value.equipmentType == equipmentVisuals[i].equipmentType)
                {
                    if (e.Value.itemId != equipmentVisuals[i].itemId || e.Value.rareType != equipmentVisuals[i].rareType)
                    {
                        EquipmentVisual newEquipmentVisual = equipmentVisuals[i];
                        newEquipmentVisual.itemId = e.Value.itemId;
                        newEquipmentVisual.rareType = e.Value.rareType;
                        newEquipmentVisual.equipmentType = e.Value.equipmentType;

                        equipmentVisuals.RemoveAt(i);
                        equipmentVisuals.Insert(i, newEquipmentVisual);
                    }
                    isAdd = false;
                    break;
                }
            }

            if (isAdd)
            {
                EquipmentVisual equipmentVisual = CreateEquipmentVisual(e.Value);
                this.equipmentVisuals.Add(equipmentVisual);
            }
        }

        List<int> removes = new List<int>();
        int index = 0;
        foreach (EquipmentVisual equipmentVisual in equipmentVisuals)
        {
            bool isRemove = true;
            foreach (var e in playerBehavior.characterEquipments.equipments)
            {
                if (e.Value.equipmentType == equipmentVisual.equipmentType && e.Value.itemId == equipmentVisual.itemId &&
                    e.Value.rareType == equipmentVisual.rareType)
                {
                    isRemove = false;
                    break;
                }
            }

            if (isRemove)
            {
                removes.Add(index);
            }

            index++;
        }

        if (removes.Count > 0)
        {
            for (int i = removes.Count - 1; i >= 0; i--)
            {
                equipmentVisuals.RemoveAt(removes[i]);
            }
        }
#endif

    }
private EquipmentVisual CreateEquipmentVisual(Equipment e)
    {
        EquipmentVisual equipmentVisual = null;
#if ENABLE_SERVER
        equipmentVisual = new()
        {
            itemId = e.itemId,
            rareType = e.rareType,
            equipmentType = e.equipmentType
        };
#endif
        return equipmentVisual;
    }

    protected void Update()
    {
        if (isClient)
        {
            if (!isInitialize)
                return;

            if (Time.frameCount % 10 == 3)
            {
                if (hideHelmetCache != hideHelmet)
                {
                    OnHelmetValueChange(hideHelmetCache, hideHelmet);
                }
                if (hidenFaceHairCache != hidenFaceHair)
                {
                    OnFaceHairValueChange(hidenFaceHairCache, hidenFaceHair);
                }
                if (hideHairCache != hideHair)
                {
                    OnHairValueChange(hideHairCache, hideHair);
                }
            }
        }

    }

    [Client]
    protected void OnAddItemList(EquipmentVisual e)
    {
        if (UIManager.instance == null)
            return;

        for (int i = 0; i < localEquipmentVisual.Count; i++)
        {
            if (localEquipmentVisual[i].equipmentType == e.equipmentType)
            {
                localEquipmentVisual[i] = e;
                break;
            }
        }
        if (TryGetLocalEquipmentByType(e.equipmentType, out var existed) == false)
        {
            localEquipmentVisual.Add(e);
        }

        if (e.equipmentType == EquipmentType.SkinHorse)
        {
            ReloadEquipmentVisuals();
        }
        else if (e.equipmentType == EquipmentType.Horse)
        {
            ChangeBodySprites(e.itemId);
        }
        else if (e.equipmentType == EquipmentType.Key || e.equipmentType == EquipmentType.Scroll || e.equipmentType == EquipmentType.Summon)
        {
            if (isLocalPlayer)
                SoundManager.instance.SpawnSound("FoundItem", 0, 1);
        }
        else if (e.equipmentType == EquipmentType.SkinTitle)
        {
            if (playerBody != null)
            {
                playerBody.ReloadAnchorChatWithTitle();
            }
        }
        else
            LoadEquipment(e);
    }

    [Client]
    protected void OnRemoveItemList(EquipmentVisual e)
    {
        if (UIManager.instance != null)
        {
            for (int i = 0; i < localEquipmentVisual.Count; i++)
            {
                if (localEquipmentVisual[i].equipmentType == e.equipmentType)
                {
                    localEquipmentVisual.RemoveAt(i);
                    break;
                }
            }

            if (e.equipmentType == EquipmentType.Pet)
            {
                UnloadPet();
            }
            else if (e.equipmentType == EquipmentType.SkinHorse)
            {
                ReloadEquipmentVisuals();
            }
            else if (e.equipmentType == EquipmentType.Horse)
            {
                ChangeBodySprites(-1);
            }
            else if (e.equipmentType == EquipmentType.SkinTitle)
            {
                if (playerBody)
                {
                    playerBody.ReloadAnchorChatWithTitle();
                }
            }
            else
            {
                if (playerBody != null && playerBody.bodySprites != null)
                    playerBody.bodySprites.ResetEquipmentSprite(e);
            }

            RefreshPetCollectionAnimationIfNeeded(e.equipmentType);

            if (isLocalPlayer)
            {
#if ENABLE_CLIENT
                UIManager.instance.FindView<MyCharacterInfoView>().OnVisualEquipmentChange(e);
#endif
            }
        }
    }

    [Client]
    private void ChangeBodySprites(int cardId, bool forceReloadEquipment = false)
    {
        StartCoroutine(ChangeBodySpriteCoroutine(cardId, forceReloadEquipment));
    }

    IEnumerator ChangeBodySpriteCoroutine(int cardId, bool forceReloadEquipment)
    {
        while (playerBody == null)
        {
            yield return new WaitForEndOfFrame();
        }

        bool reloadEquipment = false;
        if (cardId != playerBody.bodyId) reloadEquipment = true;

        if (reloadEquipment == false && forceReloadEquipment == false)
            yield break;

        if (reloadEquipment && playerBody)
        {
            playerBody.LoadBody(cardId);
        }

        isInitialize = true;

        if (reloadEquipment && cardId > 0)
        {
            var card = UIManager.instance.GetCard(cardId);
            if(card.heightOfMount == 0) // Ngựa default không cao đột biến
            {
                playerBody.nameAnchor.localPosition = new Vector3(0, playerBody.heightOfNormalMount, 0);
            }
            else
            {
                playerBody.nameAnchor.localPosition = new Vector3(0, card.heightOfMount, 0);
            }
        }
        else if (reloadEquipment)
        {
            playerBody.nameAnchor.localPosition = Vector3.zero;
        }

        if (reloadEquipment && playerBody)
        {
            playerBody.ReloadAnchorChatWithTitle();
        }

        ReloadEquipmentVisuals();
    }

    private void ReloadEquipmentVisuals()
    {
        if (playerBody == null) return;
        if (playerBody.bodySprites == null) return;
        var isSkinHorseValid = IsSkinHorseValid();

        foreach (var e in equipmentVisuals)
        {
            if (e.equipmentType == EquipmentType.SkinHorse && isSkinHorseValid == false
                || e.equipmentType == EquipmentType.Horse && isSkinHorseValid == true)
            {
                continue;
            }

            LoadEquipment(e);
        }
    }
    public bool IsSkinHorseValid()
    {
        var eSkinHorse = GetEquipment(EquipmentType.SkinHorse);
        var equippedHorse = GetEquipment(EquipmentType.Horse);

        bool skinHorseValid = false;

        if (eSkinHorse != null && equippedHorse != null)
        {
            var card = UIManager.instance.GetCard(eSkinHorse.itemId);
            if (card != null &&
                card.craftOutputIds != null &&
                card.craftOutputIds.Length > 0 &&
                card.craftOutputIds[0] == equippedHorse.itemId &&
                eSkinHorse.rareType == equippedHorse.rareType)
            {
                skinHorseValid = true;
            }
        }

        return skinHorseValid;
    }

    [Client]
    protected void OnSetItemList(EquipmentVisual e)
    {
        if (UIManager.instance != null)
        {
            if (TryGetLocalEquipmentByType(e.equipmentType, out var existing) && IsSameVisual(existing, e))
            {
                return;
            }

            int index = -1;
            for (int i = 0; i < localEquipmentVisual.Count; i++)
            {
                if (localEquipmentVisual[i].equipmentType == e.equipmentType)
                {
                    index = i; break;
                }
            }
            if (index > -1)
            {
                localEquipmentVisual[index] = e;
            }

            if (e.equipmentType == EquipmentType.SkinTitle)
            {
                if (playerBody)
                    playerBody.ReloadAnchorChatWithTitle();
                return;
            }

            Card card = UIManager.instance.GetCard(e.itemId);
            if (card == null)
                return;

            if (e.equipmentType == EquipmentType.SkinHorse)
            {
                ReloadEquipmentVisuals();
            }
            else if (card.equipmentType == EquipmentType.Horse)
            {
                ChangeBodySprites(e.itemId, true);
            }
            else
                LoadEquipment(e);
        }
    }

    [Client]
    protected virtual void OnClearItemList(EquipmentVisual e)
    {

    }

    //Load Equipment to character
    [Client]
    public void LoadEquipment(EquipmentVisual e)
    {
        if (playerBody == null)
            return;

        if (!isInitialize)
            return;

        if (UIManager.instance != null)
        {
            Card card = UIManager.instance.GetCard(e.itemId);
            if (card == null)
                return;
            LogicLoadEquipment(e, card);
        }

    }

    private void LogicLoadEquipment(EquipmentVisual e, Card card)
    {
        if (e.equipmentType == EquipmentType.Item ||
            e.equipmentType == EquipmentType.Key ||
            e.equipmentType == EquipmentType.Artifact)
        {
            //Nothing
        }
        else if ((card.IsCollection() && card.equipmentType != EquipmentType.SkinHorse) || e.equipmentType == EquipmentType.SkinTitle)
        {

        }
        else if (e.equipmentType == EquipmentType.Pet)
        {
            if (playerBody.petBehavior != null)
            {
                if (playerBody.petBehavior.id != e.itemId)
                {
                    LoadPet(e, true);
                }
                else
                {
                    playerBody.petBehavior.LoadData(playerBehavior, e);
                }
            }
            else
            {
                LoadPet(e, false);
            }
        }
        else
        {
            if (playerBehavior.characterType == CharacterType.Player
                && playerBody != null
                && playerBody.bodySprites != null)
            {
                var baseHorse = (e.equipmentType == EquipmentType.SkinHorse)
                           ? GetEquipment(EquipmentType.Horse)
                           : null;
                if (baseHorse != null)
                {   
                    playerBody.bodySprites.LoadSkinHorse(e, baseHorse.rareType);
                }
                else
                {
                    playerBody.bodySprites.LoadEquipment(e, hideHelmet, hidenFaceHair, hideHair);

                    if (isLocalPlayer)
                    {
#if ENABLE_CLIENT
                        UIManager.instance.FindView<MyCharacterInfoView>().
                            OnVisualEquipmentChange(e);
#endif
                    }
                }
            }
        }
    }

    [Client]
    void LoadPet(EquipmentVisual e, bool unload)
    {
        if (unload)
            UnloadPet();

        // ✅ SERVER-ONLY: Add null check for UIManager
        if (UIManager.instance == null) return;

        Card card = UIManager.instance.GetCard(e.itemId);
        if (card == null)
            return;
        Transform t = PoolManager.Pools["Pets"].Spawn(card.GetName(0));
        t.localPosition = Vector3.zero;
        MCP.Unity.UnityUtils.SetActive(t.gameObject, true);
        t.localScale = Vector3.one;
        t.name = card.GetName(0);
        playerBody.petBehavior = t.GetComponent<PetBehavior>();
        playerBody.petBehavior.LoadData(this.playerBehavior, e);
        t.transform.position = this.transform.position + new Vector3(UnityEngine.Random.Range(-2, 2), UnityEngine.Random.Range(-2, 2), 0);
    }

    [Client]
    void UnloadPet()
    {
        if (playerBody != null && playerBody.petBehavior != null)
        {
            var petBehavior = playerBody.petBehavior;
            playerBody.petBehavior = null;

            if (petBehavior.gameObject.activeSelf)
            {
                PoolManager.Pools["Pets"].Despawn(petBehavior.transform);
            }
        }

    }

    [Client]
    private void OnFaceHairValueChange(bool oldValue, bool newValue)
    {
        hidenFaceHairCache = newValue;

        if (isLocalPlayer)
        {
            string username = ClientManager.instance.myUsername;
            string key = username + "FaceHair";
            if (newValue == true)
            {
                LocalPrefs.Save(key, 1);
            }
            else
            {
                LocalPrefs.Save(key, 0);
            }
        }

        var currentFacehair = GetEquipment(EquipmentType.FaceHair);
        if (currentFacehair != null)
        {
            LoadEquipment(currentFacehair);
        }
    }



    [Client]
    private void OnHelmetValueChange(bool oldValue, bool newValue)
    {
        hideHelmetCache = newValue;

        if (isLocalPlayer)
        {
            string username = ClientManager.instance.myUsername;
            string key = username + "Helmet";

            if (newValue == true)
            {
                LocalPrefs.Save(key, 1);
            }
            else
            {
                LocalPrefs.Save(key, 0);
            }
        }

        var currentHelmet = GetEquipment(EquipmentType.Helmet);
        if (currentHelmet != null)
        {
            LoadEquipment(currentHelmet);
        }
    }

    [Client]
    private void OnHairValueChange(bool oldValue, bool newValue)
    {
        hideHairCache = newValue;

        if (isLocalPlayer)
        {
            LocalPrefs.Save(ClientManager.instance.myUsername + EquipmentType.Hair, newValue ? 1 : 0);
        }

        var currentHair = GetEquipment(EquipmentType.Hair);
        if (currentHair != null)
        {
            LoadEquipment(currentHair);
        }
    }

    public bool IsEquipmentHidden(EquipmentType equipmentType)
    {
        switch (equipmentType)
        {
            case EquipmentType.Hair: return hideHair;
            case EquipmentType.FaceHair: return hidenFaceHair;
            case EquipmentType.Helmet: return hideHelmet;
            default: return false;
        }
    }

    public virtual EquipmentVisual GetEquipment(EquipmentType equipmentType)
    {
        foreach (var e in equipmentVisuals)
        {
            if (e.equipmentType == equipmentType)
                return e;
        }

        return null;
    }

    public virtual List<EquipmentVisual> GetEquipments()
    {
        return localEquipmentVisual;
    }

    public void Reset()
    {
        localEquipmentVisual.Clear();
        equipmentVisuals.Clear();
    }

    int GetMountCard()
    {
        foreach (var entry in equipmentVisuals)
        {
            if (entry.equipmentType == EquipmentType.Horse)
            {
                return entry.itemId;
            }
        }

        return -1;
    }
}

[System.Serializable]
public class EquipmentVisual
{
    public int itemId;
    public RareType rareType = RareType.Common;
    public EquipmentType equipmentType;

    //Temp
    public byte level;

    public EquipmentVisual()
    {

    }

    public EquipmentVisual(Equipment e)
    {
        this.itemId = e.itemId;
        this.rareType = e.rareType;
        this.equipmentType = e.equipmentType;
        this.level = (byte)e.level;
    }

    public bool IsSkin()
    {
        return equipmentType == EquipmentType.Body || equipmentType == EquipmentType.Eye 
            || equipmentType == EquipmentType.Hair || equipmentType == EquipmentType.FaceHair;
    }
}

