﻿using UnityEngine;

public class CharacterBodyStatus : MonoBehaviour
{
    public enum BodyStatus
    {
        Normal, Poison, Fire, Freeze, Wind
    }

    [SerializeField] SpriteRenderer[] spriteRenderer;
    [SerializeField] GameObject target;
    [SerializeField] Material material;
    [SerializeField] BodyStatus status = BodyStatus.Normal;
    private int colorRampBlendId;
    private int colorRampLuminosityId;
    private Material materialInstance;

    [SerializeField] Texture overlayFreezeTexture;
    [SerializeField] Texture overlayPoisonTexture;
    [SerializeField] Texture overlayFireTexture;
    [SerializeField] Texture overlayWindTexture;

    private void Awake()
    {
        if (material != null)
        {
            SetUpMaterial();
        }

        if (overlayWindTexture == null)
        {
            overlayWindTexture = Resources.Load<Texture>("palette-wind");
        }

        if (overlayFreezeTexture == null)
        {
            overlayFreezeTexture = Resources.Load<Texture>("palleteIce");
        }

        if(overlayPoisonTexture == null)
        {
            overlayPoisonTexture = Resources.Load<Texture>("palette-gameboy");
        }

        if(overlayFireTexture == null)
        {
            overlayFireTexture = Resources.Load<Texture>("palleteFire");
        }
    }

    private void SetUpMaterial()
    {
        colorRampBlendId = Shader.PropertyToID("_ColorRampBlend");
        colorRampLuminosityId = Shader.PropertyToID("_ColorRampLuminosity");
        materialInstance = new Material(material);

        for (int i = 0, length = spriteRenderer.Length; i < length; i++)
        {
            if (spriteRenderer[i] != null)
            {
                spriteRenderer[i].material = materialInstance;
            }
        }
    }

    public void UpdateStatus(BodyStatus status, Animator animator)
    {
        if (material == null || animator == null)
        {
            return;
        }

        if (this.status == status)
        {
            return;
        }

        this.status = status;
        switch (this.status)
        {
            
            case BodyStatus.Normal:
                DisplayNormalStatus(animator);
                break;
            case BodyStatus.Wind:
                DisplayWindStatus(animator);
                break;
            case BodyStatus.Poison:
                DisplayPoisonStatus(animator);
                break;
            case BodyStatus.Freeze:
                DisplayFreezeStatus(animator);
                break;
            case BodyStatus.Fire: 
                DisplayFireStatus(animator);
                break;
            default:
#if UNITY_EDITOR
                Debug.Log("BodyStatus invalid " + this.status);
#endif
                DisplayNormalStatus(animator);
                break;
        }
    }

    private void DisplayNormalStatus(Animator animator)
    {   
        materialInstance.SetFloat(colorRampBlendId, 0f);
        materialInstance.SetFloat(colorRampLuminosityId, 1f);
        animator.speed = 1f;
    }
    private void DisplayWindStatus(Animator animator)
    {
        materialInstance.SetFloat(colorRampBlendId, 1);
        materialInstance.SetFloat(colorRampLuminosityId, 0.1f);
        animator.speed = 1f;
        materialInstance.SetTexture("_ColorRampTex", overlayWindTexture);
    }
    private void DisplayPoisonStatus(Animator animator)
    {
        materialInstance.SetFloat(colorRampBlendId,1);
        materialInstance.SetFloat(colorRampLuminosityId, 0.1f);
        animator.speed = 1f;
        materialInstance.SetTexture("_ColorRampTex", overlayPoisonTexture);
    }

    private void DisplayFireStatus(Animator animator)
    {
        materialInstance.SetFloat(colorRampBlendId, 1);
        materialInstance.SetFloat(colorRampLuminosityId, 0.5f);
        animator.speed = 1f;
        materialInstance.SetTexture("_ColorRampTex", overlayFireTexture);
    }

    private void DisplayFreezeStatus(Animator animator)
    {
        materialInstance.SetFloat(colorRampBlendId,1f);
        materialInstance.SetFloat(colorRampLuminosityId, 0.1f);
        animator.speed = 0.5f;
        materialInstance.SetTexture("_ColorRampTex", overlayFreezeTexture);
    }

    [ContextMenu(nameof(SetUp))]
    public void SetUp()
    {
#if ENABLE_CLIENT || UNITY_EDITOR

            spriteRenderer = target.GetComponentsInChildren<SpriteRenderer>(true);
#endif
    }
}
