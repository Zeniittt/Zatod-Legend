﻿using System;
using System.Collections;
using System.Collections.Generic;
using MCP.DataModels.BaseModels;
using MCP.Manager;
using Mirror;
using PathologicalGames;
using UnityEngine;

public class CharacterEquipments : CharacterItems
{
    public List<string> collectionsIds = new();
    public List<Equipment> collectionsValid = new();
    public List<Equipment> collectionsValidPet = new();
    public List<Equipment> collectionsValidEmote = new();
    public Equipment skinHorseValid;
    protected override void Awake()
    {
        base.Awake();
        characterBehavior = this.GetComponent<CharacterBehavior>();
    }

    public override void OnStartClient()
    {
        base.OnStartClient();
    }

    public override void LoadEquipmentFromData(Equipment equipment)
    {
        base.LoadEquipmentFromData(equipment);
        CheckCollection(equipment);
    }

    public override void AddEquipment(Equipment equipment)
    {
        base.AddEquipment(equipment);
        CheckCollection(equipment);
    }

    public override void ResetEquipment(Equipment equipment)
    {
        base.ResetEquipment(equipment);
        CheckCollection(equipment);
    }

    public override bool RemoveEquipment(string id)
    {
        var equipment = GetEquipment(id);
        bool result = base.RemoveEquipment(id);
        CheckCollectionOnRemove(equipment);

        return result;
    }

    #region Collection

    private void CheckCollection(Equipment equipment)
    {
        if (equipments.ContainsKey(equipment.id) == false)
        {
            return;
        }

        bool isNotInCollection = collectionsIds.Contains(equipment.id) == false;
        if (equipment.IsCollection() && isNotInCollection && equipment.equipmentType != EquipmentType.Avatar)
        {
            collectionsIds.Add(equipment.id);
            OnCollectionChange();
        }
        else if (equipment.equipmentType == EquipmentType.Horse)
        {
            OnCollectionHorseChange();
            OnSkinHorseChange();
        }
        else if (equipment.equipmentType == EquipmentType.Pet)
        {
            OnCollectionPetChange();
        }
    }

    private void CheckCollectionOnRemove(Equipment equipment)
    {
        if (equipment == null)
        {
            return;
        }

        if (collectionsIds.Contains(equipment.id))
        {
            collectionsIds.Remove(equipment.id);
            OnCollectionChange();
        }
        else if (equipment.equipmentType == EquipmentType.Horse)
        {
            OnCollectionHorseChange();
            OnSkinHorseChange();
        }
        else if (equipment.equipmentType == EquipmentType.Pet)
        {
            OnCollectionPetChange();
        }
    }

    private void OnCollectionChange()
    {
        OnSkinHorseChange();
        OnCollectionHorseChange();
        OnCollectionPetChange();
        OnCollectionEmoteChange();
    }
    private void OnCollectionEmoteChange()
    {
        collectionsValidEmote.Clear();

        var equippedEmotes = GetEquipments(EquipmentType.Emote);
        if (equippedEmotes == null || equippedEmotes.Count == 0) return;

        Dictionary<int, Equipment> equippedEmotesDict = new Dictionary<int, Equipment>();
        foreach (var emote in equippedEmotes)
        {
            if (!equippedEmotesDict.ContainsKey(emote.itemId))
            {
                equippedEmotesDict.Add(emote.itemId, emote);
            }
        }

        List<Equipment> highestAmountSet = new List<Equipment>();

        foreach (var emote in equippedEmotesDict)
        {
            int currentId = emote.Key;
            Equipment currentEquip = emote.Value;

            var card = DataHolder.Instance().GetData<Card>(currentId);
            if (card == null || card.craftOutputIds == null) continue;

            List<Equipment> potentialSet = new List<Equipment>();
            potentialSet.Add(currentEquip);

            for (int i = 0; i < card.craftOutputIds.Length; i++)
            {
                int relativeEmoteId = card.craftOutputIds[i];

                if (equippedEmotesDict.TryGetValue(relativeEmoteId, out Equipment relativeEmote))
                {
                    potentialSet.Add(relativeEmote);
                }
            }

            if (potentialSet.Count > highestAmountSet.Count)
            {
                highestAmountSet = potentialSet;
                if (highestAmountSet.Count == equippedEmotes.Count)
                {
                    break;
                }
            }
        }

        if (highestAmountSet.Count > 0)
        {
            collectionsValidEmote.AddRange(highestAmountSet);
        }
    }
    private void OnCollectionPetChange()
    {
        collectionsValidPet.Clear();

        bool havePet = false;
        int petId = -1;
        var pet = GetEquipment(EquipmentType.Pet);
        if (pet != null)
        {
            havePet = true;
            petId = pet.itemId;
        }

        foreach (var item in collectionsIds)
        {
            var equipment = GetEquipment(item);
            if (equipment == null)
            {
                continue;
            }

            var card = DataHolder.Instance().GetData<Card>(equipment.itemId);
            if (card == null)
            {
                continue;
            }
            bool collectionSupportPet = false;
            if (havePet && card.craftOutputIds.Length > 0)
            {
                for (int i = 0; i < card.craftOutputIds.Length; i++)
                {
                    collectionSupportPet = havePet && card.craftOutputIds[i] == petId && card.IsCollectionPet();
                    if (collectionSupportPet)
                    {
                        break;
                    }
                }
            }

            if (collectionSupportPet)
            {
                collectionsValidPet.Add(equipment);
            }
        }
    }
    private void OnSkinHorseChange()
    {
        skinHorseValid = null;
        bool haveHorse = false;
        int horseId = -1;
        var horse = GetEquipment(EquipmentType.Horse);
        if (horse != null)
        {
            haveHorse = true;
            horseId = horse.itemId;
        }
        foreach (var item in collectionsIds)
        {
            var equipment = GetEquipment(item);
            if (equipment == null)
            {
                continue;
            }

            var card = DataHolder.Instance().GetData<Card>(equipment.itemId);
            if (card == null)
            {
                continue;
            }
            bool skinSupportHorse = false;
            if (haveHorse && card.craftOutputIds.Length > 0)
            {
                skinSupportHorse = haveHorse
                    && card.craftOutputIds[0] == horseId
                    && card.equipmentType == EquipmentType.SkinHorse
                    && equipment.rareType == horse.rareType;
            }
            if (skinSupportHorse)
            {
                skinHorseValid = equipment;
                break;
            }
        }
       
    }
    private void OnCollectionHorseChange()
    {
        collectionsValid.Clear();

        bool haveHorse = false;
        int horseId = -1;
        var horse = GetEquipment(EquipmentType.Horse);
        if (horse != null)
        {
            haveHorse = true;
            horseId = horse.itemId;
        }

        foreach (var item in collectionsIds)
        {
            var equipment = GetEquipment(item);
            if (equipment == null)
            {
                continue;
            }

            var card = DataHolder.Instance().GetData<Card>(equipment.itemId);
            if (card == null)
            {
                continue;
            }
            bool collectionSupportHorse = false;
            if (haveHorse && card.craftOutputIds.Length > 0)
            {
                for (int i = 0; i < card.craftOutputIds.Length; i++)
                {
                    collectionSupportHorse = haveHorse && card.craftOutputIds[i] == horseId && card.IsCollectionHorse();
                    if (collectionSupportHorse)
                    {
                        break;
                    }
                }
            }

            bool collectionSupportWalk = haveHorse == false && card.craftOutputIds.Length > 0 && card.craftOutputIds[0] == GameConst.BODY_DEFAULT_ID;

            if (collectionSupportHorse)
            {
                collectionsValid.Add(equipment);
            }
            else if (collectionSupportWalk)
            {
                collectionsValid.Add(equipment);
            }
        }
    }

    #endregion

    [Client]
    private void ReloadInventorySlotUI()
    {
        if (!isLocalPlayer || UIManager.instance == null)
            return;

        if (characterBehavior is PlayerBehavior player)
        {
            player.RequestInventorySlotReload();
        }
    }

    [Client]
    protected override void OnAddItemList(Equipment e)
    {
        base.OnAddItemList(e);
        if (isLocalPlayer == false)
            return;

        //Check before Update Stats
        CheckCollection(e);
        characterBehavior.OnUpdateStats();
        ReloadInventorySlotUI();

        var myChar = ClientManager.instance.myCharacter;
        var ui = UIManager.instance;

        if (ui == null)
            return;

        var characterView = ui.FindView<CharacterView>();
        characterView.LoadData(GetEquipments());
        characterView.Tween(e);
        ui.FindView<InventoryView>().Reload();

        if (BattleManager.IsCharacterSkin(e) || e.equipmentType == EquipmentType.Avatar)
        {
            ui.FindView<HUDView>().avatarUI.LoadData(GetEquipments());
        }
        else if (e.equipmentType == EquipmentType.Artifact)
        {
            ui.FindView<HUDView>().SetArtifactChange();
        }

        ui.FindView<CraftView>().TryReload(e);

        var ingredientView = ui.FindView<IngredientView>();
        if (ingredientView.IsOpen)
        {
            ingredientView.Load(myChar);
        }

        ui.FindView<CollectionView>().OnEquipmentChange(e);

#if ENABLE_CLIENT
        ui.FindView<MyCharacterInfoView>().ReloadAll(e);
#endif
    }

    [Client]
    protected override void OnRemoveItemList(Equipment e)
    {
        if (isLocalPlayer)
        {   
            //Check before Update Stats
            CheckCollectionOnRemove(e);
            base.OnRemoveItemList(e);
            characterBehavior.OnUpdateStats();
            ReloadInventorySlotUI();

            var myChar = ClientManager.instance.myCharacter;
            var ui = UIManager.instance;

            if (ui == null)
                return;

            var characterView = ui.FindView<CharacterView>();
            characterView.LoadData(GetEquipments());

            ui.FindView<InventoryView>().Reload();
            if (BattleManager.IsCharacterSkin(e) || e.equipmentType == EquipmentType.Avatar)
            {
                ui.FindView<HUDView>().avatarUI.LoadData(GetEquipments());
            }
            else if (e.equipmentType == EquipmentType.Artifact)
            {
                ui.FindView<HUDView>().SetArtifactChange();
            }

            ui.FindView<ItemView>().ReloadIfViewing(e);

            ui.FindView<CraftView>().OnRemoveEquipment(e);

            var ingredientView = ui.FindView<IngredientView>();
            if (ingredientView.IsOpen)
            {
                ingredientView.Load(myChar);
            }

            ui.FindView<CollectionView>().OnEquipmentChange(e);

#if ENABLE_CLIENT
            ui.FindView<MyCharacterInfoView>().ReloadAll(e);
#endif
        }
    }



    [Client]
    protected override void OnSetItemList(Equipment e)
    {
        if (characterBehavior.mobId == GameConst.STORAGE_BUILDING_ID)
        {
            if (characterBehavior.clanId == ClientManager.instance.myCharacter.clanId)
            {
                var buildingView = UIManager.instance.FindView<BuildingView>();
                if (buildingView.IsOpen && characterBehavior is PlayerBehavior buildingBehavior)
                {
                    if (buildingView.TargetBuilding.userName == buildingBehavior.userName)
                    {
                        buildingView.OnOtherStorageChange(buildingBehavior);
                    }
                }
            }
            return;
        }

        if (isLocalPlayer)
        {
            //Check before Update Stats
            CheckCollection(e);
            characterBehavior.OnUpdateStats();
            ReloadInventorySlotUI();
            var ui = UIManager.instance;

            if (ui == null)
                return;

            ui.FindView<CharacterView>().CheckEquipemtExist(e);

            if (e.equipmentType == EquipmentType.Artifact)
            {
                ui.FindView<HUDView>().SetArtifactChange();
            }
            ui.FindView<ItemView>().ReloadIfViewing(e);

            ui.FindView<CraftView>().OnSetEquipment(e);
#if ENABLE_CLIENT
            ui.FindView<MyCharacterInfoView>().ReloadAll(e);
#endif
            ui.FindView<CollectionView>().OnEquipmentChange(e);
        }
        else if (this.characterBehavior.characterType == CharacterType.Building
            && ClientManager.instance.myCharacter.clanId != ""
            && this.characterBehavior.clanId == ClientManager.instance.myCharacter.clanId)
        {
            if (UIManager.instance != null)
            {
                var buildingView = UIManager.instance.FindView<BuildingView>();
                if (buildingView.IsOpen)
                {
                    buildingView.Reload();
                }
            }

        }

    }

    [Client]
    public Equipment GetEquipmentUpgradeAble()
    {
        foreach (KeyValuePair<string, Equipment> keyValue in equipments)
        {
            var e = keyValue.Value;
            var currencyData = e.GetUpgradeCost(e.level);

            if (currencyData != null && ClientManager.instance.myCharacter.HaveEnoughMoney(currencyData))
            {
                return keyValue.Value;
            }
        }

        return null;
    }
}






