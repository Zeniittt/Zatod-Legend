using MCP.Ability;
using MCP.DataModel.Utils;
using MCP.DataModels.BaseModels;
using MCP.Unity;
using Mirror;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PathologicalGames;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using static RuntimeAreaController;
using static MCP.Unity.UnityUtils;
using static GameConst;

public partial class CharacterBehavior : NetworkBehaviour
{
    private readonly Collider2D[] normalAttackAoeBuffer = new Collider2D[64];
    #region Event Struct

    public struct OnSendStatCharacter
    {
        public StatType typeStat;
        public Vector2 position;
        public bool isEnemy;
        public int value;
    }
    public struct OnSendMapPosition
    {
        public Vector3 position;
    }

    public struct OnSendStatSkill
    {
        public Vector2 skillAppearPostion;
        public Equipment artifact;
        public bool isLocalPlayer;
        public PlayerBehavior playerBehavior;
    }

    public struct OnSkinSetChanged
    {
        public int setIndex;
        public EquipmentType skinType;
    }

    public struct OnSkinSetSwitched
    {
        public int newSetIndex;
    }
    #endregion
    [SyncVar]
    public string userName = "";
    [SyncVar(hook = nameof(HookCharacterName))]
    public string characterName;

    [HideInInspector] public int killBossNumber;
    [SyncVar, SerializeField]
    private string teamId = "";
    [SyncVar(hook = nameof(HookClanId))]
    public string clanId = "";
    [HideInInspector] public int arenaCount = 0;
    [HideInInspector] public int clanArenaCount = 0;

    [SyncVar]
    private int arenaId = -1;

    [HideInInspector]
    public CharacterEffects characterEffects;

    [HideInInspector]
    public CharacterBuffs characterBuffs;
    [HideInInspector]
    public CharacterMap characterMap;
    private MobProtectionSync cachedMobProtectionSync;
    private bool cachedMobProtectionSyncInitialized;

    //Hidden Stat
    [HideInInspector] public float hitSpeed = 0.5f;
    [HideInInspector] public float heal = 0;

    /// <summary>
    /// Chỉ số hồi máu lấy từ đá, thời gian hồi lâu
    /// </summary>
    [HideInInspector] public float healStat = 0;
    [HideInInspector] public float range = 0.75f;

    [HideInInspector] public float criticalBonus = 0;
    [HideInInspector] public float lifeSteal = 0;
    [HideInInspector] public float accuracy = 0;
    [HideInInspector] public float luck = 0;
    [HideInInspector] public float dodge = 0;
    [HideInInspector] public float poisonStat = 0;
    [HideInInspector] public float poisonDefense = 0;
    [HideInInspector] public float freezeStat = 0;
    [HideInInspector] public float freezeDoT = 0;
    [HideInInspector] public float fireStat = 0;
    [HideInInspector] public float fireDot = 0;
    [HideInInspector] public float multitarget = 0;
    [HideInInspector] public float windStat = 0;
    [HideInInspector] public float summonStat = 0;
    [HideInInspector] public float invincibleStat = 0;
    [HideInInspector] public float counterAttack = 0;
    [HideInInspector] public float defense = 0;
    [HideInInspector] public float critical = 0;
    [SerializeField] float counterDamage = 0;
    [HideInInspector] public float goldRate = 0;
    [HideInInspector] public float diamondRate = 0;
    [HideInInspector] public float ingredientRate = 0;


    public RuntimeAreaController runtimeAreaController;
    public RuntimeLandData runtimeLandData;
    public RuntimeZoneType landZoneType = RuntimeZoneType.None;


    public string landId;
    public string lockAreaId;

    //Max
    [HideInInspector] public float maxCritical = 450;
    [HideInInspector] public float maxDefense = 450;
    [HideInInspector] public float maxDodge = 450;
    [HideInInspector] public float maxPoisonStat = 450;
    [HideInInspector] public float maxFireStat = 600;
    [HideInInspector] public float maxFreezeStat = 600;
    [HideInInspector] public float maxMultitarget = 600;
    [HideInInspector] public float maxWindStat = 600;
    [HideInInspector] public float maxAccuracy = 600;
    [HideInInspector] public float maxCriticalBonus = 450;
    [HideInInspector] public float maxCounterAttack = 450;
    [HideInInspector] public float maxLifeSteal = 450;
    [HideInInspector] public float maxHealLongTime = 600;
    [HideInInspector] public float maxSummonStat = 1800;
    [HideInInspector] public float maxInvincibleStat = 600;
    [System.NonSerialized] public float maxFury = 600;

    [HideInInspector]
    public int seasonId = 0;

    //[HideInInspector]
    public bool isInitialized = false;
    //[HideInInspector]
    public bool isDataInitialized = false;
    public CharacterType characterType = CharacterType.Player;
    //[HideInInspector]
    public StatData statData = new StatData();

    //Stat của các món đồ trên người cộng lại
    public StatData rawStatData = new();

    [HideInInspector]
    public List<CharacterBehavior> enermies = new List<CharacterBehavior>();
    public CharacterBehavior enermy;
    private CharacterState characterState = CharacterState.Idle;
    public CharacterHealth characterHealth;

    public bool movementByAbility = false;

    public GameObject abilityHolder;
    public Ability[] abilities;

    public OnAttackAbility onAttackAbility;

    public CircleCollider2D circleCollider2D;

    protected CharacterBehavior lastEnermy;

    [HideInInspector]
    public CharacterBehavior lastKiller;

    [HideInInspector]
    public bool isNew = true;
    [HideInInspector]
    public float hitTime = 0;
    protected float healTime = 0;
    protected float longHealTime = 0;
    protected float damageOverTimeTimer = 0;
    protected float buildingSaveTime;
    public float delayHealTime = 0;
    private float temporaryInvincibleTime = 0f;
    protected Direction direction = Direction.R;
    protected Direction lastDirection = Direction.L;
    protected Vector3 lastPosition = Vector3.zero;
    //protected Vector3 lastlastPosition = Vector3.zero;
    protected float timeRun = 0;
    protected float maxTimeRun = 0.2f;

    public string[] hitPlayerSounds;
    public string[] deadSounds;

    //[HideInInspector]
    public CharacterBody characterBody;
    public int mobId = 0;

    protected int killedNumber = 0;

    public bool isActive = true;

    protected CharacterState lastCharacterState = CharacterState.Idle;

    private float timeResetCounterDamage = 0;
    //Client
    protected float timeCheckName = 0.5f;
    protected float maxTimeCheckName = 0.5f;

    public Direction GetDirection => direction;

    public float HealTime { get => healTime; set => healTime = value; }
    public float LongHealTime { get => longHealTime; set => longHealTime = value; }

    public int GetArenaId()
    {
        return arenaId;
    }

    public void SetArenaId(int value)
    {
        arenaId = value;
    }

    public void SetTemporaryInvincible(float duration)
    {
        if (duration <= 0f)
            return;

        temporaryInvincibleTime = Mathf.Max(temporaryInvincibleTime, Time.time + duration);
    }

    public bool IsTemporaryInvincible()
    {
        return temporaryInvincibleTime > Time.time;
    }

    public bool ShouldBlockDamageByTemporaryInvincible(CharacterBehavior targetBehavior)
    {
        if (targetBehavior == null)
            return false;

        if (targetBehavior.IsTemporaryInvincible())
            return true;

        return IsTemporaryInvincible() &&
               this is PlayerBehavior &&
               targetBehavior is PlayerBehavior;
    }

    public void ClearArenaId(bool forceTeleport = true)
    {
        arenaId = -1;
        if (this is PlayerBehavior player && forceTeleport)
        {
            player.TeleportExitCurrentArea();
        }
    }

    #region Player Info Get Set

    public string GetTeamIdIncludeClanId()
    {
        if (BattleManager.IsFinalWar) return FinalWarManager.TeamFor(this, teamId);
        if (teamId.IsNullOrEmpty())
        {
            return clanId;
        }
        return FinalWarManager.TeamFor(this, teamId);
    }

    public string GetTeamId()
    {
        return FinalWarManager.TeamFor(this, teamId);
    }

    public void SetTeamId(string value)
    {
        teamId = value;
    }

    public int GetTrophy()
    {
        if (this is PlayerBehavior player)
        {
            return player.trophy;
        }
        return 0;
    }

    public float GetPower()
    {
        return DataUtils.GetPowerStats(statData);
    }

    public static int GetClanRaidPoint(float power)
    {
        if (float.IsNaN(power) || power <= 0f)
        {
            return 1;
        }

        if (power >= 450f)
        {
            return 10;
        }

        return (int)(power / 50f) + 1;
    }

    private static bool IsClanRaidPlayerClan(string clanName)
    {
        return IsUserClan(clanName) &&
            !ClanData.IsNoClanOrClanNPC(clanName) &&
            clanName != VikingVillageManager.VIKING_CLAN_ID;
    }

    private void TryAwardClanRaidPoint(
        CharacterBehavior killer,
        PlayerBehavior victim,
        ClanData victimClan,
        float power)
    {
#if ENABLE_SERVER
        if (killer == null || victim == null || victimClan == null || BattleManager.instance == null)
        {
            return;
        }

        if (victim.GetCharacterState() == CharacterState.Dead || victim.GetHealth() > 0)
        {
            return;
        }

        if (EventManager.instance == null)
        {
            return;
        }

        var clanRaidEvent = EventManager.instance.GetNearestGameEventData(GameEventId.ClanRaid);
        var now = BattleManager.instance.ServerNow();
        if (clanRaidEvent == null ||
            clanRaidEvent.state == GameEventState.Completed ||
            !clanRaidEvent.IsPlayable(now))
        {
            return;
        }

        if (victimClan.clanBuildings == null ||
            !victimClan.clanBuildings.Contains(victim.userName))
        {
            return;
        }

        if (!IsClanRaidPlayerClan(victimClan.clanName))
        {
            return;
        }

        if (string.IsNullOrEmpty(killer.clanId))
        {
            return;
        }

        var killerClan = BattleManager.instance.GetClanData(killer.clanId);
        if (killerClan == null ||
            string.IsNullOrEmpty(killerClan.clanName) ||
            !killerClan.HasVillage ||
            !IsClanRaidPlayerClan(killerClan.clanName) ||
            killerClan.clanName == victimClan.clanName)
        {
            return;
        }

        int point = GetClanRaidPoint(power);
        BattleManager.instance.UpdateLeaderboardsByCurrency(
            CurrencyID.ClanRaidPoint,
            killerClan.clanName,
            point);
        BattleManager.LogClan(
            killerClan,
            LogAction.ClanDestroyBuilding,
            $"Event:ClanRaid|KillerClan:{killerClan.clanName}|VictimClan:{victimClan.clanName}|BuildingId:{victim.userName}|Power:{power:F2}|Point:{point}",
            value: point.ToString());
#endif
    }

    public void SetTrophy(int value)
    {
        if (this is PlayerBehavior player)
        {
            player.trophy = System.Math.Max(0, value);
        }
    }

    public string GetLeaveClanTime()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.leaveClanTime;
        }
        return "";
    }

    public void SetLeaveClanTime(string value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.leaveClanTime = value;
        }
    }

    public int GetCraftNumber()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.craftNumber;
        }
        return 0;
    }

    public void SetCraftNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.craftNumber = value;
        }
    }

    public void AddCraftNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.craftNumber += value;
        }
    }

    public int GetUndeadChestNumber()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.undeadChestNumber;
        }
        return 0;
    }

    public void SetUndeadChestNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.undeadChestNumber = value;
        }
    }

    public void AddUndeadChestNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.undeadChestNumber += value;
        }
    }

    public int GetCenterLandChestNumber()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.centerChestNumber;
        }
        return 0;
    }

    public void SetCenterLandChestNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.centerChestNumber = value;
        }
    }

    public void AddCenterLandChestNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.centerChestNumber += value;
        }
    }

    public int GetTeamBattleScore()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.syncTeamBattleArenaScore;
        }
        return 0;
    }

    public void SetTeamBattleScore(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.syncTeamBattleArenaScore = value;
        }
    }

    public void AddTeamBattleScore(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.syncTeamBattleArenaScore += value;
        }
    }

    public int GetChestNumber()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.chestNumber;
        }
        else if (characterType == CharacterType.Building)
        {
            var characterData = BattleManager.instance.GetCharacterData(userName);
            if (characterData != null)
            {
                return characterData.chestNumber;
            }
        }
        return 0;
    }

    public void SetChestNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.chestNumber = value;
        }
        else if (characterType == CharacterType.Building)
        {
            var characterData = BattleManager.instance.GetCharacterData(userName);
            if (characterData != null)
            {
                characterData.chestNumber = value;
                BattleManager.instance.SaveCharacterData(characterData);
            }
        }
    }

    public void AddChestNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.chestNumber += value;
        }
        else if (characterType == CharacterType.Building)
        {
            var characterData = BattleManager.instance.GetCharacterData(userName);
            if (characterData != null)
            {
                characterData.chestNumber += value;
                BattleManager.instance.SaveCharacterData(characterData);
            }
        }
    }

    public int GetProgress()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.progress;
        }
        return 0;
    }

    public void SetProgress(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.progress = value;
        }
    }

    public void AddProgress(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.progress += value;
        }
    }

    public int GetClanScore()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.clanScore;
        }
        return 0;
    }

    public void AddClanScore(int score)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.clanScore += score;
        }
    }

    public void SetClanScore(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.clanScore = value;
        }
    }

    public int GetKillPlayerNumber()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.killPlayerNumber;
        }

        return 0;
    }

    public void SetKillPlayerNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.killPlayerNumber = value;
        }
    }

    public int GetKillMobNumber()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.killMobNumber;
        }
        return 0;
    }

    public void SetKillMobNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.killMobNumber = value;
        }
    }

    public void AddKillMobNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.killMobNumber += value;
        }
    }

    public int GetKillMobFireCraftNumber()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.killMobFireCraftNumber;
        }
        return 0;
    }

    public void SetKillMobFireCraftNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.killMobFireCraftNumber = value;
        }
    }

    public void AddKillMobFireCraftNumber(int value)
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.killMobFireCraftNumber += value;
        }
    }

    public int GetKillBossNumber()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.killBossNumber;
        }
        else
        {
            return killBossNumber;
        }
    }
    public int GetClanPurchasePet()
    {
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            return playerMap.syncClanPurchasePet;
        }
        else
        {
            return -1;
        }
    }

    public void SetKillBossNumber(int value)
    {
#if ENABLE_SERVER
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.killBossNumber = value;
        }
        else
        {
            killBossNumber = value;
            SetRoyaltiMainBuilding();
        }
#endif
    }

    private void SetRoyaltiMainBuilding()
    {
#if ENABLE_SERVER
        if (characterType == CharacterType.Building && mobId == GameConst.MAIN_BUILDING_ID)
        {
            if (TryGetComponent<BuildingSyncRoyalty>(out var skill))
            {
                skill.royalty = killBossNumber;
            }
        }
#endif
    }

    public void AddKillBossNumber(int value)
    {
#if ENABLE_SERVER
        if (characterMap != null && characterMap is PlayerMap playerMap)
        {
            playerMap.killBossNumber += value;
        }
        else
        {
            killBossNumber += value;
        }
#endif
    }

    public CharacterState GetCharacterState()
    {
        return characterState;
    }

    public bool IsCharacterState(CharacterState state)
    {
        return characterState == state;
    }

    public void SetCharacterState(CharacterState value)
    {
        if (characterState == CharacterState.Dead && value != CharacterState.Dead)
            trophyDeathSettled = false;
        characterState = value;
    }

    protected void ClientSetCharacterState(CharacterState characterState)
    {
        SetCharacterState(characterState);
    }

    #endregion

    protected virtual void Awake()
    {
        isInitialized = false;
        circleCollider2D = this.GetComponent<CircleCollider2D>();
        characterMap = this.GetComponent<CharacterMap>();
        cachedMobProtectionSync = this.GetComponent<MobProtectionSync>();
        cachedMobProtectionSyncInitialized = true;

        if ((abilities == null || abilities.Length == 0) && abilityHolder != null)
        {
            abilities = abilityHolder.GetComponentsInChildren<Ability>(true);
        }

        if (onAttackAbility != null)
        {
            onAttackAbility.Init(this);
        }

        for (int i = 0, length = abilities.Length; i < length; i++)
        {
            if (abilities[i] != null)
            {
                abilities[i].Init(this);
            }
        }
    }



    public override void OnStartServer()
    {
        base.OnStartServer();
        for (int i = 0, length = abilities.Length; i < length; i++)
        {
            if (abilities[i] != null)
            {
                abilities[i].ResetAbility();
            }
        }
        UpdateLandData(true);
    }

    public override void OnStartClient()
    {
        base.OnStartClient();
        isInitialized = false;

        if (!isLocalPlayer && ClientManager.instance != null)
            ClientManager.instance.Queue(this);

        for (int i = 0, length = abilities.Length; i < length; i++)
        {
            if (abilities[i] != null)
            {
                abilities[i].ResetAbility();
            }
        }
    }

    public virtual void Initialize()
    {

    }

    public virtual void LoadCharacterBody()
    {

    }

    public virtual void CheckCharacterBody()
    {
        if (characterBody != null)
        {
            /*
            if (characterBody.sortingGroup != null)
                characterBody.sortingGroup.enabled = true;
            characterBody.enabled = true;*/
            if (characterBody.OutlineAble != null)
                characterBody.OutlineAble.DisableOutline();
            characterBody.transform.position = this.transform.position;

            if (!characterBody.gameObject.activeSelf)
                characterBody.gameObject.SetActive(true);
        }
    }

    public void EnableCollider(bool enable)
    {
        if (circleCollider2D != null && circleCollider2D.enabled != enable)
        {
            circleCollider2D.enabled = enable;
        }
    }

    //Dao TODO: world manager
    //public bool IsZoneCombat(MapZoneType mapZoneType)
    //{
    //    return mapZoneType == MapZoneType.Undead || mapZoneType == MapZoneType.White ||
    //        mapZoneType == MapZoneType.Viking;
    //}



    public void HookClanId(string oldValue, string newValue)
    {
        if (characterType == CharacterType.Player)
        {
            if (isLocalPlayer)
            {
                OnUpdateStats();
                //Out or kicked
                if (string.IsNullOrEmpty(newValue))
                {
                    if (UIManager.instance != null)
                        UIManager.instance.FindView<HUDView>().OnLeaveOrQuitClan();
                    StartCoroutine(ReloadBuilding(false));
                }
                else
                {
                    StartCoroutine(ReloadBuilding(true));
                }
            }
        }
        else if (characterType == CharacterType.Building)
        {
            OnUpdateStats();
        }

        if (characterBody != null)
        {
            characterBody.ReloadClanName();
        }
    }

    public void HookCharacterName(string oldValue, string newValue)
    {
        if (characterBody != null)
        {
            characterBody.ReloadCharacterName();
        }
    }

    private IEnumerator ReloadBuilding(bool waitForClanData)
    {
        if (waitForClanData)
        {
            yield return new WaitUntil(() => ClientClanManager.Instance.HaveData);
        }
        else
        {
            yield return null;
        }
        var buildingIds = ClientClanManager.Instance.GetBuildingIds;

        if (buildingIds == null)
        {
            BattleManager.Log(GameLogType.Info, "Building Ids cache null");
            yield break;
        }

        foreach (var id in buildingIds)
        {
            var localPlayer = ClientManager.instance.GetLocalPlayerBehavior(id);

            if (localPlayer != null)
            {
                localPlayer.OnUpdateStats();
            }
        }
    }

    public T FindAbility<T>() where T : Ability
    {
        foreach (var condition in abilities)
        {
            if (condition is T result)
            {
                return result;
            }
        }

        return null;
    }

    public bool CanNotAddEffect(int[] conflictEffects, Effect effect)
    {
        return characterEffects == null ||
        characterEffects.HaveEffect(effect) ||
        characterEffects.Conflict(conflictEffects);
    }

    public virtual void OnUpdateStats()
    {

    }

    public virtual StatData UpdateRawStat()
    {
        rawStatData.ResetStats();
        return rawStatData;
    }

    public void UpdateLandData(bool forceUpdate = false)
    {
        var position = this.transform.position.ToVector2Int();

        var cacheOld = runtimeAreaController;

        runtimeLandData = null;
        runtimeAreaController = null;
        landZoneType = RuntimeZoneType.None;

        runtimeLandData = landId.IsNonEmpty() ? WorldManager.Instance.GetLandData(landId) : WorldManager.Instance.GetLandData(position);
        if (runtimeLandData != null)
        {
            runtimeAreaController ??= runtimeLandData.GetAreaController(this.transform.position);
            landZoneType = WorldManager.Instance.GetLandZone(position) ?? RuntimeZoneType.None;
        }

        if (cacheOld != runtimeAreaController || forceUpdate)
        {
            OnChangeAreaController(cacheOld, runtimeAreaController);
        }
    }
    public void OnChangeAreaController(RuntimeAreaController oldArea, RuntimeAreaController newArea)
    {
        if (isServer)
        {
            OnEnterArea(newArea);

            OnExitArea(oldArea);
        }
    }
    public void OnEnterArea(RuntimeAreaController areaController)
    {
        if (areaController != null)
        {
            AssignTeamByType(areaController.OnEnterAssignTeamType);
        }
    }
    public void OnExitArea(RuntimeAreaController areaController)
    {
        if (areaController != null)
        {
            AssignTeamByType(areaController.OnExitAssignTeamType);
        }
    }
    public void ForceInvokeEnterArea()
    {
        var areaController = GetRuntimeAreaController();
        OnEnterArea(areaController);
    }
    public LandType GetLandType()
    {
        return characterMap.GetLandType();
    }
    public void AssignTeamByType(AssignTeamType assignTeamType)
    {
#if ENABLE_SERVER
        // A registered New Arena player owns team membership through NewArena. Area
        // transitions must not replace that arena team with a map-combat team.
        if (this is PlayerBehavior arenaPlayer &&
            arenaPlayer.GetArenaId() != -1 &&
            NewArenaManager_Server.TryGetArena(arenaPlayer.GetArenaId(), out var newArena) &&
            newArena.IsRegistered(arenaPlayer.userName, out _, out _))
        {
            return;
        }
#endif

        switch (assignTeamType)
        {
            case AssignTeamType.None:
                break;
            case AssignTeamType.Random:
                if (!this.teamId.Contains("Manual_"))
                    SetTeamId("Manual_" + System.Guid.NewGuid().ToString());
                break;
            case AssignTeamType.Clan:
                if (this is MobBehavior summonMob && summonMob.isSummonMob && summonMob.summoner != null)
                {
                    var summonerTeamId = summonMob.summoner.GetTeamId();
                    if (summonerTeamId.IsNullOrEmpty())
                    {
                        summonMob.summoner.AssignTeamByType(assignTeamType);
                        summonerTeamId = summonMob.summoner.GetTeamId();
                    }

                    if (summonerTeamId.IsNonEmpty())
                    {
                        SetTeamId(summonerTeamId);
                    }
                    else if (summonMob.summoner.clanId.IsNonEmpty())
                    {
                        SetTeamId(summonMob.summoner.clanId);
                    }
                    else
                    {
                        SetTeamId("player_" + summonMob.summoner.userName);
                    }
                }
                else if (clanId.IsNonEmpty())
                {
                    //SetTeamId("clan_"+clanId);
                    SetTeamId(clanId);
                }
                else
                {
                    if (this is MobBehavior mob)
                    {
                        if (mob.summoner != null)
                        {
                            SetTeamId("player_" + mob.summoner.userName);
                        }
                    }
                    else if (this is PlayerBehavior player)
                    {
                        SetTeamId("player_" + player.userName);
                    }
                }
                break;
            case AssignTeamType.Reset:
                SetTeamId("");
                break;
        }
    }


    [Server]
    public void SetLandType(LandType value)
    {
#if ENABLE_SERVER
        LandType previousValue = characterMap.GetLandType();
        characterMap.SetLandType(value);
        if (this is PlayerBehavior && previousValue == LandType.BeginnerLand && value == LandType.CenterLand)
        {
            EconomyManager.RecordBeginnerLandPassed();
        }
#endif
    }


    public virtual int GetGold()
    {
        return 0;
    }

    public virtual int GetHealth()
    {
        if (characterHealth != null)
            return characterHealth.value;
        else
            return 0;
    }

    public virtual void SetAnimator(Animator anim)
    {
        this.characterBody.animator = anim;
    }


    // Update is called once per frame
    protected virtual void Update()
    {


    }

    public void CheckDameOverTime(float deltaTime = -1f)
    {
#if ENABLE_SERVER
        if (deltaTime < 0f)
            deltaTime = Time.deltaTime;

        if (damageOverTimeTimer > 1)
        {
            damageOverTimeTimer = 0;

            if (IsTemporaryInvincible() || FinalWarManager.IsEliminated(this))
                return;
            FinalWarManager.RemoveBlockedDamageEffects(this);

            //Poison
            var dotDmg = (int)statData.GetStat(StatType.PoisonDoT).value;

            if (poisonDefense > 0)
            {
                var reduce = dotDmg / 100 * poisonDefense;
                dotDmg -= (int)reduce;
            }

            if (dotDmg >= characterHealth.value)
            {
                dotDmg = characterHealth.value - 1;
            }

            if (dotDmg > 0)
            {
                characterHealth.AddValue(-dotDmg);
                if (healStat > 0)
                    longHealTime += 1;
            }

            //Fire
            dotDmg = (int)fireDot;
            if (dotDmg >= characterHealth.value)
            {
                dotDmg = characterHealth.value - 1;
            }

            if (dotDmg > 0)
            {
                characterHealth.AddValue(-dotDmg);
                if (healStat > 0)
                    longHealTime += 1;
            }
        }
        else
        {
            damageOverTimeTimer += deltaTime;
        }
#endif
    }

    protected bool MeAndTargetIsUndeadLane(CharacterBehavior characterBehavior)
    {
        return GetLandType() == LandType.UndeadLand && characterBehavior.GetLandType() == LandType.UndeadLand;
    }

    protected bool MeAndTargetIsArenaFreeForAll(CharacterBehavior characterBehavior)
    {
        //return GetMapZoneType() == MapZoneType.ArenaFreeForAll && characterBehavior.GetMapZoneType() == MapZoneType.ArenaFreeForAll;
        return IsStandingOn(RuntimeAreaController.RuntimeAreaType.ArenaFreeForAll) &&
               characterBehavior.IsStandingOn(RuntimeAreaController.RuntimeAreaType.ArenaFreeForAll);
    }

    public int GetNumberOfTarget()
    {
        if (multitarget == 0)
            return 1;
        else
        {
#if ENABLE_SERVER
            if (multitarget >= 120)
                return 9;
            else if (multitarget >= 110)
                return 8;
            else if (multitarget >= 100)
                return 7;
            else if (multitarget >= 90)
                return 6;
            else if (multitarget >= 70)
                return 5;
            else if (multitarget >= 50)
                return 4;
            else if (multitarget >= 25)
                return 3;
            else if (multitarget >= 10)
                return 2;
#endif
            return 1;
        }

    }

    public bool GetNormalAttackAoEChance()
    {
        int random = 0;
#if ENABLE_SERVER
        if (multitarget >= 120)
            random = 100;
        else if (multitarget >= 110)
            random = Random.Range(95, 100);
        else if (multitarget >= 100)
            random = Random.Range(84, 100);
        else if (multitarget >= 90)
            random = Random.Range(78, 100);
        else if (multitarget >= 70)
            random = Random.Range(72, 100);
        else if (multitarget >= 50)
            random = Random.Range(66, 100);
        else if (multitarget >= 25)
            random = Random.Range(60, 100);
        else if (multitarget >= 10)
            random = Random.Range(50, 100);
#endif
        return random > 85f;
    }

    [Server]
    public void LogicHitAoe()
    {
#if ENABLE_SERVER
        var targetPos = enermy.transform.position;
        int targetNumber = GetNumberOfTarget();
        var radius = 2;

        int targetLayerMask = this is MobBehavior
            ? BattleManager.instance.playerLayerMask.value
            : BattleManager.instance.normalAttackAoeLayerMask.value;
        int hitCount = Physics2D.OverlapCircleNonAlloc(targetPos, radius, normalAttackAoeBuffer, targetLayerMask, 0);

        int count = 0;
        List<string> hitUserNames = new List<string>();

        RpcNormalAttackAoE(targetPos, radius);

        for (int i = 0; i < hitCount; i++)
        {
            var hitCollider = normalAttackAoeBuffer[i];
            if (hitCollider == null)
                continue;
            var characterBehavior = hitCollider.GetComponent<CharacterBehavior>();
            if (characterBehavior == null)
                continue;

            if (string.IsNullOrEmpty(characterBehavior.userName))
                continue;

            if (characterBehavior.userName == this.userName)
                continue;

            if (hitUserNames.Contains(characterBehavior.userName))
                continue;

            if (!CanAttack(characterBehavior))
                continue;

            hitUserNames.Add(characterBehavior.userName);


            LogicHitTarget(characterBehavior);
            count++;

            if (count >= targetNumber)
            {
                break;
            }
        }
#endif
    }

    [ClientRpc]
    private void RpcNormalAttackAoE(Vector2 targetPos, float radius)
    {
#if ENABLE_CLIENT 
        var vfx = PoolManager.Pools["VFX"].Spawn("VFXMultitarget", targetPos, Quaternion.identity).GetComponent<AutoDestroy>();
        var mainBuffAOE = vfx.radius.main;
        mainBuffAOE.startSize = 0.5f + radius * 2;
        vfx.PlayVFX();
#endif
    }

    [Client]
    protected void ClientCheckDameOverTime()
    {
        if (damageOverTimeTimer > 1)
        {
            damageOverTimeTimer = 0;

            var dotDmg = (int)statData.GetStat(StatType.PoisonDoT).value;

            if (poisonDefense > 0)
            {
                var reduce = dotDmg / 100 * poisonDefense;
                dotDmg -= (int)reduce;
            }

            if (dotDmg >= characterHealth.value)
            {
                dotDmg = characterHealth.value - 1;
            }

            if (dotDmg > 0)
            {
                //VfxManager.instance.OnPlayerPoisonEffect(characterBody.transform.position, dotDmg);
                EventDispatcher.Raise(new OnSendStatCharacter
                {
                    typeStat = StatType.PoisonDoT,
                    position = characterBody.transform.position,
                    value = dotDmg,
                });
            }

            dotDmg = (int)fireDot;
            if (dotDmg >= characterHealth.value)
            {
                dotDmg = characterHealth.value - 1;
            }

            if (dotDmg > 0)
            {
                //VfxManager.instance.OnPlayerPoisonEffect(characterBody.transform.position, dotDmg);
                EventDispatcher.Raise(new OnSendStatCharacter
                {
                    typeStat = StatType.FireDot,
                    position = characterBody.transform.position,
                    value = dotDmg,
                });
            }

        }
        else
        {
            damageOverTimeTimer += Time.deltaTime;
        }
    }

    #region StatCombat
    [Server]
    public float GetTimeResetCounterDamage()
    {
#if ENABLE_SERVER
        return timeResetCounterDamage;
#else
        return 0f;
#endif
    }

    [Server]
    public void ResetCounterDamage()
    {
#if ENABLE_SERVER
        SetCounterDamage(0);
        timeResetCounterDamage = 0;
#endif
    }

    [Server]
    public void AddTimeResetCounterDamage(float value)
    {
#if ENABLE_SERVER
        timeResetCounterDamage += value;
#endif
    }

    public float GetCounterDamage()
    {
        return counterDamage;
    }

    [Server]
    protected void SetCounterDamage(float value)
    {
#if ENABLE_SERVER
        timeResetCounterDamage = 0;
        counterDamage = value;
#endif
    }

    #endregion
    void OnDestroy()
    {
#if ENABLE_CLIENT|| UNITY_LOCAL_HOST
        if (characterBody != null && PoolManager.Pools.ContainsKey("Characters") && PoolManager.Pools["Characters"] != null)
        {
            PoolManager.Pools["Characters"].Despawn(characterBody.transform);
        }
#endif
    }

    [ServerCallback]
    public virtual List<Equipment> GetLimitedEquipmentOnDead()
    {
        return null;
    }

    [ServerCallback]
    public virtual void AddLimitedEquipmentsOnKill(List<Equipment> equipments)
    {

    }

    //[ServerCallback]
    //public virtual List<Equipment> GetEquipmentsOnDead()
    //{
    //    List<Equipment> lostEquipment = new List<Equipment>();
    //    return lostEquipment;
    //}

    //[ServerCallback]
    //public virtual CurrencyData[] GetCurrencyDataOnDead(float goldRate = 1, float diamondRate = 1) { return new CurrencyData[0]; }

    [ServerCallback]
    public virtual void AddEquipmentsOnKill(List<Equipment> equipments, CurrencyData[] currencyDatas) { }

    [ServerCallback]
    public virtual void LostEquipments(List<Equipment> equipments, int gold) { }

    [ServerCallback]
    public virtual (int gold, List<Equipment> equipments) GetDeathDrops() { return (default); }

    [ServerCallback]
    private (List<Equipment> equipments, CurrencyData[] currency) CalculateLoot((int gold, List<Equipment> equipments) drops, CharacterBehavior from)
    {
#if ENABLE_SERVER
        var lootEquipments = new List<Equipment>();
        foreach (var e in drops.equipments)
        {
            if (Random.value <= 0.7f)
            {
                lootEquipments.Add(e);


                if (from != null && from.mobId == GameConst.STORAGE_BUILDING_ID && e.state == EquipmentState.Lock)
                {
                    e.state = e.equipmentType == EquipmentType.Ingredient ? EquipmentState.Ingredient : EquipmentState.Inventory;
                }
            }
        }
        var lootCurrency = new[] { new CurrencyData() { currencyId = GameConst.GOLD_ID, value = (int)(drops.gold * 0.5f) } };
        return (lootEquipments, lootCurrency);
#else
        return default;
#endif
    }


    [Server]
    public void LogicHitTarget(CharacterBehavior targetBehavior)
    {
#if ENABLE_SERVER
        if (!CanAttack(targetBehavior)) return;

        //Add Time For targetBehavior
        if (targetBehavior is PlayerBehavior player2)
        {
            if (player2.healStat > 0) player2.longHealTime += 1;
        }

        //Add enemy to target
        if (targetBehavior.enermy == null && (this.transform.position - targetBehavior.transform.position).sqrMagnitude <= targetBehavior.range * targetBehavior.range)
            targetBehavior.enermy = this;

        if (this.characterType == CharacterType.Player)
        {
            if (targetBehavior is MobBehavior mob)
            {
                Card card = DataHolder.Instance().GetData<Card>(mob.mobId);
                //Participate join to kill Boss        
                if (card.isParticipateReward)
                {
                    if (!mob.participates.Contains(this.userName))
                        mob.participates.Add(this.userName);
                }
            }
        }

        int damage = GetDamage(targetBehavior);
        if (damage > 0 && targetBehavior is PlayerBehavior hitPlayer)
        {
            hitPlayer.MarkHitForAdCooldown(this);
        }
        targetBehavior.characterHealth.AddValue(-damage);

        //Die
        if (targetBehavior.GetHealth() <= 0)
        {
            HandleKillTarget(this, targetBehavior);
        }

#endif
    }

    public void HandleKillTarget(CharacterBehavior killer, CharacterBehavior victim)
    {
        if (victim == null) return;
        if (killer == null) return;

        // Nếu killer là mob được summon, chuyển hệ quả về owner
        CharacterBehavior actualKiller = killer;
        if (killer is MobBehavior mobKiller && mobKiller.summoner != null)
        {
            actualKiller = mobKiller.summoner;
        }

        // Inspect match membership before an event death callback can unregister it.
#if ENABLE_SERVER_TEST
        // Temporary test actors must not turn cloned gear into loot or player rewards.
        if (victim is PlayerBehavior testVictim && victim.characterType == CharacterType.Player &&
            (testVictim.isFinalWarTestBot || actualKiller is PlayerBehavior testKiller && testKiller.isFinalWarTestBot))
        {
            victim.lastKiller = killer;
            testVictim.Dead();
            if (!testVictim.isFinalWarTestBot) BattleManager.instance.SavePlayerData(testVictim);
            return;
        }
#endif
        TrySettleDeathTrophy(actualKiller, victim);

        if (NewArenaManager_Server.TryGetArena(victim.arenaId, out var arena))
        {
            // 25-2 Chuyển killer thành actualKiller
            arena.LogicOnKill(actualKiller, victim);
        }

        // Store the killer for abilities that trigger on death
        victim.lastKiller = killer;

        switch (victim.characterType)
        {
            case CharacterType.Mob:
                if (victim is MobBehavior mob && mob.GetCharacterState() != CharacterState.Dead)
                    HandleKillMob(actualKiller, mob);
                break;
            case CharacterType.Player:
                if (victim is PlayerBehavior playerVictim)
                {
                    HandleKillPlayer(actualKiller, playerVictim);
                    playerVictim.Dead();
                }
                break;
            case CharacterType.Building:
                {
                    if (victim is PlayerBehavior buildingVictim)
                    {
                        HandleKillBuiding(actualKiller, buildingVictim);
#if ENABLE_SERVER
                        // Final War capture has already revived the main building under its new owner.
                        if (!BattleManager.IsFinalWar || buildingVictim.mobId != GameConst.MAIN_BUILDING_ID || buildingVictim.GetHealth() <= 0)
#endif
                            buildingVictim.Dead();
#if ENABLE_SERVER
                        AreaClashManager.instance?.HandleBuildingKilled(actualKiller, buildingVictim);
#endif
                    }
                }
                break;
        }




        if (actualKiller.characterType == CharacterType.Player || actualKiller.characterType == CharacterType.Building)
        {
            BattleManager.instance.SavePlayerData((PlayerBehavior)actualKiller);
        }

        if (victim.characterType == CharacterType.Player || victim.characterType == CharacterType.Building)
        {
            BattleManager.instance.SavePlayerData((PlayerBehavior)victim);
        }

        void HandleKillMob(CharacterBehavior killer, MobBehavior mob)
        {
            if (killer is PlayerBehavior playerKiller)
            {
                playerKiller.AddKillMobNumber(1);
            }

            Card card = DataHolder.Instance().GetData<Card>(mob.mobId);

            if (card.isServerNotifyOnLastHit)
            {
                string killerName = killer is PlayerBehavior pk ? pk.characterName : killer.characterName;
                BattleManager.instance.SendServerNotificationToAll(killerName, GameConst.DIALOG_SERVER_LAST_HIT_MONSTER, card.GetName(0));
                if (killer is PlayerBehavior notifyKiller)
                {
                    BattleManager.Log(notifyKiller,
                        LogAction.KillBoss,
                        $"Notify:LastHit|Target:{card.GetName(0)}|Location:{notifyKiller.transform.position.x:F1},{notifyKiller.transform.position.y:F1}");
                }
            }


            if (mob.GetArenaId() > -1) EventManager.instance.OnKillInArena(killer, mob, mob.GetArenaId());


            if (killer is not PlayerBehavior playerKiller2 || killer.characterType != CharacterType.Player) return;

            if (card.isBoss)
            {
                BattleManager.Log(playerKiller2, LogAction.KillBoss,
                    $"Killer={playerKiller2.userName} ({playerKiller2.characterName});Clan={playerKiller2.clanId};Boss={mob.mobId};Location={playerKiller2.transform.position.x:F1},{playerKiller2.transform.position.y:F1}");

                playerKiller2.AddKillBossNumber(1);
            }

            // Open Box for killer  
            var boxSource = mob.mobId == GameConst.UNDEATH_T_REX_ID ?
                            BoxSourceType.UndeathTRex :
                            card.isBoss ? BoxSourceType.Boss : BoxSourceType.Mob;

            playerKiller2.ServerOpenBox(card.box, boxSource, mob.mobId);

            if (card.isParticipateReward)
            {
                bool isClanBoss = card.isClanBoss && killer.clanId.IsNonEmpty();
                foreach (string id in mob.participates)
                {
                    PlayerBehavior participate = BattleManager.instance.GetPlayerBehavior(id);

                    if (participate == null || (isClanBoss && participate.clanId != killer.clanId)) continue;

                    var sourceType = card.isBoss ? BoxSourceType.Boss : BoxSourceType.Mob;
                    participate.ServerOpenBox(card.participateBox, sourceType, mob.mobId);

                    BattleManager.instance.SavePlayerData(participate);
                }
                mob.participates.Clear();
            }

            // check mission progress
            var characterData = BattleManager.instance.GetCharacterData(playerKiller2.userName);
            playerKiller2.CheckKillMobProgress(mob, characterData);


            // Chaos event (x3 diamond)
            if (BattleManager.instance.GetEventRunning(GameEventId.x3Diamond))
            {
                var zone = WorldManager.Instance.GetLandZone(mob.transform.position.ToVector2Int());
                int diamondBonus = zone == RuntimeZoneType.Undead ? playerKiller2.GetDiamondRate() :
                                   zone == RuntimeZoneType.White ? playerKiller2.GetDiamondRate() * 2 : 0;

                if (diamondBonus > 0)
                {
                    int oldAmount = playerKiller2.characterInventory.diamond;
                    playerKiller2.characterInventory.diamond += Mathf.CeilToInt(diamondBonus);

                    var currencyData = new CurrencyData() { currencyId = GameConst.DIAMOND_ID, value = diamondBonus };
                    BattleManager.instance.gameLogicBehavior.TargetReceiveCurrency(playerKiller2.connectionToClient, oldAmount, currencyData);
                }
            }
        }

        void HandleKillPlayer(CharacterBehavior killer, PlayerBehavior victimPlayer)
        {
            if (killer is PlayerBehavior playerKiller)
            {
                playerKiller.SetKillPlayerNumber(playerKiller.GetKillPlayerNumber() + 1);
            }

            string killerName = killer is PlayerBehavior pk ? pk.characterName : killer.characterName;
            BattleManager.instance.SendServerNotificationToTarget(victimPlayer.connectionToClient, 145, NotifyType.ToastView, " " + killerName);
            BattleManager.Log(GameLogType.Debug, killer.userName + " - " + killerName + " have killed " + victimPlayer.userName + " - " + victimPlayer.characterName);

            if (killer.characterType == CharacterType.Player || killer.characterType == CharacterType.Mob && killer.GetArenaId() > -1)
            {
                EventManager.instance.OnKillInArena(killer, victimPlayer, killer.GetArenaId());
            }
            else if (killer.characterType == CharacterType.Mob && victimPlayer.GetArenaId() == 1)
            {
                //Mob kill 1 player đang trong clan war
                EventManager.instance.OnKillInArena(killer, victimPlayer, victimPlayer.GetArenaId());
            }

            (int gold, List<Equipment> equipments) drops = (0, new List<Equipment>());
            (List<Equipment> equipments, CurrencyData[] currency) loot = (new(), System.Array.Empty<CurrencyData>());

            //Loot equipment, gold
            if (!killer.IsStandingOn(RuntimeAreaController.RuntimeAreaType.ArenaFreeForAll) &&
                !victimPlayer.IsStandingOn(RuntimeAreaController.RuntimeAreaType.ArenaFreeForAll) &&
                killer.GetArenaId() == -1)
            {
                drops = victimPlayer.GetDeathDrops();
                loot = CalculateLoot(drops, victim);

                if (killer is PlayerBehavior player && player.characterType == CharacterType.Player)
                {
                    player.RpcCombatLoot(player.connectionToClient, loot.currency, loot.equipments,
                        CharacterHistoryContext.Capture(victimPlayer), HistoryLogActionType.Add);
                }

                victim.LostEquipments(drops.equipments, drops.gold);
                var lostCurrency = new CurrencyData[] {
                    new CurrencyData() { currencyId = (int)CurrencyID.Gold, value = drops.gold }
                };
                var killerContext = CharacterHistoryContext.Capture(killer as PlayerBehavior);
                if (killerContext != null)
                {
                    victimPlayer.RpcCombatLoot(victimPlayer.connectionToClient, lostCurrency, drops.equipments,
                        killerContext, HistoryLogActionType.Lost);
                }
                else
                {
                    victimPlayer.RpcLooted(victimPlayer.connectionToClient, lostCurrency, drops.equipments);
                }

                if (killer is PlayerBehavior playerKiller2)
                {
                    playerKiller2.AddEquipmentsOnKill(loot.equipments, loot.currency);
                }
            }

            if (!killer.IsStandingOn(RuntimeAreaType.ArenaFreeForAll, RuntimeAreaType.Arena) &&
                !victim.IsStandingOn(RuntimeAreaType.Arena, RuntimeAreaType.ArenaFreeForAll))
            {
                //Loot Chest keys
                var key = victimPlayer.characterInventory.GetEquipment(EquipmentType.Key);
                if (key != null)
                {
                    if (key.itemId == GameConst.DIAMOND_KEY_ID)
                    {
                        if (killer is PlayerBehavior playerKiller3)
                        {
                            playerKiller3.LogicLootDiamondKey(victimPlayer);
                        }
                    }
                    else if (key.itemId == GameConst.UNDEAD_KEY_ID)
                    {
                        if (killer is PlayerBehavior playerKiller4)
                        {
                            playerKiller4.LogicLootUndeadKey(victimPlayer, key);
                        }
                    }

                    drops.equipments.Add(key);
                }
            }


            //Kill player in PVP
            if (killer.characterType == CharacterType.Player || killer.characterType == CharacterType.Building)
            {
                if (victim.IsStandingOn(CombatZoneType.PVPWithProtection))// && victimPlayer.isProtected)
                    victimPlayer.protectionTime = BattleManager.instance.deadProtectionTime;
            }

            if (killer is PlayerBehavior playerKiller5 &&
                (killer.clanId != victim.clanId || killer.clanId == "") &&
                killer.GetArenaId() == -1 && victimPlayer.GetArenaId() == -1 &&
                !killer.IsStandingOn(RuntimeAreaController.RuntimeAreaType.ArenaFreeForAll) &&
                !victimPlayer.IsStandingOn(RuntimeAreaController.RuntimeAreaType.ArenaFreeForAll))
            {
                victimPlayer.killedNumber++;
            }


            // ========== 🆕 LOGGING: Player Death ==========
            BattleManager.Log(victimPlayer, LogAction.PlayerKilled,
                $"Killer={killer.userName} ({killerName});KillerType={killer.characterType};Gold=-{drops.gold};Items={drops.equipments.Count};Location={victimPlayer.transform.position.x:F1},{victimPlayer.transform.position.y:F1})");

            // Log each item dropped
            foreach (var item in drops.equipments)
            {
                Card card = DataHolder.Instance().GetData<Card>(item.itemId);
                BattleManager.Log(victimPlayer, LogAction.ItemDropOnDeath,
                    $"Type:{item.equipmentType}|Item:{(card != null ? card.GetName(0) : item.itemId.ToString())}|Rare:{item.rareType}|Lv:{item.level}|Killer:{killer.userName}",
                    item.ToJson());
            }

            // Log gold lost
            if (drops.gold > 0)
            {
                BattleManager.Log(victimPlayer, LogAction.GoldLostOnDeath,
                    $"Killer={this.userName} ({this.characterName})",
                    value: drops.gold.ToString());
            }
            // ========== END Player Death Logging ==========


            // ========== 🆕 LOGGING: Killer Loot ==========
            if (killer is PlayerBehavior kBehavior && killer.characterType == CharacterType.Player)
            {
                foreach (var item in loot.equipments)
                {
                    Card card = DataHolder.Instance().GetData<Card>(item.itemId);
                    BattleManager.Log(kBehavior, LogAction.ItemLootFromKill,
                        $"Type:{item.equipmentType}|Item:{(card != null ? card.GetName(0) : item.itemId.ToString())}|Rare:{item.rareType}|Lv:{item.level}|From:{victimPlayer.userName}",
                        item.ToJson());
                }
            }
            // ========== END Killer Loot Logging ==========
        }

        void HandleKillBuiding(CharacterBehavior killer, PlayerBehavior victim)
        {
#if ENABLE_SERVER
            if (BattleManager.IsFinalWar && victim.mobId == GameConst.MAIN_BUILDING_ID)
            {
                FinalWarManager.Instance?.Capture(killer, victim);
                return;
            }
#endif
            float clanRaidPower = victim.GetPower();
            var victimClan = BattleManager.instance.GetClanData(victim.clanId);
            TryAwardClanRaidPoint(killer, victim, victimClan, clanRaidPower);
            if (victimClan != null)
            {
                BattleManager.LogClan(
                    victimClan,
                    LogAction.ClanDestroyBuilding,
                    $"BuildingId:{victim.mobId}|DestroyedBy:{killer.userName}|KillerName:{killer.characterName}",
                    value: "1");
            }

            // ========== 🆕 LOGGING: Building Destroyed ==========
            BattleManager.Log((PlayerBehavior)victim, LogAction.BuildingDestroyed,
                $"BuildingType={victim.mobId};Killer={killer.characterName};KillerType={killer.characterType};ClanId={victim.clanId}",
                $"Location=({victim.transform.position.x:F1},{victim.transform.position.y:F1})");
            // ========== END Building Destroyed Logging ==========

            if (victim.mobId == GameConst.MAIN_BUILDING_ID && this.clanId != "")
            {
                VillageData villageData = WorldManager.Instance.GetOrcVillageData(victim.transform.position.ToVector2Int());

                ClanData clanData = BattleManager.instance.GetClanData(this.clanId);

                if (clanData != null && villageData != null && IsUserClan(clanData.clanName))
                {
                    ClanData targetClanData = BattleManager.instance.GetClanData(victim.clanId);
                    string orcClanName = GameConst.ORC_CLAN_KEY + villageData.id + "_" + BattleManager.instance.serverConfig.seasonId;
                    string previousOwner = victim.clanId;
                    bool capturedVillage = false;
                    int targetTrophyBeforeDestroy = targetClanData != null ? targetClanData.trophy : 0;

                    var abandondateTotalHour = (System.DateTime.Now - DataUtils.StringToTime(clanData.abandondate)).TotalHours;
                    bool canAbandondate = clanData.abandondate == "" ||
                                         (abandondateTotalHour >= BattleManager.instance.gameDataConfig.durationCaptureVillageAfterAbanndon);

                    //Deduct Royalty
                    int deductRoyalty = 5;
#if ENABLE_SERVER_TEST
                    deductRoyalty = 10;
#endif
                    //TODO: Module ability
                    var mainSkill = victim.GetComponentInChildren<MainBuildingSkill>();
                    if (mainSkill != null) { mainSkill.Sub(deductRoyalty); }
                    else
                    {
                        BattleManager.Log(GameLogType.Error, "[CharacterBehavior] ReductRoyalty error. MainBuildingSkill not found");
                    }

                    if (BattleManager.IsTournament && targetClanData != null && targetTrophyBeforeDestroy != 0)
                    {
                        int lostTrophy = targetTrophyBeforeDestroy;
                        targetClanData.trophy = 1;
                        BattleManager.instance.SaveClanData(targetClanData);
                        BattleManager.instance.CheckTopClans(targetClanData);
                        BattleManager.LogClan(
                            targetClanData,
                            LogAction.ClanTrophy,
                            $"Event:TournamentMainBuildingDestroyed|Opponent:{clanData.clanName}|NewTrophy:{targetClanData.trophy}",
                            value: (-(lostTrophy - 1)).ToString());
                    }

                    if (BattleManager.IsTournament && targetClanData != null && targetClanData.clanName != orcClanName && targetTrophyBeforeDestroy > 1)
                    {
                    }

                    if ((clanData.DontHaveVillage || clanData.GetBuildingNumber == 0)
                        && clanData.score >= BattleManager.instance.gameDataConfig.minimumVillageScore
                        && this.GetMemberRole() != MemberRole.Member && victim.GetKillBossNumber() <= 0)
                    //&& (clanData.abandondate == "" || (System.DateTime.Now - DataUtils.StringToTime(clanData.abandondate)).TotalHours >= BattleManager.instance.durationCaptureVillageAfterAbanndon))
                    {
                        if (targetClanData != null)
                        {
                            if (targetClanData.clanName == GameConst.ORC_CLAN_KEY + villageData.id + "_" + BattleManager.instance.serverConfig.seasonId)
                                EventManager.instance.DisableOrcInVillage(villageData.id);
                            targetClanData.villageId = "";
                            targetClanData.clanSlot = 0;
                            targetClanData.clanBuildings.Clear();
                            //Reset Clan Trophy
                            if (BattleManager.IsTournament)
                                targetClanData.trophy = 0;
                            // Ordinary village loss is settled once by TrySettleDeathTrophy.
                            // Tournament retains its original reset above.
                            BattleManager.instance.CheckTopClans(targetClanData);
                            BattleManager.instance.SaveClanData(targetClanData);
                            BattleManager.LogClan(
                                targetClanData,
                                LogAction.ClanVillageLost,
                                $"VillageId:{villageData.id}|LostTo:{clanData.clanName}",
                                value: "1");
                        }


                        clanData.clanBuildings.Clear();
                        clanData.villageId = villageData.id;

                        //TODO: Module ability
                        if (mainSkill != null)
                        {
                            int maxRoyalty = BattleManager.instance != null ? BattleManager.instance.GetMaxRoyalty() : GameConst.MAX_ROYALTY;
                            mainSkill.Add(maxRoyalty);
                        }

                        ReviveBuilding(victim);


                        foreach (var building in villageData.villageBuildings)
                        {
                            PlayerBehavior buildingBehavior = BattleManager.instance.GetPlayerBehavior(BattleManager.instance.serverConfig.seasonId.ToString() + "_" + building.Value.id + "_" + BattleManager.instance.serverConfig.serverIndex);
                            if (buildingBehavior != null)
                            {
                                clanData.clanBuildings.Add(buildingBehavior.userName);
                                buildingBehavior.UpdateClanId(clanData.clanName);
                                ReviveBuilding(buildingBehavior);
                                buildingBehavior.SetCharacterState(CharacterState.Idle);
                                buildingBehavior.preparationSafeTime = 0;
                                //buildingBehavior.protectionTime = 0;
                                buildingBehavior.UpdateLandData(true);
                                foreach (Equipment equipment in buildingBehavior.characterEquipments.GetEquipments())
                                {
                                    clanData.UpdateClanSlot(equipment);
                                }
                                BattleManager.instance.SavePlayerData(buildingBehavior);
                            }
                        }

                        clanData.villageDate = DataUtils.TimeToString(System.DateTime.Now);

                        foreach (var member in clanData.GetClanMembers())
                        {
                            PlayerBehavior clanMemberBehavior = BattleManager.instance.GetPlayerBehavior(member.playerName);
                            if (clanMemberBehavior != null && clanMemberBehavior.connectionToClient != null)
                            {
                                var response = new ClanResponse()
                                {
                                    ResponseType = ClanResponseType.Get,
                                    ClanData = clanData,
                                    ErrorCode = ErrorCode.Success
                                };
                                clanMemberBehavior.RpcGetClanData(clanMemberBehavior.connectionToClient, response);
                            }
                        }
                        BattleManager.LogClan(
                            clanData,
                            LogAction.ClanCaptureVillage,
                            $"VillageId:{villageData.id}|CapturedBy:{userName}|Character:{characterName}",
                            value: "1");
                        capturedVillage = true;
                    }

                    //Get Trophy & diamond
                    if (clanData.villageId != "" && targetClanData != null
                        && targetClanData.clanName != orcClanName
                        )
                    {

                        var diamondStolen = Mathf.RoundToInt(targetClanData.diamond * 0.1f);
                        var diamondReward = diamondStolen / 2;

                        targetClanData.diamond -= diamondStolen;
                        clanData.diamond += diamondReward;

                        BattleManager.LogClan(
                            clanData,
                            LogAction.ClanDiamond,
                            $"Event:VillageCapture|Opponent:{targetClanData.clanName}|Change:+{diamondReward}|NewDiamond:{clanData.diamond}",
                            value: diamondReward.ToString());

                        BattleManager.LogClan(
                            targetClanData,
                            LogAction.ClanDiamond,
                            $"Event:VillageCapture|Opponent:{clanData.clanName}|Change:-{diamondStolen}|NewDiamond:{targetClanData.diamond}",
                            value: (-diamondStolen).ToString());

                        BattleManager.instance.SaveClanData(targetClanData);


                    }

                    BattleManager.instance.SaveClanData(clanData);
                    if (capturedVillage && !BattleManager.IsTournament)
                        BattleManager.instance.gameLogicBehavior.ServerSendMainBuildingCaptureAnnouncement(
                            killer.characterType == CharacterType.Player ? killer.characterName : null,
                            clanData.clanName, previousOwner, villageData.id, previousOwner == orcClanName);
                }
            }
            else if (victim.mobId == GameConst.MACHANDISE_BUILDING)
            {
                var merchandiseSkill = victim.GetComponentInChildren<MerchandiseSkill>();
                if (merchandiseSkill.HasReachedDestination() == false)
                {
                    merchandiseSkill.OnDead();
                    victim.AddChestNumber(1);

                    if (string.IsNullOrEmpty(this.clanId) == false)
                    {
                        ClanData clanData = BattleManager.instance.GetClanData(this.clanId);
                        if (clanData != null && victim.GetCraftNumber() >= victim.GetChestNumber())
                        {
                            var merchandiseReward = BattleManager.instance.gameDataConfig.clanMerchandiseDiamondReward / 2;
                            clanData.score += merchandiseReward;
                            clanData.diamond += merchandiseReward;
                            BattleManager.LogClan(
                                clanData,
                                LogAction.ClanDiamond,
                                $"Event:MerchandiseIntercept|Opponent:{victim.clanId}|Character:{characterName}|Change:+{merchandiseReward}|NewDiamond:{clanData.diamond}",
                                value: merchandiseReward.ToString());
                            BattleManager.LogClan(
                                clanData,
                                LogAction.ClanScore,
                                $"Event:MerchandiseIntercept|Opponent:{victim.clanId}|Character:{characterName}|Change:+{merchandiseReward}|NewScore:{clanData.score}",
                                value: merchandiseReward.ToString());
                            BattleManager.instance.SaveClanData(clanData);
                        }

                        if (clanData != null && IsUserClan(clanData.clanName) == false)
                        {
                            BattleManager.instance.AddCurrencyData(this.userName, new CurrencyData
                            {
                                currencyId = (int)CurrencyID.PlayerTrophy,
                                value = 5
                            });
                            BattleManager.LogClan(
                                clanData,
                                LogAction.ClanTrophy,
                                $"Event:MerchandiseIntercept|Opponent:{victim.clanId}|Character:{characterName}",
                                value: "5");
                        }
                    }
                }
            }
            else if (victim.mobId == GameConst.DIAMOND_MINER_BUILDING_ID && this.clanId != "")
            {
                ClanData clanData = BattleManager.instance.GetClanData(this.clanId);
                ClanData targetClanData = BattleManager.instance.GetClanData(victim.clanId);

                if (clanData != null && targetClanData != null && IsUserClan(this.clanId))
                {
                    var minerDiamondStolen = Mathf.RoundToInt(targetClanData.diamond * 0.05f);
                    var minerDiamondReward = minerDiamondStolen / 2;

                    targetClanData.diamond -= minerDiamondStolen;
                    clanData.diamond += minerDiamondReward;

                    BattleManager.LogClan(
                        clanData,
                        LogAction.ClanDiamond,
                        $"Event:DiamondMinerRaid|Opponent:{targetClanData.clanName}|Change:+{minerDiamondReward}|NewDiamond:{clanData.diamond}",
                        value: minerDiamondReward.ToString());

                    BattleManager.LogClan(
                        targetClanData,
                        LogAction.ClanDiamond,
                        $"Event:DiamondMinerRaid|Opponent:{clanData.clanName}|Change:-{minerDiamondStolen}|NewDiamond:{targetClanData.diamond}",
                        value: (-minerDiamondStolen).ToString());

                    BattleManager.instance.SaveClanData(clanData);
                    BattleManager.instance.SaveClanData(targetClanData);
                }
            }
            else if (victim.mobId == GameConst.BUFF_TROPHY_TOWER_ID && this.clanId != "" && BattleManager.IsTournament == false)
            {
                ClanData clanData = BattleManager.instance.GetClanData(this.clanId);
                ClanData targetClanData = BattleManager.instance.GetClanData(victim.clanId);

                if (clanData != null && targetClanData != null && IsUserClan(this.clanId))
                {
                    var trophyLost = 1;
                    if (targetClanData.trophy < 1 || Mathf.Abs(clanData.trophy - targetClanData.trophy) > 50)
                        trophyLost = 0;


                    BattleManager.LogClan(
                        clanData,
                        LogAction.ClanTrophy,
                        $"Event:BuffTowerRaid|Opponent:{targetClanData.clanName}|NewTrophy:{clanData.trophy}",
                        value: trophyLost.ToString());

                    BattleManager.LogClan(
                        targetClanData,
                        LogAction.ClanTrophy,
                        $"Event:BuffTowerRaid|Opponent:{clanData.clanName}|NewTrophy:{targetClanData.trophy}",
                        value: (-trophyLost).ToString());

                    BattleManager.instance.SaveClanData(clanData);
                    BattleManager.instance.SaveClanData(targetClanData);
                }
            }
            else if (victim.mobId == GameConst.STORAGE_BUILDING_ID || ClanPetStableHelper.IsStableBuilding(victim))
            {
                var drops = victim.GetDeathDrops();
                var loot = CalculateLoot(drops, victim);

                victim.LostEquipments(drops.equipments, drops.gold);

                if (ClanPetStableHelper.IsStableBuilding(victim))
                {
                    foreach (var equipment in loot.equipments)
                    {
                        ClanPetStableHelper.ResetEggStatsForLoot(equipment);
                    }
                }

                this.AddEquipmentsOnKill(loot.equipments, loot.currency);

                var storageClan = BattleManager.instance.GetClanData(victim.clanId);
                if (storageClan != null)
                {
                    string lostItems = drops.equipments != null && drops.equipments.Count > 0
                        ? string.Join(",", drops.equipments.Select(e => $"{e.itemId}:{(int)e.rareType}:{e.level}"))
                        : string.Empty;
                    BattleManager.LogClan(
                        storageClan,
                        LogAction.ClanStorageLost,
                        $"Event:StorageDestroyed|LostEquip:{drops.equipments.Count}|LostGold:{drops.gold}|DestroyedBy:{killer.userName}",
                        actionObject: lostItems,
                        value: drops.gold.ToString());
                }

                // ========== 🆕 LOGGING: Killer Loot ==========
                if (killer is PlayerBehavior kBehavior && killer.characterType == CharacterType.Player)
                {
                    foreach (var item in loot.equipments)
                    {
                        Card card = DataHolder.Instance().GetData<Card>(item.itemId);
                        BattleManager.Log(kBehavior, LogAction.ItemLootFromKill,
                            $"Type:{item.equipmentType}|Item:{(card != null ? card.GetName(0) : item.itemId.ToString())}|Rare:{item.rareType}|Lv:{item.level}|From:{victim.userName}|Clan:{victim.clanId})",
                            item.ToJson());
                    }
                }
                // ========== END Killer Loot Logging ==========
            }
        }


        void ReviveBuilding(PlayerBehavior building)
        {
#if ENABLE_SERVER
            building.FullyHeal(1f);
            if (characterType == CharacterType.Building && this is PlayerBehavior buildingBehavior && buildingBehavior.clanId.IsNonEmpty())
            {
                var clanData = BattleManager.instance.GetClanData(buildingBehavior.clanId);
                if (clanData != null)
                {
                    BattleManager.LogClan(
                        clanData,
                        LogAction.ClanBuildingRevive,
                        $"Building:{buildingBehavior.characterName}|MobId:{buildingBehavior.mobId}|ClanDiamond:{clanData.diamond}|By:{buildingBehavior.userName}",
                        value: "0");
                }
            }
#endif
        }
    }

    public static bool IsUserClan(string clanName)
    {
        return clanName != string.Empty && clanName != GameConst.ASSASIN_CLAN_KEY && clanName != GameConst.ROYALFORCE_CLAN_KEY &&
            clanName != EventManager.ORC_REVENGE_CLAN_ID;
    }

    public static bool IsNpcClan(string clanName)
    {
        return IsUserClan(clanName) == false;
    }

    public int GetDiamondRate()
    {
        int n = Random.Range(0, 100);
        if (diamondRate <= 1)
            return 1;
        else if (diamondRate <= 2)
        {
            if (n < (diamondRate - 1) * 100)
                return 2;
            else
                return 1;
        }
        else
        {
            if (n < (diamondRate - 2) * 100)
                return 3;
            else
                return 2;
        }
    }

    private void LogicLootDiamondKey(PlayerBehavior targetBehavior)
    {
#if ENABLE_SERVER
        var keyBehavior = ChestKeyManager.Instance.GetKey(WorldManager.CENTER_LAND_NAME);

        if (keyBehavior == null) return;
        if (keyBehavior.owner != targetBehavior) return;

        bool dontHaveSlotForKey = false;

        if (characterType == CharacterType.Player)
        {
            var equipmentCount = GetComponent<CharacterInventory>().GetEquipmentCount();
            var slot = GetComponent<PlayerBehavior>().GetFinalInventorySlot();
            dontHaveSlotForKey = equipmentCount >= slot;
        }

        if (characterType == CharacterType.Mob || dontHaveSlotForKey)
        {
            targetBehavior.GetLimitedEquipmentOnDead();

            NetworkServer.Destroy(keyBehavior.gameObject);

            BattleManager.instance.SendServerNotificationToAll(targetBehavior.characterName, GameConst.DIALOG_SERVER_LOST_KEY);
        }
        else if (characterType == CharacterType.Player)
        {
            this.AddLimitedEquipmentsOnKill(targetBehavior.GetLimitedEquipmentOnDead());

            var chest = ChestKeyManager.Instance.GetChest(WorldManager.CENTER_LAND_NAME);
            if (chest != null) chest.ResetTime(targetBehavior);

            keyBehavior.owner = (PlayerBehavior)this;
            keyBehavior.ownerId = this.userName;
            keyBehavior.Reset();

            BattleManager.instance.SendServerNotificationToAll(characterName, GameConst.DIALOG_SERVER_CAPTURE_KEY);

        }
#endif
    }

    private void LogicLootUndeadKey(CharacterBehavior targetBehavior, Equipment keyEquipment)
    {
#if ENABLE_SERVER
        var keyBehavior = ChestKeyManager.Instance.GetKey(WorldManager.UNDEAD_LAND_NAME);
        if (keyBehavior == null) return;

        bool dontHaveSlotForKey = false;

        if (characterType == CharacterType.Player)
        {
            var equipmentCount = GetComponent<CharacterInventory>().GetEquipmentCount();
            var slot = GetComponent<PlayerBehavior>().GetFinalInventorySlot();
            dontHaveSlotForKey = equipmentCount >= slot;
        }

        if (characterType == CharacterType.Mob || dontHaveSlotForKey)
        {
            targetBehavior.GetLimitedEquipmentOnDead();

            NetworkServer.Destroy(keyBehavior.gameObject);

            BattleManager.instance.SendServerNotificationToAll(targetBehavior.characterName, GameConst.DIALOG_SERVER_LOST_UNDEAD_KEY);
        }
        else if (characterType == CharacterType.Player)
        {
            this.AddLimitedEquipmentsOnKill(targetBehavior.GetLimitedEquipmentOnDead());

            keyBehavior.owner = (PlayerBehavior)this;
            keyBehavior.ownerId = userName;
            keyBehavior.Reset();

            var chest = ChestKeyManager.Instance.GetChest(WorldManager.UNDEAD_LAND_NAME);
            if (chest != null)
            {
                chest.ResetTime((PlayerBehavior)targetBehavior);

                if (chest.keyBehavior == keyBehavior &&
                    (transform.position - chest.transform.position).sqrMagnitude <= GameConst.OPEN_CHEST_DISTANCE * GameConst.OPEN_CHEST_DISTANCE)
                {
                    SetCharacterState(CharacterState.OpenChest);
                }
            }

            BattleManager.instance.SendServerNotificationToAll(characterName, GameConst.DIALOG_SERVER_CAPTURE_UNDEAD_KEY);
        }
#endif
    }

    /*
    public void AddTrophy(CharacterBehavior targetBehavior)
    {

        //Sẽ chuyển sang pvp player point 
        return;

        if (characterType != CharacterType.Player)
        {
            return;
        }

        if (BattleManager.IsTournament)
        {
            return;
        }

        int winTrophy = BattleManager.instance.GetWinTrophy(this.GetTrophy(), targetBehavior.GetTrophy());

        if (this.clanId == GameConst.ROYALFORCE_CLAN_KEY && targetBehavior.clanId == GameConst.ASSASIN_CLAN_KEY)
        {
            winTrophy *= 2;
        }

        if (targetBehavior.GetTrophy() > -3)
        {
            if (this.GetTrophy() < BattleManager.instance.gameDataConfig.maxPlayerTrophy - winTrophy)
                this.SetTrophy(this.GetTrophy() + winTrophy);
            else if (this.GetTrophy() < BattleManager.instance.gameDataConfig.maxPlayerTrophy)
                this.SetTrophy(BattleManager.instance.gameDataConfig.maxPlayerTrophy);
        }

        targetBehavior.SetTrophy(targetBehavior.GetTrophy() - winTrophy - 1);
        if (targetBehavior.GetTrophy() < -5)
            targetBehavior.SetTrophy(-5);
        BattleManager.instance.CheckTopPlayers((PlayerBehavior)this);
        BattleManager.instance.CheckTopPlayers((PlayerBehavior)targetBehavior);
        BattleManager.Log((PlayerBehavior)targetBehavior, LogAction.TrophyLostOnDeath, winTrophy.ToString(), $"Killer={this.userName} ({this.characterName})");
    }
    */
    /*
    public bool AddTrophy(int value, bool isArena = false)
    {
        //Sẽ chuyển sang pvp player point 
        return false;

        if (characterType != CharacterType.Player)
        {
            return false;
        }    

        if (BattleManager.IsTournament)
        {
            return false;
        }    

        // if (IsCompletedTutorial() == false)
        // {
        //     return false;
        // }

        if (isArena)
            this.SetTrophy(this.GetTrophy() + value);
        else
        {
            if (this.GetTrophy() < BattleManager.instance.gameDataConfig.maxPlayerTrophy - value)
                this.SetTrophy(this.GetTrophy() + value);
            else if (this.GetTrophy() < BattleManager.instance.gameDataConfig.maxPlayerTrophy)
                this.SetTrophy(BattleManager.instance.gameDataConfig.maxPlayerTrophy);
        }

        BattleManager.instance.CheckTopPlayers((PlayerBehavior)this);
        return true;
    }
    */

    public bool IsCompletedTutorial()
    {
        var characterData = BattleManager.instance.GetCharacterData(userName);
        if (characterData == null)
            return false;

        if (characterData.questNumber > 0)
            return true;

        if (characterData.progress > GameConst.MAX_BEGINNER_PROGRESS_POINT)
            return true;

        return false;
    }


    public float GetCloneScore()
    {
        float score = 0;
        score += GetKillBossNumber() * 10;
        score += GetCraftNumber() * 10;
        score += GetChestNumber() * 10;
        score += GetClanScore();
        score += GetKillMobNumber() / 3;
        score += GetKillPlayerNumber() / 2;
        if (GetTrophy() > 50)
            score += GetTrophy() * 10;
        return score;
    }

    protected static float ScaleNonNegativeCombatStat(float value)
    {
        if (value <= 0f || float.IsNaN(value))
        {
            return 0f;
        }

        return Mathf.Pow(value, 0.7f);
    }

    protected static float GetFuryTriggerChance(float fury)
    {
        if (fury <= 50f || float.IsNaN(fury))
            return 0f;

        return Mathf.Min((fury - 50f) / 550f * 0.7f, 1f);
    }

    public int GetDamage(CharacterBehavior targetBehavior, float? overrideDamage = null)
    {
#if ENABLE_SERVER_TEST
        // Bots have no client connection; keep damage identical and omit owner-only cosmetic RPCs.
        void RpcDodge(NetworkConnectionToClient recipient, Vector2 position, bool enemy)
        { if (recipient != null) this.RpcDodge(recipient, position, enemy); }
        void RpcLifeSteal(NetworkConnectionToClient recipient, Vector2 position, bool enemy, int value)
        { if (recipient != null) this.RpcLifeSteal(recipient, position, enemy, value); }
        void RpcCounterAttack(NetworkConnectionToClient recipient, Vector2 position, bool enemy, int value)
        { if (recipient != null) this.RpcCounterAttack(recipient, position, enemy, value); }
        void RpcNormalDamage(NetworkConnectionToClient recipient, Vector2 position, bool enemy, int value)
        { if (recipient != null) this.RpcNormalDamage(recipient, position, enemy, value); }
        void RpcFuryDamage(NetworkConnectionToClient recipient, Vector2 position, bool enemy, int value)
        { if (recipient != null) this.RpcFuryDamage(recipient, position, enemy, value); }
        void RpcCriticalDamage(NetworkConnectionToClient recipient, Vector2 position, bool enemy, int value)
        { if (recipient != null) this.RpcCriticalDamage(recipient, position, enemy, value); }
        void RpcCriticalBonusDamage(NetworkConnectionToClient recipient, Vector2 position, bool enemy, int value)
        { if (recipient != null) this.RpcCriticalBonusDamage(recipient, position, enemy, value); }
#endif
        if (characterType == CharacterType.Building && targetBehavior != null && targetBehavior.characterType == CharacterType.Trap)
            return 0;
        if (IsMobTrapOrSiegeInteraction(this, targetBehavior)) return 0;
        if (FinalWarManager.BlocksCombat(this, targetBehavior)) return 0;
        int n = Random.Range(1, 100);
        float damage = overrideDamage ?? this.statData.GetStat(StatType.Damage).value;

        //Deal damage by ability
        if (damage == 0)
        {
            return 0;
        }

        if (ShouldBlockDamageByTemporaryInvincible(targetBehavior))
        {
            return 0;
        }

#if ENABLE_SERVER
        Vector2 target = targetBehavior.transform.position;

        float furyChance = GetFuryTriggerChance(statData.GetStat(StatType.Fury).value);
        bool furyTriggered = characterType == CharacterType.Player &&
                             characterHealth != null && GetHealth() > 0 &&
                             characterHealth.GetRatio() < 0.1f &&
                             furyChance > 0f && Random.value < furyChance;

        //Dodge
        if (!furyTriggered && targetBehavior.dodge > 0)
        {
            float opponentDodge = targetBehavior.dodge - this.accuracy * 0.9f;
            if (n < opponentDodge)
            {
                //Trong trường hợp mục tiêu né thành công, đòn đánh này vẫn trả dmg phản.
                int conterDmgValue = (int)GetCounterDamage();
                damage = conterDmgValue;
                ResetCounterDamage();

                //Rpc để client nhìn thấy mục tiêu né
                //Rpc để client nhìn thấy vẫn trả dmg phản vào mục tiêu
                #region Rpc Effect

                //Player vs Player
                if (this.characterType == CharacterType.Player && targetBehavior.characterType == CharacterType.Player)
                {
                    RpcDodge(this.connectionToClient, target, true);
                    RpcDodge(targetBehavior.connectionToClient, target, false);
                    RpcDodgeToPlayerInRegisterZone(target);
                    if (conterDmgValue > 0)
                    {
                        RpcCounterAttack(this.connectionToClient, target, false, conterDmgValue);
                        RpcCounterAttack(targetBehavior.connectionToClient, target, true, conterDmgValue);

                        RpcDamageToPlayerIngredisterZone(RpcCounterAttack, target, conterDmgValue);
                    }
                }
                //Player vs mob || building
                else if (this.characterType == CharacterType.Player &&
                    (targetBehavior.characterType == CharacterType.Mob || targetBehavior.characterType == CharacterType.Building))
                {
                    RpcDodge(this.connectionToClient, target, true);

                    if (conterDmgValue > 0)
                    {
                        RpcCounterAttack(this.connectionToClient, target, false, conterDmgValue);
                    }
                }
                //Mob||Building vs Player
                else if ((this.characterType == CharacterType.Mob || this.characterType == CharacterType.Building)
                         && targetBehavior.characterType == CharacterType.Player)
                {
                    RpcDodge(targetBehavior.connectionToClient, target, false);
                    if (conterDmgValue > 0)
                    {
                        RpcCounterAttack(targetBehavior.connectionToClient, target, true, conterDmgValue);
                    }
                }
                #endregion

                return (int)damage;
            }
        }

        n = Random.Range(1, 100);
        float effectivePoisonStat = GetEffectiveStatusStat(poisonStat, targetBehavior);
        float effectiveFireStat = GetEffectiveStatusStat(fireStat, targetBehavior);
        float effectiveFreezeStat = GetEffectiveStatusStat(freezeStat, targetBehavior);
        float effectiveWindStat = GetEffectiveStatusStat(windStat, targetBehavior);

        //Poison
        if (effectivePoisonStat > 0 && n < effectivePoisonStat / 6f - targetBehavior.defense / 10f && targetBehavior.DontHaveEffect(GameConst.POISON_INGREDIENT_ID))
        {
            //random trigger
            //duration
            int r = Random.Range(0, 100);

            int duration = 10;
            float reduction = targetBehavior.defense / 450f - this.accuracy / 600f + Mathf.Min(0.5f, targetBehavior.healStat / 600);
            if (reduction < 0)
                reduction = 0;
            if (reduction > 1)
                reduction = 1;
            int slowMoveSpeedPercent = (int)(1 + 50 * Mathf.Min(effectivePoisonStat, 600) / 450 * (1f - reduction));
            int dmgPerSecond = (int)(effectivePoisonStat * targetBehavior.characterHealth.maxValue / 15000 * (1f - reduction));

            if (targetBehavior.characterType == CharacterType.Mob)
            {
                dmgPerSecond = dmgPerSecond / 5;
                slowMoveSpeedPercent = slowMoveSpeedPercent / 2;
            }

            var poisonDotEffect = new Effect()
            {
                effectId = GameConst.POISON_INGREDIENT_ID,
                finalWarSourceClan = BattleManager.IsFinalWar ? FinalWarManager.Principal(this).clanId : null,
                stats = new Stat[]
                {
                    new Stat()
                    {
                        statDataType = StatDataType.Normal,
                        statType = StatType.PoisonDoT,
                        value = dmgPerSecond,
                    },

                    new Stat()
                    {
                        statDataType = StatDataType.Normal,
                        statType = StatType.Speed,
                        value = -slowMoveSpeedPercent,
                    }
                },
                endTime = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(duration)),
            };

            targetBehavior.characterEffects.AddEffect(poisonDotEffect);
            targetBehavior.characterEffects.OnUpdateEffects();
        }

        //Fire
        n = Random.Range(1, 100);
        if (effectiveFireStat > 0 && n < effectiveFireStat / 7f - targetBehavior.dodge / 10 && targetBehavior.DontHaveEffect(GameConst.FIRE_INGREDIENT_ID))
        {
            //Same poison
            float fireStatDamage = Mathf.Clamp(effectiveFireStat - targetBehavior.freezeStat * 20, 0, effectiveFireStat);

            int dmgPerSecond = (int)fireStatDamage / 2;
            int duration = 5 + (int)(effectiveFireStat / 120 * (1 + targetBehavior.defense / 100));

            //Same freeze
            float nerfDefPercent = fireStatDamage / 12;

            if (targetBehavior is MobBehavior)
            {
                duration /= 2;
                dmgPerSecond /= 5;
            }

            if (duration >= 0.5f)
            {
                var effect = new Effect()
                {
                    effectId = GameConst.FIRE_INGREDIENT_ID,
                    finalWarSourceClan = BattleManager.IsFinalWar ? FinalWarManager.Principal(this).clanId : null,
                    stats = new Stat[]
                    {
                        new()
                        {
                            statDataType = StatDataType.Normal,
                            statType = StatType.FireDot,
                            value = dmgPerSecond,
                        },
                    },

                    endTime = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(duration)),
                };

                if (nerfDefPercent > 0)
                {
                    var nerfDef = new Stat()
                    {
                        statDataType = StatDataType.Multipler,
                        statType = StatType.Defense,
                        value = -nerfDefPercent,
                    };

                    effect.stats = DataUtils.Add(nerfDef, effect.stats);
                }

                targetBehavior.characterEffects.AddEffect(effect);
                targetBehavior.characterEffects.OnUpdateEffects();
            }
        }

        //Summon
        if (summonStat > 100)
        {
            float triggerChance = 1f + (summonStat - 100f) / 55f; // Xác suất tính theo %

            if(summonStat > 600)
            {
                triggerChance = 10f + (summonStat - 600f) / 100;
            }

            float randomRoll = Random.Range(0f, 1000f);

            if (triggerChance * 10 > randomRoll)
            {
                TriggerSummonStat(targetBehavior);
            }
        }

        //Freeze
        if (effectiveFreezeStat > 0 && targetBehavior.DontHaveEffect(GameConst.FREEZE_INGREDIENT_ID))
        {
            int r = Random.Range(0, 100);

            if (r < effectiveFreezeStat - targetBehavior.dodge / 20)
            {
                //600 freeze stat = 6s duration
                var duration = Mathf.Clamp(effectiveFreezeStat / 5, 2, 10);
                float reduceRate = 1 + targetBehavior.defense / 120;
                duration = duration / reduceRate;
                if (targetBehavior is MobBehavior)
                {
                    duration = duration / 5;
                }

                if (duration >= 0.5f)
                {
                    var effect = new Effect()
                    {
                        effectId = GameConst.FREEZE_INGREDIENT_ID,
                        stats = new Stat[]
                        {
                            new()
                            {
                                statDataType = StatDataType.Normal,
                                statType = StatType.FreezeDoT,
                                value = effectiveFreezeStat,
                            }
                        },
                        endTime = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(duration)),
                    };

                    targetBehavior.characterEffects.AddEffect(effect);
                    targetBehavior.characterEffects.OnUpdateEffects();
                }
            }
        }

        //Wind
        n = Random.Range(1, 100);
        if (effectiveWindStat > 0 && targetBehavior.DontHaveEffect(GameConst.WIND_INGREDIENT_ID))
        {
            float triggerChance = effectiveWindStat / 7f;

            if (n < triggerChance)
            {
                float reductionPercent = (effectiveWindStat / 600f) * 70f;
                reductionPercent = Mathf.Clamp(reductionPercent, 0f, 70f);

                float duration = 10f;

                var windEffect = new Effect()
                {
                    effectId = GameConst.WIND_INGREDIENT_ID,
                    stats = new Stat[]
                    {
                        new Stat()
                        {
                            statDataType = StatDataType.Multipler,
                            statType = StatType.Accuracy,
                            value = -reductionPercent,
                        },
                        new Stat()
                        {
                            statDataType = StatDataType.Multipler,
                            statType = StatType.Dodge,
                            value = -reductionPercent,
                        }
                    },
                    endTime = DataUtils.TimeToString(System.DateTime.Now.AddSeconds(duration)),
                };

                targetBehavior.characterEffects.AddEffect(windEffect);
                targetBehavior.characterEffects.OnUpdateEffects();
            }
        }

        bool isCritical = false;

        n = Random.Range(1, 100);
        if (n < critical)
        {
            isCritical = true;
            damage *= 2;
        }

        float d = targetBehavior.defense;
        if (this.accuracy > targetBehavior.dodge)
            d = d - (this.accuracy - targetBehavior.dodge) / 2.5f;

        if (!furyTriggered && d > 0)
            damage = damage * (1f - d / 100);

        //Critical Bonus
        if (isCritical && criticalBonus > 0)
        {
            var criticalBonusValue = criticalBonus * 2f;

            if (!furyTriggered)
            {
                //Player vs Player
                if (this.characterType == CharacterType.Player && targetBehavior.characterType == CharacterType.Player)
                {
                    RpcCriticalBonusDamage(this.connectionToClient, target, false, (int)criticalBonusValue);
                    RpcCriticalBonusDamage(targetBehavior.connectionToClient, target, true, (int)criticalBonusValue);

                    RpcDamageToPlayerIngredisterZone(RpcCriticalBonusDamage, target, (int)criticalBonusValue);
                }
                //Player vs mob || building
                else if (this.characterType == CharacterType.Player &&
                    (targetBehavior.characterType == CharacterType.Mob || targetBehavior.characterType == CharacterType.Building))
                {
                    RpcCriticalBonusDamage(this.connectionToClient, target, false, (int)criticalBonusValue);
                }
                //Mob||Building vs Player
                else if ((this.characterType == CharacterType.Mob || this.characterType == CharacterType.Building)
                            && targetBehavior.characterType == CharacterType.Player)
                {
                    RpcCriticalBonusDamage(targetBehavior.connectionToClient, target, true, (int)criticalBonusValue);
                }
            }

            damage += criticalBonusValue;
        }

        if (damage < 1)
            damage = 1;

        int counterDmgValue = (int)GetCounterDamage();
        if (furyTriggered)
        {
            damage += counterDmgValue;
            damage *= 2;
        }

        if (this.lifeSteal > 0)
        {
            float randomLifeSteal = Random.Range(this.lifeSteal - 5, this.lifeSteal + 5);
            //Life Steal
            if (randomLifeSteal > 0 && targetBehavior.characterType != CharacterType.Building)
            {
                if (targetBehavior.characterType == CharacterType.Player)
                    randomLifeSteal += 10;

                var lifeStealValue = Mathf.Min((int)(damage * randomLifeSteal / 100), targetBehavior.GetHealth());
                this.characterHealth.AddValue(lifeStealValue);

                //Player vs Player
                if (this.characterType == CharacterType.Player && targetBehavior.characterType == CharacterType.Player)
                {
                    RpcLifeSteal(this.connectionToClient, transform.position, false, lifeStealValue);
                    RpcLifeSteal(targetBehavior.connectionToClient, transform.position, true, lifeStealValue);

                    RpcDamageToPlayerIngredisterZone(RpcCriticalBonusDamage, transform.position, lifeStealValue);

                }
                //Player vs mob || building
                else if (this.characterType == CharacterType.Player &&
                   (targetBehavior.characterType == CharacterType.Mob || targetBehavior.characterType == CharacterType.Building))
                {
                    RpcLifeSteal(this.connectionToClient, transform.position, false, lifeStealValue);
                }
                //Mob||Building vs Player
                else if ((this.characterType == CharacterType.Mob || this.characterType == CharacterType.Building)
                           && targetBehavior.characterType == CharacterType.Player)
                {
                    RpcLifeSteal(targetBehavior.connectionToClient, transform.position, true, lifeStealValue);
                }
            }
        }

        n = Random.Range(1, 100);

        //Counter
        if (this.characterType != CharacterType.Building && targetBehavior.counterAttack > 0 && n < targetBehavior.counterAttack)
        {
            float r = 0;
            if (this.dodge > targetBehavior.accuracy)
                r = (this.dodge - targetBehavior.accuracy) / 2f;
            targetBehavior.SetCounterDamage(damage * (1 - r / 100f));
        }

        //Damage not include critical bonus
        // Fury has its own presentation path. It takes precedence over the
        // normal/critical main-hit text while preserving the authoritative
        // critical calculation above.
        if (furyTriggered)
        {
            //Player vs Player
            if (this.characterType == CharacterType.Player && targetBehavior.characterType == CharacterType.Player)
            {
                RpcFuryDamage(this.connectionToClient, target, false, (int)damage);
                RpcFuryDamage(targetBehavior.connectionToClient, target, true, (int)damage);

                RpcDamageToPlayerIngredisterZone(RpcFuryDamage, target, (int)damage);
            }
            //Player vs mob || building
            else if (this.characterType == CharacterType.Player &&
                (targetBehavior.characterType == CharacterType.Mob || targetBehavior.characterType == CharacterType.Building))
            {
                RpcFuryDamage(this.connectionToClient, target, false, (int)damage);
            }
            //Mob||Building vs Player
            else if ((this.characterType == CharacterType.Mob || this.characterType == CharacterType.Building)
                       && targetBehavior.characterType == CharacterType.Player)
            {
                RpcFuryDamage(targetBehavior.connectionToClient, target, true, (int)damage);
            }
        }
        else if (isCritical)
        {
            float dmg = damage;
            if (criticalBonus > 0)
            {
                dmg -= criticalBonus * 2f;
            }

            //Player vs Player
            if (this.characterType == CharacterType.Player && targetBehavior.characterType == CharacterType.Player)
            {
                RpcCriticalDamage(this.connectionToClient, target, false, (int)dmg);
                RpcCriticalDamage(targetBehavior.connectionToClient, target, true, (int)dmg);

                RpcDamageToPlayerIngredisterZone(RpcCriticalBonusDamage, transform.position, (int)dmg);

            }
            //Player vs mob || building
            else if (this.characterType == CharacterType.Player &&
                (targetBehavior.characterType == CharacterType.Mob || targetBehavior.characterType == CharacterType.Building))
            {
                RpcCriticalDamage(this.connectionToClient, target, false, (int)dmg);
            }
            //Mob||Building vs Player
            else if ((this.characterType == CharacterType.Mob || this.characterType == CharacterType.Building)
                       && targetBehavior.characterType == CharacterType.Player)
            {
                RpcCriticalDamage(targetBehavior.connectionToClient, target, true, (int)dmg);
            }
        }
        else
        {
            //Player vs Player
            if (this.characterType == CharacterType.Player && targetBehavior.characterType == CharacterType.Player)
            {
                RpcNormalDamage(this.connectionToClient, target, false, (int)damage);
                RpcNormalDamage(targetBehavior.connectionToClient, target, true, (int)damage);

                RpcDamageToPlayerIngredisterZone(RpcNormalDamage, target, (int)damage);
            }
            //Player vs mob || building
            else if (this.characterType == CharacterType.Player &&
                (targetBehavior.characterType == CharacterType.Mob || targetBehavior.characterType == CharacterType.Building))
            {
                RpcNormalDamage(this.connectionToClient, target, false, (int)damage);
            }
            //Mob||Building vs Player
            else if ((this.characterType == CharacterType.Mob || this.characterType == CharacterType.Building)
                       && targetBehavior.characterType == CharacterType.Player)
            {
                RpcNormalDamage(targetBehavior.connectionToClient, target, true, (int)damage);
            }
        }


        #region Counter damage

        //Add counter dmg to final dmg
        if (!furyTriggered)
            damage += counterDmgValue;
        ResetCounterDamage();

        #region Rpc Effect
        if (!furyTriggered && counterDmgValue > 0)
        {
            //Player vs Player
            if (this.characterType == CharacterType.Player && targetBehavior.characterType == CharacterType.Player)
            {
                RpcCounterAttack(this.connectionToClient, target, false, counterDmgValue);
                RpcCounterAttack(targetBehavior.connectionToClient, target, true, counterDmgValue);

                RpcDamageToPlayerIngredisterZone(RpcCounterAttack, target, counterDmgValue);

            }
            //Player vs mob || building
            else if (this.characterType == CharacterType.Player &&
                (targetBehavior.characterType == CharacterType.Mob || targetBehavior.characterType == CharacterType.Building))
            {
                RpcCounterAttack(this.connectionToClient, target, false, counterDmgValue);
            }
            //Mob||Building vs Player
            else if ((this.characterType == CharacterType.Mob || this.characterType == CharacterType.Building)
                       && targetBehavior.characterType == CharacterType.Player)
            {
                RpcCounterAttack(targetBehavior.connectionToClient, target, true, counterDmgValue);
            }
        }
        #endregion

        #endregion
#endif
        return (int)damage;
    }

#if ENABLE_SERVER
    private float GetEffectiveStatusStat(float sourceStat, CharacterBehavior targetBehavior)
    {
        if (sourceStat <= 0 || targetBehavior == null)
            return sourceStat;

        float invincibleReduction = Mathf.Clamp(targetBehavior.invincibleStat, 0f, 600f) / 860f;
        return sourceStat * (1f - invincibleReduction);
    }

    private void TriggerSummonStat(CharacterBehavior targetBehavior)
    {
        // Chọn card dựa vào summonStat với hệ thống Weighted Random
        // Tính trọng số cho từng con dựa trên summonStat
        float weightCon1 = 0f;
        float weightCon2 = 0f;
        float weightCon3 = 0f;
        
        if (summonStat <= 600)
        {
            // Dưới 600: chỉ con 1
            weightCon1 = 1f;
        }
        else if (summonStat <= 1200)
        {
            weightCon2 = (summonStat - 600f) / summonStat; 
            weightCon1 = 600f/summonStat; 
        }
        else
        {
            weightCon3 = (summonStat - 1200f) / summonStat;
            weightCon2 = 600f / summonStat;
            weightCon1 = 600f / summonStat;
        }
        
        // Weighted random selection
        float totalWeight = weightCon1 + weightCon2 + weightCon3;
        float roll = Random.Range(0f, totalWeight);
        
        int cardId;
        if (roll < weightCon1)
        {
            cardId = 1900; // con 1
        }
        else if (roll < weightCon1 + weightCon2)
        {
            cardId = 1920; // con 2
        }
        else
        {
            cardId = 1921; // con 3
        }

        var card = DataHolder.Instance().GetData<Card>(cardId);
        if (card == null)
            return;

        float x = this.transform.position.x + Random.Range(-2f, 2f);
        float y = this.transform.position.y + Random.Range(-2f, 2f);
        Vector3 spawnPos = new(x, y, 0);
        Vector2 distance = transform.position - spawnPos;
        var mob = NetworkPoolManager.instance.Get(card.GetName(0), spawnPos, Quaternion.identity);

        if (mob == null)
        {
            return;
        }

        var mobBehavior = mob.GetComponent<MobBehavior>();
        if (mobBehavior == null)
        {
            return;
        }

        mobBehavior.UpdateClanId(clanId);
        mobBehavior.landId = landId;
        mobBehavior.lockAreaId = lockAreaId;
        mobBehavior.enermy = targetBehavior;
        mobBehavior.summoner = this;
        mobBehavior.summonerName = userName;
        mobBehavior.characterName = characterName;
        mobBehavior.offsetToSummonner = distance;
        mobBehavior.isSummonMob = true;

        var summonLand = WorldManager.Instance.GetLandData(landId);
        var allowedSpawn = FinalWarManager.ResolveVillagePosition(FinalWarManager.GetProtectedVillage(mobBehavior),
            summonLand, transform.position, spawnPos);
        if (!allowedSpawn.HasValue)
        {
            NetworkPoolManager.instance.Return(card.GetName(0), mob);
            return;
        }
        mob.transform.position = allowedSpawn.Value;

        if (string.IsNullOrEmpty(GetTeamId()))
        {
            AssignTeamByType(AssignTeamType.Clan);
            mobBehavior.AssignTeamByType(AssignTeamType.Clan);
        }
        else
        {
            mobBehavior.SetTeamId(GetTeamId());
        }

        int arenaId = GetArenaId();
        if (arenaId > -1)
        {
            mobBehavior.SetArenaId(arenaId);

            if (!mob.TryGetComponent<NewArenaTeamTag>(out var tag))
                tag = mob.AddComponent<NewArenaTeamTag>();
            tag.ResetData();
            tag.arenaId = arenaId;

            if (NewArenaManager_Server.TryGetArena(arenaId, out var arena) && arena.TryFindPlayerInfo(this.userName, out var playerInfo))
            {
                tag.teamIndex = playerInfo.team.teamIndex;
            }
            else
            {
                tag.teamIndex = -1;
            }

            tag.killTeamScore = 0;
            tag.killMemberScore = 0;
        }

        // ✅ Initialize MobProtectionSync component
        var protectionSync = mobBehavior.GetComponent<MobProtectionSync>();
        if (protectionSync != null)
        {
            protectionSync.UpdateFromSummoner();
        }

        NetworkServer.Spawn(mob);
    }
#endif

    private bool DontHaveEffect(int effectId)
    {
        if (characterEffects == null)
        {
            return false;
        }
        else
        {
            return characterEffects.HaveEffect(effectId) == false;
        }
    }

    [Server]
    private void RpcDodgeToPlayerInRegisterZone(Vector2 pos)
    {
        if (GetArenaId() <= -1)
            return;

        var arenaBehavior = EventManager.instance.GetArenaBehavior(GetArenaId());
        if (arenaBehavior == null)
            return;

        var playersInRegisterZone = arenaBehavior.GetPlayersInRegisterZone();
        foreach (var item in playersInRegisterZone)
        {
            RpcDodge(item.connectionToClient, pos, false);
        }
    }

    private void RpcDamageToPlayerIngredisterZone(System.Action<NetworkConnectionToClient, Vector2, bool, int> logic, Vector2 pos, int value)
    {
        if (GetArenaId() <= -1)
            return;

        var arenaBehavior = EventManager.instance.GetArenaBehavior(GetArenaId());
        if (arenaBehavior == null)
            return;

        var playersInRegisterZone = arenaBehavior.GetPlayersInRegisterZone();
        foreach (var item in playersInRegisterZone)
        {
            if (item != null && item.connectionToClient != null)
            {
                logic?.Invoke(item.connectionToClient, pos, false, value);
            }
        }
    }

    [Server]
    public void SpawnObject(string prefabName, string poolName, Vector2 position, bool isVFX)
    {
        ClientRpcSpawnObject(prefabName, poolName, position, isVFX);
    }

    [ClientRpc]
    protected void ClientRpcSpawnObject(string prefabName, string poolName, Vector2 position, bool isVFX)
    {
#if !ENABLE_ADMIN
        if (PoolManager.Pools[poolName] != null)
        {
            var gameObject = PoolManager.Pools[poolName].Spawn(prefabName, position, Quaternion.identity);

            if (isVFX)
            {
                gameObject.GetComponent<AutoDestroy>().PlayVFX();
            }
        }
#endif
    }


    [Server]
    public void SpawnMovementObject(string prefabName, Vector2 start, Vector2 end, float duration,
        double shotTimestamp)
    {
        ClientRpcSpawnMovementObject(prefabName, start, end, duration, shotTimestamp);
    }

    [ClientRpc]
    public void ClientRpcSpawnMovementObject(string prefabName, Vector2 start, Vector2 end, float duration,
        double shotTimestamp)
    {
        EventDispatcher.Raise(new ObjectMovement()
        {
            prefabName = prefabName,
            duration = duration,
            start = start,
            end = end,
            shotTimestamp = shotTimestamp
        });
    }

    [Server]
    public void SpawnHommingMovementObject(string prefabName, Vector2 start, Vector2 end,
        float duration, uint targetNetId, uint projectileId, double shotTimestamp)
    {
        ClientRpcSpawnHommingMovementObject(
            prefabName,
            start,
            end,
            duration,
            targetNetId,
            projectileId,
            shotTimestamp);
    }

    [ClientRpc]
    public void ClientRpcSpawnHommingMovementObject(string prefabName, Vector2 start, Vector2 end,
        float duration, uint targetNetId, uint projectileId, double shotTimestamp)
    {
        EventDispatcher.Raise(new HommingMovement()
        {
            prefabName = prefabName,
            duration = duration,
            start = start,
            end = end,
            targetNetId = targetNetId,
            projectileId = projectileId,
            shotTimestamp = shotTimestamp
        });
    }

    [Server]
    public void CancelHommingMovementObject(uint projectileId)
    {
        ClientRpcCancelHommingMovementObject(projectileId);
    }

    [ClientRpc]
    public void ClientRpcCancelHommingMovementObject(uint projectileId)
    {
        EventDispatcher.Raise(new HommingMovementCancellation
        {
            projectileId = projectileId
        });
    }

    [Server]
    public void SpawnMovementPredict(string prefabName, string prefabNamePredict, string poolName,
        Vector2 start, Vector2 end, float duration, float radius, double shotTimestamp)
    {
        ClientRpcSpawnMovementPredict(
            prefabName,
            prefabNamePredict,
            poolName,
            start,
            end,
            duration,
            radius,
            shotTimestamp);
    }

    [ClientRpc]
    public void ClientRpcSpawnMovementPredict(string prefabName, string prefabNamePredict, string poolName,
        Vector2 start, Vector2 end, float duration, float radius, double shotTimestamp)
    {
#if !ENABLE_ADMIN && ENABLE_CLIENT

        if (PoolManager.Pools[poolName] != null)
        {
            var gameObject = PoolManager.Pools[poolName].Spawn(prefabName);

            float elapsed = Mathf.Max(0f, (float)(NetworkTime.time - shotTimestamp));
            float remainingDuration = Mathf.Max(0f, duration - elapsed);
            gameObject.GetComponent<MCPMovement.Runtime.MCPMove.LogicMove.EntityMove>().
                Init(start, end, remainingDuration, (obj) => PoolManager.Pools[poolName].Despawn(obj.transform));
        }

        if (PoolManager.Pools[poolName] != null)
        {
            float elapsed = Mathf.Max(0f, (float)(NetworkTime.time - shotTimestamp));
            float remainingDuration = Mathf.Max(0f, duration - elapsed);
            StartCoroutine(SpawnMovementPredictVfx(
                prefabNamePredict,
                poolName,
                end,
                radius,
                remainingDuration,
                duration));
        }
#endif
    }

#if !ENABLE_ADMIN && ENABLE_CLIENT
    private IEnumerator SpawnMovementPredictVfx(
        string prefabNamePredict,
        string poolName,
        Vector2 end,
        float radius,
        float delay,
        float lifetime)
    {
        yield return MCPCoroutines.WaitFor(delay);
        if (PoolManager.Pools[poolName] == null)
        {
            yield break;
        }

        var gameObject = PoolManager.Pools[poolName].Spawn(prefabNamePredict);
        var autoDestroy = gameObject.GetComponent<AutoDestroy>();

        if (autoDestroy.radius == null)
        {
            yield break;
        }

        var radiusVFX = autoDestroy.radius.main;
        radiusVFX.startLifetime = lifetime;
        radiusVFX.startSize = 1 + radius * 2;
        autoDestroy.radius.transform.position = end;
        autoDestroy.PlayVFX();
    }
#endif

    [Server]
    public void SpawnRadiusObject(string prefabName, string poolName, Vector2 start, float duration, float radius)
    {
        ClientRpcSpawnRadiusObject(prefabName, poolName, start, duration, radius);
    }

    [ClientRpc]
    public void ClientRpcSpawnRadiusObject(string prefabName, string poolName, Vector2 start, float duration, float radius)
    {
#if !ENABLE_ADMIN && ENABLE_CLIENT 
        if (PoolManager.Pools[poolName] != null)
        {
            StartCoroutine(SpawnVFX());
            IEnumerator SpawnVFX()
            {
                yield return MCPCoroutines.WaitFor(duration);
                var gameObject = PoolManager.Pools[poolName].Spawn(prefabName);
                var autoDestroy = gameObject.GetComponent<AutoDestroy>();
                if (autoDestroy.radius == null)
                {
                    autoDestroy.PlayVFX();
                    yield break;
                }
                var radiusVFX = autoDestroy.radius.main;
                radiusVFX.startLifetime = duration;
                radiusVFX.startSize = 1 + radius * 2;
                autoDestroy.radius.transform.position = start;

                autoDestroy.PlayVFX();
            }
        }
#endif
    }

    [TargetRpc]
    private void RpcReward(NetworkConnectionToClient networkConnectionToClient, NotifyData notifyData)
    {
        // ✅ SERVER-ONLY: Add null check for UIManager
        if (UIManager.instance == null) return;
        UIManager.instance.FindView<ToastView>(UIManager.TOAST_VIEW_LEFT).Load(notifyData);
    }


    [TargetRpc]
    protected virtual void RpcDodge(NetworkConnectionToClient networkConnectionToClient, Vector2 position, bool isEnemy)
    {
        //VfxManager.instance.OnDodgeEffect(position, isEnemy);
        EventDispatcher.Raise(new OnSendStatCharacter
        {
            typeStat = StatType.Dodge,
            position = position,
            isEnemy = isEnemy
        });
    }

    [TargetRpc]
    protected virtual void RpcLifeSteal(NetworkConnectionToClient networkConnectionToClient, Vector2 position, bool isEnemy, int value)
    {
        EventDispatcher.Raise(new CharacterHealth.OnAddHealthValue()
        {
            Position = transform.position,
            Value = value,
        });

    }

    [ClientRpc]
    public void ClientRpcHeal(Vector2 position, int value)
    {
        EventDispatcher.Raise(new CharacterHealth.OnAddHealthValue()
        {
            Position = transform.position,
            Value = value,
        });

        //TODO: event
        PoolManager.Pools["VFX"].Spawn("VFXHealSingleTarget", position, Quaternion.identity).GetComponent<AutoDestroy>().PlayVFX();
    }

    [TargetRpc]
    protected virtual void RpcCounterAttack(NetworkConnectionToClient networkConnectionToClient, Vector2 position, bool isEnemy, int value)
    {
        if (SoundManager.instance != null)
            SoundManager.instance.PlaySounds(hitPlayerSounds);

        //VfxManager.instance.OnCounterAttackEffect(position, isEnemy, value);
        EventDispatcher.Raise(new OnSendStatCharacter
        {
            typeStat = StatType.Counterattack,
            position = position,
            isEnemy = isEnemy,
            value = value
        });
    }

    [TargetRpc]
    protected virtual void RpcNormalDamage(NetworkConnectionToClient networkConnectionToClient, Vector2 position, bool isEnemy, int value)
    {
        if (SoundManager.instance != null)
            SoundManager.instance.PlaySounds(hitPlayerSounds);

        //VfxManager.instance.OnNormalDamageEffect(position, isEnemy, value);
        EventDispatcher.Raise(new OnSendStatCharacter
        {
            typeStat = StatType.Damage,
            position = position,
            isEnemy = isEnemy,
            value = value
        });
    }

    [TargetRpc]
    protected virtual void RpcFuryDamage(NetworkConnectionToClient networkConnectionToClient, Vector2 position, bool isEnemy, int value)
    {
        if (SoundManager.instance != null)
            SoundManager.instance.PlaySounds(hitPlayerSounds);

        EventDispatcher.Raise(new OnSendStatCharacter
        {
            typeStat = StatType.Fury,
            position = position,
            isEnemy = isEnemy,
            value = value
        });
    }

    [TargetRpc]
    protected virtual void RpcCriticalDamage(NetworkConnectionToClient networkConnectionToClient, Vector2 position, bool isEnemy, int value)
    {
        if (SoundManager.instance != null)
            SoundManager.instance.PlaySounds(hitPlayerSounds);

        //VfxManager.instance.OnCriticalDamageEffect(position, isEnemy, value);
        EventDispatcher.Raise(new OnSendStatCharacter
        {
            typeStat = StatType.Critical,
            position = position,
            isEnemy = isEnemy,
            value = value
        });
    }

    [TargetRpc]
    protected virtual void RpcCriticalBonusDamage(NetworkConnectionToClient networkConnectionToClient, Vector2 position, bool isEnemy, int value)
    {
        if (SoundManager.instance != null)
            SoundManager.instance.PlaySounds(hitPlayerSounds);

        //VfxManager.instance.OnCriticalBonusDamageEffect(position, isEnemy, value);
        EventDispatcher.Raise(new OnSendStatCharacter
        {
            typeStat = StatType.CriticalBonus,
            position = position,
            isEnemy = isEnemy,
            value = value
        });
    }


    [ClientCallback]
    public void SetupVisual()
    {
        if (characterBody != null && characterBody.isInView)
        {
            SetDirection();
            SyncVisualLastPosition(this.characterBody.transform.position);
            DoAnimation(GetCharacterState());
            lastCharacterState = GetCharacterState();

            var value = -Mathf.RoundToInt(this.characterBody.transform.position.y * 10);

            if (characterBody.sortingGroup.sortingOrder != value)
            {
                characterBody.sortingGroup.sortingOrder = value;
            }
        }

    }

    public void SyncVisualLastPosition(Vector3 position)
    {
        lastPosition = position;
    }

    [ClientCallback]
    protected void SetDirection()
    {
        if (characterType == CharacterType.Building && mobId != GameConst.MACHANDISE_BUILDING)
            return;

        if (direction != lastDirection && characterBody != null && characterBody.body != null)
        {
            if (direction == Direction.R)
            {
                characterBody.body.transform.rotation = Quaternion.Euler(new Vector3(0, 180, 0));
                characterBody.body.transform.localScale = new Vector3(characterBody.body.transform.localScale.x, characterBody.body.transform.localScale.y, -1);
            }
            else
            {
                characterBody.body.transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0));
                characterBody.body.transform.localScale = new Vector3(characterBody.body.transform.localScale.x, characterBody.body.transform.localScale.y, 1);
            }
            lastDirection = this.direction;
        }
    }

    [ClientCallback]
    protected virtual void DoAnimation(CharacterState characterState)
    {
        if (characterBody != null && characterState != lastCharacterState && characterBody.gameObject.activeSelf && characterBody.animator.gameObject.activeSelf)
        {
            switch (characterState)
            {
                case CharacterState.Idle:
                    characterBody.animator.Play(AnimationHelper.HashIdle);
                    break;
                case CharacterState.Run:
                    characterBody.animator.Play(AnimationHelper.HashRun);
                    break;
                case CharacterState.Attack:
                    characterBody.animator.Play(AnimationHelper.HashAttack);
                    break;
                case CharacterState.Dead:
                    characterBody.animator.Play(AnimationHelper.HashDead);
                    break;
                case CharacterState.OpenChest:
                    characterBody.animator.Play(AnimationHelper.HashOpenChest);
                    break;
                default:
                    characterBody.animator.Play(characterState.ToString().ToLower());
                    break;
            }
        }
    }
    [Client]
    public void UpdateIcons()
    {
#if !ENABLE_ADMIN        
        var isInArena = IsStandingOn(RuntimeAreaController.RuntimeAreaType.Arena, RuntimeAreaController.RuntimeAreaType.ArenaFreeForAll);
        var isInBeginnerLand = IsInBeginnerLand();
        var landZoneType = GetRuntimeZoneType();
        var characterVisual = GetComponent<CharacterVisual>();
        bool isBuildingEventProtected = characterType == CharacterType.Building && GetVillageProtectionEventTime() > 0;

        if (characterVisual != null && characterVisual.isTired)
            SetActive(characterBody.tiredIcon, true);
        else
            SetActive(characterBody.tiredIcon, false);

        if (characterVisual != null && characterVisual.isWatchingAd)
        {
            SetActive(characterBody.watchAdIcon, true);
            SetActive(characterBody.arenaIcon, false);
            SetActive(characterBody.wantedIcon, false);
            SetActive(characterBody.protectionIcon, false);
        }
        else if (isInArena)
        {
            SetActive(characterBody.arenaIcon, true);
            SetActive(characterBody.wantedIcon, false);
            SetActive(characterBody.protectionIcon, false);
            SetActive(characterBody.watchAdIcon, false);
        }
        else if (isInBeginnerLand)
        {
            SetActive(characterBody.protectionIcon, true);
            SetActive(characterBody.wantedIcon, false);
            SetActive(characterBody.arenaIcon, false);
            SetActive(characterBody.watchAdIcon, false);
        }
        else if (!isBuildingEventProtected && (GetProtectionTime() > 0 && (IsStandingOn(CombatZoneType.PVPWithProtection) || characterType == CharacterType.Building) ||
                IsStandingOn(CombatZoneType.Safe, CombatZoneType.PVE)))
        {
            SetActive(characterBody.protectionIcon, true);
            SetActive(characterBody.wantedIcon, false);
            SetActive(characterBody.arenaIcon, false);
            SetActive(characterBody.watchAdIcon, false);
        }
        else if (IsStandingOn(CombatZoneType.PVP))
        {
            SetActive(characterBody.wantedIcon, true);
            SetActive(characterBody.protectionIcon, false);
            SetActive(characterBody.arenaIcon, false);
            SetActive(characterBody.watchAdIcon, false);
        }
        else
        {
            SetActive(characterBody.protectionIcon, false);
            SetActive(characterBody.wantedIcon, false);
            SetActive(characterBody.arenaIcon, false);
            SetActive(characterBody.watchAdIcon, false);
        }
#endif        
    }

    [Client]
    public void EnableTargetOutline(CharacterBehavior target)
    {
        if (isLocalPlayer && target != null && target.characterBody != null && target.characterBody.OutlineAble != null)
        {
            target.characterBody.OutlineAble.EnableOutline();
        }
    }

    [Client]
    protected void DisableTargetOutline(CharacterBehavior target)
    {
        if (isLocalPlayer && target != null && target.characterBody != null && target.characterBody.OutlineAble != null)
        {
            target.characterBody.OutlineAble.DisableOutline();
        }
    }

    public virtual bool CanAttack(CharacterBehavior target)
    {
        if (characterType == CharacterType.Building && target != null && target.characterType == CharacterType.Trap)
            return false;
        if (IsMobTrapOrSiegeInteraction(this, target)) return false;
#if ENABLE_SERVER
        if (this is PlayerBehavior reporter && reporter.characterRole == CharacterRole.Reporter)
            return false;
        if (target is PlayerBehavior targetReporter && targetReporter.characterRole == CharacterRole.Reporter)
            return false;
#endif
        if (target == null) return false;
        if (FinalWarManager.BlocksCombat(this, target)) return false;
        if (BattleManager.instance == null) return false;
        if (BattleManager.instance.GetIsMaintenance()) return false;
        if (!this.isActive || !target.isActive) return false;
        if (this.IsWatchingAd() || target.IsWatchingAd()) return false;
        if (this.characterType == CharacterType.Npc || target.characterType == CharacterType.Npc) return false;
        if (this.GetHealth() <= 0 || target.GetHealth() <= 0) return false;
        if (!CanAttackCombatPlane(target)) return false;
        bool isAreaClashTarget = !string.IsNullOrEmpty(target.userName) &&
            target.userName.StartsWith(AreaClashManager.PoolIdPrefix);
        if (isAreaClashTarget)
        {
            if (AreaClashManager.instance == null ||
                !AreaClashManager.instance.CanAttackAreaClash(this, target))
            {
                return false;
            }

            // Area Clash buildings use only their event-time and ownership rules.
            // Do not let normal building/team/protection/zone checks suppress the
            // client's attack animation or the server's authoritative hit.
            return true;
        }
        if (this.characterType == CharacterType.Player &&
            target.characterType == CharacterType.Building &&
            (string.IsNullOrEmpty(this.clanId) ||
             this.clanId == GameConst.ASSASIN_CLAN_KEY ||
             this.clanId == GameConst.ROYALFORCE_CLAN_KEY))
            return false;
        if (IsStandingOn(CombatZoneType.Safe) || target.IsStandingOn(CombatZoneType.Safe)) return false;
        if (IsType(CharacterType.Building) && target.IsType(CharacterType.Building)) return false;

        //Mob đánh nhau với mob
        if (IsType(CharacterType.Mob) && target.IsType(CharacterType.Mob) && target is SiegeUnitBehavior == false && this is not SiegeUnitBehavior)
        {
            if (this is MobBehavior owner)
            {
                if (!owner.canAttackOtherMob)
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        var attackerAreaController = GetRuntimeAreaController();
        var targetAreaController = target.GetRuntimeAreaController();

        if (attackerAreaController == null || targetAreaController == null) return false;

        //Tạm thời nếu 2 người đứng ở 2 vùng lấy team khác nhau sẽ ko đánh (ít trường hợp như thế)
        //FIXED: Removed this check as it prevents combat at zone boundaries (Village/Grass)
        //if (attackerAreaController.OnEnterAssignTeamType != targetAreaController.OnEnterAssignTeamType) return false;

        //Assign lại team
        this.AssignTeamByType(attackerAreaController.OnEnterAssignTeamType);
        target.AssignTeamByType(targetAreaController.OnEnterAssignTeamType);

        if (IsSameTeam(target) && !isAreaClashTarget) return false;

        // Check auto shield cho PvP (Player vs Player)
        if (this is PlayerBehavior player && target is PlayerBehavior targetPlayer)
        {
            if (player.IsAutoShieldActived() || targetPlayer.IsAutoShieldActived())
                return false;
        }

        // Check auto shield cho Summoned Mob (isSummonMob = true)
        // Summoned mob có shield (từ owner) không thể bị tấn công bởi Player hoặc summoned mob khác
        if (target is MobBehavior targetMob && targetMob.isSummonMob && target.HasAutoShield())
        {
            // Chỉ block khi attacker là Player hoặc summoned mob
            if (this is PlayerBehavior || (this is MobBehavior attackerMob && attackerMob.isSummonMob))
                return false;
        }
        // Summoned mob có shield không thể tấn công Player hoặc summoned mob khác
        if (this is MobBehavior thisMob && thisMob.isSummonMob && this.HasAutoShield())
        {
            // Chỉ block khi target là Player
            if (target is PlayerBehavior)
                return false;
            // Hoặc target là summoned mob (dù có hay không có shield)
            if (target is MobBehavior targetSummon && targetSummon.isSummonMob)
                return false;
        }

        // 
        if (target is MobBehavior targetMob2 && targetMob2.mobId == 780)
        {
            if (HasAutoShield())
            {
                return false;
            }
        }

        if (this is MobBehavior && mobId == GameConst.WERE_WOLF_ID)
        {
            if (target is PlayerBehavior targetPlayer2 && targetPlayer2.HasAutoShield())
            {
                return false;
            }
        }

        //Can not attack building if village under protection
        if (target.characterType == CharacterType.Building && !isAreaClashTarget)
        {
            bool isOrcRevengeMob = this is MobBehavior && MonsterHelper.IsOrcRevenge(mobId);

            if (target.mobId == GameConst.MACHANDISE_BUILDING)
            {
                if (target.IsStandingOn(RuntimeAreaType.ArenaFreeForAll))
                {
                    return false;
                }
            }
            else
            {
                if (IsNpcClan(clanId) && clanId.IsNonEmpty() && !isOrcRevengeMob)
                {
                    return false;
                }
            }

            if (this.IsType(CharacterType.Mob))
            {
                if (!CanAttackBuildingAsMob())
                {
                    return false;
                }
            }
            else
            {
                if (IsBuildingAttackBlockedByVillageProtection(target))
                    return false;
            }
        }

        var playerZone = GetCombatZone();
        var targetZone = target.GetCombatZone();

        if (playerZone == null || targetZone == null) return false;

        if (IsAnyType(CharacterType.Player, CharacterType.Building) && target.IsAnyType(CharacterType.Player, CharacterType.Building))
        {
            if (IsStandingOn(CombatZoneType.PVE) || target.IsStandingOn(CombatZoneType.PVE)) return false;

            //Protection and PVPWithProtection
            var playerProtected = playerZone == CombatZoneType.PVPWithProtection && GetProtectionTime() > 0;
            var targetProtected = targetZone == CombatZoneType.PVPWithProtection && target.GetProtectionTime() > 0;
            if (playerProtected || targetProtected) return false;
        }

        //Player đánh summon của người khác
        if (IsType(CharacterType.Player) && target.IsType(CharacterType.Mob))
        {
            if (target is MobBehavior mobTarget2)
            {
                if (mobTarget2.isSummonMob)
                {
                    var playerProtected = playerZone == CombatZoneType.PVPWithProtection && GetProtectionTime() > 0;
                    var targetProtected = targetZone == CombatZoneType.PVPWithProtection && target.GetProtectionTime() > 0;
                    if (playerProtected || targetProtected) return false;
                }
            }
        }


        return true;
    }

    internal static bool IsMobTrapOrSiegeInteraction(CharacterBehavior attacker, CharacterBehavior target)
    {
        bool attackerMob = attacker is MobBehavior && attacker is not SiegeUnitBehavior;
        bool targetMob = target is MobBehavior && target is not SiegeUnitBehavior;
        return attackerMob && (target is TrapBehavior ||
                target is SiegeUnitBehavior && !attacker.CanAttackSiegeAsMob())
            || targetMob && (attacker is TrapBehavior ||
                attacker is SiegeUnitBehavior && !target.CanTakeDamageSiegeAsMob());
    }

    internal bool CanAttackSiegeAsMob()
    {
        return this is MobBehavior && this is not SiegeUnitBehavior &&
            characterType == CharacterType.Mob && HasMobSiegePermission(GetCombatCard(), attack: true);
    }

    internal bool CanTakeDamageSiegeAsMob()
    {
        return this is MobBehavior && this is not SiegeUnitBehavior &&
            characterType == CharacterType.Mob && HasMobSiegePermission(GetCombatCard(), attack: false);
    }

    internal static bool HasMobSiegePermission(Card card, bool attack)
    {
        return card != null && card.equipmentType == EquipmentType.Mob &&
            (attack ? card.canAttackSiege : card.canTakeDamageSiege);
    }

    protected virtual bool CanAttackBuildingAsMob()
    {
        return false;
    }

    protected bool IsBuildingAttackBlockedByVillageProtection(CharacterBehavior target)
    {
        if (target == null || BattleManager.instance == null || target.GetVillageProtectionEventTime() > 0)
            return true;

        if (!string.IsNullOrEmpty(clanId) && IsUserClan(clanId))
        {
            ClanData clanData = BattleManager.instance.GetClanData(clanId);
            if (clanData != null && clanData.villageId != "" &&
                clanData.IsProtected(System.DateTime.Now) &&
                (BattleManager.IsTournament || !clanData.IsPreparation()))
            {
                return true;
            }
        }

        if (!string.IsNullOrEmpty(target.clanId) && IsUserClan(target.clanId))
        {
            ClanData clanData = BattleManager.instance.GetClanData(target.clanId);
            MerchandiseSkill merchandiseSkill = target.GetComponentInChildren<MerchandiseSkill>();
            bool targetIsRunningMerchandise = merchandiseSkill != null && merchandiseSkill.IsRunning();
            if (clanData != null && clanData.villageId != "" &&
                clanData.IsProtected(System.DateTime.Now) &&
                (BattleManager.IsTournament || !clanData.IsPreparation()) &&
                !targetIsRunningMerchandise)
            {
                return true;
            }
        }

        return false;
    }

    private bool CanAttackCombatPlane(CharacterBehavior target)
    {
        AttackPlaneMask targetPlaneMask;
        switch (target.GetCombatPlane())
        {
            case CombatPlane.Ground:
                targetPlaneMask = AttackPlaneMask.Ground;
                break;
            case CombatPlane.Air:
                targetPlaneMask = AttackPlaneMask.Air;
                break;
            default:
                return false;
        }

        return (GetAttackPlaneMask() & targetPlaneMask) != AttackPlaneMask.None;
    }

    private CombatPlane GetCombatPlane()
    {
        Card combatCard = GetCombatCard();
        return combatCard != null ? combatCard.combatPlane : CombatPlane.Ground;
    }

    private AttackPlaneMask GetAttackPlaneMask()
    {
        Card combatCard = GetCombatCard();
        return combatCard != null ? combatCard.attackPlaneMask : AttackPlaneMask.Ground;
    }

    private Card GetCombatCard()
    {
        if (!IsAnyType(CharacterType.Mob, CharacterType.Building))
            return null;

        return DataHolder.Instance().GetData<Card>(mobId);
    }

    protected virtual void OnTriggerEnter2D(Collider2D collision)
    {
#if !ENABLE_ADMIN

        for (int i = 0, length = abilities.Length; i < length; i++)
        {
            if (abilities[i] != null)
            {
                abilities[i].OnOwnerTriggerEnter2D(collision);
            }
        }

        CharacterBehavior target = collision.GetComponent<CharacterBehavior>();

        if (target == null)
            return;

        if (target is TrapBehavior trap && isClient && isLocalPlayer)
        {
            UIManager.instance?.OnEnterTrap(trap);
        }

        if (target.characterType == CharacterType.Npc)
        {
            if (isClient && isLocalPlayer && GetCharacterState() != CharacterState.Dead)
                OnClientLocalPlayerEnterNPC(target);
        }
        else if (target.characterType == CharacterType.Building)
        {
            if (isClient && isLocalPlayer && GetCharacterState() != CharacterState.Dead && IsClanMate(target))
            {
                OnClientLocalPlayerEnterBuilding(target);
            }
            else
            {
                if (this.characterType == CharacterType.Mob && !CanAttack(target)) return;

                if (!enermies.Contains(target))
                    enermies.Add(target);
            }
        }
        else
        {
            if (this.characterType == CharacterType.Mob && !CanAttack(target)) return;

            if (!enermies.Contains(target))
                enermies.Add(target);
        }

#endif
    }

    private void OnClientLocalPlayerEnterNPC(CharacterBehavior target)
    {
        NpcBehavior npc = target as NpcBehavior;
        if (npc == null)
        {
            return;
        }

        // ✅ SERVER-ONLY: Add null check for UIManager (may not exist in headless mode)
        if (UIManager.instance == null)
        {
            Debug.LogWarning("[CharacterBehavior] UIManager.instance is null - cannot handle NPC interaction in headless mode");
            return;
        }

        if (npc.npcType == NpcType.Shop)
        {
            UIManager.instance.OnEnterShop();
        }
        else if (npc.npcType == NpcType.Merge)
        {
            UIManager.instance.OnEnterMerge();
        }
        else if (npc.npcType == NpcType.Governor)
        {
            UIManager.instance.OnEnterVillageGovernor();
        }
        else if (npc.npcType == NpcType.Clan)
        {
            UIManager.instance.OnEnterClanManager();
        }
        else if (npc.npcType == NpcType.Artifact)
        {
            UIManager.instance.OnEnterArtifact();
        }
        else if (npc.npcType == NpcType.Assasin)
        {
            UIManager.instance.OnEnterAssassin();
        }
        else if (npc.npcType == NpcType.ChangeName)
        {
            UIManager.instance.OnEnterChangeName();
        }
        else if (npc.npcType == NpcType.Colosseum)
        {
            UIManager.instance.OnEnterColosseum();
        }
        else if (npc.npcType == NpcType.ArenaShop)
        {
            UIManager.instance.OnEnterArenaShop();
        }
        else if (npc.npcType == NpcType.ClanWar)
        {
            UIManager.instance.OnEnterClanWar();
        }
        else if (npc.npcType == NpcType.Event)
        {
            UIManager.instance.OnEnterEvent();
        }
        else if (npc.npcType == NpcType.RoyalGuard)
        {
            UIManager.instance.OnEnterRoyalGuard();
        }
        else if (npc.npcType == NpcType.Teleport)
        {
            UIManager.instance.OnEnterTeleport();
        }
        else if (npc.npcType == NpcType.UndeadTeleport)
        {
            UIManager.instance.OnEnterTeleportNPC();
        }
        else if (npc.npcType == NpcType.Guard)
        {
            //UIManager.instance.OnEnterGuardian();
        }
        else if (npc.npcType == NpcType.Jail)
        {
            UIManager.instance.OnUnlockJailView();
        }
        else if (npc.npcType == NpcType.Healer)
        {
            UIManager.instance.OnEnterHealerShop();
        }
        else if (npc.npcType == NpcType.FactionWar)
        {
            UIManager.instance.OnEnterFactionWar();
        }
        else if (npc.npcType == NpcType.FactionWarUnregister)
        {
            UIManager.instance.OnEnterFactionWarUnregister();
        }
        else if (npc.npcType == NpcType.SurvivalWar)
        {
            UIManager.instance.OnEnterSurvivalWar();
        }
        else if (npc.npcType == NpcType.Tournament)
        {
            UIManager.instance.OnEnterNPCShip();
        }
        else if (npc.npcType == NpcType.CosmeticShop)
        {
            UIManager.instance.OnEnterNPCCosmeticShop();
        }

        bool meetNPCProgressChanged = false;
        var quest = ClientQuestManager.Instance.GetMyBeginngerQuestEditor();
        var questData = ClientQuestManager.Instance.GetMyBeginnerQuestData();

        if (quest != null && questData != null && questData.questState != QuestState.Rewarded)
        {
            var level = quest.GetLevel(questData);
            if (level == null)
                return;

            if (level.questType == QuestType.MeetNPC && npc.npcType == level.npcRequire)
            {
                meetNPCProgressChanged |= TryUpdateMeetNPCQuestProgress(questData);
            }
        }

        var tutorial = ClientQuestManager.Instance.GetTutorialQuestEditor();
        var tutorialData = ClientQuestManager.Instance.GetTutorial();

        if (tutorial != null && tutorialData != null && tutorialData.questLevel < tutorial.levels.Count)
        {
            var level = tutorial.levels[tutorialData.questLevel];
            if (level.questType == QuestType.MeetNPC && npc.npcType == level.npcRequire)
            {
                meetNPCProgressChanged |= TryUpdateMeetNPCQuestProgress(tutorialData);
            }
        }

        if (meetNPCProgressChanged && this is PlayerBehavior playerBehavior && playerBehavior.isLocalPlayer)
        {
            playerBehavior.RequestUpdateMeetNPCQuestProgress(npc.npcType, ClientManager.instance.GetApiToken());
        }
    }

    private void OnClientLocalPlayerEnterBuilding(CharacterBehavior target)
    {
        if (UIManager.instance != null)
        {
            UIManager.instance.DisableNpcButton();
        }

        PlayerBehavior building = target as PlayerBehavior;
        if (building == null)
        {
            return;
        }

        // ✅ SERVER-ONLY: Add null check for UIManager (may not exist in headless mode)
        if (UIManager.instance == null)
        {
            Debug.LogWarning("[CharacterBehavior] UIManager.instance is null - cannot handle Building interaction in headless mode");
            return;
        }

        if (building.mobId == BLESSING_TOWER_ID)
        {
            UIManager.instance.OnEnterBlessingTower(building);
        }
    }

    private void OnClientLocalPlayerExitBuilding(CharacterBehavior target)
    {
        PlayerBehavior building = target as PlayerBehavior;
        if (building == null)
        {
            return;
        }

        // ✅ SERVER-ONLY: Add null check for UIManager (may not exist in headless mode)
        if (UIManager.instance == null)
        {
            Debug.LogWarning("[CharacterBehavior] UIManager.instance is null - cannot handle Building interaction in headless mode");
            return;
        }

        if (building.mobId == BLESSING_TOWER_ID)
        {
            UIManager.instance.OnExitBlessingTower();
        }
    }

    private bool TryUpdateMeetNPCQuestProgress(QuestData questData)
    {
        if (questData.completedStep >= questData.requireValue)
        {
            return false;
        }

        questData.completedStep++;
        return true;
    }

    //GetTeamIdIncludeClanId is temp solution. Should assign clanId to teamId or recheck all logic, if can we replace all GetTeamId with GetTeamIdIncludeClanId
    public bool IsSameTeamIncludeClan(CharacterBehavior characterBehavior) => IsSameTeamIncludeClan(characterBehavior.GetTeamIdIncludeClanId());
    public bool IsSameTeamIncludeClan(string targetTeamId) => GetTeamIdIncludeClanId().IsNonEmpty() && GetTeamIdIncludeClanId() == targetTeamId;


    public bool IsSameTeam(CharacterBehavior characterBehavior) => IsSameTeam(characterBehavior.GetTeamId());
    public bool IsSameTeam(string targetTeamId) => GetTeamId().IsNonEmpty() && GetTeamId() == targetTeamId;

    private bool IsClanMate(CharacterBehavior target)
    {
        return clanId == target.clanId && clanId != "";
    }

    protected virtual void OnTriggerStay2D(Collider2D collision)
    {
#if ENABLE_CLIENT || UNITY_LOCAL_HOST
        // Covers spawn/reconnect while already overlapping; Enter remains the main flow.
        if (isClient && isLocalPlayer && collision != null &&
            collision.GetComponent<TrapBehavior>() is TrapBehavior trap)
            UIManager.instance?.OnEnterTrap(trap);
#endif
    }

    protected virtual void OnTriggerExit2D(Collider2D collision)
    {
        CharacterBehavior target = collision.GetComponent<CharacterBehavior>();
        if (target == null)
            return;

        if (target != null && enermies.Contains(target))
            enermies.Remove(target);

        if (isClient && isLocalPlayer)
        {
            if (target is TrapBehavior trap)
                UIManager.instance?.OnExitTrap(trap);
            if (target.characterType == CharacterType.Npc)
            {
                if (UIManager.instance != null)
                    UIManager.instance.DisableNpcButton();
            }
            else if (target.characterType == CharacterType.Building)
            {
                if (UIManager.instance != null)
                    OnClientLocalPlayerExitBuilding(target);
            }
        }
    }


    public float GetStatsScore()
    {
        var speed = statData.GetStat(StatType.Speed).value;
        var dmg = statData.GetStat(StatType.Damage).value;
        var health = statData.GetStat(StatType.Health).value;

        float totalScore = 0;

        totalScore += ClientManager.instance.GetScoreStat(StatType.Damage, dmg);
        totalScore += ClientManager.instance.GetScoreStat(StatType.Health, health);
        totalScore += ClientManager.instance.GetScoreStat(StatType.Speed, speed);

        return totalScore;
    }

    public PlayerBehavior AsPlayer()
    {
        return this as PlayerBehavior; // null nếu không phải PlayerBehavior
    }

    public float GetProtectionTime()
    {
        if (this.characterType == CharacterType.Player || this.characterType == CharacterType.Building)
        {
            var manualProtectionTime = ((PlayerBehavior)this).protectionTime;
            if (this.characterType != CharacterType.Building)
            {
                return manualProtectionTime;
            }

            return Mathf.Max(manualProtectionTime, GetVillageProtectionEventTime());
        }

        // ✅ NEW: Check MobProtectionSync for summoned mobs
        if (this.characterType == CharacterType.Mob)
        {
            var protectionSync = GetMobProtectionSync();
            if (protectionSync != null)
            {
                return protectionSync.protectionTime;
            }
        }

        return 0f;
    }

    public float GetVillageProtectionEventTime()
    {
        if (characterType != CharacterType.Building || ClanData.IsNoClanOrClanNPC(clanId))
        {
            return 0f;
        }

#if ENABLE_SERVER
        var clanData = BattleManager.instance != null ? BattleManager.instance.GetClanData(clanId) : null;
        if (clanData == null || !clanData.HasVillage)
        {
            return 0f;
        }
#endif

        if (EventManager.instance == null)
        {
            return 0f;
        }

        var now = BattleManager.instance != null
            ? BattleManager.instance.ServerNow()
            : System.DateTime.UtcNow;
#if ENABLE_SERVER
        var gameEvent = EventManager.instance.GetNearestGameEventData(GameEventId.VillageProtection);
#else
        var gameEvent = EventManager.instance.GetNearestLocalGameEventData(GameEventId.VillageProtection);
#endif
        if (gameEvent == null || !gameEvent.IsPlayable(now))
            return 0f;

        var eventTime = gameEvent.GetEventTime(now);
        return eventTime == null
            ? 0f
            : Mathf.Max(0f, (float)(eventTime.ServerEndTime(now) - now).TotalSeconds);
    }

    public bool HasAutoShield()
    {
        if (this is PlayerBehavior player)
            return player.IsAutoShieldActived();

        // ✅ NEW: Check MobProtectionSync for summoned mobs
        if (this.characterType == CharacterType.Mob)
        {
            var protectionSync = GetMobProtectionSync();
            if (protectionSync != null)
            {
                return protectionSync.autoShieldActive;
            }
        }

        return false;
    }

    private MobProtectionSync GetMobProtectionSync()
    {
        if (cachedMobProtectionSyncInitialized == false)
        {
            cachedMobProtectionSync = GetComponent<MobProtectionSync>();
            cachedMobProtectionSyncInitialized = true;
        }

        return cachedMobProtectionSync;
    }

    public float GetPreparationTime()
    {
        if (this.characterType == CharacterType.Building)
            return ((PlayerBehavior)this).preparationSafeTime;
        return 0f;
    }

    public MemberRole GetMemberRole()
    {
        if (this.characterType == CharacterType.Player)
            return ((PlayerBehavior)this).memberRole;
        return MemberRole.Member;
    }

    public bool IsWatchingAd()
    {
        if (this.characterType == CharacterType.Player)
            return ((PlayerBehavior)this).isWatchingAd;
        return false;
    }

    public bool IsArenaWinner()
    {
        if (this.characterType == CharacterType.Player)
            return ((PlayerBehavior)this).arenaWinner;
        return false;
    }


    // =======  LAND & AREA =======

    // ===GET===
    public RuntimeZoneType GetRuntimeZoneType()
    {
        if (landZoneType == RuntimeZoneType.None)
        {
            UpdateLandData();
        }
        return landZoneType;
    }
    public CombatZoneType? GetCombatZone()
    {
        if (GetRuntimeAreaController() == null) { return null; }
        return runtimeAreaController.CombatZoneType;
    }
    public RuntimeAreaController.RuntimeAreaType? GetRuntimeAreaType()
    {
        if (GetRuntimeAreaController() == null) { return null; }
        return runtimeAreaController.Type;
    }
    public RuntimeAreaController GetRuntimeAreaController()
    {
        if (runtimeAreaController == null) { UpdateLandData(); }
        return runtimeAreaController;
    }
    public RuntimeLandData GetRuntimeLandData()
    {
        if (runtimeLandData == null) { UpdateLandData(); }
        return runtimeLandData;
    }
    private float finalWarBlockedNotifyAt;

    public Vector2 ClampPosition(Vector2 pos, bool autoCorrect = false)
    {
        var land = WorldManager.Instance.GetLandData(landId);
        if (land == null && autoCorrect)
        {
            //For every character hasn't assign landId such as building, mob,...
            land = WorldManager.Instance.GetLandData(transform.position.ToVector2Int());
        }
        if (land == null) return pos;

        var area = lockAreaId.IsNonEmpty() ? land.GetAreaController(lockAreaId) : null;

        pos = area != null ? area.ClampInside(pos) :
            mobId == GameConst.MACHANDISE_BUILDING ? land.GetClampMapPositionWithFilter(pos, ignoreTypes: new[] { RuntimeAreaType.Jail }) : //Horse cart ignore Jail
                land.ClampLandPosition(pos);
        var village = FinalWarManager.GetProtectedVillage(this, landId: land.landName);
        Vector2 allowed = FinalWarManager.ResolveVillagePosition(village, land, transform.position, pos) ?? (Vector2)transform.position;
        if (village != null && allowed != pos && this is PlayerBehavior player && Time.unscaledTime >= finalWarBlockedNotifyAt)
        {
            finalWarBlockedNotifyAt = Time.unscaledTime + 2f;
#if ENABLE_SERVER
            if (isServer && player.connectionToClient != null)
                BattleManager.instance.SendServerNotificationToTarget(player.connectionToClient, int.MaxValue, NotifyType.MiddleNotify,
                    FinalWarManager.VillageBlockedMessage);
#endif
#if ENABLE_CLIENT
            if (!isServer && player.isLocalPlayer)
                IngameNotifyManager.instance?.OnMiddleNotify(FinalWarManager.VillageBlockedMessage);
#endif
        }
        return allowed;
    }

    // Helper method: Find nearest valid position when stuck inside obstacle
    private Vector2 FindNearestValidPosition(RuntimeLandData land, Vector2 stuckPos, Vector2 fallback)
    {
        // Calculate penetration depth based on actual movement distance
        Vector2 movementVector = stuckPos - fallback;
        float penetrationDepth = movementVector.magnitude;

        // If no movement or very small, use default push distance
        if (penetrationDepth < 0.01f)
            penetrationDepth = 0.2f;

        // Push distance = penetration depth + safety margin
        // This ensures we push out far enough even with high speed
        float pushDistance = penetrationDepth + 0.5f;

        // Try 8 directions around stuck position
        Vector2[] directions = new Vector2[] {
            Vector2.up, Vector2.down, Vector2.left, Vector2.right,
            new Vector2(1, 1).normalized, new Vector2(1, -1).normalized,
            new Vector2(-1, 1).normalized, new Vector2(-1, -1).normalized
        };

        foreach (var dir in directions)
        {
            Vector2 testPos = stuckPos + dir * pushDistance;  // ✅ Use dynamic distance based on movement

            if (!land.IsInsideImpassableArea(testPos))
            {
                return testPos;  // Found valid position
            }
        }

        return fallback;  // All blocked, return old position
    }

    //Similiar to normal ClampPosition but will check the path is move across obstacle
    public Vector2 ValidateMovement(Vector2 oldPos, Vector2 newPos)
    {
        if (!WorldManager.Instance.TryGetLandData(landId, out var land))
        {
            land = WorldManager.Instance.GetLandData(newPos.ToVector2Int())
                 ?? WorldManager.Instance.GetLandData(oldPos.ToVector2Int());
            if (land == null) return oldPos;
        }
        Vector2 target = land.GetClampLandPosition(newPos);

        var area = lockAreaId.IsNonEmpty() ? land.GetAreaController(lockAreaId) : null;
        if (area != null)
        {
            target = area.ClampInside(target);
            return FinalWarManager.ResolveVillagePosition(FinalWarManager.GetProtectedVillage(this, landId: land.landName),
                land, oldPos, target, true) ?? oldPos;
        }

        bool isBuilding = (mobId == GameConst.MACHANDISE_BUILDING);

        if (land.UsingCollisiion && !isBuilding)
        {
            if (land.IsPathBlocked(oldPos, target))
            {
                Vector2 tryX = new Vector2(target.x, oldPos.y);
                bool xOk = !land.IsPathBlocked(oldPos, tryX);

                Vector2 afterX = xOk ? tryX : oldPos;

                Vector2 tryY = new Vector2(afterX.x, target.y);
                bool yOk = !land.IsPathBlocked(afterX, tryY);

                if (xOk && yOk) target = tryY;                 // đi được cả 2
                else if (xOk) target = afterX;               // chỉ X
                else
                {
                    // thử Y trước (phòng TH hành lang đứng)
                    Vector2 tryYOnly = new Vector2(oldPos.x, target.y);
                    if (!land.IsPathBlocked(oldPos, tryYOnly))
                        target = tryYOnly;         // chỉ Y
                    else
                        target = oldPos;           // kẹt hoàn toàn
                }
            }
        }

#if ENABLE_CLIENT 
        // ✅ CLIENT ONLY: Smooth penetration resolution
        // Add safety check for client visual smoothness when stuck between obstacles
        if (land.UsingCollisiion && land.IsInsideImpassableArea(target))
        {
            target = FindNearestValidPosition(land, target, oldPos);
        }
#endif

        if (!isBuilding)
        {
            target = land.ClampLandPosition(target);
        }
        else
        {
            target = land.GetClampMapPositionWithFilter(target, ignoreTypes: new[] { RuntimeAreaController.RuntimeAreaType.Jail });
        }
        var village = FinalWarManager.GetProtectedVillage(this, landId: land.landName);
        Vector2 allowed = FinalWarManager.ResolveVillagePosition(village, land, oldPos, target, true) ?? oldPos;
        if (village != null && allowed != target && this is PlayerBehavior player && Time.unscaledTime >= finalWarBlockedNotifyAt)
        {
            finalWarBlockedNotifyAt = Time.unscaledTime + 2f;
#if ENABLE_SERVER
            if (isServer && player.connectionToClient != null)
                BattleManager.instance.SendServerNotificationToTarget(player.connectionToClient, int.MaxValue, NotifyType.MiddleNotify,
                    FinalWarManager.VillageBlockedMessage);
#endif
#if ENABLE_CLIENT
            if (!isServer && player.isLocalPlayer)
                IngameNotifyManager.instance?.OnMiddleNotify(FinalWarManager.VillageBlockedMessage);
#endif
        }
        return allowed;

        //if (land.UsingCollisiion && !isBuilding)
        //{
        //    var newPos1 = new Vector2(newPos.x, oldPos.y);
        //    var newPos2 = new Vector2(oldPos.x, newPos.y);

        //    if (land.IsPathBlocked(oldPos, newPos1))
        //    {
        //        newPos.x = oldPos.x;
        //    }

        //    if (land.IsPathBlocked(oldPos, newPos2))
        //    {
        //        newPos.y = oldPos.y;
        //    }
        //}

        //return mobId == GameConst.MACHANDISE_BUILDING ? land.GetClampMapPositionWithFilter(newPos, ignoreTypes: new[] { AreaType.Jail }) : //Horse cart ignore Jail
        //                                                land.ClampLandPosition(newPos);
    }

    public bool IsInZoneIgnoreAutomation(Vector2Int vector2)
    {
        var isInIgnoreAreas = WorldManager.Instance.IsInIgnoreAutoArea(vector2);

        var landZone = WorldManager.Instance.GetLandZone(vector2);
        bool isInVillage = true;
        if (landZone != null)
        {
            isInVillage = landZone == RuntimeZoneType.Village;
        }
        else
        {
            BattleManager.Log(GameLogType.Warning, userName + " landZone null " + vector2.ToString());
        }

        bool isNotInCenter = IsInLand(WorldManager.CENTER_LAND_NAME) == false;

        return isInVillage || isInIgnoreAreas || isNotInCenter;
    }

    //====LAND====

    /// <summary>
    /// Check if character is in the land with the given name, the name can find in <see cref="WorldManager"/>
    /// </summary>
    public bool IsInLand(string landName)
    {
        var land = GetRuntimeLandData();
        if (land == null) { return false; }
        return land.landName == landName;
    }
    public bool IsInBeginnerLand()
    {
        return IsInLand(WorldManager.BEGINNER_LAND_NAME);
    }
    public bool IsInCenterLand()
    {
        return IsInLand(WorldManager.CENTER_LAND_NAME);
    }
    public bool IsInUndeadLand()
    {
        return IsInLand(WorldManager.UNDEAD_LAND_NAME);
    }
    public bool IsInWarLand()
    {
        return IsInLand(WorldManager.WAR_LAND_NAME);
    }

    public bool IsInSurvivalLand()
    {
        return IsInLand(WorldManager.SURVIVAL_LAND_NAME);
    }

    public bool IsInShipLand()
    {
        return IsInLand(WorldManager.SHIP_LAND_NAME);
    }

    //===== AREA =====
    public bool IsStandingInside(params RuntimeAreaController.RuntimeAreaType[] ts)
    {
        var land = GetRuntimeLandData();
        if (land == null) { return false; }

        return land.GetAreaControllers(filterTypes: ts).Count > 0;
    }
    public bool IsStandingInside(RuntimeAreaController.RuntimeAreaType t)
    {
        var land = GetRuntimeLandData();
        if (land == null) { return false; }

        return land.GetAreaControllers(type: t).Count > 0;
    }
    public bool IsStandingInside(CombatZoneType t)
    {
        var land = GetRuntimeLandData();
        if (land == null) { return false; }
        return land.GetAreaControllers(combatZone: t).Count > 0;
    }
    public bool IsStandingOn(params RuntimeAreaController.RuntimeAreaType[] ts)
    {
        var area = GetRuntimeAreaController();
        if (area == null) { return false; }
        return ts.Contains(area.Type);
    }
    public bool IsStandingOn(params CombatZoneType[] ts)
    {
        var area = GetRuntimeAreaController();
        if (area == null) { return false; }
        return ts.Contains(area.CombatZoneType);
    }
    public bool IsStandingOn(RuntimeAreaController.RuntimeAreaType t) => GetRuntimeAreaType() == t;
    public bool IsStandingOn(CombatZoneType t) => GetCombatZone() == t;
    public bool IsStandingOn(RuntimeZoneType t) => GetRuntimeZoneType() == t;
    public bool IsStandingOn(params RuntimeZoneType[] ts) => ts.Contains(GetRuntimeZoneType());
    public bool IsStandingOnPVP()
    {
        return IsStandingOn(CombatZoneType.PVP, CombatZoneType.PVPArena, CombatZoneType.PVPWithProtection);
    }

    // ======= CHARACTER TYPE =======
    public bool IsType(CharacterType type)
    {
        return this.characterType == type;
    }
    public bool IsAnyType(params CharacterType[] types)
    {
        return types.Contains(this.characterType);
    }

    // ======= ATTACKABLE ========
    public bool CanAttackPlayer()
    {
        if (GetHealth() <= 0)
        {
            return false;
        }
        if (this is PlayerBehavior player)
        {
            if (player.IsAutoShieldActived())
            {
                return false;
            }
        }
        // Summoned mob có shield (từ owner) không thể attack player
        if (this is MobBehavior mob && mob.isSummonMob && this.HasAutoShield())
        {
            return false;
        }
        if (IsStandingOn(CombatZoneType.PVP, CombatZoneType.PVPArena))
        {
            return true;
        }
        if (IsStandingOn(CombatZoneType.PVPWithProtection) && GetProtectionTime() == 0)
        {
            return true;
        }

        return false;
    }
    public bool CanAttackMob()
    {
        if (GetHealth() <= 0)
        {
            return false;
        }
        if (IsStandingOn(CombatZoneType.Safe))
        {
            return false;
        }
        return false;
    }
    public bool CanTakeBuff(CharacterBehavior characterBehavior)
    {
        return IsUserClan(clanId);
    }

    //================ CLAN ================
    public void UpdateClanId(string newClanId)
    {
        clanId = newClanId;
        ForceInvokeEnterArea();
    }
}





public enum CharacterState
{
    Idle = 0,
    Run = 1,
    Attack = 2,
    Dead = 3,
    OpenChest = 4
}

public enum DebuffType
{
    Stun,
    Frozen,
    Burn,
    Poison,
    Wind,
}

public enum Direction { R, L }

