﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OutlineAble : MonoBehaviour
{
    public SpriteRenderer[] spriteRenderer;
    private MaterialPropertyBlock materialProperty;
    private int propertyID;
    private int propertyHealID;
    private Coroutine coroutine;
#if UNITY_EDITOR
    [Header("Editor")]
    public GameObject target;
    public Material material;
    [ContextMenu(nameof(SetUp))]
    public void SetUp()
    {
#if ENABLE_CLIENT || UNITY_EDITOR
        spriteRenderer = target.GetComponentsInChildren<SpriteRenderer>(true);
        for (int i = 0; i < spriteRenderer.Length; i++)
        {
            spriteRenderer[i].material = material;
        }
#endif
    }

#endif

        private void Awake()
    {
#if ENABLE_CLIENT || UNITY_EDITOR
        propertyID = Shader.PropertyToID("_OutlineAlpha");
        propertyHealID = Shader.PropertyToID("_InnerOutlineAlpha");
        materialProperty = new MaterialPropertyBlock();
#endif
    }

    public void EnableOutline()
    {
        SetValue(propertyID, 1);
    }

    public void DisableOutline() => SetValue(propertyID, 0);

    private void SetValue(int id, float value)
    {
#if ENABLE_CLIENT || UNITY_EDITOR
        for (int i = 0, length = spriteRenderer.Length; i < length; i++)
        {
            if (spriteRenderer[i] != null && materialProperty != null) {
                spriteRenderer[i].GetPropertyBlock(materialProperty);
                materialProperty.SetFloat(id, value);
                spriteRenderer[i].SetPropertyBlock(materialProperty);
            }
        }
#endif
    }

    public void TriggerHealOutline()
    {
#if ENABLE_CLIENT || UNITY_EDITOR
        if (coroutine != null)
        {
            StopCoroutine(coroutine);
        }
        coroutine = StartCoroutine(HealOutlineCO());
#endif
    }

    private IEnumerator HealOutlineCO()
    {
        float alpha = 0.8f;
        SetValue(propertyHealID, alpha);

        while (alpha > 0)
        {
            yield return null;
            alpha -= Time.deltaTime;
            SetValue(propertyHealID, alpha);
        }
    }
}
