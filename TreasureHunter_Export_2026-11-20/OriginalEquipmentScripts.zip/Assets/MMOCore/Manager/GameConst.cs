﻿using MCP.DataModels.BaseModels;
using System.Linq;

public static class GameConst
{

    public const int PIN_LENGTH = 4;

    public const int MAX_COLLECTION = 3;
    public const int MAX_COLLECTION_PET = 2;
    public const int MAX_COLLECTION_EMOTE = 4;
    public const int REVIVE_CLAN_DEFAULT = 5;
    //Currency id
    public const int REALMONEY_ID = 0;
    public const int GOLD_ID = 1;
    public const int DIAMOND_ID = 2;
    public const int SHARD_ID = 3;
    public const int TH_COIN_ID = 4;
    public const int ARENA_COIN_ID = 5;
    public const int REX_FANG_ID = 34;
    public const int SKIP_AD_NUMBER_ID = 16;
    public const int CLAN_WAR_TOTEM_ID = 765;

    //HealPotion
    public const int ITEM_0 = 32;
    //Elixir
    public const int ELIXIR_1 = 900;
    public const int ELIXIR_2 = 901;
    public const int ELIXIR_3 = 902;
    public const int ELIXIR_4 = 903;
    public const int ELIXIR_5 = 904;
    public const int ELIXIR_6 = 905;

    public const int MAIN_BUILDING_ID = 126;
    public const int GOLD_MINER_BUILDING_ID = 2501;
    public const int INGREDIENT_MINER_BUILDING_ID = 175;
    public const int BUFF_DAMAGE_TOWER_ID = 375;
    public const int BLESSING_TOWER_ID = 2231;
    public const int BLESSING_TOWER_BUFF = 2233; // Building Part chứa stat buff cho player
    public const int BLESSING_BUFF_EFFECT_ID_BASE = 223300;
    public const int PET_STABLE = 2368;
    public const int FORGE_BUILDING_ID = 3653;
    public const int CATAPULT_SIEGE_UNIT_ID = 3651;
    public const int BALLOON_SIEGE_UNIT_ID = 3652;

    //LAND
    public const string BEGINNER_LAND_NAME = WorldManager.BEGINNER_LAND_NAME;
    public const string CENTER_LAND_NAME = WorldManager.CENTER_LAND_NAME;
    public const string UNDEAD_LAND_NAME = WorldManager.UNDEAD_LAND_NAME;
    public const string WAR_LAND_NAME = WorldManager.WAR_LAND_NAME;

    //Arena
    public const int ARENA_PVP_UNDER_80_TROPHY = 0;
    public const int ARENA_PVP_80_TROPHY = 2;
    public const int ARENA_CLAN_WAR = 1;
    public const int ARENA_TEAM_BATTLE = 5;
    public const int ARENA_SURVIVAL = 6;
    public const int CLAN_WAR_ORC_ID = 781;
    public const int FACTION_WAR_CANNON_ID = 1297;
    public const int CLAN_WAR_ARCHER_ID = 1864;


    //TODO-FIX: We should need other way to bind areaId to arenaId
    public const string ARENA_PVP_UNDER_80_TROPHY_AREA = "Arena_1";
    public const string ARENA_PVP_80_TROPHY_AREA = "Arena_2";
    public const string ARENA_CLAN_WAR_AREA = "Arena_Clan";

    public static readonly (string landId, string areaId, int arenaId)[] ARENA_DATA = new (string, string, int)[]
    {
        //TODO-FIX: We should need other way to bind areaId to arenaId
        (CENTER_LAND_NAME, ARENA_PVP_UNDER_80_TROPHY_AREA, ARENA_PVP_UNDER_80_TROPHY),
        (CENTER_LAND_NAME, ARENA_PVP_80_TROPHY_AREA, ARENA_PVP_80_TROPHY),
        (CENTER_LAND_NAME, ARENA_CLAN_WAR_AREA, ARENA_CLAN_WAR),
    };


    public static readonly (string landName, string areaId) JAIL_LOCATION = (BEGINNER_LAND_NAME, "Jail_Center");

    //team battle
    public const int TEAM_BATTLE_CANNON_0 = 1297;
    public const int TEAM_BATTLE_ARCHER_0 = 1300;
    public const int TEAM_BATTLE_MAIN_1 = 1298;
    public const int TEAM_BATTLE_TOTEM_0 = 1301;


    public const int MACHANDISE_BUILDING = 218;
    public const int DIAMOND_MINER_BUILDING_ID = 183;
    public const int STORAGE_BUILDING_ID = 171;
    public const int BUFF_TROPHY_TOWER_ID = 374;
    public static bool IsNormalRestrictedBuffBuilding(int buildingId)
    {
        return buildingId == INGREDIENT_MINER_BUILDING_ID
            || buildingId == BUFF_DAMAGE_TOWER_ID
            || buildingId == BUFF_TROPHY_TOWER_ID
            || buildingId == DIAMOND_MINER_BUILDING_ID
            || buildingId == BLESSING_TOWER_ID;
    }

    public static bool IsAlwaysRestrictedClanBuilding(int buildingId)
    {
        return buildingId == GOLD_MINER_BUILDING_ID;
    }
    public const int POTION_ID = 32;
    public const int POTION_FACTION_WAR_ID = 1853;
    public const string ROYALFORCE_CLAN_KEY = "Royal Force";
    public const string ASSASIN_CLAN_KEY = "Assassin";
    public const string ORC_CLAN_KEY = "Orc";
    public const int ORC_VILLAGE_HALF_SIZE = 9;
    public const string EQUIPMENT_KEY = "Equipment";
    public const string INGREDIENT_KEY = "Ingredient";
    public const string POTION_KEY = "Potion";
    public const string LIMITED_EDITION = "(Limited Edition)";
    public const int MAX_CHAT_HISTORY = 100;
    public const int BUILDING_LEVEL_4 = 27;
    public const int BUILDING_LEVEL_3 = 22;
    public const int BUILDING_LEVEL_2 = 13;
    public const int CRAFT_SLOT_DEFAULT = 4;
    public const int CRAFT_SLOT_MAX = 8;
    public const int BASIC_INVENTORY_SLOT = 8;
    public const int MAX_INVENTORY_SLOT = 16;
    public const int CRAFT_SLOT_TRADE_DEFAULT = 8;
    public const int CRAFT_SLOT_TRADE_MAX = 12;
    public const int MIN_NUMBER_TO_MERGE_INGREDIENT = 2;
    public const int MAX_NUMBER_TO_MERGE_INGREDIENT = 8;
    public const int MAX_CRAFT_LEVEL = 1000000;
    public const int MAX_CRAFT_NUMBER = 1000000;
    public const int MIN_CRAFT_LEVEL = 1;
    public const int NUMBER_TO_MERGE_EVENT_ITEM = 5;
    public const string INDEX_SERVER_REGION_KEY = "ServerRegion";
    public const string ACCOUNT_INFO_LOCAL = "AccountInfoLocal";
    public const string LOCAL_LOGIN_ACCOUNTS = "LocalLoginAccounts";

    public const string COUNTRY_CODE_KEY = "Country-Code";
    public const string COUNTRY_NAME_KEY = "Country-Name";

    public const int MAX_ROYALTY = 20;
    public const int TOURNAMENT_MAX_ROYALTY = 100;
    public const int HAIR_DEFAULT_ID = 0;
    public const int FACEHAIR_DEFAULT_ID = 10;
    public const int BODY_DEFAULT_ID = 31;
    public const int EYE_DEFAULT_ID = 88;
    public const int POISON_INGREDIENT_ID = 814;
    public const int FREEZE_INGREDIENT_ID = 899;
    public const int FIRE_INGREDIENT_ID = 999;
    public const int HEALLONGTIME_INGREDIENT_ID = 1066;
    public const int MULTITARGET_INGREDIENT_ID = 362;
    public const int WIND_INGREDIENT_ID = 1732;
    public const int CRAFTCHANCE_INGREDIENT_ID = 67;

    //ShopID

    public const string SHOP_ID_HEALER_GATE = "HealerGate";


    //KeyChest

    public const float OPEN_CHEST_DISTANCE = 1.7f;
    public const int DIAMOND_KEY_ID = 35;

    public const int DIAMOND_CHEST_ID = 1097;


    public const int UNDEAD_CHEST_ID = 1098;
    public const int UNDEAD_KEY_ID = 1059;

    //Dialog
    public const int DIALOG_REWARD_PREVIEW_DEFAULT = 552;
    public const int DIALOG_REWARD_PREVIEW_CHECKBOX = 1558;
    public const int DIALOG_SERVER_CHEST = 133;
    public const int DIALOG_SERVER_LOST_KEY = 134;
    public const int DIALOG_SERVER_CAPTURE_KEY = 135;

    public const int DIALOG_SERVER_DIAMOND_KEY = 136;
    public const int DIALOG_SERVER_SPAWN_TREX = 137;
    public const int DIALOG_SERVER_OPEN_CHEST = 138;
    public const int DIALOG_SERVER_CREATE_CLAN = 139;
    public const int DIALOG_SERVER_LAST_HIT_MONSTER = 140;

    public const int DIALOG_SERVER_SPAWN_UNDEATH_TREX = 230;
    public const int DIALOG_SERVER_START_HUNTING = 432;
    public const int DIALOG_SERVER_SPAWN_POISON_SLIME_KING = 1444;

    public const int DIALOG_SERVER_UNDEAD_CHEST = 700;
    public const int DIALOG_SERVER_UNDEAD_KEY = 701;
    public const int DIALOG_SERVER_OPEN_UNDEAD_CHEST = 702;
    public const int DIALOG_SERVER_LOST_UNDEAD_KEY = 703;
    public const int DIALOG_SERVER_CAPTURE_UNDEAD_KEY = 704;
    public const int DIALOG_NOTIFY_CHANGE_SUCCESS = 823;

    //Connection
    public const float TIMEOUT_TIME_SECOND = 1f;

    //Quest
    public const int BEGINNER_QUEST_ENTRY = 335;
    public const int BEGINNER_QUEST_CRAFT_POTION = 324;
    public const int BEGINNER_QUEST_FINAL = 333;
    public const int BEGINNER_STORY_QUEST_ENTRY = 358;

    public const int ACHIEVEMENT_QUEST_POINT_ID = 357;
    public const int QUEST_DAILY_QUEST_POINT = 67;
    public const int CONTINUOUS_COMPLETED_0 = 77;
    public const int DAILY_QUEST_PER_DAY = 7;
    public const int DAILY_QUEST_POINT_PER_QUEST = 20;
    public const int DAILY_BOX_COMMON = 41;
    public const int DAILY_BOX_RARE = 42;
    public const int DAILY_BOX_EPIC = 43;
    public const int DAILY_BOX_LEGENDARY = 44;
    public const int DAILY_BOX_MYTHICAL = 70;
    public const int SKIN_BOX_COMMON = 50;
    public const int SKIN_BOX_RARE = 51;
    public const int SKIN_BOX_EPIC = 52;
    public const int SKIN_BOX_LEGEND = 53;
    public const int CONTINUOUS_LOGIN_0 = 82;
    public const int VIP_CONTINUOUS_LOGIN_0 = 113;
    public const int MIN_CONTINOUS_LOGIN_ON_SEASON = 1;
    public const int MAX_CONTINOUS_LOGIN_ON_SEASON = 28;

    public const int CLAN_QUEST_POINT_COMMON = 420;
    public const int CLAN_QUEST_POINT_RARE = 421;
    public const int CLAN_QUEST_POINT_EPIC = 422;
    public const int CLAN_QUEST_POINT_TOTAL = 566;
    public const int CLAN_QUEST_TOTAL_BOX = 266;


    public const int BOX_QUEST_POINT_ZERO = 124;
    public const int BOX_PLAYER_TOP1 = 81;
    public const int BOX_PLAYER_TOP2 = 80;
    public const int BOX_PLAYER_TOP3 = 79;

    public const int BOX_CLAN_TOP1 = 91;
    public const int BOX_CLAN_TOP2 = 90;
    public const int BOX_CLAN_TOP3 = 89;

    public const int BOX_IAP_TOP1 = 601;
    public const int BOX_IAP_TOP2 = 600;
    public const int BOX_IAP_TOP3 = 599;
    public const int BOX_CHEST_CENTER_TOP1 = 607;
    public const int BOX_CHEST_CENTER_TOP2 = 606;
    public const int BOX_CHEST_CENTER_TOP3 = 605;
    public const int BOX_CHEST_UNDEAD_TOP1 = 613;
    public const int BOX_CHEST_UNDEAD_TOP2 = 612;
    public const int BOX_CHEST_UNDEAD_TOP3 = 611;

    public const int MAX_BEGINNER_PROGRESS_POINT = 29;

    public const string CLAN_QUEST_DEFAULT_NAME = "Clan";

    public const int QUEST_TUTORIAL_HORSE_CRAFT_INVENTORY = 399;

    //Item
    public const int ITEM_BEGINNER_LIMITED = 50;

    //Common Box
    public const int BOX_BEGINNER_LIMITED = 216;
    public const int BOX_AVATAR_THSHOP = 241;
    public const int BOX_COLLECTION_THSHOP = 170;
    public const int BOX_MIRA_PET = 191;

    //Horse
    public const int HORSE_14_ID = 665;
    public const int HORSE_19_ID = 1061;
    public const int HORSE_20_ID = 1062;
    public const int HORSE_21_ID = 1252;
    public const int HORSE_22_ID = 1253;
    public const int HORSE_23_ID = 1379;
    public const int HORSE_1_ID = 43;
    public const int HORSE_28_ID = 1510;
    public const int HORSE_29_ID = 1511;
    public const int HORSE_31_ID = 1513;

    //Mira Pet
    public const int PET_0_ID = 38;
    public const int PET_1_ID = 41;
    public const int PET_2_ID = 42;

    //Quest season
    public const int MID_SEASON_BOX = 71;
    public const int END_SEASON_PLAYER_TOP_10 = 72;
    public const int END_SEASON_CLAN_TOP_10 = 82;

    public const int WERE_WOLF_ID = 780;

    //Event Monster
    public const int SNOW_BEAR_RUN = 792;
    public const int MERCHANDISE_BEAR = 794;
    public const int RED_T_REX_ID = 121;
    public const int UNDEATH_T_REX_ID = 224;

    //Neutral
    public const int DEFAULT_MOB_ID = 33;
    public const int SNAILU_ID = 34;
    public const int MOSQUI_ID = 37;
    public const int ASTROMOPHY_ID = 36;
    public const int RED_DRAGON_ID = 39;
    public const int SPIDER_OVERLORD_ID = 51;
    public const int DEVOURING_BLOSSOM_ID = 52;
    public const int ORC_WARLORD_ID = 53;
    public const int GREEN_DRAGON_ID = 1043;

    //Summon
    public const int SUMMON_0_LEXICON_WRAITH = 85;
    public const int SUMMON_1_SWARM_LORD = 86;
    public const int SUMMON_2_GRUMBLE_TROLL = 87;
    public const int SUMMON_3_BLUE_DRAGON = 80;
    public const int SUMMON_4_VIKING = 782;

    //Summon clan mob
    public const int BLUE_DRAGON_ID = 81;
    public const int SWARM_LORD_ID = 82;
    public const int LEXICON_WRAITH_ID = 83;
    public const int GRUMBLETROLL_ID = 84;

    //Undeath
    public const int MONOEVIL_ID = 209;
    public const int SLITHER_ID = 210;
    public const int SPECTRE_ID = 211;
    public const int GRAVELING_ID = 212;

    //Orc village
    public const int ORC_VILLAGE_ID = 135;
    public const int ORC_VILLAGE_LEADER_ID = 136;
    public const int ORC_VILLAGE_KING_ID = 137;

    //Orc Revenge
    public const int OGRE_SHAMAN_ID = 598;
    public const int OGRE_WARRIOR_ID = 599;
    public const int AXE_ORC_ID = 600;
    public const int WOODEN_STICK_ORC_ID = 601;

    //White
    public const int SNOW_COW_ID = 615;
    public const int SNOW_MAMMOTH_ID = 616;
    public const int WHITE_WOLF_ID = 617;
    public const int SNOW_BEAR_ID = 618;


    //vip
    public const int VIP_FACE_HAIR_0 = 1110;
    public const int VIP_FACE_HAIR_1 = 1111;
    public const int VIP_FACE_HAIR_2 = 1339;
    public const int VIP_FACE_HAIR_3 = 1340;
    public const int VIP_FACE_HAIR_4 = 1774;
    public const int VIP_FACE_HAIR_5 = 1775;
    public const int VIP_FACE_HAIR_6 = 2022;
    public const int VIP_FACE_HAIR_7 = 2023;
    public const int VIP_BODY_0 = 1106;
    public const int VIP_BODY_1 = 1107;
    public const int VIP_BODY_2 = 1343;
    public const int VIP_BODY_3 = 1344;
    public const int VIP_BODY_4 = 1770;
    public const int VIP_BODY_5 = 1771;
    public const int VIP_BODY_6 = 2018;
    public const int VIP_BODY_7 = 2019;
    public const int HORSE_VIP_0 = 1102;
    public const int HORSE_VIP_1 = 1103;
    public const int HORSE_VIP_2 = 1347;
    public const int HORSE_VIP_3 = 1348;
    public const int HORSE_VIP_4 = 1766;
    public const int HORSE_VIP_5 = 1767;
    public const int HORSE_VIP_6 = 2016;
    public const int HORSE_VIP_7 = 2017;
    public const int HORSE_VIP_8 = 2175;
    public const int HORSE_VIP_9 = 2176;
    public const int HORSE_VIP_10 = 3661;
    public const int HORSE_VIP_11 = 3662;

    public const int HORSE_THAILAND_0 = 2203;
    public const int HORSE_THAILAND_1 = 2204;



    //Arena
    public const int ARENA_FINAL_PET = 754;

    //Viking
    public const int VIKING_MAIN_BUILDING = 783;
    public const int VIKING_LEADER = 785;
    public const int VIKING_STORAGE_BUILDING = 784;
    public const int VIKING_WARRIOR = 786;
    public const int VIKING_ARCHER_TOWER = 788;
    public const int VIKING_KING = 789;
    public const int VIKING_MAGE = 848;
    public const int VIKING_PRIEST = 849;
    public const int VIKING_KNIGHT = 870;

    public const int VIKING_MAIN_FURY = 893;
    public const int VIKING_LEADER_FURY = 894;
    public const int VIKING_KING_FURY = 895;

    public const int VIKING_MAIN_TITAN = 896;
    public const int VIKING_LEADER_TITAN = 897;
    public const int VIKING_KING_TITAN = 898;

    //Clan wp
    public const int CLAN_BACK_0 = 1488;
    public const int CLAN_BOOT_0 = 1492;
    public const int CLAN_CLOTH_0 = 1496;
    public const int CLAN_HELMET_0 = 1500;

    public const int CLAN_WEAPONS_0 = 1504;

    public static int[] ClanGears = new int[]
    {
        CLAN_BACK_0,
        CLAN_BOOT_0,
        CLAN_CLOTH_0,
        CLAN_HELMET_0,
        CLAN_WEAPONS_0,
    };

    //Vip wp
    public const int VIP_BACK_0 = 1514;
    public const int VIP_BOOT_0 = 1518;
    public const int VIP_CLOTH_0 = 1522;
    public const int VIP_HELMET_0 = 1526;

    public const int VIP_WEAPONS_0 = 1530;

    public static int[] VipGears = new int[]
    {
        VIP_BACK_0,
        VIP_BOOT_0,
        VIP_CLOTH_0,
        VIP_HELMET_0,
        VIP_WEAPONS_0,
    };
    //Fullmoon
    public const int FULLMOON_PET_0 = 803;//old
    public const int FULLMOON_HORSE_0 = 812;//old

    public const int FULLMOON_PET_1 = 1135;
    public const int FULLMOON_PET_2 = 1136;//evo
    public const int FULLMOON_HORSE_1 = 1137;
    public const int FULLMOON_HORSE_2 = 1138;//evo

    public const int FULLMOON_BODY_0 = 1139;
    public const int FULLMOON_BODY_1 = 1140;
    public const int FULLMOON_EYE_0 = 1141;
    public const int FULLMOON_EYE_1 = 1142;
    public const int FULLMOON_FACEHAIR_0 = 1143;
    public const int FULLMOON_FACEHAIR_1 = 1144;
    public const int FULLMOON_HAIR_0 = 1145;
    public const int FULLMOON_HAIR_1 = 1146;
    public const int FULLMOON_HAIR_2 = 1147;
    public const int FULLMOON_HAIR_3 = 1148;

    public const int FULLMOON_BOSS_SCROLL = 815;
    public const int MOONLIT_WARDEN_ID = 804;
    public const int MOONLIT_SHADOWN_ID = 813;
    public const int MOONLIT_TINY = 816;

    public const int FULLMOON_BOOT_0 = 807;
    public const int FULLMOON_BACK_0 = 808;
    public const int FULLMOON_CLOTH_0 = 806;
    public const int FULLMOON_HELMET_0 = 805;

    public const int FULLMOON_WEAPONS_0 = 809;
    public const int FULLMOON_WEAPONS_1 = 810;
    public const int FULLMOON_WEAPONS_2 = 811;

    //Halloween
    public const int HALLOWEEN_PET = 829;
    public const int HALLOWEEN_HORSE = 830;
    public const int HALLOWEEN_PET_2 = 1307;
    public const int HALLOWEEN_PET_3 = 1308;
    public const int HALLOWEEN_HORSE_1 = 1309;
    public const int HALLOWEEN_HORSE_2 = 1310;

    public const int HALLOWEEN_FACE_HAIR_0 = 833; // Evo
    public const int HALLOWEEN_FACE_HAIR_1 = 841;
    public const int HALLOWEEN_FACE_HAIR_2 = 1315;
    public const int HALLOWEEN_FACE_HAIR_3 = 1316; // Evo

    public const int HALLOWEEN_EYE_0 = 834;
    public const int HALLOWEEN_EYE_1 = 842; // EVO
    public const int HALLOWEEN_EYE_2 = 1313;
    public const int HALLOWEEN_EYE_3 = 1314; // EVO

    public const int HALLOWEEN_HAIR_0 = 831; // EVO
    public const int HALLOWEEN_HAIR_1 = 832; // EVO
    public const int HALLOWEEN_HAIR_6 = 1319; // EVO
    public const int HALLOWEEN_HAIR_7 = 1320; // EVO

    public const int HALLOWEEN_HAIR_2 = 839;
    public const int HALLOWEEN_HAIR_3 = 840;
    public const int HALLOWEEN_HAIR_4 = 1317;
    public const int HALLOWEEN_HAIR_5 = 1318;

    public const int HALLOWEEN_BODY_0 = 843;
    public const int HALLOWEEN_BODY_1 = 844;
    public const int HALLOWEEN_BODY_2 = 1311;
    public const int HALLOWEEN_BODY_3 = 1312;

    public const int NIGHTMARE_WARDEN = 838;
    public const int DRACULA = 845;
    public const int HALLOWEEN_BOSS_SCROLL = 846;

    public const int HALLOWEEN_BOOT_0 = 825;
    public const int HALLOWEEN_BACK_0 = 822;
    public const int HALLOWEEN_CLOTH_0 = 823;
    public const int HALLOWEEN_HELMET_0 = 824;

    public const int HALLOWEEN_WEAPONS_0 = 826;
    public const int HALLOWEEN_WEAPONS_1 = 827;
    public const int HALLOWEEN_WEAPONS_2 = 828;

    //Thanksgiving
    public const int THANKSGIVING_PET_ID = 872;
    public const int THANKSGIVING_PET_2 = 1536;
    public const int THANKSGIVING_PET_3 = 1537;
    public const int THANKSGIVING_HORSE_ID = 871;
    public const int THANKSGIVING_HORSE_1 = 1534;
    public const int THANKSGIVING_HORSE_2 = 1535;

    public const int THANKSGIVING_FACE_HAIR_ID_1 = 875;
    public const int THANKSGIVING_FACE_HAIR_ID_0 = 876;
    public const int THANKSGIVING_FACE_HAIR_2 = 1544;
    public const int THANKSGIVING_FACE_HAIR_3 = 1545;
    public const int THANKSGIVING_HAIR_0 = 877;
    public const int THANKSGIVING_HAIR_1 = 878;
    public const int THANKSGIVING_HAIR_2 = 879;
    public const int THANKSGIVING_HAIR_3 = 880;
    public const int THANKSGIVING_HAIR_4 = 1538;
    public const int THANKSGIVING_HAIR_5 = 1539;
    public const int THANKSGIVING_HAIR_6 = 1540;
    public const int THANKSGIVING_HAIR_7 = 1541;

    public const int THANKSGIVING_EYE_0 = 881;
    public const int THANKSGIVING_EYE_1 = 882;
    public const int THANKSGIVING_EYE_2 = 1542;
    public const int THANKSGIVING_EYE_3 = 1543;

    public const int THANKSGIVING_BODY_0 = 890;
    public const int THANKSGIVING_BODY_1 = 891;
    public const int THANKSGIVING_BODY_2 = 1546;
    public const int THANKSGIVING_BODY_3 = 1547;


    public const int HIGHNOON_PHANTOM_ID = 874;
    public const int HIGHNOON_WARDEN_ID = 1548;

    public const int THANKSGIVING_BOSS_SCROLL = 892;
    public const int THANKSGIVING_BOOT_0 = 883;
    public const int THANKSGIVING_BACK_0 = 884;
    public const int THANKSGIVING_CLOTH_0 = 885;
    public const int THANKSGIVING_HELMET_0 = 886;

    public const int THANKSGIVING_WEAPONS_0 = 887;
    public const int THANKSGIVING_WEAPONS_1 = 888;
    public const int THANKSGIVING_WEAPONS_2 = 889;

    //Noel
    public const int NOEL_MERCHANDISE = 906;
    public const int BLIZZARD_WARDEN = 907;
    public const int BLIZZARD_WARRIOR = 1039;

    public const int NOEL_MOB = 908;

    public const int NOEL_PET = 909;
    public const int NOEL_PET_2 = 1720;
    public const int NOEL_PET_3 = 1721;

    public const int NOEL_HORSE = 910;
    public const int NOEL_HORSE_1 = 1718;
    public const int NOEL_HORSE_2 = 1719;

    public const int NOEL_BOOT_0 = 911;
    public const int NOEL_BACK_0 = 912;
    public const int NOEL_CLOTH_0 = 913;
    public const int NOEL_HELMET_0 = 914;

    public const int NOEL_WEAPONS_0 = 915;
    public const int NOEL_WEAPONS_1 = 916;
    public const int NOEL_WEAPONS_2 = 917;

    public const int NOEL_BODY_0 = 918;
    public const int NOEL_BODY_1 = 919;
    public const int NOEL_BODY_2 = 1722;
    public const int NOEL_BODY_3 = 1723;

    public const int NOEL_EYE_0 = 920;
    public const int NOEL_EYE_1 = 921;
    public const int NOEL_EYE_2 = 1724;
    public const int NOEL_EYE_3 = 1725;

    public const int NOEL_FACEHAIR_0 = 922;
    public const int NOEL_FACEHAIR_1 = 923;
    public const int NOEL_FACEHAIR_2 = 1726;
    public const int NOEL_FACEHAIR_3 = 1727;

    public const int NOEL_HAIR_0 = 924;
    public const int NOEL_HAIR_1 = 925;
    public const int NOEL_HAIR_2 = 926;
    public const int NOEL_HAIR_3 = 927;
    public const int NOEL_HAIR_4 = 1728;
    public const int NOEL_HAIR_5 = 1729;
    public const int NOEL_HAIR_6 = 1730;
    public const int NOEL_HAIR_7 = 1731;

    public const int NOEL_BOSS_SCROLL = 1003;

    public static readonly int[] NoelEvents = new int[]
    {
        NOEL_MERCHANDISE,
        BLIZZARD_WARDEN,
        BLIZZARD_WARRIOR,

        NOEL_MOB,

        NOEL_PET,
        NOEL_PET_2,
        NOEL_PET_3,

        NOEL_HORSE,
        NOEL_HORSE_1,
        NOEL_HORSE_2,

        NOEL_BOOT_0,
        NOEL_BACK_0,
        NOEL_CLOTH_0,
        NOEL_HELMET_0,

        NOEL_WEAPONS_0,
        NOEL_WEAPONS_1,
        NOEL_WEAPONS_2,

        NOEL_BODY_0,
        NOEL_BODY_1,
        NOEL_BODY_2,
        NOEL_BODY_3,

        NOEL_EYE_0,
        NOEL_EYE_1,
        NOEL_EYE_2,
        NOEL_EYE_3,

        NOEL_FACEHAIR_0,
        NOEL_FACEHAIR_1,
        NOEL_FACEHAIR_2,
        NOEL_FACEHAIR_3,

        NOEL_HAIR_0,
        NOEL_HAIR_1,
        NOEL_HAIR_2,
        NOEL_HAIR_3,
        NOEL_HAIR_4,
        NOEL_HAIR_5,
        NOEL_HAIR_6,
        NOEL_HAIR_7,

        NOEL_BOSS_SCROLL
    };



    //Newyear
    public const int NEW_YEAR_HORSE = 980;
    public const int NEW_YEAR_HORSE_1 = 1902;
    public const int NEW_YEAR_HORSE_2 = 1903;
    public const int NEW_YEAR_PET_0 = 1011;
    public const int NEW_YEAR_PET_1 = 981;
    public const int NEW_YEAR_PET_2 = 1898;
    public const int NEW_YEAR_PET_3 = 1899;

    public const int NEW_YEAR_BOOT_0 = 982;
    public const int NEW_YEAR_BACK_0 = 983;
    public const int NEW_YEAR_CLOTH_0 = 984;
    public const int NEW_YEAR_HELMET_0 = 985;

    public const int NEW_YEAR_WEAPONS_0 = 986;
    public const int NEW_YEAR_WEAPONS_1 = 987;
    public const int NEW_YEAR_WEAPONS_2 = 988;

    public const int NEW_YEAR_BODY_0 = 989;
    public const int NEW_YEAR_BODY_1 = 990;
    public const int NEW_YEAR_BODY_2 = 1888;
    public const int NEW_YEAR_BODY_3 = 1889;
    public const int NEW_YEAR_EYE_0 = 991;
    public const int NEW_YEAR_EYE_1 = 992;
    public const int NEW_YEAR_EYE_2 = 1890;
    public const int NEW_YEAR_EYE_3 = 1891;

    public const int NEW_YEAR_FACEHAIR_0 = 993;
    public const int NEW_YEAR_FACEHAIR_1 = 994;
    public const int NEW_YEAR_FACEHAIR_2 = 1892;
    public const int NEW_YEAR_FACEHAIR_3 = 1893;
    public const int NEW_YEAR_HAIR_0 = 995;
    public const int NEW_YEAR_HAIR_1 = 996;
    public const int NEW_YEAR_HAIR_2 = 997;
    public const int NEW_YEAR_HAIR_3 = 998;
    public const int NEW_YEAR_HAIR_4 = 1894;
    public const int NEW_YEAR_HAIR_5 = 1895;
    public const int NEW_YEAR_HAIR_6 = 1896;
    public const int NEW_YEAR_HAIR_7 = 1897;

    public const int NEW_YEAR_WARDEN = 1000;
    public const int NEW_YEAR_BLOSSOM = 1001;


    public const int NEW_YEAR_BOSS_SCROLL = 1004;

    //Birthday
    public const int BIRTHDAY_HORSE = 1017;
    public const int BIRTHDAY_HORSE_2 = 2078;
    public const int BIRTHDAY_HORSE_3 = 2079;
    public const int BIRTHDAY_PET_0 = 1018;
    public const int BIRTHDAY_PET_1 = 1040;
    public const int BIRTHDAY_PET_2 = 2080;
    public const int BIRTHDAY_PET_3 = 2081;

    public const int BIRTHDAY_BOOT_0 = 1019;
    public const int BIRTHDAY_BACK_0 = 1020;
    public const int BIRTHDAY_CLOTH_0 = 1021;
    public const int BIRTHDAY_HELMET_0 = 1022;

    public const int BIRTHDAY_WEAPONS_0 = 1023;
    public const int BIRTHDAY_WEAPONS_1 = 1024;
    public const int BIRTHDAY_WEAPONS_2 = 1025;

    public const int BIRTHDAY_BODY_0 = 1026;
    public const int BIRTHDAY_BODY_1 = 1027;
    public const int BIRTHDAY_BODY_2 = 2082;
    public const int BIRTHDAY_BODY_3 = 2083;
    public const int BIRTHDAY_EYE_0 = 1028;
    public const int BIRTHDAY_EYE_1 = 1029;
    public const int BIRTHDAY_EYE_2 = 2084;
    public const int BIRTHDAY_EYE_3 = 2085;

    public const int BIRTHDAY_FACEHAIR_0 = 1030;
    public const int BIRTHDAY_FACEHAIR_1 = 1031;
    public const int BIRTHDAY_FACEHAIR_2 = 2086;
    public const int BIRTHDAY_FACEHAIR_3 = 2087;

    public const int BIRTHDAY_HAIR_0 = 1032;
    public const int BIRTHDAY_HAIR_1 = 1033;
    public const int BIRTHDAY_HAIR_2 = 1034;
    public const int BIRTHDAY_HAIR_3 = 1035;
    public const int BIRTHDAY_HAIR_4 = 2088;
    public const int BIRTHDAY_HAIR_5 = 2089;
    public const int BIRTHDAY_HAIR_6 = 2090;
    public const int BIRTHDAY_HAIR_7 = 2091;

    public const int BIRTHDAY_WARDEN = 1038;
    public const int BIRTHDAY = 1036;

    public const int BIRTHDAY_BOSS_SCROLL = 1042;

    //Easter Festival
    public const int EASTERFESTIVAL_HORSE_0 = 1067;
    public const int EASTERFESTIVAL_HORSE_1 = 1068;

    public const int EASTERFESTIVAL_PET_0 = 1069;
    public const int EASTERFESTIVAL_PET_1 = 1070;
    public const int EASTERFESTIVAL_PET_2 = 1088;
    public const int EASTERFESTIVAL_PET_3 = 1089;

    public const int EASTERFESTIVAL_BOOT_0 = 1071;
    public const int EASTERFESTIVAL_BACK_0 = 1072;
    public const int EASTERFESTIVAL_CLOTH_0 = 1073;
    public const int EASTERFESTIVAL_HELMET_0 = 1074;
    public const int EASTERFESTIVAL_WEAPON_0 = 1075;
    public const int EASTERFESTIVAL_WEAPON_1 = 1076;
    public const int EASTERFESTIVAL_WEAPON_2 = 1077;

    public const int EASTERFESTIVAL_BODY_0 = 1078;
    public const int EASTERFESTIVAL_BODY_1 = 1079;
    public const int EASTERFESTIVAL_EYE_0 = 1080;
    public const int EASTERFESTIVAL_EYE_1 = 1081;
    public const int EASTERFESTIVAL_FACEHAIR_0 = 1082;
    public const int EASTERFESTIVAL_FACEHAIR_1 = 1083;
    public const int EASTERFESTIVAL_HAIR_0 = 1084;
    public const int EASTERFESTIVAL_HAIR_1 = 1085;
    public const int EASTERFESTIVAL_HAIR_2 = 1086;
    public const int EASTERFESTIVAL_HAIR_3 = 1087;

    public const int WOLFIE = 1063;
    public const int WOLFIE_WARDEN = 1064;
    public const int WOLFIE_TINY = 1065;

    public const int EASTERFESTIVAL_BOSS_SCROLL = 1090;


    //Tournament
    public const int TOURNAMENT_MOB_AQUASAUR_ID = 1456;
    public const int TOURNAMENT_MOB_BRACHIOSAURUS_ID = 1457;
    public const int TOURNAMENT_MOB_CROCODYLOSAURUS_ID = 1458;
    public const int TOURNAMENT_MOB_PTEROSAUR_ID = 1459;
    public const int TOURNAMENT_MOB_TYRANNOSAURUS_ID = 1460;
    public const int TOURNAMENT_HORSE_0 = 1409;
    public const int TOURNAMENT_HORSE_1 = 1410;
    public const int TOURNAMENT_HORSE_2 = 1411;
    public const int TOURNAMENT_HORSE_3 = 1412;
    public const int TOURNAMENT_HORSE_4 = 1413;
    public const int TOURNAMENT_HORSE_5 = 1414;
    public const int TOURNAMENT_PET_0 = 1415;
    public const int TOURNAMENT_BACK_0 = 1426;
    public const int TOURNAMENT_BOOT_0 = 1432;
    public const int TOURNAMENT_HELMET_0 = 1448;
    public const int TOURNAMENT_CLOTH_0 = 1436;
    public const int TOURNAMENT_WEAPONS_0 = 1452;
    public const int TOURNAMENT_BODY_0 = 1430;
    public const int TOURNAMENT_EYE_0 = 1440;
    public const int TOURNAMENT_FACEHAIR_0 = 1442;
    public const int TOURNAMENT_HAIR_0 = 1444;

    public const int ADMOB_REWARD_BOX_ID = 733;
    public const int ADMOB_REWARD_BOX_ID_NOCLAN = 735;


    #region Operation
    public const int GIFT_PET_0 = 1182;

    public const string PUBLISHERS_VIETNAM = "VietNam";
    #endregion
    public static bool IsBoxTop3(int boxId)
    {
        return boxId == BOX_PLAYER_TOP1 || boxId == BOX_PLAYER_TOP2 || boxId == BOX_PLAYER_TOP3
            || boxId == BOX_CLAN_TOP1 || boxId == BOX_CLAN_TOP2 || boxId == BOX_CLAN_TOP3 ||
            boxId == BOX_IAP_TOP1 || boxId == BOX_IAP_TOP2 || boxId == BOX_IAP_TOP3 ||
            boxId == BOX_CHEST_CENTER_TOP1 || boxId == BOX_CHEST_CENTER_TOP2 || boxId == BOX_CHEST_CENTER_TOP3 ||
            boxId == BOX_CHEST_UNDEAD_TOP1 || boxId == BOX_CHEST_UNDEAD_TOP2 || boxId == BOX_CHEST_UNDEAD_TOP3;
    }

    private static readonly int[] EventConstants = new int[]
    {
        // Fullmoon
        FULLMOON_PET_0, FULLMOON_HORSE_0, FULLMOON_PET_1, FULLMOON_PET_2, FULLMOON_HORSE_1, FULLMOON_HORSE_2,
        FULLMOON_BODY_0, FULLMOON_BODY_1, FULLMOON_EYE_0, FULLMOON_EYE_1, FULLMOON_FACEHAIR_0, FULLMOON_FACEHAIR_1, FULLMOON_HAIR_0,
        FULLMOON_HAIR_1, FULLMOON_HAIR_2, FULLMOON_HAIR_3, FULLMOON_BOSS_SCROLL, MOONLIT_WARDEN_ID, MOONLIT_SHADOWN_ID, MOONLIT_TINY,
        FULLMOON_BOOT_0, FULLMOON_BACK_0, FULLMOON_CLOTH_0, FULLMOON_HELMET_0, FULLMOON_WEAPONS_0, FULLMOON_WEAPONS_1, FULLMOON_WEAPONS_2,

        // New Year
        NEW_YEAR_HORSE, NEW_YEAR_HORSE_1, NEW_YEAR_HORSE_2, NEW_YEAR_PET_0, NEW_YEAR_PET_1, NEW_YEAR_BOOT_0, NEW_YEAR_BACK_0,
        NEW_YEAR_CLOTH_0, NEW_YEAR_HELMET_0, NEW_YEAR_WEAPONS_0, NEW_YEAR_WEAPONS_1, NEW_YEAR_WEAPONS_2,
        NEW_YEAR_BODY_0, NEW_YEAR_BODY_1, NEW_YEAR_EYE_0, NEW_YEAR_EYE_1, NEW_YEAR_FACEHAIR_0, NEW_YEAR_FACEHAIR_1,
        NEW_YEAR_HAIR_0, NEW_YEAR_HAIR_1, NEW_YEAR_HAIR_2, NEW_YEAR_HAIR_3, NEW_YEAR_WARDEN,
        NEW_YEAR_BLOSSOM, NEW_YEAR_BOSS_SCROLL,NEW_YEAR_HORSE, NEW_YEAR_PET_0, NEW_YEAR_PET_1, NEW_YEAR_BOOT_0, NEW_YEAR_BACK_0,
        NEW_YEAR_BODY_2, NEW_YEAR_BODY_3,
        NEW_YEAR_EYE_2, NEW_YEAR_EYE_3,
        NEW_YEAR_FACEHAIR_2, NEW_YEAR_FACEHAIR_3,
        NEW_YEAR_HAIR_4, NEW_YEAR_HAIR_5, NEW_YEAR_HAIR_6, NEW_YEAR_HAIR_7,
        NEW_YEAR_PET_2, NEW_YEAR_PET_3,

        // Noel
        NOEL_MERCHANDISE, BLIZZARD_WARDEN, BLIZZARD_WARRIOR, NOEL_MOB, NOEL_PET, NOEL_PET_2, NOEL_PET_3,
        NOEL_HORSE, NOEL_HORSE_1, NOEL_HORSE_2,
        NOEL_BOOT_0, NOEL_BACK_0, NOEL_CLOTH_0, NOEL_HELMET_0, NOEL_WEAPONS_0, NOEL_WEAPONS_1, NOEL_WEAPONS_2,
        NOEL_BODY_0, NOEL_BODY_1, NOEL_BODY_2, NOEL_BODY_3,
        NOEL_EYE_0, NOEL_EYE_1, NOEL_EYE_2, NOEL_EYE_3,
        NOEL_FACEHAIR_0, NOEL_FACEHAIR_1, NOEL_FACEHAIR_2, NOEL_FACEHAIR_3,
        NOEL_HAIR_0, NOEL_HAIR_1, NOEL_HAIR_2, NOEL_HAIR_3, NOEL_HAIR_4, NOEL_HAIR_5, NOEL_HAIR_6, NOEL_HAIR_7, NOEL_BOSS_SCROLL,

        // Halloween
        HALLOWEEN_PET, HALLOWEEN_HORSE, HALLOWEEN_FACE_HAIR_0, HALLOWEEN_FACE_HAIR_1,
        HALLOWEEN_EYE_0, HALLOWEEN_EYE_1, HALLOWEEN_HAIR_0, HALLOWEEN_HAIR_1, HALLOWEEN_HAIR_2,
        HALLOWEEN_HAIR_3, HALLOWEEN_BODY_0, HALLOWEEN_BODY_1, NIGHTMARE_WARDEN, DRACULA,
        HALLOWEEN_BOSS_SCROLL, HALLOWEEN_PET_2, HALLOWEEN_PET_3, HALLOWEEN_HORSE_1,
        HALLOWEEN_HORSE_2, HALLOWEEN_FACE_HAIR_2, HALLOWEEN_FACE_HAIR_3, HALLOWEEN_EYE_2,
        HALLOWEEN_EYE_3, HALLOWEEN_HAIR_4, HALLOWEEN_HAIR_5, HALLOWEEN_HAIR_6, HALLOWEEN_HAIR_7,
        HALLOWEEN_BODY_2, HALLOWEEN_BODY_3, HALLOWEEN_BOOT_0, HALLOWEEN_BACK_0, HALLOWEEN_CLOTH_0,
        HALLOWEEN_HELMET_0, HALLOWEEN_WEAPONS_0, HALLOWEEN_WEAPONS_1, HALLOWEEN_WEAPONS_2,

        // Thanksgiving
        THANKSGIVING_PET_ID, THANKSGIVING_HORSE_ID, THANKSGIVING_FACE_HAIR_ID_1, THANKSGIVING_FACE_HAIR_ID_0,
        THANKSGIVING_HAIR_0, THANKSGIVING_HAIR_1,THANKSGIVING_HAIR_2,THANKSGIVING_HAIR_3, THANKSGIVING_EYE_0,THANKSGIVING_EYE_1, THANKSGIVING_BODY_0, THANKSGIVING_BODY_1,
        HIGHNOON_PHANTOM_ID, THANKSGIVING_BOSS_SCROLL, THANKSGIVING_BOOT_0, THANKSGIVING_BACK_0,
        THANKSGIVING_CLOTH_0, THANKSGIVING_HELMET_0, THANKSGIVING_WEAPONS_0, THANKSGIVING_WEAPONS_1,
        THANKSGIVING_WEAPONS_2,THANKSGIVING_PET_2, THANKSGIVING_PET_3, THANKSGIVING_HORSE_1, THANKSGIVING_HORSE_2,
        THANKSGIVING_FACE_HAIR_2, THANKSGIVING_FACE_HAIR_3,THANKSGIVING_HAIR_4 ,THANKSGIVING_HAIR_5 ,THANKSGIVING_HAIR_6,
        THANKSGIVING_HAIR_7,THANKSGIVING_EYE_2, THANKSGIVING_EYE_3,THANKSGIVING_BODY_2, THANKSGIVING_BODY_3,HIGHNOON_WARDEN_ID,

        //Birthday
        BIRTHDAY_HORSE,BIRTHDAY_PET_0,BIRTHDAY_PET_1,BIRTHDAY_BOOT_0,BIRTHDAY_BACK_0,
        BIRTHDAY_CLOTH_0,BIRTHDAY_HELMET_0,BIRTHDAY_WEAPONS_0,BIRTHDAY_WEAPONS_1,BIRTHDAY_WEAPONS_2,BIRTHDAY_BODY_0,
        BIRTHDAY_BODY_1,BIRTHDAY_EYE_0,BIRTHDAY_EYE_1,BIRTHDAY_FACEHAIR_0,BIRTHDAY_FACEHAIR_1,BIRTHDAY_HAIR_0,BIRTHDAY_HAIR_1,
        BIRTHDAY_HAIR_2,BIRTHDAY_HAIR_3,BIRTHDAY_WARDEN,BIRTHDAY,BIRTHDAY_BOSS_SCROLL,
        BIRTHDAY_HORSE_2, BIRTHDAY_HORSE_3, BIRTHDAY_PET_2, BIRTHDAY_PET_3, BIRTHDAY_BODY_2, BIRTHDAY_BODY_3,
        BIRTHDAY_EYE_2, BIRTHDAY_EYE_3, BIRTHDAY_FACEHAIR_2, BIRTHDAY_FACEHAIR_3, BIRTHDAY_HAIR_4,
        BIRTHDAY_HAIR_5, BIRTHDAY_HAIR_6, BIRTHDAY_HAIR_7,

        //EasterFestival
        EASTERFESTIVAL_HORSE_0, EASTERFESTIVAL_HORSE_1, EASTERFESTIVAL_PET_0, EASTERFESTIVAL_PET_1, EASTERFESTIVAL_PET_2, EASTERFESTIVAL_PET_3, EASTERFESTIVAL_BOOT_0,
        EASTERFESTIVAL_BACK_0, EASTERFESTIVAL_CLOTH_0, EASTERFESTIVAL_HELMET_0, EASTERFESTIVAL_WEAPON_0, EASTERFESTIVAL_WEAPON_1, EASTERFESTIVAL_WEAPON_2,
        EASTERFESTIVAL_BODY_0, EASTERFESTIVAL_BODY_1, EASTERFESTIVAL_EYE_0, EASTERFESTIVAL_EYE_1, EASTERFESTIVAL_FACEHAIR_0, EASTERFESTIVAL_FACEHAIR_1,
        EASTERFESTIVAL_HAIR_0, EASTERFESTIVAL_HAIR_1, EASTERFESTIVAL_HAIR_2, EASTERFESTIVAL_HAIR_3, WOLFIE, WOLFIE_WARDEN, WOLFIE_TINY, EASTERFESTIVAL_BOSS_SCROLL,

        //Tournament
        TOURNAMENT_HORSE_0, TOURNAMENT_HORSE_1, TOURNAMENT_HORSE_2, TOURNAMENT_HORSE_3, TOURNAMENT_HORSE_4, TOURNAMENT_HORSE_5,
        TOURNAMENT_PET_0, TOURNAMENT_BACK_0, TOURNAMENT_BOOT_0, TOURNAMENT_CLOTH_0, TOURNAMENT_HELMET_0,
        TOURNAMENT_WEAPONS_0, TOURNAMENT_BODY_0, TOURNAMENT_EYE_0, TOURNAMENT_FACEHAIR_0, TOURNAMENT_HAIR_0,
    };

    public static readonly int[] ThankGivingEvents = new int[]
    {
          THANKSGIVING_BOSS_SCROLL,
          THANKSGIVING_BOOT_0  ,
          THANKSGIVING_BACK_0  ,
          THANKSGIVING_CLOTH_0 ,
          THANKSGIVING_HELMET_0 ,

          THANKSGIVING_WEAPONS_0,
          THANKSGIVING_WEAPONS_1,
          THANKSGIVING_WEAPONS_2,
    };

    private static readonly int[] EventPetConstants = new int[]
    {
        BIRTHDAY_PET_0,BIRTHDAY_PET_1,BIRTHDAY_PET_2,BIRTHDAY_PET_3,EASTERFESTIVAL_PET_0,EASTERFESTIVAL_PET_1,EASTERFESTIVAL_PET_2,
        EASTERFESTIVAL_PET_3,FULLMOON_PET_0,FULLMOON_PET_1,FULLMOON_PET_2,HALLOWEEN_PET,HALLOWEEN_PET_2,
        HALLOWEEN_PET_3,THANKSGIVING_PET_ID,THANKSGIVING_PET_2,THANKSGIVING_PET_3,NOEL_PET,NEW_YEAR_PET_0,NEW_YEAR_PET_1,NOEL_PET_2,NOEL_PET_3,
        NEW_YEAR_PET_2,NEW_YEAR_PET_3,TOURNAMENT_PET_0,
    };
    private static readonly int[] EventHorseConstants = new int[]
    {
        NEW_YEAR_HORSE,NEW_YEAR_HORSE_1, NEW_YEAR_HORSE_2, NOEL_HORSE,HALLOWEEN_HORSE,HALLOWEEN_HORSE_1,HALLOWEEN_HORSE_2,
        THANKSGIVING_HORSE_ID,THANKSGIVING_HORSE_1,THANKSGIVING_HORSE_2,BIRTHDAY_HORSE,BIRTHDAY_HORSE_2,BIRTHDAY_HORSE_3,
        EASTERFESTIVAL_HORSE_0,EASTERFESTIVAL_HORSE_1,FULLMOON_HORSE_0,FULLMOON_HORSE_1,FULLMOON_HORSE_2,NOEL_HORSE_1,NOEL_HORSE_2,
        TOURNAMENT_HORSE_0, TOURNAMENT_HORSE_1, TOURNAMENT_HORSE_2, TOURNAMENT_HORSE_3, TOURNAMENT_HORSE_4, TOURNAMENT_HORSE_5,
    };

    public static bool IsEventItem(int value)
    {
        return EventConstants.Contains(value);
    }

    public static bool IsEventPet(int value)
    {
        return EventPetConstants.Contains(value);
    }

    public static bool IsEventHorse(int value)
    {
        return EventHorseConstants.Contains(value);
    }

    public static bool IsDefaultSkin(int id)
    {
        return id == 10 || id == 0 || id == 88 || id == BODY_DEFAULT_ID;
    }

}
