﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

#if ENABLE_CLIENT
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
#endif

public class AssetManager : MonoBehaviour
{
    
    public static AssetManager instance;
    [SerializeField]
    public MCPDictionary<Sprite> sprites = new MCPDictionary<Sprite>();
    public MCPDictionary<GameObject> prefabs = new MCPDictionary<GameObject>();
    public MCPDictionary<AudioClip> audioClips = new MCPDictionary<AudioClip>();
    public MCPDictionary<PrefabLifeTime> prefabLifeTimes = new MCPDictionary<PrefabLifeTime>();
    // String-only catalog: these do not pull textures/audio into the scene dependency graph.
    public MCPDictionary<string> spriteAddresses = new MCPDictionary<string>();
    public MCPDictionary<string> prefabAddresses = new MCPDictionary<string>();
    public MCPDictionary<string> audioAddresses = new MCPDictionary<string>();
    public MCPDictionary<string> lifetimeAddresses = new MCPDictionary<string>();
    Dictionary<string, Sprite[]> characterSprites = new Dictionary<string, Sprite[]>();

#if ENABLE_CLIENT
    private sealed class LoadedAsset
    {
        public AsyncOperationHandle Handle;
        public int Leases;
        public bool Pinned;
    }

    private readonly Dictionary<string, LoadedAsset> loaded = new Dictionary<string, LoadedAsset>();
    public int LoadedAddressCount => loaded.Count;
#else
    public int LoadedAddressCount => 0;
#endif
    private bool shuttingDown;

    public sealed class SpriteLease : IDisposable
    {
        public Sprite Asset { get; private set; }
        private Action release;
        internal SpriteLease(Sprite asset, Action releaseAction) { Asset = asset; release = releaseAction; }
        public void Dispose() { var action = release; release = null; Asset = null; action?.Invoke(); }
    }

    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
        {
            Destroy(this.gameObject);
            return;
        }

        DontDestroyOnLoad(this.gameObject);
    }
    
    /// <summary>
    /// Hàm load bỏ qua so sánh chuỗi và ép kiểu
    /// </summary>
    public void LoadSprite(string name, Action<Sprite> callback)
    {
        var sprite = GetNamed<Sprite>(name, spriteAddresses, sprites);
        if (sprite != null) callback?.Invoke(sprite);
    }

    public void LoadSpriteWithOutDefault(string name, Action<Sprite> callback)
    {
        LoadSprite(name, callback);
    }

    // Image bindings own leases; replacement/destruction releases the old asset safely.
    public SpriteLease AcquireSprite(string name)
    {
#if ENABLE_CLIENT
        if (!spriteAddresses.TryGetValue(name, out var address))
            return sprites.TryGetValue(name, out var legacy) && legacy != null
                ? new SpriteLease(legacy, null) : null;
        var entry = GetAddress<Sprite>(address);
        var sprite = entry?.Handle.Result as Sprite;
        if (sprite == null) return null;
        entry.Leases++;
        return new SpriteLease(sprite, () => ReleaseLease(address, entry));
#else
        // Server/admin retain the legacy API without loading client-only packages.
        return sprites.TryGetValue(name, out var sprite) && sprite != null
            ? new SpriteLease(sprite, null) : null;
#endif
    }

#if ENABLE_CLIENT
    private LoadedAsset GetAddress<T>(string address) where T : UnityEngine.Object
    {
        if (shuttingDown || string.IsNullOrEmpty(address)) return null;
        if (loaded.TryGetValue(address, out var existing))
        {
            if (existing.Handle.IsValid()) return existing;
            // ResourceManager can shut down before Mirror's disconnect UI callbacks.
            loaded.Remove(address);
            return null;
        }
        // Compatibility API is synchronous. The generated catalog is local-only, never remote.
        // Callers returning Sprite immediately cannot be silently changed to deferred callbacks.
        // The requested type participates in subasset resolution. Loading Object can
        // return a single-sprite texture's Texture2D instead of its Sprite in Fast Mode.
        var handle = Addressables.LoadAssetAsync<T>(address);
        try
        {
            handle.WaitForCompletion();
            if (handle.Status != AsyncOperationStatus.Succeeded || handle.Result == null)
            {
                Addressables.Release(handle);
                return null;
            }
        }
        catch (Exception exception)
        {
            if (handle.IsValid()) Addressables.Release(handle);
            Debug.LogError($"[AssetManager] Failed to load {address}: {exception.Message}");
            return null;
        }
        var entry = new LoadedAsset { Handle = handle };
        loaded.Add(address, entry);
        return entry;
    }
#endif

    private T GetNamed<T>(string name, MCPDictionary<string> addresses, MCPDictionary<T> legacy)
        where T : UnityEngine.Object
    {
#if ENABLE_CLIENT
        if (!addresses.TryGetValue(name, out var address))
            return legacy.TryGetValue(name, out var value) ? value : null;
        var entry = typeof(T) == typeof(PrefabLifeTime)
            ? GetAddress<GameObject>(address) : GetAddress<T>(address);
        if (entry == null) return null;
        // Legacy APIs transfer raw assets, not leases. Keep these until manager teardown so
        // an LRU eviction cannot unload a sprite/audio clip still referenced by a consumer.
        entry.Pinned = true;
        if (typeof(T) == typeof(PrefabLifeTime))
            return (entry.Handle.Result as GameObject)?.GetComponent<PrefabLifeTime>() as T;
        return entry.Handle.Result as T;
#else
        return legacy.TryGetValue(name, out var value) ? value : null;
#endif
    }

#if ENABLE_CLIENT
    private void ReleaseLease(string address, LoadedAsset entry)
    {
        if (!loaded.TryGetValue(address, out var current) || current != entry) return;
        entry.Leases--;
        if (entry.Leases != 0 || entry.Pinned) return;
        loaded.Remove(address);
        if (entry.Handle.IsValid()) Addressables.Release(entry.Handle);
    }
#endif

    private void OnDestroy()
    {
        shuttingDown = true;
#if ENABLE_CLIENT
        foreach (var entry in loaded.Values)
            if (entry.Handle.IsValid()) Addressables.Release(entry.Handle);
        loaded.Clear();
#endif
        characterSprites.Clear();
        if (instance == this) instance = null;
    }

    private void OnApplicationQuit() { shuttingDown = true; }

    public Sprite[] GetCharacterSprites(string path)
    {
        if (path == "")
            return null;

        if (characterSprites.ContainsKey(path))
            return characterSprites[path];
        else
        {
            UnityEngine.Object[] tObj = Resources.LoadAll(path, typeof(Sprite));
            if (tObj != null)
            {
                Sprite[] sprites = new Sprite[tObj.Length];
                for(int i = 0; i < tObj.Length; i++)
                {
                    if (tObj[i] != null)
                        sprites[i] = (Sprite)tObj[i];
                }
                //Debug.Log(path);
                characterSprites.Add(path, sprites);
                return sprites;
            }
        }

        return null;
    }

    public void Load<T>(string name,Action<T> callBack = null)
    {
        StartCoroutine(LoadCoroutine(name, callBack));
    }

    IEnumerator LoadCoroutine<T>(string name, Action<T> callBack = null)
    {
        Type myType = typeof(T);
        UnityEngine.Object result = null;
        if (myType == typeof(Sprite)) result = GetNamed<Sprite>(name, spriteAddresses, sprites);
        else if (myType == typeof(GameObject)) result = GetNamed<GameObject>(name, prefabAddresses, prefabs);
        else if (myType == typeof(AudioClip)) result = GetNamed<AudioClip>(name, audioAddresses, audioClips);
        else if (myType == typeof(PrefabLifeTime)) result = GetNamed<PrefabLifeTime>(name, lifetimeAddresses, prefabLifeTimes);
        if (result != null) callBack?.Invoke((T)(object)result);

        yield return null;
    }
}

[Serializable]
public class MCPDictionary<T> : Dictionary<string,T>, ISerializationCallbackReceiver
{
    [HideInInspector][SerializeField] private List<string> _keys = new List<string>();
    [HideInInspector][SerializeField] private List<T> _values = new List<T>();

    public void OnBeforeSerialize()
    {
        _keys.Clear();
        _values.Clear();

        foreach (var kvp in this)
        {
            _keys.Add(kvp.Key);
            _values.Add(kvp.Value);
        }
    }

    public void OnAfterDeserialize()
    {
        Clear();

        for (var i = 0; i != Math.Min(_keys.Count, _values.Count); i++)
        {
            Add(_keys[i], _values[i]);
        }
    }
}
