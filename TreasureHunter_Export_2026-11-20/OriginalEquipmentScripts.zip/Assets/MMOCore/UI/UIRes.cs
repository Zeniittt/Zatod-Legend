using MCP.DataModels.BaseModels;
using System;
using UnityEngine;
public static class UIRes
{
    private const string Path = "UIResourceDatabase";
    private static UIResourceDatabase db;
    public static UIResourceDatabase DB
    {
        get
        {
            if (db == null)
                db = Resources.Load<UIResourceDatabase>(Path);
#if UNITY_EDITOR
            if (db == null)
                Debug.LogError($"[UIRes] not found {Path}.asset in Resources!");
#endif
            return db;
        }
    }
    public static Tvalue FindUIElement<Tid, Tvalue>(Tid id)
    {
        return DB.FindUIElement<Tid, Tvalue>(id);
    }

    public static Color GetColor(RareType rareType) => DB.rarityColors[(int)rareType];
    public static Color GetColor(int index)
    {
        if (index >= DB.rarityColors.Length)
        {
            index = DB.rarityColors.Length - 1;
        }
        return DB.rarityColors[index];
    }

    public static Color GetHighlightTextColor() => DB.highlightTextColor;
}
