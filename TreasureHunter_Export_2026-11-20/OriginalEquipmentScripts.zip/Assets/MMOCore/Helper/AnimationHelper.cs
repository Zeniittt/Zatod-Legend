﻿using MCP.DataModels.BaseModels;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public partial class AnimationHelper
{
    public const string PetCollectionDefaultState = "Default";
    public static readonly int HashPetDefault = Animator.StringToHash(PetCollectionDefaultState);

    public static int HashRun = Animator.StringToHash("run"); // run default
    public static int HashRun1 = Animator.StringToHash("Run1");
    public static int HashRun2 = Animator.StringToHash("Run2");
    public static int HashRun3 = Animator.StringToHash("Run3");
    public static int HashRun4 = Animator.StringToHash("Run4");

    public static int HashIdle0 = Animator.StringToHash("idle0"); // idle default
    public static int HashIdle = Animator.StringToHash("idle");// idle default

    public static int HashIdle1 = Animator.StringToHash("idle1");
    public static int HashIdle2 = Animator.StringToHash("idle2");
    public static int HashIdle3 = Animator.StringToHash("idle3");


    public static int HashAttack = Animator.StringToHash("attack"); // attack default
    public static int HashAttack1 = Animator.StringToHash("attack1");
    public static int HashAttack2 = Animator.StringToHash("attack2");
    public static int HashAttack3 = Animator.StringToHash("attack3");
    public static int HashAttack4 = Animator.StringToHash("attack4");
    public static int HashAttack5 = Animator.StringToHash("attack5");
    public static int HashAttack6 = Animator.StringToHash("attack6");
    public static int HashAttack7 = Animator.StringToHash("attack7");

    public static int HashDead = Animator.StringToHash("dead");
    public static int HashOpenChest = Animator.StringToHash("openchest");

    private readonly Dictionary<string, int> dictionaryAttack;
    private readonly Dictionary<string, int> dictionaryRun;
    private readonly Dictionary<string, int> dictionaryIdle;

    public AnimationHelper()
    {
        dictionaryAttack = new()
        {
            { "Attack_1", HashAttack1},
            { "Attack_2", HashAttack2},
            { "Attack_3", HashAttack3},
            { "Attack_4", HashAttack4},
            { "Attack_5", HashAttack5},
            { "Attack_6", HashAttack6},
            { "Attack_7", HashAttack7},
        };

        dictionaryRun = new()
        {
            {"Run_1", HashRun1 },
            {"Run_2", HashRun2 },
            {"Run_3", HashRun3 },
            {"Run_4", HashRun4 },
        };

        dictionaryIdle = new()
        {
            {"Idle_1",HashIdle1 },
            {"Idle_2",HashIdle2 },
            {"Idle_3",HashIdle3 },
        };

    }
    public int GetAnimation(PlayerBehavior playerBehavior, CharacterState characterState)
    {
        if (playerBehavior.characterVisual == null)
        {
            if (characterState == CharacterState.Attack)
            {
                return HashAttack;
            }
            else if (characterState == CharacterState.Idle)
            {
                return HashIdle;
            }
            else if (characterState == CharacterState.Run)
            {
                return HashRun;
            }
            else if (characterState == CharacterState.Dead)
            {
                return HashDead;
            }
            else if (characterState == CharacterState.OpenChest)
            {
                return HashOpenChest;
            }
        }



        var equipments = playerBehavior.characterVisual.GetEquipments();
        var horse = GetEquipment(equipments, EquipmentType.Horse);

        if (characterState == CharacterState.Attack)
        {
            return GetAnimationAttack(equipments, horse);
        }
        else if (characterState == CharacterState.Idle)
        {
            return GetAnimationIdle(equipments, horse);
        }
        else if (characterState == CharacterState.Run)
        {
            return GetAnimationRun(equipments, horse);
        }
        else if (characterState == CharacterState.Dead)
        {
            return HashDead;
        }
        else if (characterState == CharacterState.OpenChest)
        {
            return HashOpenChest;
        }

        return -1;
    }

    public int GetAnimation(List<Equipment> equipments, CharacterState characterState)
    {
        var equipmentVisuals = equipments.Select(e => new EquipmentVisual(e)).ToList();
        var horse = GetEquipment(equipmentVisuals, EquipmentType.Horse);

        if (characterState == CharacterState.Attack)
        {
            return GetAnimationAttack(equipmentVisuals, horse);
        }
        else if (characterState == CharacterState.Idle)
        {
            return GetAnimationIdle(equipmentVisuals, horse);
        }
        else if (characterState == CharacterState.Run)
        {
            return GetAnimationRun(equipmentVisuals, horse);
        }
        else if (characterState == CharacterState.Dead)
        {
            return HashDead;
        }
        else if (characterState == CharacterState.OpenChest)
        {
            return HashOpenChest;
        }

        return -1;
    }


    public int GetAnimationPetCollection(PlayerBehavior petOwner, CharacterState petState)
    {
        if (petOwner == null || petOwner.characterVisual == null)
        {
            return HashPetDefault;
        }

        var equipments = petOwner.characterVisual.GetEquipments();
        var pet = GetEquipment(equipments, EquipmentType.Pet);
        if (petState == CharacterState.Idle)
        {
            return GetAnimationPet(equipments, pet, EquipmentType.SkinIdlePet);
        }
        else if (petState == CharacterState.Run)
        {
            return GetAnimationPet(equipments, pet, EquipmentType.SkinRunPet);
        }

        return -1;
    }

    public int GetAnimationPetCollection(List<Equipment> equipments, CharacterState petState)
    {
        if (equipments == null)
        {
            return HashPetDefault;
        }

        var equipmentVisuals = equipments.Select(e => new EquipmentVisual(e)).ToList();

        var pet = GetEquipment(equipmentVisuals, EquipmentType.Pet);
        if (petState == CharacterState.Idle)
        {
            return GetAnimationPet(equipmentVisuals, pet, EquipmentType.SkinIdlePet);
        }
        else if (petState == CharacterState.Run)
        {
            return GetAnimationPet(equipmentVisuals, pet, EquipmentType.SkinRunPet);
        }

        return -1;
    }

    public int GetAnimationPetCollection(
        Animator animator,
        PlayerBehavior petOwner,
        CharacterState petState)
    {
        return ResolvePetCollectionAnimation(animator, GetAnimationPetCollection(petOwner, petState));
    }

    public int GetAnimationPetCollection(
        Animator animator,
        List<Equipment> equipments,
        CharacterState petState)
    {
        return ResolvePetCollectionAnimation(animator, GetAnimationPetCollection(equipments, petState));
    }

    private int ResolvePetCollectionAnimation(Animator animator, int animationHash)
    {
        if (animator == null || animator.runtimeAnimatorController == null)
        {
            return HashPetDefault;
        }

        return animationHash != -1 && animator.HasState(0, animationHash)
            ? animationHash
            : HashPetDefault;
    }

    private int GetAnimationPet(List<EquipmentVisual> equipments, EquipmentVisual pet, EquipmentType equipmentType)
    {
        EquipmentVisual skin = null;

        foreach (var e in equipments)
        {
            if (GetVisualEquipmentType(e) == equipmentType)
            {
                skin = e;
                break;
            }
        }

        if (skin == null || pet == null || UIManager.instance == null)
        {
            return HashPetDefault;
        }

        Card cardSkin = UIManager.instance.GetCard(skin.itemId);
        if (cardSkin == null)
        {
            return HashPetDefault;
        }

        int petId = pet.itemId;

        if (cardSkin.craftOutputIds == null)
        {
            return HashPetDefault;
        }

        foreach (var petIdOutput in cardSkin.craftOutputIds)
        {
            if (petIdOutput == petId)
            {
                return GetAnimPetByCard(cardSkin);
            }
        }

        //Skin không thể sử dụng cho pet hiện tại
        return HashPetDefault;
    }
    private int GetAnimationAttack(List<EquipmentVisual> equipments, EquipmentVisual horse)
    {
        EquipmentVisual skin = null;

        //Get skin
        foreach (var e in equipments)
        {
            if (GetVisualEquipmentType(e) == EquipmentType.SkinAttack)
            {
                skin = e;
                break;
            }
        }

        if (skin == null)
        {
            return HashAttack;
        }

        var card = UIManager.instance.GetCard(skin.itemId);
        if (card == null)
            return HashAttack;

        var horseId = card.craftOutputIds[0];


        if (horse == null)
        {
            if (horseId == GameConst.BODY_DEFAULT_ID)
            {
                //Skin sử dụng cho đi bộ
                return GetAttackByCard(card);
            }
            else
            {
                //Đi bộ nhưng skin hiện tại phải dùng thú cưỡi
                return HashAttack;
            }
        }
        else
        {
            if (horseId == horse.itemId)
            {
                //Skin sử dụng cho thú cưỡi hiện tại
                return GetAttackByCard(card);
            }
            else
            {

                if (card.craftOutputIds.Length > 1)
                {
                    horseId = card.craftOutputIds[1];
                    if (horseId == horse.itemId)
                    {
                        //Skin sử dụng cho thú cưỡi hiện tại
                        return GetAttackByCard(card);
                    }
                    else
                    {
                        return HashAttack;
                    }
                }
                else
                {
                    //Skin không thể sử dụng cho thú cưỡi hiện tại
                    return HashAttack;
                }
            }

        }
    }

    private int GetAttackByCard(Card card)
    {
        var split = card.GetName(0).Split(' ');
        return dictionaryAttack[split[^1]];
    }

    private int GetAnimPetByCard(Card card)
    {
        if (card == null || card.languageItem == null || card.languageItem.Length == 0 || card.languageItem[0] == null)
        {
            return HashPetDefault;
        }

        string cardName = card.GetName(0);
        if (string.IsNullOrWhiteSpace(cardName))
        {
            return HashPetDefault;
        }

        int lastSpace = cardName.LastIndexOf(' ');
        if (lastSpace < 0 || lastSpace == cardName.Length - 1)
        {
            return HashPetDefault;
        }

        string stateName = cardName.Substring(lastSpace + 1);
        return Animator.StringToHash(stateName);
    }

    private int GetAnimationRun(List<EquipmentVisual> equipments, EquipmentVisual horse)
    {
        EquipmentVisual skin = null;

        //Get skin
        foreach (var e in equipments)
        {
            if (GetVisualEquipmentType(e) == EquipmentType.SkinRun)
            {
                skin = e;
                break;
            }
        }

        if (skin == null)
        {
            return HashRun;
        }

        var card = UIManager.instance.GetCard(skin.itemId);
        if (card == null)
            return HashRun;

        var horseId = card.craftOutputIds[0];

        if (horse == null)
        {
            if (horseId == 31)
            {
                //Skin sử dụng cho đi bộ
                return GetRunByCard(card);
            }
            else
            {
                //Đi bộ nhưng skin hiện tại phải dùng thú cưỡi
                return HashRun;
            }
        }
        else
        {
            if (horseId == horse.itemId)
            {
                //Skin sử dụng cho thú cưỡi hiện tại
                return GetRunByCard(card);
            }
            else
            {

                if (card.craftOutputIds.Length > 1)
                {
                    horseId = card.craftOutputIds[1];
                    if (horseId == horse.itemId)
                    {
                        //Skin sử dụng cho thú cưỡi hiện tại
                        return GetRunByCard(card);
                    }
                    else
                    {
                        return HashRun;
                    }
                }
                else
                {

                    //Skin không thể sử dụng cho thú cưỡi hiện tại
                    return HashRun;
                }
            }
        }
    }

    private int GetRunByCard(Card card)
    {
        var split = card.GetName(0).Split(' ');
        return dictionaryRun[split[^1]];
    }

    private int GetAnimationIdle(List<EquipmentVisual> equipments, EquipmentVisual horse)
    {
        EquipmentVisual skin = null;

        //Get skin
        foreach (var e in equipments)
        {
            if (GetVisualEquipmentType(e) == EquipmentType.SkinIdle)
            {
                skin = e;
                break;
            }
        }

        if (skin == null)
        {
            return HashIdle;
        }

        var card = UIManager.instance.GetCard(skin.itemId);
        if (card == null)
            return HashIdle;

        var horseId = card.craftOutputIds[0];

        if (horse == null)
        {
            if (horseId == 31)
            {
                //Skin sử dụng cho đi bộ
                return GetIdleByCard(card);
            }
            else
            {
                //Đi bộ nhưng skin hiện tại phải dùng thú cưỡi
                return HashIdle;
            }
        }
        else
        {
            if (horseId == horse.itemId)
            {
                //Skin sử dụng cho thú cưỡi hiện tại
                return GetIdleByCard(card);
            }
            else
            {
                if (card.craftOutputIds.Length > 1)
                {
                    horseId = card.craftOutputIds[1];
                    if (horseId == horse.itemId)
                    {
                        //Skin sử dụng cho thú cưỡi hiện tại
                        return GetIdleByCard(card);
                    }
                    else
                    {
                        return HashIdle;
                    }
                }
                else
                {
                    //Skin không thể sử dụng cho thú cưỡi hiện tại
                    return HashIdle;
                }
            }
        }
    }

    private int GetIdleByCard(Card card)
    {
        var split = card.GetName(0).Split(' ');
        return dictionaryIdle[split[^1]];
    }

    private EquipmentVisual FindSkinByType(List<EquipmentVisual> equipments, EquipmentType equipmentType)
    {
        foreach (var e in equipments)
        {
            if (GetVisualEquipmentType(e) == equipmentType)
            {
                return e;
            }
        }
        return null;
    }

    private EquipmentType GetVisualEquipmentType(EquipmentVisual visual)
    {
        var card = UIManager.instance.GetCard(visual.itemId);
        if (card == null)
        {
            return EquipmentType.Weapons;
        }

        return card.equipmentType;
    }

    public EquipmentVisual GetEquipment(List<EquipmentVisual> equipmentVisuals, EquipmentType equipmentType)
    {
        foreach (var e in equipmentVisuals)
        {
            if (e.equipmentType == equipmentType)
                return e;
        }

        return null;
    }
}
