using System;
using MCP.DataModel.Utils;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace MCP.DataModels.BaseModels
{
    public enum CraftTier { Tier0 = 0, Tier1 = 1, Tier2 = 2, Tier3 = 3, Tier4 = 4, Tier5 = 5, Tier6 = 6 };

    [System.Serializable]
    public class Card : BaseItem
    {
        public EquipmentType equipmentType = EquipmentType.Hair;
        public RareType rareType = RareType.Common;
        public SeasonEventType seasonEventType = SeasonEventType.None;
        public CombatPlane combatPlane = CombatPlane.Ground;
        public AttackPlaneMask attackPlaneMask = AttackPlaneMask.Ground;
        public bool trapRepairable = false;
        // Ordinary Mob Cards only; legacy data remains non-interacting with Siege.
        public bool canTakeDamageSiege = false;
        public bool canAttackSiege = false;
        public Stat[] stats = new Stat[0];
        public bool canDrop = true;
        public bool canUpgrade = false;
        public bool useForCraft = false;
        public bool craftable = false;
        public bool canEquip = true;
        public bool canSummon = false;
        public bool overrideSummonedMobStats = false;
        public bool canSell = true;
        public bool canPutToWallet = false;
        public RequireData walletRequireData = new();
        public bool canPutToClanStore = false;
        public RequireData clanStoreRequireData = new();
        public bool canPutToMarket = false;
        public RequireData marketRequireData = new();
        public bool isSeasonReset = false;

        public bool useRareColor = true;
        public bool haveVisualEffect = false;
        public int[] craftOutputIds = new int[0];
        public CraftOutputTier[] craftOutputTiers = new CraftOutputTier[0];
        public int[] buildingParts = new int[0];
        public int[] conflictEffect = new int[0];
        public SkillType skillType = SkillType.None;
        public CurrencyData[] upgradeCost = new CurrencyData[0];
        public float upgradeLevelRate = 1;
        public Box box;
        public bool isParticipateReward = false;
        public Box participateBox;

        public bool isServerNotifyOnLastHit = false;
        public bool isBoss = false;
        public bool isClanBoss = false;
        //Chest
        public int keyId = 0;
        public float heightOfMount;

        /// <summary>
        /// Power calculated directly from this card's stats.
        /// These are read-only calculated values; they are intentionally not stored in Card data.
        /// </summary>
        [JsonIgnore]
        public float power => GetPowerFromStats(false);

        [JsonIgnore]
        public float minPower => GetPowerFromStats(true);

        [JsonIgnore]
        public float maxPower => GetPowerFromStats(false, true);

        [JsonIgnore]
        public bool hasPowerRange
        {
            get
            {
                if (stats == null)
                    return false;

                foreach (Stat stat in stats)
                {
                    if (stat != null && (stat.minValue != 0 || stat.maxValue != 0))
                        return true;
                }

                return false;
            }
        }

        private float GetPowerFromStats(bool useMinValue, bool useMaxValue = false)
        {
            if (stats == null)
                return 0;

            float totalPower = 0;
            foreach (Stat stat in stats)
            {
                if (stat == null)
                    continue;

                float value = stat.value;
                bool statHasPowerRange = stat.minValue != 0 || stat.maxValue != 0;
                if (statHasPowerRange)
                {
                    if (useMinValue)
                        value = stat.minValue;
                    else if (useMaxValue)
                        value = stat.maxValue;
                }

                totalPower += DataUtils.GetPowerStat(stat.statType, value);
            }

            return totalPower;
        }

        public CurrencyData[] GetUpgradeCost(int level)
        {
            CurrencyData[] cost = new CurrencyData[0];
            foreach (CurrencyData currencyData in upgradeCost)
            {
                CurrencyData newCurrencyData = new CurrencyData();
                DataUtils.CopyObject(newCurrencyData, currencyData);
                newCurrencyData.value = (int)(newCurrencyData.value * Math.Pow(upgradeLevelRate, level));
                cost = DataUtils.Add(newCurrencyData, cost);
            }
            return cost;
        }


        public CurrencyData[] GetUpgradeCostRange(int currentLevel, int targetLevel)
        {
            if (targetLevel <= currentLevel) return Array.Empty<CurrencyData>();

            CurrencyData[] total = new CurrencyData[0];
            for (int level = currentLevel; level < targetLevel; level++)
            {
                var stepCosts = GetUpgradeCost(level);
                if (stepCosts == null || stepCosts.Length == 0) continue; // card without an upgrade cost table
                total = DataUtils.Add(stepCosts[0], total);
            }
            return total;
        }

        public float GetStat(StatDataType statDataType, EquipmentType equipmentType = EquipmentType.All)
        {
            foreach(Stat stat in stats)
            {
                if(stat.statDataType == statDataType)
                {
                    return stat.GetValue(0, equipmentType);
                }
            }
            return 0;
        }

        public float GetStat(StatType statType, EquipmentType equipmentType = EquipmentType.All)
        {
            foreach (Stat stat in stats)
            {
                if (stat.statType == statType)
                {
                    return stat.GetValue(0, equipmentType);
                }
            }
            return 0;
        }

        public Stat GetStatData(StatType statType)
        {
            foreach (Stat stat in stats)
            {
                if (stat.statType == statType)
                {
                    return stat;
                }
            }
            return null;
        }

        public bool IsCollection()
        {
            return equipmentType == EquipmentType.SkinClan || equipmentType == EquipmentType.SkinTitle
                 || IsCollectionHorse() || IsCollectionPet() || IsFlatCollection();
        }

        public bool IsFlatCollection()
        {
            // collection cộng thẳng chỉ số, không cộng theo %
            return equipmentType == EquipmentType.Avatar || equipmentType == EquipmentType.SkinHorse || equipmentType == EquipmentType.Emote;
        }
        public bool IsCollectionPet()
        {
            return equipmentType == EquipmentType.SkinRunPet || equipmentType == EquipmentType.SkinIdlePet;
        }
        public bool IsCollectionHorse()
        {
            return equipmentType == EquipmentType.SkinAttack || equipmentType == EquipmentType.SkinRun || equipmentType == EquipmentType.SkinIdle
                || equipmentType == EquipmentType.SkinDeath;
        }
        public bool IsElixir()
        {
            return id == GameConst.ELIXIR_1 || id == GameConst.ELIXIR_2 || id == GameConst.ELIXIR_3 ||
                    id == GameConst.ELIXIR_4 || id == GameConst.ELIXIR_5 || id == GameConst.ELIXIR_6;
        }

        public bool IsSkin(bool includeDefault = false)
        {
            if (includeDefault == false)
            {
                if (GameConst.IsDefaultSkin(id))
                {
                    return false;
                }
            }

            return equipmentType == EquipmentType.Hair || equipmentType == EquipmentType.FaceHair ||
                    equipmentType == EquipmentType.Eye || equipmentType == EquipmentType.Body;
        }

        // ✅ PHASE 1: Helper methods for CraftOutputTiers system
        /// <summary>
        /// Check if card has craftOutputTiers data (new system)
        /// </summary>
        public bool HasCraftOutputTiers()
        {
            return craftOutputTiers != null && craftOutputTiers.Length > 0;
        }

        /// <summary>
        /// Get card IDs by tier from craftOutputTiers (new system). Legacy craftOutputIds is not used here.
        /// </summary>
        public int[] GetCardIdsByTier(CraftTier tier)
        {
            // Try new system first
            if (HasCraftOutputTiers())
            {
                foreach (var tierData in craftOutputTiers)
                {
                    if (tierData != null && tierData.tier == tier && tierData.cardIds != null && tierData.cardIds.Length > 0)
                    {
                        return tierData.cardIds;
                    }
                }
            }

            // No configured tier: return empty so the caller keeps the original item.
            return new int[0];
        }

        /// <summary>
        /// Get number of tiers available in craftOutputTiers
        /// </summary>
        public int GetTierCount()
        {
            if (HasCraftOutputTiers())
            {
                return craftOutputTiers.Length;
            }
            return 0;
        }

    }

    [System.Serializable]
    public class CraftOutputTier
    {
        public CraftTier tier = CraftTier.Tier0;
        public int[] cardIds = new int[0];

        public CraftOutputTier()
        {
            tier = CraftTier.Tier0;
            cardIds = new int[0];
        }

        public CraftOutputTier(CraftTier t)
        {
            tier = t;
            cardIds = new int[0];
        }
    }

    [System.Serializable]
    public class Stat
    {
        public StatType statType = StatType.Health;
        public float value = 0;
        public float minValue = 0;
        public float maxValue = 0;
        public StatDataType statDataType = StatDataType.Normal;
        public StatValueType statValueType = StatValueType.Add;
        public Stat()
        {

        }

        public Stat(Stat stat)
        {
            this.value = stat.value;
            this.maxValue = stat.maxValue;
            this.minValue = stat.minValue;
            this.statType = stat.statType;
            this.statDataType = stat.statDataType;
        }

        public string StatName()
        {
            return statType.ToString();
        }

        public float GetValue(int level = 0, EquipmentType equipmentType = EquipmentType.All)
        {
            var maxLevel = 9;
            if (equipmentType == EquipmentType.BuildingPart)
            {
                if (BattleManager.TryGetGameDataConfig(out var gameDataConfig, logWarning: false))
                {
                    maxLevel = gameDataConfig.maxLevelBuilding;
                }
            }
            if (level > maxLevel)
                level = maxLevel;
            if (statType == StatType.CoolDown)
                return value;
            else
                return value * MathF.Pow(1.1f, level);
        }

        public override string ToString()
        {
            return "StatType " + statType.ToString() + " Value: " + value + " DataType " + statDataType.ToString();
        }
    }


    [System.Serializable]
    public class StatValue
    {
        public StatType statType = StatType.Health;
        public float value = 0;
        public StatDataType statDataType = StatDataType.Normal;
        public StatValueType statValueType = StatValueType.Add;

        public StatValue()
        {

        }

        public StatValue(Stat stat)
        {
            this.value = stat.value;
            this.statType = stat.statType;
            this.statValueType = stat.statValueType;
            this.statDataType = stat.statDataType;
        }

        public StatValue(StatValue stat)
        {
            this.value = stat.value;
            this.statType = stat.statType;
            this.statValueType = stat.statValueType;
        }

        public StatValue(StatValue stat, int level, EquipmentType equipmentType = EquipmentType.All)
        {
            this.value = stat.GetValue(level, equipmentType);
            this.statType = stat.statType;
        }

        public string StatName()
        {
            return statType.ToString();
        }

        public float GetValue(int level = 0, EquipmentType equipmentType = EquipmentType.All)
        {
            var maxLevel = 9;
            if (equipmentType == EquipmentType.BuildingPart)
            {
                if (BattleManager.TryGetGameDataConfig(out var gameDataConfig, logWarning: false))
                {
                    maxLevel = gameDataConfig.maxLevelBuilding;
                }
            }
            if (level > maxLevel)
                level = 0;

            if (statType == StatType.CoolDown)
                return value;
            else
                return value * MathF.Pow(1.1f, level);
        }

        public string Log()
        {
            return StatName() + " :" + value;
        }
    }

    [System.Serializable]
    public class StatData
    {
        public List<StatValue> stats = new List<StatValue>();
        private StatValue[] finalStats = new StatValue[0];

        public StatData()
        {
            Initialize();
        }

        
        void Initialize(int level = 0)
        {
            finalStats = new StatValue[0];
            int statCount = 0;
            foreach (StatType statType in Enum.GetValues(typeof(StatType)))
                statCount = Math.Max(statCount, (int)statType + 1);

            for (int i = 0; i < statCount; i++)
            {
                StatValue stat = new StatValue();
                stat.statType = (StatType)i;
                finalStats = DataUtils.Add(stat, finalStats);
            }
        }

        public StatValue[] GetFinalStat()
        {
            return finalStats;
        }

        public StatValue GetStat(StatType statType)
        {
            return finalStats[(int)statType];
        }

        public float ClampFinalStats(StatType statType, float max)
        {
            finalStats[(int)statType].value = UnityEngine.Mathf.Min(finalStats[(int)statType].value, max);
            return finalStats[(int)statType].value;
        }

        public void AddStats(StatValue[] addStats, EquipmentType equipmentType = EquipmentType.All)
        {
            stats.AddRange(addStats);
            UpdateStats(0, equipmentType);
        }

        public void AddEffect(StatData effectData)
        {
            for (int i = 0; i < finalStats.Length; i++)
            {
                for (int j = 0; j < effectData.finalStats.Length; j++)
                {
                    if (effectData.finalStats[j].statValueType == StatValueType.Max)
                    {
                        continue;
                    }

                    if (finalStats[i].statType == effectData.finalStats[j].statType)
                    {
                        if (finalStats[i].statType == StatType.Heal)
                        {
                            finalStats[i].value += effectData.finalStats[j].GetValue();
                        }
                        //DoT stats
                        else if ( finalStats[i].statType == StatType.PoisonDoT ||
                                  finalStats[i].statType == StatType.FreezeDoT ||
                                  finalStats[i].statType == StatType.FireDot)
                        {   
                            finalStats[i].value += effectData.finalStats[j].GetValue();
                        }
                        else if (finalStats[i].statType == StatType.HitSpeed)
                        {
                            /*
                            var effectValue = 1 - effectData.finalStats[j].GetValue() / 100;
                            finalStats[i].value *= effectValue;
                            if (finalStats[i].value <= 0.1)
                            {
                                finalStats[i].value = 0.1f;
                            }*/
                        }
                        else
                        {
                            var effectValue = 1 + effectData.finalStats[j].GetValue() / 100;
                            finalStats[i].value *= effectValue;
                        }
                    }
                        
                }
            }
        }

        public void AddBuff(StatData buffData)
        {
            for (int i = 0; i < finalStats.Length; i++)
            {
                for (int j = 0; j < buffData.finalStats.Length; j++)
                {
                    if (finalStats[i].statType == buffData.finalStats[j].statType)
                    {
                        finalStats[i].value += buffData.finalStats[j].GetValue();
                    }

                }
            }
        }

        public void AddStats(Stat[] addStats, int level = 0, EquipmentType equipmentType = EquipmentType.All)
        {
            foreach(Stat stat in addStats)
            {
                StatValue statValue = new StatValue(stat);
                stats.Add(statValue);
            }
            UpdateStats(level, equipmentType);
        }

        public void ResetStats()
        {
            stats = new List<StatValue>();

            for (int i = 0; i < finalStats.Length; i++)
            {
                finalStats[i].value = 0;
            }
        }


        public void UpdateStats(int level = 0, EquipmentType equipmentType = EquipmentType.All)
        {
            //Update Normal
            for (int i = 0; i < finalStats.Length; i++)
            {
                finalStats[i].value = 0;
                for (int j = 0; j < stats.Count; j++)
                {
                    if (finalStats[i].statType == stats[j].statType && stats[j].statValueType == StatValueType.Add)
                    {
                        finalStats[i].value += stats[j].GetValue(level, equipmentType);
                    }
                }
            }
        }
    }
}


