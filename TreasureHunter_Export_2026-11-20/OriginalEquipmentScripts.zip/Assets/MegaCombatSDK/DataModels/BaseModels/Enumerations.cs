namespace MCP.DataModels.BaseModels
{
    public enum AuthenType { None, Guess, Email, Facebook, Apple, Google, CustomId }
    public enum ApplicationType { None, Android, iOS, WebGL, Windows }

    //Chat
    public enum ChatID
    {
        None = 0,
        TakeItemFromStorage = 1,
        MoveItemToStorage = 2,
        WatchTower = 3,
        Player = 4,
        StartProtect = 5,
        EndProtect = 6,
        System = 7,
        Friend = 8,
        PlayerPosition = 9,
        Local = 10,
        Emote = 11,
        Global = 12,
        PutEggToPetStable = 13,
        CarePetStableEgg = 14,
        TakePetFromPetStable = 15,
        HatchPetStableEgg = 16,
        HatchPetStableEggFailed = 17,

        // Khi thêm 1 enum mới thì nhớ thêm các condition cho loại enum đó
        // để hiển thị text: ChatLink, MemberChatController, ChatPanel, BattleManager(GetChatValue)
    }
    public enum ChatType
    {
        None = 0,
        Emote = 1,
        Text = 2,
    }

    // Item
    public enum RareType { Common = 0, Rare = 1, Epic = 2, Legendary = 3 };
    public enum RewardState { None = 0, Ready = 1, Rewarded = 2, Opening = 3};
    public enum QuestType
    {
        KillMobNumber = 0,
        KillBossNumber = 1,
        OpenChestNumber = 2,
        KillPlayerNumber = 3,
        TrophyNumber = 4,
        CraftNumber = 5,
        HaveItem = 6,
        Text = 7,
        CraftItem = 8,
        JoinClan = 9,
        PlayerStat = 10,
        GoldNumber = 11,
        DiamondNumber = 12,
        ShardNumber = 13,
        CompleteQuest = 14,
        Login = 15,
        ContinuosLogin = 16,
        PVPCount = 17,
        ClanWarCount = 18,
        ArenaCoinNumber = 19,
        SpendTHInShop = 20,
        BuyIAP = 21,
        KillMobSpecific = 22,
        UsedTHInShop = 23,
        MidSeasonTopPlayer = 24,
        MidSeasonTopClan = 25,
        EndSeasonTopPlayer = 26,
        EndSeasonTopClan = 27,
        TotalArenaCount = 28,
        Minning = 29,
        HaveEquipment = 30,
        HaveIngredient = 31,
        CraftedPotion = 32,
        MeetNPC = 33,
        MeetRuntimeArea = 34,
        MiraPurchase = 35,
        MergeIngredient = 36,
        QuestScore = 37,
        StayOnTile = 38,
        UpgradeItem = 39,
        AchievementQuestPoint = 40,
        DailyQuestPoint = 41,
        LoginPoint = 42,
        HaveCurrency = 43,
        MeetRuntimeZone = 44,
        HaveInventory = 45,
        HaveEquipmentOrInventory = 46
    };

    public enum QuestCategory
    {
        Tutorial = 0,
        CyclicQuest = 1,
        DailyQuest = 2,
        Achivement = 3,
        DailyReward = 4,
        ContinuousLogin = 5,
        Beginner = 6,
        All = 7,
        AchievementTeamBattle = 8,
        DailyQuestPoint = 9,
        AchievementQuestPoint = 10,
        ContinuousLoginQuestPoint = 11,
        CyclicQuestPoint = 12,
        ClanDailyQuest = 13,
        ClanDailyQuestPoint = 14
    }

    public enum ItemType
    {
        None = 0,
        Mira = 1,
        IAP = 2,
        THShop = 3,
        Combo = 4,
        Event = 5,
        Anbe = 6,
        Vip = 7,
        ContinuosLogin = 8,
        Arena = 9,
        ClanShop = 10,
        VipStat = 11,
        All = 12,
        Healer = 13,
        TransferServer = 14,
    }

    public enum VipBonusType
    {
        None = 0,
        IngredientRate = 1,
        DiamondRate = 2,
        GoldRate = 3,
        MarketTax = 4,
        FreeEventRoll = 5,
        ListingCost = 6,
        AutoSellIngredient = 7,
        AutoMove = 8,
        IngredientMap = 9,
        EvoRate = 10,
        DailyQuestNumber = 11,
        AchivementNumber = 12,
        CraftCost = 13,
        UpgradeCost = 14,
        LimitReviveClan = 15,
        EventItemMap = 16,
        FreeAnnouncement = 17,
        AutomationTile = 18,
        ShieldAuto = 19,
        AutoAttackMob = 20,
        AutoUseHp = 21,
        AutoUseSkipAd = 22,
        AutomationTile2 = 23,
        AutomationTile3 = 24,
        AutomationTile4 = 25,
        AutomationTile5 = 26,
        AutomationTile6 = 27,
        AutomationTile7 = 28,
        AutomationTile8 = 29,
        AutomationTile9 = 30,
        AutomationTile10 = 31,
        AutomationTile11 = 32,
        AutomationTile12 = 33,
        AutomationTile13 = 34,
        AutomationTile14 = 35,
        AutomationTile15 = 36,
        AutomationTile16 = 37,
        AutomationTile17 = 38,
        AutomationTile18 = 39,
        AutomationTile19 = 40,
        AutomationTile20 = 41,
        AutomationTile21 = 42,
        AutomationTileMidSeasonReward = 43,
        AutoReturnToSafeZone = 44,
        AutoMerge = 45,
        SendGiftToFriend = 46,
        BonusV3TransferTicket = 47,
        EquipmentSet3 = 48,
        ExpandCamera = 49,
        EquipmentSet = 50,
        AutomationTile31 = 51,
        AutomationTile32 = 52,
        AutomationTile33 = 53,
        AutomationTile34 = 54,
        FilterMarket = 55,
    }

    public enum ItemClass
    {
        BaseItem = -1,
        Card = 0,
        Item = 1,
        Emote = 2,
        Recipe = 3,
        Currency = 4,
        Bundle = 5,
        Box = 6,
        CharacterTitle = 7,
        ClanTitle = 8,
        VipBonusStat = 9,
        ServerInfo = 10,
        LeaderboardConfig = 11
    }
    public enum MemberRole { Leader, Coleader, Member }
    public enum PlayerRole { Admin, Operator, Player };
    public enum GamePlayState { Lock, InProgress, Completed }
    public enum DifficultMode { Easy, Hard, Heroic }
    public enum OrderType { Sell, Buy }
    public enum RandomType { Option, CheckBox };
    public enum QuestResetSchedule { None, Hourly, Daily, Weekly, Monthly, Season }
    public enum BoxSourceType
    {
        None = 0,
        IAP = 1,
        THShop = 2,
        Combo = 3,
        Quest = 4,
        Mob = 5,
        ActivationCode = 6,
        Mira = 7,
        Event = 8,
        DailyReward = 9,
        UndeathTRex = 10,
        ShardShop = 11,
        Boss = 12,
        System = 13,
        Captcha = 14,
        ShopArena = 15,
        HitMap = 16,
        Beginner = 17,
        QuestKai = 18,
        Healer = 19,
        Tutorial = 20,
        PK = 21,
        ClanShop = 22,
        ClanDailyQuest = 23,
        Market = 24,
        Admin = 25,
        Leaderboard = 26,
        FactionWar = 27,
        Survival = 28,
        IAPGift = 29,
        WatchAd = 30,
        AutoSell = 31,
        AutomationShop = 32,
    }
    public enum LeaderboardType
    {
        None,
        Clan,
        Player,
    }
    public enum GameValueType
    {
        Add, Subtract, Set
    }
    public enum CurrencyID
    {
        RealMoney = 0,
        Gold = 1,
        Diamond = 2,
        Shard = 3,
        THCoin = 4,
        ArenaCoin = 5,
        AchievementQuestPoint = 6,
        DailyQuestPoint = 7,
        ClanTrophy = 8,
        PlayerTrophy = 9,
        ClanScore = 10,
        PlayerClanScore = 11,
        VipScore = 12,
        QuestScore = 13,
        CraftScore = 14,
        ClanDiamond = 15,
        SkipAd = 16,
        LoginPoint = 17,
        IAPValue = 18,
        ReviveClan = 19,
        TeamBattlePoint = 20,
        TeamBattleKillPoint = 21,
        Announcement = 22,
        CyclicQuestPoint = 23,
        Progress = 24,
        QuestNumber = 25,
        MobFirecraftPoint = 26,
        ClanCoin = 27,
        AutomationTile = 28,
        ClanDailyQuestPoint = 29,
        FreeEventRoll = 30,
        CenterLandChestNumber = 31,
        UndeadLandChestNumber = 32,
        TeamBattleScore = 33,
        RexFang = 34,
        SkinExchange = 35,
        LegendFang = 36,
        MythicFang = 37,
        BonusV3TransferTicket = 38,
        TransferTicket = 39,
        NumberRollSkinCosmeticToday = 40,
        TrexPoint = 41,
        MerchandisePoint = 42,
        ClanTrexPoint = 43,
        UndeadPoint = 44,
        BearHuntPoint = 45,
        OrcPoint = 46,
        BossEventPoint = 47,
        SurvivalPoint = 48,
        PvpClanPoint = 49,
        PvpPlayerPoint = 50,
        VikingPoint = 51,
        IngredientPoint = 52,
        WerewolfPoint = 53,
        PlayerArena = 54,
        ClanArena = 55,
        ClanRaidPoint = 56,
    }
    //WARNING !!! Add new stat need to change total number in Card class 
    public enum StatType
    {
        Health = 0,
        Damage = 1,
        Speed = 2,
        HitSpeed = 3,
        Defense = 4,
        Critical = 5,
        InventorySlot = 6,
        CraftChance = 7,
        SuccessChance = 8,
        IngredientSlot = 9,
        ClanSlot = 10,
        Heal = 11,
        Range = 12,
        Duration = 13,
        CriticalBonus = 14,
        Dodge = 15,
        Accuracy = 16,
        Luck = 17,
        LifeSteal = 18,
        Counterattack = 19,
        CoolDown = 20,
        NumberTarget = 21,
        Radius = 22,
        GoldRate = 23,
        DiamondRate = 24,
        IngredientRate = 25,
        PoisonStat = 26,
        PoisonDoT = 27,
        Multitarget = 28,
        FreezeStat = 29,
        FreezeDoT = 30,
        FireStat = 31,
        FireDot = 32,
        HealLongTime = 33,
        Wind = 34,
        Summon = 35,
        Invincible = 36,
        Fury = 37,
        CraftMastery = 38,
        FightingSpirit = 39,
    }

    public enum HistoryLogActionType
    {
        None = 0,
        Add,
        Lost,
    }

    public enum SkillType
    {
        None = 0,
        Buff = 1,
        TeleportRamdom = 2,
        TeleportHome = 3,
        BuffAOE = 4,
        Spawner = 5,
        AttackRandom = 6,
        AttackAOE = 7,
        Invisible = 8,
        Immortal = 9,
        DebuffAOE = 10,
        Heath = 11,
        HeathAOE = 12
    }

    //public enum NFTState { None, Active, Deactive, Staked, Withdrawed }
    public enum NpcType
    {
        Shop, Governor, Assasin, Trader, Clan, Artifact, Guard,
        Merge, ChangeName, Colosseum, ArenaShop, ClanWar, Event, RoyalGuard, Teleport,
        UndeadTeleport, Jail, Craft, Healer, FactionWar, FactionWarUnregister, SurvivalWar, Tournament, CosmeticShop
    }
    public enum MapItemState { None, Opening, Opened }
    public enum MapItemType { Chest, Gate, Key }
    public enum ChestType { None, DiamondChest, UndeadChest }
    public enum MapZoneType
    {
        None, Village, SafeZone, FireCraft, Undead, White, Arena, RegisterZone,
        Viking, BeginnerZone, ArenaFreeForAll, Jail, Grass
    }
    public enum LandType { CenterLand = 0, BeginnerLand = 1, UndeadLand = 2, Dynamic = 3, WarLand = 4, SurvivalLand = 5, ShipLand = 6 }
    public enum LoginType { Login, Register, QuickLogin, ForgetPass, VerifyForgetPass, Phone }
    public enum AuthenticateMethod { Megacombat, QuickLogin, Google, Phone, Facebook, Apple }
    public enum BannedReason { None, Auto, Refund, Mod, HackSpeed, Hack, Captcha , Admin}
    public enum AccountInfoState { None, AddEmail, RemoveEmail, ForgetPass, AddPhone, RemovePhone, PhoneLogin };

    public enum CaptchaType { None, Rotate, Drag, Maze };

    public enum AutomationState { None, AutoFarm, AutoFarmWithShield, AutoMove };
    
    public enum AutoType
    {
        // ========== GROUP 1: AUTO FARM ==========
        
        // Binary toggles
        AutoFarm,         // Bật/tắt auto farm
        AutoAttackMonster,       // Tự động đánh quái
        AutoUseHp,               // Tự động dùng HP potion
        AutoShield,              // Tự động bật shield
        AutoWatchAd,             // Tự động xem ad (skip ad item)
        AutoShieldActivated,     // shield da bat

        // Range values
        FarmRadius,              // Bán kính farm (5.0 - 50.0)
        UsePotionAtHP,           // Ngưỡng HP dùng potion (0.0 - 1.0 percentage)
        
        // Position values (farm target)
        TargetFarmX,             // Vị trí X để farm
        TargetFarmY,             // Vị trí Y để farm
        
        // Special values
        TargetIngredient,        // cardId của ingredient để farm (-1 = farm tại TargetFarm position)
        
        // ========== GROUP 2: AUTO MOVE ==========
        
        AutoMove,         // Bật/tắt auto move (requires VipBonusType.AutoMove)
        TargetMoveX,             // Vị trí X để move tới
        TargetMoveY,             // Vị trí Y để move tới
        
        // ========== GROUP 3: AUTO SELL ==========
        
        // Sell - Equipment (theo EquipmentType thực tế)
        AutoSellHelmet,          // EquipmentType.Helmet
        AutoSellCloth,           // EquipmentType.Cloth
        AutoSellBoot,            // EquipmentType.Boot
        AutoSellBack,            // EquipmentType.Back
        AutoSellWeapons,         // EquipmentType.Weapons
        AutoSellArtifact,        // EquipmentType.Artifact
        
        // Sell - Other types
        AutoSellHorse,           // EquipmentType.Horse
        AutoSellPet,             // EquipmentType.Pet
        AutoSellBuffItem,        // EquipmentType.BuffItem (potion)
        AutoSellEventItem,       // EquipmentType.EventItem
        AutoSellScroll,          // EquipmentType.Scroll
        
        // Sell - Ingredients (rarity filter trong AutoSettingElement.rareType)
        AutoSellIngredient,      // itemId = cardId hoặc -1 (all), rareType = Common/Rare/Epic/Legendary
        
        // Sell - Event Equipment (base gear có SeasonEventType != None)
        AutoSellEventHelmet,     
        AutoSellEventCloth,      
        AutoSellEventBoot,       
        AutoSellEventBack,      
        AutoSellEventWeapons,

        // ========== GROUP 4: AUTO MERGE ==========

        AutoMergeIngredient,     // Tự động merge ingredient (rareType filter)
        MergeByRarity,           // Merge đá theo rareType = Common/Rare/Epic
        GoldPreferMergeLevel,    // Level tối thiểu của đá bán được vàng để merge (1-10, filter by rareType)
        DiamondPreferMergeLevel,    // Level tối thiểu của đá bán được kim cương để merge (1-10, filter by rareType)
        MixEventItem,           // Cho phép merge đá và nguyên liệu sự kiện với nhau
        MixIngredient,           // Cho phép merge các loại đá khác nhau
        MixRarity,               // Cho phép merge các phẩm chất đá khác nhau lại với nhau

        // ========== ADDITIONAL FEATURES ==========

        BackToMainVillage,       // Tự động quay về làng chính (0,0) khi hết tile (requires VipBonusType.AutoReturnToSafeZone)
        AutoMergeAllowedIngredient, // Cho phép auto merge cardId + rareType cụ thể (value 0/1)
        AutoMergeAllowedIngredientLevel, // Level yêu cầu cho cardId + rareType cụ thể
        AutoMergeAllowedEventItem, // Cho phép auto merge EquipmentType.EventItem theo rareType (itemId = 0)
        AutoMergeAllowedEventItemLevel, // Level yêu cầu cho EquipmentType.EventItem theo rareType (itemId = 0)
    }
    
    public enum DropType
    {
        None = 0,
        Skin = 1,
        Equipment = 2,
        Item = 3,
        Mob = 4,
        Scroll = 5,
        Ingredient = 6,
        Pet = 7,
        Horse = 8,
        Summon = 9,
        BuffItem = 10,
        Collection = 11,
        EventItem = 12,
    }

    public enum EquipmentState
    {
        New,
        Inventory,
        Character,
        Ingredient,
        Trading,
        Lock,
        Collection,
        Title
    }

    public enum EquipmentType
    {
        Hair = 0,
        FaceHair = 1,
        Helmet = 2,
        Cloth = 3,
        Boot = 4,
        Back = 5,
        Weapons = 6,
        Body = 7,
        Eye = 8,
        Horse = 9,
        Item = 10,
        Pet = 11,
        Mob = 12,
        Key = 13,
        Artifact = 14,
        Ingredient = 15,
        Scroll = 16,
        Npc = 17,
        Summon = 18,
        ArtifactShard = 19,
        BuildingPart = 20,
        Building = 21,
        BuffItem = 22,
        SkinAttack = 23,
        SkinRun = 24,
        SkinIdle = 25,
        SkinDeath = 26,
        SkinClan = 27,
        SkinTitle = 28,
        EventItem = 29,
        Chest = 30,
        All = 31,
        Avatar = 32,
        SkinRunPet = 33,
        SkinIdlePet = 34,
        SkinHorse = 35,
        Emote = 36,
        Egg = 37,
        Blueprint = 38,
        Trap = 39,
    }

    public enum MessageStatus
    {
        New,
        Read,
        Deleted
    }

    public enum MobLimited { None, RedDragon, BossSafeZone }
    public enum CharacterType { Player = 0, Bot = 1, Mob = 2, Npc = 3, Building = 4, Trap = 5 }
    public enum CombatPlane
    {
        Ground = 0,
        Air = 1
    }

    [System.Flags]
    public enum AttackPlaneMask
    {
        None = 0,
        Ground = 1 << 0,
        Air = 1 << 1
    }
    public enum CharacterRole { Player, RoyalGuard, Reporter, Mod, Admin }
    public enum GamePlayMemberType { Player = 0, Bot = 1 }
    public enum GamePlayCompleteType { WinNumber, ScoreNumber, TrophyNumber, Level }
    public enum CombatZoneType { Safe, PVE, PVPWithProtection, PVP, PVPArena }

    public enum TutorialStep
    {
        None,
        Move,
        Minning,
        UseEquipment,
        Upgrade,
        AttackMob,
        Fullgear,
        Finish
    }

    public enum StatDataType { Normal, Multipler }
    public enum StatValueType { Add, Max }
    public enum MessageType
    {
        Mail = 0,
        PushNotification = 1,
        FriendRequest = 2,
        News = 3
    }
    public enum NotificationSendType { Onetime, Repeate }
    public enum NotificationScheduleType { Daily = 1, Weekly = 8 }
    public enum TransactionState { Created, Pending, Error, Completed, Cancelled }
    public enum DialogType { Tip, Dialog, Tutorial, Notification, Loading, Help, Mission, All }
    public enum GameLogType { Error, Success, Debug, Info, UserTracking, GameInit, GameEvent, Suspect, Admin, Warning }
    public enum ServerType {All, Normal, Tournament, Beginner, FinalWar}
    public enum ServerLocation {Global, Asia, Us, Eu}

    public enum LogAction
    {
        // ========== EXISTING ACTIONS (Keep for compatibility) ==========
        BuyMira, BuyAnbe, BuyIap, BuyArena, CreateOrder, UpdateOrder, CompleteOrder,
        SellEquipmentDiamond, LostEquipment, MoveToWallet, TakeFromWallet, CraftSuccess, Merge, MergeEvent,
        ExchangeShard, ChangeName, CompleteLevel, CompleteQuest, NewQuest,
        RollFree, RollTH, ReciveEquipment, ReciveCurrency, ReciveVipStat, Trophy, ClanTrophy, BuyShopTH,
        InputCode, CraftFail, NumberIngredientSuccess, NumberIngredientFail, ReciveEndSeasonReward,
        
        // ========== NEW ACTIONS (18 additions for critical events) ==========
        // 1. Server & Events
        ServerStarted, ServerStopped, EventStarted, EventEnded,
        
        // 6. Player Death
        PlayerKilled, ItemDropOnDeath, GoldLostOnDeath, TrophyLostOnDeath, ItemLootFromKill,
        
        // 7. Building Death
        BuildingDestroyed, BuildingItemDropped, BuildingRoyaltyDropped, BuildingRevive,
        
        // 8. Use Skin
        UseSkin,
        SwitchSkinSet,
        
        // 9. Clan Storage
        ClanStorageDeposit, ClanStorageWithdraw,
        
        // 10 & 12. Sell & Security
        SellCraftedItem, SuspiciousActivity, AutoToolDetected, CaptchaFailed, HackAttempt,
        
        // Auto Features Purchase
        BuyAutoFeature,
        
        // Player Movement & Exploration
        ChangeLand, FindChest, FindKey, OpenChest,
        
        // Combat
        SpawnBoss,

        KillBoss,
        
        // Events
        RollEvent,
        
        // Session
        PlayerLogin, PlayerLogout,
        
        // Misc
        WatchAd,
        
        // Quest
        AbandonQuest, QuestReward,
        
        // Clan Actions
        ClanCreate, ClanJoin, ClanLeave, ClanAbandonVillage, ClanDestroyBuilding,
        ClanProtectStart, ClanProtectEnd, ClanCaptureVillage, ClanMerchandise, ClanVillageLost,
        ClanDiamond, ClanScore, ClanRoyalty, ClanChat, ClanQuestPoint, ClanDataUpdated, ClanStorageLost,
        ClanMemberKicked, ClanMemberPromoted, ClanMemberDemoted, ClanStoragePermission, ClanBuildingRevive,
        CreateBuilding, UpgradeBuilding,
        
        // Authentication & Account
        Register, LoginSuccess, LoginFailed, ChangePassword, LinkAccount,
        ForgotPasswordOTP, VerifyOTP, DeleteAccount, IPLimited,
        
        // Security & Anti-Cheat (expanded)
        ModDetected, IAPFraud, AdFraud, SpeedHack,
        
        // Moderation & Jail
        BanAccount, JailPlayer, PayToEscapeJail,
        
        // Captcha
        CaptchaTriggered, CaptchaSuccess,
        // CaptchaFailed - already exists above in line 267
        
        // Wallet
        WalletTokenChange,
        
        // PIN Management
        CreatePin, UpdatePin, RemovePin,
        
        // Email & Phone Management
        AddEmail, VerifyAddEmail, AddPhone, VerifyAddPhone, RemovePhone, VerifyRemovePhone,
        
        // Item Operations
        SellShard, MergeIngredient,
        
        // Teleport
        Teleport,
        
        // IAP Extended
        BuyIAPByEmail,
        
        // ========== AUTOMATION ACTIONS ==========
        
        // Automation Settings (user changes)
        SetAutoSetting,          // User thay đổi 1 automation setting
        SetTargetFarm,           // User chọn vị trí farm
        SetTargetMove,           // User chọn vị trí auto-move
        BatchSetAutoSetting,     // User enable/disable nhiều settings cùng lúc

        // Admin operations
        AdminGrantBox,
        AdminGrantCurrency,
        AdminGrantItem,
        AdminGrantTH,
        AdminTransferAccount,
        AdminAdjustPlayerStat,
        AdminAdjustWallet,

        //Save Game
        SaveSuccess,
        SaveError,

        //Send Gift to Friend
        SendGiftComplete,

        //Clan Recruitment
        EditClanRecruitment,

        SaveEquipmentSet,
        SwitchEquipmentSet,

        CosmeticSkinExchangeNotFound,
        StaleCosmeticSkinRoll,
    }
    //Battle

    public enum PlayMode { Solo = 0, Group = 1, Corrupted = 2, PVP = 3 }
    public enum BattleState { Prepared, Ready, Playing, Ended, Validated, Invalided }
    public enum RankFilterType { None = 0, Global = 1, Local = 2 }
    public enum BoardType { Player = 0, Friend = 1, Clan = 2, ClanWar = 3 }
    public enum NotificationEventType { None = 0, OnUpdatePlayerFriends = 1, OnUpdatePlayerMessage = 2 }
    public enum MCPEventDetail { Price, Level, Currency, ItemId, GameplayConfig, RewardType, RewardId, Quantity }
    public enum AccountBannedStatus { PendingBanAction = 1, Banned = 2, PendingUnbanAction = 3, Unbanned = 4 }

    public enum MCPEventType
    {
        FirstOpen,

        ///<summary>
        ///Activation.OpenActivationWindow
        ///</summary>
        OpenActivationWindow,
        ///<summary>
        ///Activation.ActivateFailed
        ///</summary>
        ActivateFailed,
        ///<summary>
        ///Activation.ActivateSuccessful
        ///</summary>
        ActivateSuccessful,
        ///<summary>
        ///Activation.DiscardActivationWindow
        ///</summary>
        DiscardActivationWindow,
        ///<summary>
        ///Activation.OpenExternalLink
        ///</summary>
        OpenExternalLink,
        ///<summary>
        ///Admob.VideoAdLoaded
        ///</summary>
        VideoAdLoaded,
        ///<summary>
        ///Admob.VideoAdStarted
        ///</summary>
        VideoAdStarted,
        ///<summary>
        ///Admob.VideoAdOpened
        ///</summary>
        VideoAdOpened,
        ///<summary>
        ///Admob.VideoAdClosed
        ///</summary>
        VideoAdClosed,
        ///<summary>
        ///Admob.VideoAdRewarded
        ///</summary>
        VideoAdRewarded,
        ///<summary>
        ///Admob.VideoAdFailtoLoaded
        ///</summary>
        VideoAdFailtoLoaded,
        ///<summary>
        ///Admob.InterstitialAdLoaded
        ///</summary>
        InterstitialAdLoaded,
        ///<summary>
        ///Admob.InterstitialAdShow
        ///</summary>
        InterstitialAdShow,
        ///<summary>
        ///Admob.InterstitialAdOpened
        ///</summary>
        InterstitialAdOpened,
        ///<summary>
        ///Admob.InterstitialAdClosed
        ///</summary>
        InterstitialAdClosed,
        ///<summary>
        ///Admob.InterstitialAdFailtoLoaded
        ///</summary>
        InterstitialAdFailtoLoaded,
        ///<summary>
        ///Admob.BannerAdLoaded
        ///</summary>
        BannerAdLoaded,
        ///<summary>
        ///Admob.BannerAdShow
        ///</summary>
        BannerAdShow,
        ///<summary>
        ///Admob.BannerAdClosed
        ///</summary>
        BannerAdClosed,
        ///<summary>
        ///Admob.BannerAdOpened
        ///</summary>
        BannerAdOpened,
        ///<summary>
        ///UserAction.OpenApplication
        ///</summary>
        OpenApplication,
        ///<summary>
        ///UserAction.QuitApplication
        ///</summary>
        QuitApplication,
        ///<summary>
        ///UserAction.OpenCreateUserProfile
        ///</summary>
        OpenCreateUserProfile,
        ///<summary>
        ///UserAction.CancelCreateUserProfile
        ///</summary>
        CancelCreateUserProfile,
        ///<summary>
        ///UserAction.CreateUserProfileFailed
        ///</summary>
        CreateUserProfileFailed,
        ///<summary>
        ///UserAction.CreateUserProfileSuccesful
        ///</summary>
        CreateUserProfileSuccesful,
        ///<summary>
        ///UserAction.UpdateUserData
        ///</summary>
        UpdateUserData,
        ///<summary>
        ///UserAction.OpenLogin
        ///</summary>
        OpenLogin,
        ///<summary>
        ///UserAction.LoginFailed
        ///</summary>
        LoginFailed,
        ///<summary>
        ///UserAction.LoginSuccessful
        ///</summary>
        LoginSuccessful,
        ///<summary>
        ///UserAction.AddCharacter
        ///</summary>
        AddCharacter,
        ///<summary>
        ///UserAction.EquipItem
        ///</summary>
        EquipItem,
        ///<summary>
        ///UserAction.UseItem
        ///</summary>
        UseItem,
        ///<summary>
        ///UserAction.OpenScreen
        ///</summary>
        OpenScreen,
        ///<summary>
        ///UserAction.ClickObject
        ///</summary>
        ClickObject,
        ///<summary>
        ///Store.OpenStore
        ///</summary>
        OpenStore,
        ///<summary>
        ///Store.OpenStoreCategory
        ///</summary>
        OpenStoreCategory,
        ///<summary>
        ///Store.SearchItem
        ///</summary>
        SearchItem,
        ///<summary>
        ///Store.OpenItem
        ///</summary>
        OpenItem,
        ///<summary>
        ///Store.CheckOutItem
        ///</summary>
        CheckOutItem,
        ///<summary>
        ///Store.ConfirmPaymentItem
        ///</summary>
        ConfirmPaymentItem,
        ///<summary>
        ///Store.CancelPaymentItem
        ///</summary>
        CancelPaymentItem,
        ///<summary>
        ///InAppPurchase.OpenIAPWindow
        ///</summary>
        OpenIAPWindow,
        ///<summary>
        ///InAppPurchase.CloseIAPWindow
        ///</summary>
        CloseIAPWindow,
        ///<summary>
        ///InAppPurchase.CheckoutIAPWindow
        ///</summary>
        CheckoutIAPWindow,
        Quest,
        ApplicationSignatureFailed,
        ApplicationSignatureSuccess,
        LevelUp,
        StartBattle,
        WinBattle,
        LoseBattle,
        DrawBattle,
        BuyItem,
        GetReward,
        UpgradeItem,
        VideoAdRequest,
        InterstitialAdRequest,
        FirstIAPAction,
        ConfirmPaymentItemCancelled,
    }
}

